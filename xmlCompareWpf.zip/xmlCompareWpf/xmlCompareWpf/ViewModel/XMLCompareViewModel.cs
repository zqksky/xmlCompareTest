﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using xmlCompareWpf.Command;
using xmlCompareWpf.Model;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Xml.Linq;
using xmlCompareWpf.BaseFun;

namespace xmlCompareWpf.ViewModel
{
    class XMLCompareViewModel
    {
        public XMLCompareModel myCompare { get; set; }
        public DelegateCommand OpenFolderCommand1 { get; set; }
        public DelegateCommand OpenFolderCommand2 { get; set; }
        public DelegateCommand CompareFolderCommand { get; set; }
        public DelegateCommand ExitCommand { get; set; }

        public XMLCompareViewModel()
        {
            myCompare = new XMLCompareModel();

            OpenFolderCommand1=new DelegateCommand();
            OpenFolderCommand1.ExecuteCommand = new Action<object>(SetFolderPath1);

            OpenFolderCommand2 = new DelegateCommand();
            OpenFolderCommand2.ExecuteCommand = new Action<object>(SetFolderPath2);

            CompareFolderCommand = new DelegateCommand();
            CompareFolderCommand.ExecuteCommand = new Action<object>(CompareFolder);

            ExitCommand = new DelegateCommand();
            ExitCommand.ExecuteCommand = new Action<object>(ExitSystem);
        }
        private void SetFolderPath1(object obj)
        {
            System.Windows.Forms.FolderBrowserDialog folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                myCompare.StrFolderPath_1 = folderBrowserDialog.SelectedPath;
            }
        }

        private void SetFolderPath2(object obj)
        {
            System.Windows.Forms.FolderBrowserDialog folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                myCompare.StrFolderPath_2 = folderBrowserDialog.SelectedPath;
            }
        }

        private void ExitSystem(object obj)
        {
            Environment.Exit(0);
        }
        List<string> strListFileName = new List<string>();
        private void CompareFolder(object obj)
        {
            string strDirectoryPath1 = myCompare.StrFolderPath_1 + '\\';
            string strDirectoryPath2 = myCompare.StrFolderPath_2 + '\\';
            string strSavePath = strDirectoryPath1.TrimEnd('\\');
            strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);

            //getAllFiles(@"D:\xmlTest");

            if (myCompare.StrFolderPath_1 == "" || myCompare.StrFolderPath_2 == "")
            {
                MessageBox.Show("文件路径不能为空！");
            }
            //判断文件路径是否存在，不存在则创建文件夹 
            else if (!xmlExist(myCompare.StrFolderPath_1))
            {
                MessageBox.Show("文件路径中xml文件不存在！");
            }
            else if (!xmlExist(myCompare.StrFolderPath_2))
            {
                MessageBox.Show("文件路径中xml文件不存在！");
            }
            else
            {
                #region 
                bool flagSame = false;

                strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);

                Hashtable ht1 = new Hashtable();
                Hashtable ht2 = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                strPathList1 = getXmlFile(strDirectoryPath1);
                strPathList2 = getXmlFile(strDirectoryPath2);
                foreach (var str in strPathList1)
                {
                    if (strPathList2.Contains(str))
                    {
                        ht1 = xmlToHashtable(strDirectoryPath1 + str);
                        ht2 = xmlToHashtable(strDirectoryPath2 + str);

                        flagSame = xmlCompare(ht1, ht2, strSavePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
                saveCsvToExcel(strListFileName, strSavePath + "result.xlsx");
                #endregion
            }
        }

        #region 方法

        private bool xmlExist(string strPath)
        {
            //判断文件路径是否存在，不存在则创建文件夹 
            if (!Directory.Exists(strPath))
            {
                //System.IO.Directory.CreateDirectory(@"D:\Export");//不存在就创建目录 
                return false;
            }
            else
            {
                foreach (string str in Directory.GetFiles(strPath))
                {
                    string strTemp = str.Substring(str.LastIndexOf('.') + 1);
                    strTemp = strTemp.ToUpper();
                    //strTemp = strTemp.ToLower();
                    //MessageBox.Show(strTemp);
                    if (strTemp == "XML")
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        private List<string> getXmlFile(string path)
        {
            //path = @"D:\Qiankun Zheng\zqk\mySpireTest\";
            List<string> strList = new List<string>();
            DirectoryInfo directory = new DirectoryInfo(path);

            FileInfo[] files = directory.GetFiles("*.xml");

            //输出文件个数 
            //MessageBox.Show(files.Length.ToString()); 

            //遍历文件 
            foreach (FileInfo file in files)
            {
                strList.Add(file.Name);
                //MessageBox.Show(file.Name); 
                //MessageBox.Show(file.Directory.ToString()); 
            }
            return strList;
        }

        private void saveCsvToExcel(List<string> strListFileName, string strSaveFilePath)
        {
            string strCsvPath;
            strCsvPath = myCompare.StrFolderPath_1;
            strCsvPath = strCsvPath.TrimEnd('\\');
            strCsvPath = strCsvPath.Substring(0, strCsvPath.LastIndexOf('\\') + 1);

            //ExcelOperator myExcel = null;
            ExcelOperator myExcel = new ExcelOperator();

            myExcel.Create();
            foreach (var str in strListFileName)
            {
                string strTemp = str.Substring(0, str.IndexOf('.'));

                //sheet表名不能超过31个字符
                if (strTemp.Length > 31)
                {
                    strTemp = strTemp.Substring(0, 30);
                }

                myExcel.ImportCSV(strCsvPath + str, myExcel.AddSheet(strTemp),
                              (Microsoft.Office.Interop.Excel.Range)((myExcel.GetSheet(strTemp)).get_Range("$A$1")),
                              new int[] { 2, 2, 2, 2, 2 }, true);
            }

            myExcel.SaveAs(strSaveFilePath);
            myExcel.Close();
        }

        private Hashtable xmlToHashtable(string xmlPath)
        {
            Hashtable ht = new Hashtable();

            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
                                             select ele;
            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("CHARC").Value;
                strValue = ele.Attribute("VALUE").Value;
                if (ele.LastAttribute.Name == "VALUE_TXT")
                {
                    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                }
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);
                ht.Add(strKey, strValue);
            }
            return ht;
        }
        private bool xmlCompare(Hashtable ht1, Hashtable ht2, string SaveFilePath)
        {
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in ht1)
            {
                if (ht2.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == ht2[de.Key].ToString())
                    {
                        ht2.Remove(de.Key);
                    }
                    else
                    {
                        strList1.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()) + "," + formatStr(ht2[de.Key].ToString()));
                        ht2.Remove(de.Key);
                    }
                }
                else
                {
                    strList2.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()));
                }
            }
            foreach (DictionaryEntry de in ht2)
            {
                strList3.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()));
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);

                //若CSV文件已经打开，先关闭文件
                //closeExcel(str);

                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    sw.WriteLine("CHARC,VALUE,VALUE_TEXT,VALUE,VALUE_TEXT");
                    if (strList1.Count > 0)
                    {
                        //sw.WriteLine("");
                        sw.WriteLine("The data in A and B is not the same");
                        //sw.WriteLine("两个xml文件中不相同的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        sw.WriteLine("");
                        sw.WriteLine("There is no file1 in file2");
                        //sw.WriteLine("xml文件1中有而2中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        sw.WriteLine("");
                        sw.WriteLine("There is no file2 in file1");
                        //sw.WriteLine("xml文件2中有而1中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }

        private string formatStr(string str)
        {
            string strValue = "";

            str = str.Replace(",", " ");

            string[] strArrayTemp = new string[2];
            strArrayTemp = str.Split(';');
            if (strArrayTemp.Length == 1)
            {
                strValue = strArrayTemp[0] + ",";
            }
            else
            {
                for (int i = 0; i < strArrayTemp.Length; i++)
                {
                    strValue += strArrayTemp[i] + ",";
                }
                strValue = strValue.Trim(',');
            }
            return strValue;
        }
        #endregion
    }
}
