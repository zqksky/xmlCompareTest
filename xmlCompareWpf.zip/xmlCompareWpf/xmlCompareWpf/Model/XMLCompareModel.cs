﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace xmlCompareWpf.Model
{
    class XMLCompareModel : INotifyPropertyChanged
    {
        /// <summary>
        /// 文件夹路径1
        /// </summary>
        private string strFolderPath_1;

        public string StrFolderPath_1
        {
            get { return strFolderPath_1; }
            set { strFolderPath_1 = value; NotifyPropertyChanged("StrFolderPath_1"); }
        }

        /// <summary>
        /// 文件夹路径2
        /// </summary>
        private string strFolderPath_2;

        public string StrFolderPath_2
        {
            get { return strFolderPath_2; }
            set { strFolderPath_2 = value; NotifyPropertyChanged("StrFolderPath_2"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
