﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using BIZ;
namespace CompareCMD
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("文件比对开始");
            string path1 = ConfigurationManager.AppSettings["PathV1In"];
            string path2 = ConfigurationManager.AppSettings["PathV2In"];
            string pathout = ConfigurationManager.AppSettings["PathOut"];
            string floderList = ConfigurationManager.AppSettings["FloderName"];
            BizProcess.ProcessSelectInputs(path1, path2, floderList, pathout);
            Console.WriteLine("文件比对结束");
            Console.ReadKey();
        }
    }
}
