﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;

namespace BIZ
{
    public class FileBiz
    {
        

        /// <summary>
        /// 读取文件建下所有txt文件数据
        /// </summary>
        /// <param name="path">文件夹路径</param>
        /// <returns>数据列表</returns>
        public static List<TagModel> ReadTxtFiles(string path)
        {
            List<FileInfo> list = TextFileHelper.GetFolderTxtFiles(path);
            List<TagModel> listmodel = new List<TagModel>();
            foreach (var file in list)
            { 
                //读取读取文本需要内容
               TagModel tmp=  ReadFileData(file);
               if (tmp != null)
               {
                   listmodel.Add(tmp);
               }
            }
            return listmodel;
        }

        /// <summary>
        /// 读取文本文件内容
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        private static TagModel ReadFileData(FileInfo file)
        {
            List<string> listLine = File.ReadAllLines(file.FullName).ToList();
            TagModel model=null;          
            string fieldName = "";
            int postion = 0;
            string folderName = file.Directory.Name;
            if (listLine.Count > 0)
            {
              

                //0.TagName
                 fieldName = "Tag Name:";
                var query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                if (query.Count > 0)
                {
                    model = new TagModel();
                    model.FileName = file.Name;
                    postion = GetListIndexByValue(listLine, fieldName);
                    if (postion >= 0)
                    {
                        if (listLine[postion + 1].Trim() == "")//防止tagName分行
                        {
                            model.TagName = GetValue(query[0], fieldName);
                        }
                        else
                        {
                            model.TagName = GetValue(listLine[postion].Trim() + listLine[postion + 1].Trim(), fieldName);
                        }
                    }
                    if (model.TagName == "Tubing_C5_0.75")
                    {
                        string aa = "";
                    }

                    //1.New Add Error 
                    fieldName = "Error:";
                    postion = GetListIndexByValue(listLine, fieldName);
                    if (postion >= 0)//异常数据
                    {
                        model.ProjectName = folderName;
                        //获取error信息，多行
                        model.ErrorsInfo = GetErrorInfo(listLine, postion, fieldName);
                        //Chiller Model:
                        fieldName = "Chiller Model:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.ChillerModel = GetValue(query[0], fieldName).TrimEnd('-');
                        }
                        //Chiller Capacity: 
                        fieldName = "Chiller Capacity:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            var ltmt = new List<string>();
                            ltmt.Add(GetCapValue(GetValue(query[0], fieldName)));//需要做单位换算
                            model.ChillerCapacity = ltmt;
                            model.PercentLoad = new List<string>();
                            model.PercentLoad.Add("100.00");
                        }
                        //Starter VFD: 
                        fieldName = "Starter VFD:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.StarterVFD = GetValue(query[0], fieldName);
                        }
                        //CmpSize:
                        fieldName = "CmpSize:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.CmpSize = GetValue(query[0], fieldName);
                        }
                        //Operation Type:
                        fieldName = "Operation Type:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.OperationType = GetValue(query[0], fieldName);
                        }
                    }
                    else//正常数据
                    {

                        //2.Chiller Model
                        fieldName = "Chiller Model";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.ChillerModel = GetValue(query[0], fieldName);
                        }
                        //3.Float Valve Size
                        fieldName = "Float Valve Size";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) == 0).ToList();
                        if (query.Count > 0)
                        {
                            model.FloatValueSize = GetValue(query[0], fieldName);
                        }
                        else
                        {
                            //fieldName = "Economizer Float Valve";
                            fieldName = "High Side Orifice Size";
                            query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                            if (query.Count > 0)
                            {
                                model.FloatValueSize = GetValue(query[0], fieldName);
                            }
                            else
                            {
                                //High Side Condenser Float Valve/Condenser Float Valve
                                fieldName = "Condenser Float Valve";
                                query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                                if (query.Count > 0)
                                {
                                    model.FloatValueSize = GetValue(query[0], fieldName);
                                }
                                else
                                {
                                    fieldName = "High Side Condenser Float Valve";
                                    query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                                    if (query.Count > 0)
                                    {
                                        model.FloatValueSize = GetValue(query[0], fieldName);
                                    }
                                }
                            }
                        }
                        //4.Flasc Orifice
                        fieldName = "Flasc Orifice";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.FlascOrifice = DataUtility.MoveInvalidTabChar(GetValue(query[0], fieldName));
                        }
                        //5.Percent Load
                        fieldName = "Percent Load";
                        postion = GetListIndexByValue(listLine, fieldName);
                        if (postion >= 0)
                            model.PercentLoad = GetValues(listLine, postion);
                        //6.Chiller Capacity
                        fieldName = "Chiller Capacity";
                        postion = GetListIndexByValue(listLine, fieldName);
                        if (postion >= 0)
                            model.ChillerCapacity = GetCapacityValues(listLine, postion);
                        else
                        {
                            fieldName = "Chiller Heating Capacity";
                            postion = GetListIndexByValue(listLine, fieldName);
                            if (postion >= 0)
                            {
                                model.ChillerCapacity = GetCapacityValues(listLine, postion);
                            }
                            else
                            {
                                fieldName = "Chiller Heating";
                                postion = GetListIndexByValue(listLine, fieldName);
                                if (listLine[postion + 1].Trim().IndexOf("Capacity") >= 0)
                                {
                                    model.ChillerCapacity = GetCapacityValues(listLine, postion + 1);
                                }
                            }
                        }
                        //7.Chiller COPR
                        fieldName = "Chiller COPR";
                        postion = GetListIndexByValue(listLine, fieldName);
                        if (postion >= 0)
                            model.ChillerCOPR = GetValues(listLine, postion);
                        else
                        {
                            //Heating
                            fieldName = "Chiller Heating COP";
                            postion = GetListIndexByValue(listLine, fieldName);
                            if (postion >= 0)
                                model.ChillerCOPR = GetValues(listLine, postion);
                        }
                        //8.Operation Type
                        fieldName = "Operation Type";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                            model.OperationType = GetValue(query[0], fieldName);
                        //9.Starter / VFD
                        fieldName = "Starter / VFD";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                            model.StarterVFD = GetValue(query[0], fieldName);
                        //10.Compressor-/Size
                        //先找第一个Compressor出现的位置
                        fieldName = "Compressor";
                        postion = GetListIndexByValue(listLine, fieldName, true);
                        fieldName = "Size";
                        if (postion >= 0)
                            model.CmpSize = GetValue(listLine[postion + 1], fieldName);
                        //11.Total Rigging Weight
                        fieldName = "Total Rigging Weight";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                            model.TotalRiggingWeight = DataUtility.MoveInvalidTabChar(GetValue(query[0], fieldName));
                        //12.Total Operating Weight
                        fieldName = "Total Operating Weight";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                            model.TotalOperatingWeight = DataUtility.MoveInvalidTabChar(GetValue(query[0], fieldName));
                        //13.Refrigerant Weight
                        fieldName = "Refrigerant Weight";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                            model.RefrigerantWeight = DataUtility.MoveInvalidTabChar(GetValue(query[0], fieldName));
                        //14.clr Pressure Drop
                        fieldName = "Pressure Drop";
                        postion = GetListIndexByValue(listLine, fieldName);
                        if (postion >= 0)
                            model.ClrPressureDrop = GetValues(listLine, postion);
                        //15.cnd- Pressure Drop
                        postion = GetListIndexByValue(listLine, fieldName, 2, true);
                        if (postion >= 0)
                        {
                            model.CndPressureDrop = GetValues(listLine, postion);
                        }

                        //16.low side valve: Economizer Float Valve size or Float Ball vlve size
                        fieldName = "Economizer Float Valve Size";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.FloatBallValueSize = GetValue(query[0], fieldName);
                        }
                        else
                        {
                            fieldName = "Float Ball Valve Size";
                            query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                            if (query.Count > 0)
                            {
                                model.FloatBallValueSize = GetValue(query[0], fieldName);
                            }
                            else
                            {
                                fieldName = "Economizer Float Valve";
                                query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                                if (query.Count > 0)
                                {
                                    model.FloatBallValueSize = GetValue(query[0], fieldName);
                                }
                                else
                                {
                                    model.FloatBallValueSize = "0";
                                }
                            }
                        }
                        //17.sum time
                        fieldName = "Sum_Time:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.RunTimes = GetValue(query[0], fieldName);
                        }
                        //18.projectName Project Name:
                        fieldName = "Project Name:";
                        query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                        if (query.Count > 0)
                        {
                            model.ProjectName = DataUtility.MoveInvalidTabChar(GetValue(query[0], fieldName));
                        }

                        model.ProductName = DataProcess.GetProductName(model.CmpSize);
                        model.ProductType = DataProcess.GetProductType(model.ProductName);
                    }

                }
                else
                { 
                   //
                    string tag = "";
                }
            }
            return model;
        }


        private static string GetValue(string line,string field)
        {
            int index = line.IndexOf(field);
            return line.Substring(index + field.Length).Trim();
        }

        private static List<string> GetValues(List<string> lines, int pos)
        {
            List<string> rtlist = new List<string>();

            for (int i = pos + 1; i < lines.Count; i++)
            {
                if (lines[i].Trim() == "")
                {
                    break;
                }
                rtlist.Add(DataUtility.MoveInvalidSpaceChar( lines[i].Trim()));
            }
            return rtlist;
        }

        private static List<string> GetCapacityValues(List<string> lines, int pos)
        {
            List<string> rtlist = new List<string>();

            for (int i = pos + 1; i < lines.Count; i++)
            {
                if (lines[i].Trim() == "")
                {
                    break;
                }

                rtlist.Add(GetCapValue(lines[i]));
            }
            return rtlist;
        }

        private static int GetListIndexByValue(List<string> listLines, string value,bool isAbs=false)
        {
            int j = -1;
           
            if (!isAbs)
            {
                var list = listLines.Select((item, index) =>
                                     new { item, index }).Where(i => i.item.IndexOf(value) >= 0).ToList();
                if (list.Count<=0)
                {
                    j = -1;
                }
                else
                {
                    j = list.FirstOrDefault().index;
                }
                
            }
            else
            {
                var list = listLines.Select((item, index) =>
                                    new { item, index }).Where(i => i.item.Trim()==value).ToList();
                if (list.Count <= 0)
                {
                    j = -1;
                }
                else
                {
                    j = list.FirstOrDefault().index;
                }
            }
            return j;        
        }

        private static int GetListIndexByValue(List<string> listLines, string value,int num ,bool isAbs = false)
        {
            int j = -1;
           
            if (!isAbs)
            {
                var list = listLines.Select((item, index) =>
                                      new { item, index }).Where(i => i.item.IndexOf(value) >= 0).ToList();
                if (list.Count >= num)
                {
                    j = list[num - 1].index;
                }
            }
            else
            {
                var list = listLines.Select((item, index) =>
                                    new { item, index }).Where(i => i.item.Trim() == value).ToList();
                if (list.Count >= num)
                {
                    j = list[num - 1].index;
                }
            }
            return j;
        }

        public static string GetErrorInfo(List<string> listLines, int postion,string field)
        {
            string rtn = listLines[postion].Trim().Substring(listLines[postion].IndexOf(field)+field.Length);
            int k = 1;
            while (!string.IsNullOrEmpty(listLines[postion+k]))
            {
                rtn = rtn + listLines[postion + k];
                k++;
            }
            return rtn;
        }

        /// <summary>
        ///将值转换成英制单位
        /// </summary>
        /// <param name="cap"></param>
        /// <returns></returns>
        public static string GetCapValue(string cap)
        {
            string rtn = "";
            string value = DataUtility.MoveInvalidCharBefore(cap.Trim(), ' ');
            string sUnit = DataUtility.MoveInvalidCharAfter(cap.Trim(), ' ');
            if (sUnit.IndexOf("tonR") >= 0)
            {
                rtn = value;
            }
            else
            {
                rtn = CapEngUnit(value);
            }
            return rtn;
        
        }

        public static string CapEngUnit(string value)
        {
            string rtn = "";
            //计算
            double p = 3.51667;
            double c = 0;
            if (double.TryParse(value, out c))
            {
                rtn = (c / p).ToString();
            }
            else
            {
                rtn = "0";
            }
            return rtn;
        }

        public static List<SummaryPerfModel> GetSummaryPerf(List<TagModel> listSele,string usrType,string version)
        {
            List<SummaryPerfModel> listsum = new List<SummaryPerfModel>();
            foreach (var m in listSele)
            {
                SummaryPerfModel spm = new SummaryPerfModel();
                spm.ProductName = DataProcess.GetProductName(m.CmpSize);
                spm.OperationType =m.OperationType;
                spm.ProductType = DataProcess.GetProductType(spm.ProductName);
                spm.RunTimes =double.Parse(m.RunTimes);
                spm.UserType = usrType;
                spm.Version = version;
                spm.ChillerModel = m.ChillerModel;
                spm.TagName = m.TagName;
                listsum.Add(spm);
            }
            return listsum;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="listV1"></param>
        /// <param name="listV2"></param>
        public static List<OutSummaryPerfModel> SummaryDataProcess(List<SummaryPerfModel> listV1, List<SummaryPerfModel> listV2)
        {
            List<OutSummaryPerfModel> listout = new List<OutSummaryPerfModel>();
               //先operation分类
                List<string> listOperation = GetListType(listV1, listV2, "OperationType");
                for (int i = 0; i < listOperation.Count; i++)
                {
                    List<SummaryPerfModel> lstV1Operation = listV1.Where(t => t.OperationType == listOperation[i]).ToList();
                    List<SummaryPerfModel> lstV2Operation = listV2.Where(t => t.OperationType == listOperation[i]).ToList();
                    List<string> listProType = GetListType(lstV1Operation, lstV2Operation, "ProductType");
                    for (int j = 0; j < listProType.Count; j++)
                    {
                        List<SummaryPerfModel> lstV1ProType = lstV1Operation.Where(t => t.ProductType == listProType[j]).ToList();
                        List<SummaryPerfModel> lstV2ProType = lstV2Operation.Where(t => t.ProductType == listProType[j]).ToList();
                        List<string> listProName = GetListType(lstV1ProType, lstV2ProType, "ProductName");
                        for (int k = 0; k < listProName.Count; k++)
                        {
                            List<SummaryPerfModel> lstV1ProName = lstV1ProType.Where(t => t.ProductName == listProName[k]).ToList();
                            List<SummaryPerfModel> lstV2ProName = lstV2ProType.Where(t => t.ProductName == listProName[k]).ToList();
                            OutSummaryPerfModel model = new OutSummaryPerfModel();
                            model.OperationType = listOperation[i];
                            model.ProductName = listProName[k];
                            model.ProductType = listProType[j];
                           
                            var ll = lstV2ProName.Where(t => t.RunTimes < 0).ToList();
                            //计算test count/totalTime
                            int v1apo_engCount = 0;
                            int v1apo_salesCount = 0;
                            int v1nao_engCount = 0;
                            int v1nao_salesCount = 0;

                            double v1apo_engTime = 0;
                            double v1apo_salesTime = 0;
                            double v1nao_engTime = 0;
                            double v1nao_salesTime = 0;

                            int v2apo_engCount = 0;
                            int v2apo_salesCount = 0;
                            int v2nao_engCount = 0;
                            int v2nao_salesCount = 0;

                            double v2apo_engTime = 0;
                            double v2apo_salesTime = 0;
                            double v2nao_engTime = 0;
                            double v2nao_salesTime = 0;

                            if (lstV1ProName.Count > 0)
                            {//APO_ENG,NAO_SALES,APO_SALES,NAO_ENG
                                v1apo_engCount = lstV1ProName.Where(t => t.UserType.ToUpper() == "APO_ENG" && t.Version == "V1").ToList().Count;
                                v1apo_salesCount = lstV1ProName.Where(t => t.UserType.ToUpper() == "APO_SALES" && t.Version == "V1").ToList().Count;
                                v1nao_engCount = lstV1ProName.Where(t => t.UserType.ToUpper() == "NAO_ENG" && t.Version == "V1").ToList().Count;
                                v1nao_salesCount = lstV1ProName.Where(t => t.UserType.ToUpper() == "NAO_SALES" && t.Version == "V1").ToList().Count;
                                var g = (lstV1ProName.Where(t => t.Version.ToUpper() == "V1").ToList().GroupBy(t => t.UserType)).ToList();
                                var results = g.Select(x => new
                                {                                  
                                    Name = x.First().UserType,
                                    SumRunTimes = x.Sum(s => s.RunTimes)
                                }).ToList();
                                var tmp = results.Where(t => t.Name.ToUpper() == "APO_ENG").ToList();
                                if(tmp.Count>0)
                                    v1apo_engTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "APO_SALES").ToList();
                                if(tmp.Count>0)
                                    v1apo_salesTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "NAO_ENG").ToList();
                                if (tmp.Count > 0)
                                    v1nao_engTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "NAO_SALES").ToList();
                                if (tmp.Count > 0)
                                    v1nao_salesTime =tmp[0].SumRunTimes;
                            }
                            if (lstV2ProName.Count > 0)
                            {
                                v2apo_engCount = lstV2ProName.Where(t => t.UserType.ToUpper() == "APO_ENG" && t.Version == "V2").ToList().Count;
                                v2apo_salesCount = lstV2ProName.Where(t => t.UserType.ToUpper() == "APO_SALES" && t.Version == "V2").ToList().Count;
                                v2nao_engCount = lstV2ProName.Where(t => t.UserType.ToUpper() == "NAO_ENG" && t.Version == "V2").ToList().Count;
                                v2nao_salesCount = lstV2ProName.Where(t => t.UserType.ToUpper() == "NAO_SALES" && t.Version == "V2").ToList().Count;
                                var g = lstV2ProName.Where(t => t.Version.ToUpper() == "V2").ToList().GroupBy(t => t.UserType);
                                var results = g.Select(x => new
                                {
                                    Name = x.First().UserType,
                                    SumRunTimes = x.Sum(s => s.RunTimes)
                                });

                                var tmp = results.Where(t => t.Name.ToUpper() == "APO_ENG").ToList();
                                if (tmp.Count > 0)
                                    v2apo_engTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "APO_SALES").ToList();
                                if (tmp.Count > 0)
                                    v2apo_salesTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "NAO_ENG").ToList();
                                if (tmp.Count > 0)
                                    v2nao_engTime = tmp[0].SumRunTimes;
                                tmp = results.Where(t => t.Name.ToUpper() == "NAO_SALES").ToList();
                                if (tmp.Count > 0)
                                    v2nao_salesTime = tmp[0].SumRunTimes;
                            }
                            model.V1APO_EngCount = v1apo_engCount;
                            model.V1APO_SalesCount = v1apo_salesCount;
                            model.V1NAO_EngCount = v1nao_engCount;
                            model.V1NAO_SalesCount = v1nao_salesCount;
                            model.V1SumCount = v1apo_engCount + v1apo_salesCount + v1nao_engCount + v1nao_salesCount;

                            model.V1APO_EngTimes = v1apo_engTime;
                            model.V1APO_SalesTimes = v1apo_salesTime;
                            model.V1NAO_EngTimes = v1nao_engTime;
                            model.V1NAO_SalesTimes = v1nao_salesTime;

                            model.V1SumTimes = v1apo_engTime + v1apo_salesTime + v1nao_engTime + v1nao_salesTime;

                            model.V2APO_EngCount = v2apo_engCount;
                            model.V2APO_SalesCount = v2nao_salesCount;
                            model.V2NAO_EngCount = v2nao_engCount;
                            model.V2NAO_SalesCount = v2nao_salesCount;
                            model.V2SumCount = v2apo_engCount + v2nao_salesCount + v2apo_salesCount + v2nao_engCount;

                            model.V2APO_EngTimes = v2apo_engTime;
                            model.V2APO_SalesTimes = v2apo_salesTime;
                            model.V2NAO_SalesTimes = v2nao_salesTime;
                            model.V2NAO_EngTimes = v2nao_engTime;

                            model.V2SumTimes = v2apo_engTime + v2apo_salesTime + v2nao_salesTime + v2nao_engTime;
                            listout.Add(model);
                        }
                    }

                }
                return listout;
        
        }

        public static List<string> GetListType(List<SummaryPerfModel> listV1, List<SummaryPerfModel> listV2, string TypeName)
        {
            List<string> lstRT = new List<string>();
            List<string> list2 = new List<string>();
            List<string> list1 = new List<string>();
            if (TypeName == "OperationType")
            {
               list2 = listV2.Select(t => t.OperationType).ToList().Distinct().ToList();
               list1 = listV1.Select(t => t.OperationType).ToList().Distinct().ToList();
                
            }
            else if (TypeName == "ProductType")
            {
                list2 = listV2.Select(t => t.ProductType).ToList().Distinct().ToList();
                list1 = listV1.Select(t => t.ProductType).ToList().Distinct().ToList();
            }
            else if (TypeName == "ProductName")
            {
                list2 = listV2.Select(t => t.ProductName).ToList().Distinct().ToList();
                list1 = listV1.Select(t => t.ProductName).ToList().Distinct().ToList();
            }

            lstRT = list1.Union(list2).ToList() ;
            return lstRT;
        
        }

        #region Selections


        public static SelectionsModel ReadSelectionFileTxt(FileInfo fileinfo)
        {
            List<string> listLine = File.ReadAllLines(fileinfo.Directory+@"\"+fileinfo.Name).ToList();
           SelectionsModel  SelModel = new SelectionsModel();
           SelModel.FileName = fileinfo.Name;
           List<SelectionsReadModel> listRead = new List<SelectionsReadModel>();
            string TagName = fileinfo.Name.Substring(0,fileinfo.Name.IndexOf('.'));
            string fieldName = "";
            int postion = 0;
            int postionStart = 0;
            string projectName = "";
            int posStep = 2;
            if (listLine.Count > 0)
            {
                //0.ProjectName
                fieldName = "Project Name:";
                var query = listLine.Where(a => a.Trim().IndexOf(fieldName) >= 0).ToList();
                if (query.Count > 0)
                {
                    projectName = DataUtility.MoveInvalidCharBefore(GetValue(query[0], fieldName).Trim(), '\t');
                    //projectName = DataUtility.MoveInvalidCharBefore(GetValue(query[0], fieldName).Trim(), '\t').Substring(0,7);
                }
                SelModel.ProjectName = projectName;
                SelModel.TagName = TagName;
                
                //1.Chiller Selection Summary 找到这个位置+3开始找每行数据
                fieldName="Chiller Selection Summary";
                postion = GetListIndexByValue(listLine, fieldName,true);
                if (postion >= 0)
                {                    
                    postion = postion + 2;
                    //获取Cap单位
                    string line = listLine[postion];
                    List<string> title=line.Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    string unit = title.Count >= 3 ? title[2] : "Tons";
                    if (title.Count >= 10)
                    {
                        posStep = 1;
                    }
                    SelModel.CapacityUnit = unit == "Tons" ? "0" : "1";
                    postion = postion + posStep;
                    //best
                    if (posStep == 2)
                        line = listLine[postion] + listLine[postion + 1];
                    else
                        line = listLine[postion];
                    listRead.Add(GetSelectionModel(line,SelModel.CapacityUnit));
                    postion=postion+posStep;
                    line=listLine[postion];
                    //string lineNext = "";
                    //if (posStep == 2)
                    //    lineNext = listLine[postion + 1];
                    //else
                    //    lineNext = listLine[postion];          
                    string lineNext = listLine[postion+1];
                    if (lineNext.IndexOf("Selection") >= 0)
                    {
                        while (!string.IsNullOrEmpty(lineNext.Trim()) && line.Trim()!="\f")
                        {
                            if(string.IsNullOrEmpty(line))
                                postion = postion + 1;

                            if (posStep == 2)
                                line = listLine[postion] + listLine[postion + 1];
                            else
                                line = listLine[postion];
                            listRead.Add(GetSelectionModel(line, SelModel.CapacityUnit));
                            postion = postion + posStep;
                            line = listLine[postion];
                            if ((postion+1)>=listLine.Count)
                            {
                                break;
                            }
                            if (posStep == 2)
                                lineNext = listLine[postion + 1];
                            else
                                lineNext = listLine[postion ];
                        }                      
                    }
                    fieldName="Chiller Selection Summary (Continued)";
                    postionStart= GetListIndexByValue(listLine, fieldName, true);
                       
                    while (postionStart >= 0 && postionStart>postion)
                    {
                        postion = postionStart;
                        postion = postion + 2+posStep;
                        if ((postion) >= listLine.Count)
                        {
                            break;
                        }
                        line = listLine[postion];
                        if (postion + 1 >= listLine.Count)
                        {
                            break;
                        }
                        if (posStep == 2)
                            lineNext = listLine[postion + 1];
                        else
                            lineNext = listLine[postion];
                        while (!string.IsNullOrEmpty(lineNext.Trim()) && line.Trim() != "\f")
                        {
                            if (string.IsNullOrEmpty(line))
                                postion = postion + 1;
                            if (posStep == 2)
                                line = listLine[postion] + listLine[postion + 1];
                            else
                                line = listLine[postion];
                            listRead.Add(GetSelectionModel(line, SelModel.CapacityUnit));
                            postion = postion + posStep;
                            line = listLine[postion];
                            if ((postion + 1) >= listLine.Count)
                            {
                                break;
                            }
                            if (posStep == 2)
                                lineNext = listLine[postion + 1];
                            else
                                lineNext = listLine[postion];                      
                        }                       
                        postionStart = GetPostionByStartPostion(listLine, fieldName, postion) ;
                    }
                }
            }
            else
            {

                string aa = "";
            }

           SelModel.ListSelectionsReadModel=  listRead;
           return SelModel;
        }

        public static SelectionsReadModel GetSelectionModel(string line, string CapacityUnit)
        {
            SelectionsReadModel model = new SelectionsReadModel();
          
            if (line.IndexOf("Best") >= 0)
            {
                model.IsBest = true;
            }
            else
            {
                model.IsBest = false;
            }
            //selection Name
            model.SelectionName = line.Trim().Substring(0, line.Trim().IndexOf('\t')).Trim();
            //model
            model.ChillerModel = line.Trim().Substring(line.Trim().IndexOf('\t')).Trim().Substring(0, 22);

            List<string> lt = line.Trim().Substring(line.Trim().IndexOf('\t')).Trim().Substring(22).Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            string[] pass = lt[0].Split('/');
            model.ClrPass = pass[0];
            model.CndPass = pass[1];
            bool haveChar = false;
            string cap=lt[1];
            if (cap == "*")
            {
                cap = lt[2];
                haveChar = true;
            }
            
            if (CapacityUnit == "0")
            {
                model.Capacity = cap;
            }
            else
            { 
                //公制换算成英制
                model.Capacity = CapEngUnit(cap);

            }
            if (!haveChar)
            {
                model.FullLoad = lt[2];
                if (lt.Count > 6)//有些列表会缺少IPLV
                {
                    model.IPLV = lt[3];
                    model.ClrPressDrop = lt[4];
                    model.CndPressDrop = lt[5];
                    model.Price = lt[6];
                }
                else
                {
                    model.IPLV = "0";
                    model.ClrPressDrop = lt[3];
                    model.CndPressDrop = lt[4];
                    model.Price = lt[5];
                }
            }
            else
            {
                model.FullLoad = lt[3];
                if (lt.Count > 7)//有些列表会缺少IPLV
                {
                    model.IPLV = lt[4];
                    model.ClrPressDrop = lt[5];
                    model.CndPressDrop = lt[6];
                    model.Price = lt[7];
                }
                else
                {
                    model.IPLV = "0";
                    model.ClrPressDrop = lt[4];
                    model.CndPressDrop = lt[5];
                    model.Price = lt[6];
                }
            
            }
            return model;
        }


        public static int GetPostionByStartPostion(List<string> listLine, string fieldName, int postionStart)
        {          
           var  list= listLine .Select((item, index) =>
                                      new { item, index }).Where(i => i.item==fieldName && i.index > postionStart ).ToList();

           if (list.Count>0)
           {
               return list.FirstOrDefault().index;
           }
           else
           {
               return -1;
           }

        }


        public static List<SelectionsModel> ReadSelectionsFiles(string path)
        {
            List<SelectionsModel> list = new List<SelectionsModel>();
            List<FileInfo> listFile = TextFileHelper.GetFolderTxtFiles(path);

            foreach (var file in listFile)
            {

                //读取读取文本需要内容
                SelectionsModel tmp = ReadSelectionFileTxt(file);
                if (tmp != null)
                {
                    list.Add(tmp);
                }
               
            }
            return list;
        }

        #endregion
    }
}
