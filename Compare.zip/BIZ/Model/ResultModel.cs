﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class ResultModel
    {
        public bool Result;
        public string ResultDesc;
    }
}
