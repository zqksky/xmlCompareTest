﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class TagModel
    {
        private string tagName;

        public string TagName
        {
            get { return tagName; }
            set { tagName = value; }
        }
        private string chillerModel;

        public string ChillerModel
        {
            get { return chillerModel; }
            set { chillerModel = value; }
        }
        private string floatValueSize;

        public string FloatValueSize
        {
            get { return floatValueSize; }
            set { floatValueSize = value; }
        }
        private string flascOrifice;

        public string FlascOrifice
        {
            get { return flascOrifice; }
            set { flascOrifice = value; }
        }
        private List<string> percentLoad;

        public List<string> PercentLoad
        {
            get { return percentLoad; }
            set { percentLoad = value; }
        }
        private List<string> chillerCapacity;

        public List<string> ChillerCapacity
        {
            get { return chillerCapacity; }
            set { chillerCapacity = value; }
        }
        private List<string> chillerCOPR;

        public List<string> ChillerCOPR
        {
            get { return chillerCOPR; }
            set { chillerCOPR = value; }
        }

        private List<string> clrPressureDrop;

        public List<string> ClrPressureDrop
        {
            get { return clrPressureDrop; }
            set { clrPressureDrop = value; }
        }

        private string starterVFD;

        public string StarterVFD
        {
            get { return starterVFD; }
            set { starterVFD = value; }
        }
        private string operationType;

        public string OperationType
        {
            get { return operationType; }
            set { operationType = value; }
        }
        private string totalRiggingWeight;

        public string TotalRiggingWeight
        {
            get { return totalRiggingWeight; }
            set { totalRiggingWeight = value; }
        }
        private string totalOperatingWeight;

        public string TotalOperatingWeight
        {
            get { return totalOperatingWeight; }
            set { totalOperatingWeight = value; }
        }
        private string refrigerantWeight;

        public string RefrigerantWeight
        {
            get { return refrigerantWeight; }
            set { refrigerantWeight = value; }
        }
        private List<string> cndPressureDrop;

        public List<string> CndPressureDrop
        {
            get { return cndPressureDrop; }
            set { cndPressureDrop = value; }
        }

        private string cmpSize;

        public string CmpSize
        {
            get { return cmpSize; }
            set { cmpSize = value; }
        }
        private string floatBallValueSize;

        public string FloatBallValueSize
        {
            get { return floatBallValueSize; }
            set { floatBallValueSize = value; }
        }


        private string errorsInfo;

        public string ErrorsInfo
        {
            get { return errorsInfo; }
            set { errorsInfo = value; }
        }

        private string sumTime="0";
        /// <summary>
        /// 单位秒
        /// </summary>
        public string RunTimes
        {
            get { return sumTime; }
            set { sumTime = value; }
        }

        private string projectName;

        public string ProjectName
        {
            get { return projectName; }
            set { projectName = value; }
        }

        private string fileName;

        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }


        public string ProductType { get; set; }
        public string ProductName { get; set; }

    }
    public class TagListEquality : IEqualityComparer<TagModel>
    {
        public bool Equals(TagModel x, TagModel y)
        {
            return x.ChillerModel == y.ChillerModel && x.TagName == y.TagName;
        }

        public int GetHashCode(TagModel obj)
        {
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return obj.ToString().GetHashCode();
            }
        }
    }
}
