﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class SummaryPerfModel
    {
        public string UserType { get; set; }
        public string Version { get;set; }
        public string OperationType { get; set; }
        public string ProductType { get; set; }
        public string ProductName { get; set; }
        public int TagCount { get; set; }
        public double RunTimes { get; set; }
        public string ChillerModel { get; set; }
        public string TagName { get; set; }
    }
}
