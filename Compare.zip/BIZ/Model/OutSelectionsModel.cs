﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class OutSelectionsModel
    {
        public string ProjectName { get; set; }
        public string TagName { get; set; }
        public List<SelectionsOutListModel> ListSelections { get; set; }
        public string FileName { get; set; }
        public int CommonCandidatates { get; set; }

        public int V1 { get; set; }

        public int V2 { get; set; }
        /// <summary>
        /// 0:NG 1:OK
        /// </summary>
        public string IsPassSelections { get; set; }

        /// <summary>
        /// 0:NG 1:OK
        /// </summary>
        public string IsPassPerf { get; set; }

        /// <summary>
        /// 0:相同（交集）1:in GT 2:in Val
        /// </summary>
        public string WaringType { get; set; }
        public string WaringDesc { get; set; }

        public string Seq { get; set; }
    }



    public class SelectionsOutListModel
    {
        /// <summary>
        /// 0:相同 1:in GT 2:in Val
        /// </summary>
        public string OutModel { get; set; }

        public string ChillerModel { get; set; }

        public string Capacity { get; set; }

        public string ClrPass { get; set; }

        public string CndPass { get; set; }

        public string FullLoad { get; set; }

        public string IPLV { get; set; }

        public string ClrPressDrop { get; set; }

        public string CndPressDrop { get; set; }

        public string Price { get; set; }

    }
}
