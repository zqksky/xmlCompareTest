﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class OutSummaryPerfModel
    {
        public string OperationType { get; set; }
        public string ProductType { get; set; }
        public string ProductName { get; set; }

        public int V1APO_EngCount { get; set; }
        public int V1APO_SalesCount { get; set; }
        public int V1NAO_EngCount { get; set; }
        public int V1NAO_SalesCount { get; set; }
        public int V1SumCount { get; set; }
        public int V2APO_EngCount { get; set; }
        public int V2APO_SalesCount { get; set; }
        public int V2NAO_EngCount { get; set; }
        public int V2NAO_SalesCount { get; set; }
        public int V2SumCount { get; set; }

        public double V1APO_EngTimes { get; set; }
        public double V1APO_SalesTimes { get; set; }
        public double V1NAO_EngTimes { get; set; }
        public double V1NAO_SalesTimes { get; set; }
        public double V1SumTimes { get; set; }
        public double V2APO_EngTimes { get; set; }
        public double V2APO_SalesTimes { get; set; }
        public double V2NAO_EngTimes { get; set; }
        public double V2NAO_SalesTimes { get; set; }
        public double V2SumTimes { get; set; }

    }
}
