﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class SelectionsModel
    {
        public string ProjectName { get; set; }
        public string TagName { get; set; }
        public string FileName { get; set; }
        /// <summary>
        /// 0:英制 1：公制
        /// </summary>
        public string CapacityUnit { get; set; }
        public List<SelectionsReadModel> ListSelectionsReadModel { get; set; }
    
    }

    public class SelectionsReadModel
    {
      
        public string SelectionName { get; set; }
        public bool IsBest { get; set; }
        public string ChillerModel { get; set; }
        public string ClrPass { get; set; }
        public string CndPass { get; set; }
        public string Capacity { get; set; }
        public string FullLoad { get; set; }
        public string IPLV { get; set; }
        public string ClrPressDrop { get; set; }
        public string CndPressDrop { get; set; }
        public string Price { get; set; }
        
    }
    public class SelectionModelEquality : IEqualityComparer<SelectionsModel>
    {
        public bool Equals(SelectionsModel x, SelectionsModel y)
        {
            return x.ProjectName.ToLower() == y.ProjectName.ToLower() && x.TagName.ToLower() ==y.TagName.ToLower();
        }

        public int GetHashCode(SelectionsModel obj)
        {
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return obj.ToString().GetHashCode();
            }
        }
    }

    public class SelectionSumModelEquality : IEqualityComparer<SelectionsReadModel>
    {
        public bool Equals(SelectionsReadModel x, SelectionsReadModel y)
        {
            return x.ChillerModel.ToLower() == y.ChillerModel.ToLower() && CompareCapacityValue(x.Capacity, y.Capacity);
        }

        public int GetHashCode(SelectionsReadModel obj)
        {
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return obj.ToString().GetHashCode();
            }
        }

        private  bool CompareCapacityValue(string gt, string cm)
        {
            double re = (Math.Abs(double.Parse(gt) - double.Parse(cm)) /
                        double.Parse(cm));
            if (re <= 0.0005)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
