﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BIZ
{
    public class OutModel
    {
        private string tagName;

        public string TagName
        {
            get { return tagName; }
            set { tagName = value; }
        }
        private string chillerModel;

        public string ChillerModel
        {
            get { return chillerModel; }
            set { chillerModel = value; }
        }

        private string starterVFD;

        public string StarterVFD
        {
            get { return starterVFD; }
            set { starterVFD = value; }
        }
        private string operationType;

        public string OperationType
        {
            get { return operationType; }
            set { operationType = value; }
        }
        private string totalRiggingWeight;

        public string TotalRiggingWeight
        {
            get { return totalRiggingWeight; }
            set { totalRiggingWeight = value; }
        }
        private string totalOperatingWeight;

        public string TotalOperatingWeight
        {
            get { return totalOperatingWeight; }
            set { totalOperatingWeight = value; }
        }
        private string refrigerantWeight;

        public string RefrigerantWeight
        {
            get { return refrigerantWeight; }
            set { refrigerantWeight = value; }
        }
        private Dictionary<string, string> cndPressureDrop;

        public Dictionary<string, string> CndPressureDrop
        {
            get { return cndPressureDrop; }
            set { cndPressureDrop = value; }
        }

        private string cmpSize;

        public string CmpSize
        {
            get { return cmpSize; }
            set { cmpSize = value; }
        }
        private string floatBallValueSize;

        public string FloatBallValueSize
        {
            get { return floatBallValueSize; }
            set { floatBallValueSize = value; }
        }

        private string floatValueSize;

        public string FloatValueSize
        {
            get { return floatValueSize; }
            set { floatValueSize = value; }
        }
        private string flascOrifice;

        public string FlascOrifice
        {
            get { return flascOrifice; }
            set { flascOrifice = value; }
        }
        private List<string> percentLoad;

        public List<string> PercentLoad
        {
            get { return percentLoad; }
            set { percentLoad = value; }
        }
        private Dictionary<string, string> chillerCapacity;

        public Dictionary<string, string> ChillerCapacity
        {
            get { return chillerCapacity; }
            set { chillerCapacity = value; }
        }
        private Dictionary<string, string> chillerCOPR;

        public Dictionary<string, string> ChillerCOPR
        {
            get { return chillerCOPR; }
            set { chillerCOPR = value; }
        }

        private Dictionary<string, string> clrPressureDrop;

        public Dictionary<string, string> ClrPressureDrop
        {
            get { return clrPressureDrop; }
            set { clrPressureDrop = value; }
        }


        private int compareType;
        /// <summary>
        /// 0：交集,1:a 差集,2：b差集
        /// </summary>
        public int CompareType
        {
            get { return compareType; }
            set { compareType = value; }
        }

        private string productName;

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        private string productType;

        public string ProductType
        {
            get { return productType; }
            set { productType = value; }
        }

        private string waringDesc;

        public string WaringDesc
        {
            get { return waringDesc; }
            set { waringDesc = value; }
        }

        private string errorType;
        /// <summary>
        /// 0:无error,1:相同,2:不相同
        /// </summary>
        public string ErrorType
        {
            get { return errorType; }
            set { errorType = value; }
        }

        private string projectName;
        /// <summary>
        /// e3a名称
        /// </summary>
        public string ProjectName
        {
            get { return projectName; }
            set { projectName = value; }
        }

        private double v1RunTimes;
        /// <summary>
        /// 运行时间，单位秒
        /// </summary>
        public double V1RunTimes
        {
            get { return v1RunTimes; }
            set { v1RunTimes = value; }
        }

        private double v2RunTimes;

        public double V2RunTimes
        {
            get { return v2RunTimes; }
            set { v2RunTimes = value; }
        }

        private string fileName;

        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }

    }
}
