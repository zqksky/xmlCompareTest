﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace BIZ
{
    public class CompareBiz
    {
        public static int Seq = 0;

        #region Perf
        
       
        public static List<OutModel> Compare(List<TagModel> listGT, List<TagModel> list)
        {
            //先将两个集合取交集，进行比对将数据
            List<TagModel> listIntersect = listGT.Intersect(list, new TagListEquality()).ToList();
            List<OutModel> outlist = CompareIntersect(listIntersect, list);
            //listGT与交集进行求差集，求出a不存在于b集合的数据
            List<OutModel> lista=  CompareExcept(listIntersect, listGT, 1);
            //list集合与求出的交集，求差集，差集值时b不存在于a中的数据
            List<OutModel> listb= CompareExcept(listIntersect, list, 2);

            outlist.AddRange(lista);
            outlist.AddRange(listb);

                return outlist;
        }

        /// <summary>
        /// 交集
        /// </summary>
        public static List<OutModel> CompareIntersect(List<TagModel> listIntersect,List<TagModel> listC)
        {
            List<OutModel> listout = new List<OutModel>();          
           
            foreach (var gt in listIntersect)
            {
                if (gt.TagName == "Tubing_C5_0.75")
                {
                    string aa = "";
                }
                OutModel om = new OutModel();
                om.CompareType = 0;
                var query = listC.Where(item => item.ChillerModel == gt.ChillerModel && item.TagName == gt.TagName).ToList();
                if (query.Count >= 0)
                {
                    om.ChillerModel = gt.ChillerModel;
                    om.TagName = gt.TagName;
                    om.OperationType = gt.OperationType;
                    om.StarterVFD = gt.StarterVFD;
                    om.FloatBallValueSize = gt.FloatBallValueSize == query[0].FloatBallValueSize ? "Success" : "Fail";
                    om.FloatValueSize = gt.FloatValueSize == query[0].FloatValueSize ? "Success" : "Fail";
                    om.FlascOrifice = gt.FlascOrifice == query[0].FlascOrifice ? "Success" : "Fail";
                    om.TotalOperatingWeight = CompareDouble(gt.TotalOperatingWeight, query[0].TotalOperatingWeight);
                    om.TotalRiggingWeight = CompareDouble(gt.TotalRiggingWeight, query[0].TotalRiggingWeight);
                    om.RefrigerantWeight = CompareDouble(gt.RefrigerantWeight, query[0].RefrigerantWeight);
                    om.CmpSize = gt.CmpSize == query[0].CmpSize ? "Success" : "Fail";
                    om.ProductName = DataProcess.GetProductName(gt.CmpSize);
                    om.ErrorType = "0";
                    om.ProjectName = gt.ProjectName;
                    om.ProductType = DataProcess.GetProductType(om.ProductName);
                    om.V1RunTimes =double.Parse (gt.RunTimes);
                    om.V2RunTimes = double.Parse(query[0].RunTimes);
                    om.FileName = gt.FileName;
                    //errorinfo
                    if (string.IsNullOrEmpty(gt.ErrorsInfo) && string.IsNullOrEmpty(query[0].ErrorsInfo))//两者都正确
                    {
                        
                        if (gt.ChillerCapacity == null || query[0].ChillerCapacity == null)
                        {
                            om.WaringDesc = "Chiller Capacity is null";
                        }
                        else
                        {
                            //先比较partload 100%
                            if (CompareCapacityValue(gt.ChillerCapacity[0], query[0].ChillerCapacity[0]) == "Success")
                            {
                                //1.ChillerCapacity
                                Dictionary<string, string> dicCapGt = InsertDic(gt.PercentLoad, gt.ChillerCapacity);
                                Dictionary<string, string> dicCapQry = InsertDic(query[0].PercentLoad, query[0].ChillerCapacity);
                                //om.ChillerCapacity = CompareCapacityDic(dicCapGt, dicCapQry);
                                om.ChillerCapacity = dicCapGt;//修改至前面显示
                                //2.ChillerCOPR
                                Dictionary<string, string> dicCoprGt = InsertDic(gt.PercentLoad, gt.ChillerCOPR);
                                Dictionary<string, string> dicCoprQry = InsertDic(query[0].PercentLoad, query[0].ChillerCOPR);
                                om.ChillerCOPR = ComparePercentTageDic(dicCoprGt, dicCoprQry);
                                //3.ClrPressureDrop
                                Dictionary<string, string> dicClrPressGt = InsertDic(gt.PercentLoad, gt.ClrPressureDrop);
                                Dictionary<string, string> dicClrPressQry = InsertDic(query[0].PercentLoad, query[0].ClrPressureDrop);
                                om.ClrPressureDrop = ComparePercentTageDic(dicClrPressGt, dicClrPressQry);
                                //4.CndPressureDrop
                                Dictionary<string, string> dicCndPressGt = InsertDic(gt.PercentLoad, gt.CndPressureDrop);
                                Dictionary<string, string> dicCndPressQry = InsertDic(query[0].PercentLoad, query[0].CndPressureDrop);
                                om.CndPressureDrop = ComparePercentTageDic(dicCndPressGt, dicCndPressQry);
                                //5.PercentLoad
                                om.PercentLoad = gt.PercentLoad.Union(query[0].PercentLoad).Distinct().ToList();
                            }
                            else
                            {
                                //不同，则整个partload group都不进行比对
                                om.WaringDesc = "Chiller Capacity 100% value different";
                                Dictionary<string, string> dicCapGt = InsertDic(gt.PercentLoad, gt.ChillerCapacity);
                                om.ChillerCapacity = dicCapGt;//修改至前面显示
                                om.PercentLoad = gt.PercentLoad.Union(query[0].PercentLoad).Distinct().ToList();
                            }
                        }
                    }
                    else if (!string.IsNullOrEmpty(gt.ErrorsInfo) && !string.IsNullOrEmpty(query[0].ErrorsInfo))//两者都不正确
                    { 
                        //比较错误信息是否相同
                        if (gt.ErrorsInfo == query[0].ErrorsInfo)
                        {
                            om.ErrorType = "0";
                            om.WaringDesc = "Error message of two version align";                            
                        }
                        else
                        {
                            om.ErrorType = "2";
                            om.WaringDesc = "Error message of two version conflict";
                        }

                    }
                    else if (string.IsNullOrEmpty(gt.ErrorsInfo) && !string.IsNullOrEmpty(query[0].ErrorsInfo))//原来正确，现在不正确
                    {
                        om.ErrorType = "2";
                        om.WaringDesc = "Groundtruth is correct,but report error in validation";
                    }
                    else if (!string.IsNullOrEmpty(gt.ErrorsInfo) && string.IsNullOrEmpty(query[0].ErrorsInfo))//原来不正确，现在正确
                    {
                        om.ErrorType = "1";
                        om.WaringDesc = "Groundtruth is wrong,but validation is correct";               
                    }
                    listout.Add(om);
                }
            }
            return listout;
        }


        /// <summary>
        /// 差集
        /// </summary>
        public static List<OutModel> CompareExcept(List<TagModel> listIntersect, List<TagModel> list, int flag)
        {
            List<TagModel> listExcept = list.Except(listIntersect, new TagListEquality()).ToList();
            
            List<OutModel> listout = new List<OutModel>();
            foreach(var m in listExcept)
            {
                if (m.TagName == "Tubing_C5_0.75")
                {
                    string aa = "";
                }
                OutModel om = new OutModel();
                om.CompareType = flag;
                om.ChillerModel = m.ChillerModel;
                om.TagName = m.TagName;
                om.OperationType = m.OperationType;
                om.StarterVFD = m.StarterVFD;
                om.FloatBallValueSize = m.FloatBallValueSize;
                om.FloatValueSize = m.FloatValueSize;
                om.FlascOrifice = m.FlascOrifice ;
                om.TotalOperatingWeight = m.TotalOperatingWeight;
                om.TotalRiggingWeight =m.TotalRiggingWeight;
                om.RefrigerantWeight = m.RefrigerantWeight;
                om.CmpSize = m.CmpSize;
                om.ProductName = DataProcess.GetProductName(m.CmpSize);

                om.ProductType = DataProcess.GetProductType(om.ProductName);
                om.ProjectName = m.ProjectName;
                om.FileName = m.FileName;
                //1.ChillerCapacity
                Dictionary<string, string> dicCapGt = InsertDic(m.PercentLoad, m.ChillerCapacity);
                
                om.ChillerCapacity =dicCapGt;
                //2.ChillerCOPR
                Dictionary<string, string> dicCoprGt = InsertDic(m.PercentLoad, m.ChillerCOPR);
                
                om.ChillerCOPR = dicCoprGt;
                //3.ClrPressureDrop
                Dictionary<string, string> dicClrPressGt = InsertDic(m.PercentLoad, m.ClrPressureDrop);
                
                om.ClrPressureDrop = dicClrPressGt;
                //4.CndPressureDrop
                Dictionary<string, string> dicCndPressGt = InsertDic(m.PercentLoad, m.CndPressureDrop);
                
                om.CndPressureDrop = dicCndPressGt;
                //5.PercentLoad
                om.PercentLoad = m.PercentLoad;
                om.ErrorType = "0";
                if (flag == 1)
                {
                    om.WaringDesc = "This tag in groundtruth ,not found in validation  ";
                    //原存在，但是错误
                    if (!string.IsNullOrEmpty(m.ErrorsInfo))
                    {
                        om.ErrorType = "2";
                        om.WaringDesc = om.WaringDesc + " but report error  in  groundtruth";
                    }
                    else {
                        om.ErrorType = "3";
                        om.WaringDesc = om.WaringDesc ;
                    }
                    om.V1RunTimes = double.Parse(m.RunTimes);
                }
                else if(flag==2)
                {
                    om.WaringDesc = "This tag in validation ,not found in groundtruth  ";
                    //现在存在原来不存在，但是错误
                    if (!string.IsNullOrEmpty(m.ErrorsInfo))
                    {
                        om.ErrorType = "2";
                        om.WaringDesc = om.WaringDesc + " but report error in  validation . ";
                    }
                    else
                    {
                        om.ErrorType = "3";
                        om.WaringDesc = om.WaringDesc ;
                    }
                    om.V2RunTimes = double.Parse(m.RunTimes);
                }
                listout.Add(om);
             }

                return listout;
        }

        public static Dictionary<string,string> InsertDic( List<string> partload,List<string> value)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            if(value!=null)
            for (int i = 0; i < partload.Count; i++)
            {
                dic.Add(partload[i], value[i]);
            }
            return dic;
        }

        /// <summary>
        /// 字符比较
        /// </summary>
        /// <param name="gt"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        public static Dictionary<string ,string > CompareCapacityDic(Dictionary<string,string> gt,Dictionary<string,string> cm)
        {
            Dictionary<string, string> rt = new Dictionary<string, string>();
            string formatStr1 = "GT";
            string formatStr2 = "CM";
             List<string> listKeys= gt.Keys.Union(cm.Keys).ToList();
             for (int i = 0; i < listKeys.Count; i++)
             {
                 if (gt.ContainsKey(listKeys[i]) && cm.ContainsKey(listKeys[i]))//两者都有对应的partload
                 {                   
                     rt.Add(listKeys[i],CompareCapacityValue(gt[listKeys[i]], cm[listKeys[i]]));
                 }
                 else if (!gt.ContainsKey(listKeys[i]) && cm.ContainsKey(listKeys[i]))//cm有 gt无
                 {

                     rt.Add(listKeys[i], formatStr2);
                 }
                 else if (gt.ContainsKey(listKeys[i]) && !cm.ContainsKey(listKeys[i]))//gt有，cm无
                 {
                     rt.Add(listKeys[i], formatStr1);
                 }

             }
            return rt;
        }

        private static string CompareCapacityValue(string gt, string cm)
        {
            double re = (Math.Abs(double.Parse(gt) - double.Parse(cm)) /
                        double.Parse(cm));
            if (re <= 0.0005)
            {
                return "Success";
            }
            else
            {
              return   "Fail";
            }
        }

        /// <summary>
        /// 结果为数值比较
        /// </summary>
        /// <param name="gt"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        public static Dictionary<string, string> ComparePercentTageDic(Dictionary<string, string> gt, Dictionary<string, string> cm)
        {
            Dictionary<string, string> rt = new Dictionary<string, string>();
            string formatStr1 = "GT";
            string formatStr2 = "CM";
            List<string> listKeys = gt.Keys.Union(cm.Keys).ToList();
            for (int i = 0; i < listKeys.Count; i++)
            {
                if (gt.ContainsKey(listKeys[i]) && cm.ContainsKey(listKeys[i]))//两者都有对应的partload
                {
                    //计算误差(valid- GT)/GT, format .00%
                    if (gt[listKeys[i]] == cm[listKeys[i]])
                    {
                        rt.Add(listKeys[i], ".00");
                    }
                    else
                    {
                       rt.Add(listKeys[i], CompareDouble(gt[listKeys[i]],cm[listKeys[i]]));
                    }
                }
                else if (!gt.ContainsKey(listKeys[i]) && cm.ContainsKey(listKeys[i]))//cm有 gt无
                {

                    rt.Add(listKeys[i], formatStr2);
                }
                else if (gt.ContainsKey(listKeys[i]) && !cm.ContainsKey(listKeys[i]))//gt有，cm无
                {
                    rt.Add(listKeys[i], formatStr1);
                }

            }
            return rt;
        }


        public static string CompareDouble(string gt, string cm)
        { 
            //sub
            double dvalid = 0;
            double dgt = 0;
            string rtn = "";
            if (double.TryParse(gt, out dgt) && double.TryParse(cm, out dvalid))
            {
                string tmp = ((dvalid - dgt) / dgt).ToString();
                rtn = tmp;
            }
            else
            {
                rtn = "error";//先返回error用于判断，具体值在优化
            }
            return rtn;
        }

        #endregion

        #region Selections
        public static List<OutSelectionsModel> CompareSelections(List<SelectionsModel> listGT, List<SelectionsModel> list)
        {
            List<OutSelectionsModel> listOut = new List<OutSelectionsModel>();
            //先将两个集合取交集，进行比对将数据
            List<SelectionsModel> listIntersect = listGT.Intersect(list, new SelectionModelEquality()).ToList();
            //先根据 projectName TagName 过滤数据
            listOut=CompareSelectionsModelIntersect(listIntersect, list);
            List<SelectionsModel> listTmpExcept = listGT.Except(listIntersect, new SelectionModelEquality()).ToList();
            if (listTmpExcept.Count>0)
            listOut.AddRange(GetSelectionsModelExcept(listTmpExcept,"1"));
            listTmpExcept = list.Except(listIntersect, new SelectionModelEquality()).ToList();
            if (listTmpExcept.Count > 0)
                listOut.AddRange(GetSelectionsModelExcept(listTmpExcept, "2"));
            return listOut;
        }

        public static List<OutSelectionsModel> CompareSelectionsModelIntersect(List<SelectionsModel> listIntersect, List<SelectionsModel> listVal)
        {
            List<OutSelectionsModel> listOut = new List<OutSelectionsModel>();
            string isPssPerf="1";
            foreach (var gt in listIntersect)
            {
                List<SelectionsOutListModel> soListModel = new List<SelectionsOutListModel>();
                OutSelectionsModel model = new OutSelectionsModel();
                model.ProjectName = gt.ProjectName;
                model.TagName = gt.TagName;
                model.Seq= "Tag_" + Seq.ToString("00000");
                model.WaringType = "0";
                model.FileName = gt.FileName;
                var query = listVal.Where(item => item.ProjectName.ToLower() == gt.ProjectName.ToLower() && item.TagName.ToLower() == gt.TagName.ToLower()).ToList();
                if (query.Count > 0)
                { 
                    //求交差集算数量，以model为主键
                    List<SelectionsReadModel> listTmpIntersect = gt.ListSelectionsReadModel.Intersect(query[0].ListSelectionsReadModel, new SelectionSumModelEquality()).ToList();
                    model.CommonCandidatates = listTmpIntersect.Count;
                    //比较交集
                    soListModel = CompareSelectionsModelListIntersect(listTmpIntersect, query[0].ListSelectionsReadModel, out isPssPerf);
                    //求差集
                    List<SelectionsReadModel> listTmpExcept = gt.ListSelectionsReadModel.Except(listTmpIntersect, new SelectionSumModelEquality()).ToList();
                    model.V1 = listTmpExcept.Count;                   
                    soListModel.AddRange( GetModelListExcept(listTmpExcept, "1"));
                    //填差集
                    listTmpExcept = query[0].ListSelectionsReadModel.Except(listTmpIntersect, new SelectionSumModelEquality()).ToList();
                    model.V2 = listTmpExcept.Count;
                    soListModel.AddRange(GetModelListExcept(listTmpExcept, "2"));

                    if (model.V1 > 0 || model.V2 > 0)
                    {
                        model.IsPassSelections = "0";
                    }
                    else
                    {
                        model.IsPassSelections = "1";
                    }
                    model.IsPassPerf = isPssPerf;
                    model.ListSelections = soListModel;
                    Seq++;
                    listOut.Add(model);
                }
              
            }
            return listOut;
        }

        public static List<SelectionsOutListModel> CompareSelectionsModelListIntersect(  List<SelectionsReadModel> lstGt,  List<SelectionsReadModel> lstVal,out string IsPassPerf)
        {
            List<SelectionsOutListModel> listout = new List<SelectionsOutListModel>();
            IsPassPerf = "1";
            foreach (var gt in lstGt)
            {
                var query = lstVal.Where(item => item.ChillerModel.ToLower() == gt.ChillerModel.ToLower()).ToList();
                SelectionsOutListModel model = new SelectionsOutListModel();
                if (query.Count > 0)
                {                    
                    model.OutModel = "0";
                    model.ChillerModel = gt.ChillerModel;
                    //Capacity
                    model.Capacity= gt.Capacity;
                    //Cooler Pass
                    model.ClrPass = gt.ClrPass == query[0].ClrPass ? "Success" : "Fail";
                    //Condenser Pass
                    model.CndPass = gt.CndPass == query[0].CndPass ? "Success" : "Fail";
                    //full load kW/Ton
                    model.FullLoad= CompareDouble(gt.FullLoad, query[0].FullLoad); 
                    //IPLV Kw/Ton
                    model.IPLV = CompareDouble(gt.IPLV, query[0].IPLV); 
                    //Cooler Pressure Drop
                    model.ClrPressDrop = CompareDouble(gt.ClrPressDrop, query[0].ClrPressDrop); 
                    //Condenser Pressure Drop
                    model.CndPressDrop = CompareDouble(gt.CndPressDrop, query[0].CndPressDrop); 
                    //Price
                    model.Price = CompareDouble(gt.Price, query[0].Price);
                    IsPassPerf=  GetPassPerf(model);
                }
                listout.Add(model);
            }
            return listout;
        }

        public static List<SelectionsOutListModel> GetModelListExcept(List<SelectionsReadModel> listEx,string flag)
        {
            List<SelectionsOutListModel> listOut=new List<SelectionsOutListModel> ();
            foreach (var ex in listEx)
            {
                SelectionsOutListModel model = new SelectionsOutListModel();
                model.OutModel = flag;
                model.Capacity = ex.Capacity;
                model.ChillerModel = ex.ChillerModel;
                model.ClrPass = ex.ClrPass;
                model.CndPass = ex.CndPass;
                model.ClrPressDrop = ex.ClrPressDrop;
                model.CndPressDrop = ex.CndPressDrop;
                model.FullLoad = ex.FullLoad;
                model.IPLV = ex.IPLV;
                model.Price = ex.Price;
                listOut.Add(model);
            }

            return listOut;
        }

        public static string GetPassPerf(SelectionsOutListModel model)
        {
            string rtn = "1";
            if (model.Capacity == "Fail" || model.ClrPass == "Fail" || model.CndPass == "Fail")
            {
                rtn = "0";
            }
            if (double.Parse(model.FullLoad) != 0 || double.Parse(model.IPLV) != 0 || double.Parse(model.ClrPressDrop) != 0 || double.Parse(model.CndPressDrop) != 0)
            {
                rtn = "0";
            }
            return rtn;
        }

        public static List<OutSelectionsModel> GetSelectionsModelExcept(List<SelectionsModel> listEx,string flg)        
        {
            List<OutSelectionsModel> listOut = new List<OutSelectionsModel>();
            foreach (var ex in listEx)
            {
                OutSelectionsModel model = new OutSelectionsModel();
                model.FileName = ex.FileName;
                model.WaringType = flg;
                model.ProjectName = ex.ProjectName;
                model.TagName = ex.TagName;
                model.Seq = "Tag_" + Seq.ToString("00000");;
                Seq++;
                listOut.Add(model);
            }

            return listOut;
        }

        #endregion

    }
}
