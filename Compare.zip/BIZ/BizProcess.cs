﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.HSSF.UserModel;
using System.IO;

namespace BIZ
{
    public static class BizProcess
    {
        public static ResultModel  ProcessPer(string inPathGt,string inPathVal,string folderlist,string outPath,string userType)
        {
            ResultModel md = new ResultModel();
            if (string.IsNullOrEmpty(inPathGt) || string.IsNullOrEmpty(inPathVal) || string.IsNullOrEmpty(folderlist) || string.IsNullOrEmpty(outPath))
            {
                md.Result = false;
                md.ResultDesc = "Error of input parameter";
                return md;
            }
            bool b = false;
            //获取比较文件夹数量
            List<string> folders = folderlist.Split(',').ToList();
            //校验两个输入路径下文件是否合法
            b = CheckFoldrs(folders, inPathGt);
            if (!b)
            {
                md.Result = false;
                md.ResultDesc = "GT Folder check failure";
                return md;
            }
            b = CheckFoldrs(folders, inPathVal);
            if (!b)
            {
                md.Result = false;
                md.ResultDesc = "Val Folder check failure";
                return md;
            }
            HSSFWorkbook workbook = new HSSFWorkbook();
            ////循环读取文件夹下数据处理
            List<SummaryPerfModel> listV1 = new List<SummaryPerfModel>();
            List<SummaryPerfModel> listV2 = new List<SummaryPerfModel>();
            foreach (var fs in folders)
            { 
                List<TagModel> list1 = FileBiz.ReadTxtFiles((@inPathGt + @"\" + fs));
                if (list1.Count > 0)
                { 
                    ExcelUtility.ListModelToExcel(list1,@outPath,workbook,userType,fs+"_GT");
                }
               
                List<TagModel> list2 = FileBiz.ReadTxtFiles((@inPathVal + @"\" + fs));
                if (list2.Count > 0)
                {
                    ExcelUtility.ListModelToExcel(list2, @outPath, workbook, userType, fs + "_Val");
                }
                List<OutModel> list3 = CompareBiz.Compare(list1, list2);

                listV1.AddRange( FileBiz.GetSummaryPerf(list1, fs, "V1"));
                listV2.AddRange ( FileBiz.GetSummaryPerf(list2, fs, "V2"));
               
                if (list3.Count > 0)
                    b = ExcelUtility.ListPerfModelToExcel(list3, @outPath, workbook,userType, fs);
             }
            List<OutSummaryPerfModel> listOutSum = FileBiz.SummaryDataProcess(listV1, listV2);
            if(listOutSum.Count>0)
                b = ExcelUtility.ListPerfSummaryToExcel(listOutSum, @outPath, workbook);

          
            if (b)
            {
                md.Result = b;
                md.ResultDesc = "Successfully";
            }
            else
            {
                md.Result = b;
                md.ResultDesc = "failed";
            }
           return md;
        }


        public static void ProcessSelectInputs(string inPathGt, string inPathVal, string folderlist, string outPath)
        { 
            //读取文件
            //FileBiz.ReadSelectionFileTxt();
            List<string> folders = folderlist.Split(',').ToList();
            List<SummaryPerfModel> listSummary = new List<SummaryPerfModel>();
            bool b = false;
            foreach (var fs in folders)
            {
                CompareBiz.Seq = 0;//初始化序号
                List<SelectionsModel> list1 = FileBiz.ReadSelectionsFiles((@inPathGt + @"\" + fs));
                List<SelectionsModel> list2 = FileBiz.ReadSelectionsFiles((@inPathVal + @"\" + fs));
                //比较
                List<OutSelectionsModel> list3= CompareBiz.CompareSelections(list1, list2);
                //输出多个文件
                HSSFWorkbook workbook = new HSSFWorkbook();
                ExcelUtility.ListSelectionsModelToExcel(list3, outPath + @"\" + fs + ".xls", workbook);
            }


        }


        public static bool CheckFoldrs(List<string> folders, string path)
        {
            bool b = true;
            foreach (var f in folders)
            {
                if (!TextFileHelper.FolderIsExists(path + @"\" + f))
                {
                    b = false;
                    break;
                }

            }
            return b;
        }
    }
}
