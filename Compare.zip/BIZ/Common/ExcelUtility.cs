﻿using System;
using System.Data;
using System.IO;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;
using System.Collections.Generic;
using System.Linq;
using NPOI.SS.Util;
using NPOI.HSSF.Util;
namespace BIZ
{
    public class ExcelUtility
    {
       
        private static ICellStyle defStyle = null;
        private static ICellStyle titleStyle = null;
        private static ICellStyle failStyle = null;
        private static ICellStyle doubleStyle = null;
        private static ICellStyle greenStyle = null;
        private static ICellStyle orangeStyle = null;

        public static bool ListModelToExcel(List<TagModel> listOut, string savePath, HSSFWorkbook workbook, string userType, string sheetName = "Sheet0")
        {
            bool result = false;

            FileStream fs = null;
            IRow row = null;
            ISheet sheet = null;
            ICell cell = null;
            defStyle = GetDefaultStyle(workbook);
            titleStyle = GetTitleStyle(workbook);
          
            int nStartRow = 1;
            int nOpStartNum = 1;
            int nProStartNum = 1;
            int nProTypeStartNum = 1;
            int nEndRow = 1;
            //try
            //{
            if (listOut != null && listOut.Count > 0)
            {
                sheet = workbook.CreateSheet(sheetName);//创建一个名称为Sheet0的表
                //设置列头
                row = sheet.CreateRow(0);//excel第一行设为列头
                List<string> lstColName = DataProcess.GetPerfExcelColumnName();
                int c = 0;
                for (c = 0; c < lstColName.Count; c++)
                {
                    cell = row.CreateCell(c);
                    SetCellValue(cell, lstColName[c], titleStyle);
                    sheet.SetColumnWidth(c, 20 * 256);
                }
                //自定义列
                if (userType == "0")
                {
                    lstColName = DataProcess.GetCustomExcelColumnName();
                    int idx = 0;
                    for (int j = c; j < c + lstColName.Count; j++)
                    {
                        cell = row.CreateCell(j);
                        SetCellValue(cell, lstColName[idx], titleStyle);
                        sheet.SetColumnWidth(j, 20 * 256);
                        idx++;
                    }
                }

                //数据筛选
                //先选出Operation
                List<string> listOperation = listOut.Select(t => t.OperationType).ToList().Distinct().ToList();
                int nOperationTypeNum = listOperation.Count;
                //排序listOperation
                listOperation.Sort();
                for (int i = 0; i < listOperation.Count; i++)
                {
                    if (listOperation[i] == null)
                    {
                        continue;
                    }
                    //操作类型分类
                    List<TagModel> listProType = listOut.Where(t => t.OperationType == listOperation[i]).ToList();
                    List<string> lstProType = listProType.Select(t => t.ProductType).ToList().Distinct().ToList();
                    foreach (var pt in lstProType)
                    {
                        //操作模式分类
                        List<TagModel> listCmpType = listProType.Where(t => t.ProductType == pt).ToList();
                        List<string> lstPro = listCmpType.Select(t => t.ProductName).ToList().Distinct().ToList();
                        //排序listPro
                        lstPro.Sort();
                        for (int j = 0; j < lstPro.Count; j++)
                        {
                            //根据产品分类数据
                            List<TagModel> listProduct = listCmpType.Where(t => t.ProductName == lstPro[j]).ToList();
                            //排序
                            var lstProQuery = from product in listProduct
                                              orderby
                                                  product.StarterVFD
                                              select product;
                            foreach (var pro in listProduct)
                            {
                                //填写数据
                                nStartRow = nEndRow;
                                row = sheet.CreateRow(nEndRow);
                                cell = row.CreateCell(0);//空前两个用于合并
                                SetCellValue(cell, pro.OperationType, defStyle);
                                cell = row.CreateCell(1);
                                SetCellValue(cell, pro.ProductType, defStyle);
                                cell = row.CreateCell(2);
                                SetCellValue(cell, pro.ProductName, defStyle);
                                //3.tagName
                                cell = row.CreateCell(3);
                                SetCellValue(cell, pro.TagName, defStyle);
                                //4.ChillerModel
                                cell = row.CreateCell(4);
                                SetCellValue(cell, pro.ChillerModel, defStyle);
                                //5.ChillerCap
                                cell = row.CreateCell(5);
                                if (pro.ChillerCapacity != null && pro.PercentLoad != null)
                                {
                                    SetCellValue(cell, pro.ChillerCapacity[0], defStyle);
                                }
                                //6.StarterVFd
                                cell = row.CreateCell(6);
                                SetCellValue(cell, pro.StarterVFD, defStyle);
                                //7.HighSideValue
                                cell = row.CreateCell(7);
                                SetCellValue(cell, pro.FloatValueSize,defStyle);
                                //8.LowSideValue
                                cell = row.CreateCell(8);
                                SetCellValue(cell, pro.FloatBallValueSize, defStyle);
                                //9.FlascOrifice
                                cell = row.CreateCell(9);
                                SetCellValue(cell, pro.FlascOrifice, defStyle);
                                //10.TotalOperatingWeight
                                cell = row.CreateCell(10);
                                if (pro.TotalOperatingWeight != null && pro.TotalOperatingWeight.ToLower() != "error")
                                    SetCellValue(cell, double.Parse(pro.TotalOperatingWeight));
                                //11.TotalRiggingWeight
                                cell = row.CreateCell(11);
                                if (pro.TotalRiggingWeight != null && pro.TotalRiggingWeight.ToLower() != "error")
                                    SetCellValue(cell, double.Parse(pro.TotalRiggingWeight));
                                //12.RefrigerantWeight
                                cell = row.CreateCell(12);
                                if (pro.RefrigerantWeight != null && pro.RefrigerantWeight.ToLower() != "error")
                                    SetCellValue(cell, double.Parse(pro.RefrigerantWeight));


                                if (!string.IsNullOrEmpty(pro.ErrorsInfo))
                                {
                                    cell = row.CreateCell(13);
                                    cell = row.CreateCell(14);
                                    SetCellValue(cell, pro.ErrorsInfo, defStyle);
                                    cell = row.CreateCell(15);
                                    cell = row.CreateCell(16);
                                    MergeCells(sheet, nStartRow, nStartRow, 14, 16);
                                    nEndRow++;
                                    //添加用户自定义列
                                    if (userType == "0")
                                    {
                                        cell = row.CreateCell(17);
                                        SetCellValue(cell, pro.RunTimes.ToString(), defStyle);
                                      
                                        cell = row.CreateCell(18);
                                        SetCellValue(cell, pro.ProjectName, defStyle);
                                        cell = row.CreateCell(19);
                                        SetCellValue(cell, pro.FileName, defStyle);
                                    }
                                
                                }
                                else
                                {
                                    //13.PercentLoad
                                    cell = row.CreateCell(13);
                                    SetCellValue(cell, pro.PercentLoad[0], defStyle);
                                    //14.ChillerCOPR
                                    cell = row.CreateCell(14);
                                    //SetCellValue(cell, pro.ChillerCOPR[pro.PercentLoad[0]], workbook, 2);
                                    SetCellValue(cell, pro.ChillerCOPR[0], defStyle);
                                    //15.ClrPressureDrop
                                    cell = row.CreateCell(15);
                                    //SetCellValue(cell, pro.ClrPressureDrop[pro.PercentLoad[0]], workbook, 2);
                                    SetCellValue(cell, pro.ClrPressureDrop[0], defStyle);
                                    //16.CndPressureDrop
                                    cell = row.CreateCell(16);
                                    //SetCellValue(cell, pro.CndPressureDrop[pro.PercentLoad[0]], workbook, 2);
                                    SetCellValue(cell, pro.CndPressureDrop[0], defStyle);
                                    nEndRow++;
                                    List<string> listPl = pro.PercentLoad;
                                    //添加用户自定义列
                                    if (userType == "0")
                                    {
                                        cell = row.CreateCell(17);
                                        SetCellValue(cell, pro.RunTimes.ToString(), defStyle);
                                        cell = row.CreateCell(18);
                                        SetCellValue(cell, pro.ProjectName.ToString(), defStyle);
                                        cell = row.CreateCell(19);
                                        SetCellValue(cell, pro.FileName, defStyle);
                                    }
                                    for (int p = 1; p < listPl.Count; p++)
                                    {
                                        row = sheet.CreateRow(nEndRow);
                                        CreateDefaultCell(cell, row);
                                        //11.PercentLoad
                                        cell = row.CreateCell(13);
                                        SetCellValue(cell, listPl[p], defStyle);

                                      
                                        {
                                            //14.ChillerCOPR
                                            cell = row.CreateCell(14);
                                            SetCellValue(cell, pro.ChillerCOPR[p], defStyle);
                                            //15.ClrPressureDrop
                                            cell = row.CreateCell(15);
                                            SetCellValue(cell, pro.ClrPressureDrop[p], defStyle);

                                            //16.CndPressureDrop
                                            cell = row.CreateCell(16);
                                            SetCellValue(cell, pro.CndPressureDrop[p], defStyle);
                                        }

                                        nEndRow++;
                                    }

                                }

                                //合并单元格
                                MergeDataCells(sheet, 3, 12, nStartRow, nEndRow - 1);
                                MergeDataCells(sheet, 17, 20, nStartRow, nEndRow - 1);

                            }
                            //合并产品单元格
                            MergeDataCells(sheet, 2, 2, nProStartNum, nEndRow - 1);
                            nProStartNum = nEndRow;
                        }
                        //合并产品类型单元格
                        MergeDataCells(sheet, 1, 1, nProTypeStartNum, nEndRow - 1);
                        nProTypeStartNum = nEndRow;
                    }
                    //合并模式单元格
                    MergeDataCells(sheet, 0, 0, nOpStartNum, nEndRow - 1);
                    nOpStartNum = nEndRow;
                }

                //保存文件
                using (fs = File.OpenWrite(savePath))
                {
                    workbook.Write(fs);//向打开的这个xls文件中写入数据
                    result = true;
                }
            }

            return result;
            //}
            //catch (Exception ex)
            //{
            //    return false;
            //}
            //finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
        }

        public static bool ListPerfModelToExcel(List<OutModel> listOut, string savePath, HSSFWorkbook workbook,string userType, string sheetName = "Sheet0")
        {
            bool result = false;

            FileStream fs = null;
            IRow row = null;
            ISheet sheet = null;
            ICell cell = null;
            defStyle = GetDefaultStyle(workbook);
            titleStyle=GetTitleStyle(workbook);
            failStyle = GetFailStyle(workbook);
            doubleStyle = GetDoubleStyle(workbook);
            greenStyle = GetGreenStyle(workbook);
            orangeStyle = GetOrangeStyle(workbook);
            int nStartRow = 1;
            int nOpStartNum = 1;
            int nProStartNum = 1;
            int nProTypeStartNum = 1;
            int nEndRow = 1;
            //try
            //{
                if (listOut != null && listOut.Count > 0)
                {
                    sheet = workbook.CreateSheet(sheetName);//创建一个名称为Sheet0的表
                    //设置列头
                    row = sheet.CreateRow(0);//excel第一行设为列头
                    List<string> lstColName = DataProcess.GetPerfExcelColumnName();
                    int c = 0;
                    for ( c = 0; c < lstColName.Count; c++)
                    {
                        cell = row.CreateCell(c);
                        SetCellValue(cell, lstColName[c], titleStyle);
                        sheet.SetColumnWidth(c, 20 * 256);
                    }
                    //自定义列
                    if (userType == "0")
                    {
                        lstColName = DataProcess.GetCustomPerfExcelColumnName();
                        int idx = 0;
                        for (int j = c; j < c + lstColName.Count; j++)
                        {
                            cell = row.CreateCell(j);
                            SetCellValue(cell, lstColName[idx], titleStyle);
                            sheet.SetColumnWidth(j, 20 * 256);
                            idx++;
                        }
                    }

                    //数据筛选
                    //先选出Operation
                    List<string> listOperation = listOut.Select(t => t.OperationType).ToList().Distinct().ToList();
                    int nOperationTypeNum = listOperation.Count;
                    //排序listOperation
                    listOperation.Sort();
                    for (int i = 0; i < listOperation.Count; i++)
                    {
                        if (listOperation[i] == null)
                        {
                            continue;
                        }
                        //操作类型分类
                        List<OutModel> listProType = listOut.Where(t => t.OperationType == listOperation[i]).ToList();
                        List<string> lstProType = listProType.Select(t => t.ProductType).ToList().Distinct().ToList();
                        foreach (var pt in lstProType)
                        {
                            //操作模式分类
                            List<OutModel> listCmpType = listProType.Where(t => t.ProductType == pt).ToList();
                            List<string> lstPro = listCmpType.Select(t => t.ProductName).ToList().Distinct().ToList();
                            //排序listPro
                            lstPro.Sort();
                            for (int j = 0; j < lstPro.Count; j++)
                            {
                                //根据产品分类数据
                                List<OutModel> listProduct = listCmpType.Where(t => t.ProductName == lstPro[j]).ToList();
                                //排序
                                var lstProQuery = from product in listProduct
                                                  orderby
                                                      product.StarterVFD
                                                  select product;
                                foreach (var pro in listProduct)
                                {
                                    //填写数据
                                    nStartRow = nEndRow;
                                    row = sheet.CreateRow(nEndRow);
                                    cell = row.CreateCell(0);//空前两个用于合并
                                    SetCellValue(cell, pro.OperationType, defStyle);
                                    cell = row.CreateCell(1);
                                    SetCellValue(cell, pro.ProductType, defStyle);
                                    cell = row.CreateCell(2);
                                    SetCellValue(cell, pro.ProductName, defStyle);                                  
                                    //3.tagName
                                    cell = row.CreateCell(3);
                                    SetCellValue(cell, pro.TagName, defStyle);
                                    //4.ChillerModel
                                    cell = row.CreateCell(4);
                                    SetCellValue(cell, pro.ChillerModel, defStyle);
                                    //5.ChillerCap
                                    cell = row.CreateCell(5);
                                    if (pro.ChillerCapacity != null && pro.PercentLoad != null)
                                    {                                        
                                        SetCellValue(cell, pro.ChillerCapacity[pro.PercentLoad[0]], defStyle);
                                    }
                                    //6.StarterVFd
                                    cell = row.CreateCell(6);
                                    SetCellValue(cell, pro.StarterVFD, defStyle);
                                    //7.HighSideValue
                                    cell = row.CreateCell(7);
                                    SetCellValue(cell, pro.FloatValueSize, workbook, 1);                                    
                                    //8.LowSideValue
                                    cell = row.CreateCell(8);
                                    SetCellValue(cell, pro.FloatBallValueSize,workbook, 1);
                                    //9.FlascOrifice
                                    cell = row.CreateCell(9);                                    
                                    SetCellValue(cell, pro.FlascOrifice, workbook, 1);
                                    //10.TotalOperatingWeight
                                    cell = row.CreateCell(10);                                                                       
                                    if (pro.TotalOperatingWeight!=null && pro.TotalOperatingWeight.ToLower()!="error")
                                    SetCellValue(cell, double.Parse(pro.TotalOperatingWeight));
                                    //11.TotalRiggingWeight
                                    cell = row.CreateCell(11);
                                    if (pro.TotalRiggingWeight != null && pro.TotalRiggingWeight.ToLower() != "error")                                   
                                    SetCellValue(cell, double.Parse(pro.TotalRiggingWeight));
                                    //12.RefrigerantWeight
                                    cell = row.CreateCell(12);
                                    if (pro.RefrigerantWeight != null && pro.RefrigerantWeight.ToLower() != "error")                                   
                                    SetCellValue(cell, double.Parse(pro.RefrigerantWeight));
                                   

                                    if (!string.IsNullOrEmpty(pro.WaringDesc))
                                    {
                                        cell = row.CreateCell(13);                                       
                                        cell = row.CreateCell(14);
                                        if (pro.ErrorType == "0")
                                        {
                                            if (pro.CompareType != 0)
                                            {
                                                SetCellValue(cell, pro.WaringDesc, orangeStyle);
                                            }
                                            else
                                            {
                                                SetCellValue(cell, pro.WaringDesc, greenStyle);
                                            }
                                        }
                                        else
                                        {
                                            if (pro.ErrorType == "1" || pro.ErrorType == "3" )
                                            {
                                                SetCellValue(cell, pro.WaringDesc, orangeStyle);
                                            }
                                            else if (pro.ErrorType == "2")
                                            {
                                                SetCellValue(cell, pro.WaringDesc, failStyle);
                                            }
                                            
                                        }
                                        cell = row.CreateCell(15);
                                        cell = row.CreateCell(16);
                                        MergeCells(sheet, nStartRow, nStartRow, 14, 16);
                                        nEndRow++;
                                        //添加用户自定义列
                                        if (userType == "0")
                                        {
                                            cell = row.CreateCell(17);
                                            SetCellValue(cell, pro.V1RunTimes.ToString(), defStyle);
                                            cell = row.CreateCell(18);
                                            SetCellValue(cell, pro.V2RunTimes.ToString(), defStyle);
                                            cell = row.CreateCell(19);
                                            SetCellValue(cell, pro.ProjectName, defStyle);
                                            cell = row.CreateCell(20);
                                            SetCellValue(cell, pro.FileName, defStyle);
                                        }
                                    }
                                    else
                                    {                                      
                                            //13.PercentLoad
                                            cell = row.CreateCell(13);
                                            SetCellValue(cell, pro.PercentLoad[0], defStyle);
                                            //14.ChillerCOPR
                                            cell = row.CreateCell(14);                                            
                                            //SetCellValue(cell, pro.ChillerCOPR[pro.PercentLoad[0]], workbook, 2);
                                            SetCellValue(cell, double.Parse(pro.ChillerCOPR[pro.PercentLoad[0]]));
                                            //15.ClrPressureDrop
                                            cell = row.CreateCell(15);                                            
                                            //SetCellValue(cell, pro.ClrPressureDrop[pro.PercentLoad[0]], workbook, 2);
                                            SetCellValue(cell, double.Parse(pro.ClrPressureDrop[pro.PercentLoad[0]]));
                                            //16.CndPressureDrop
                                            cell = row.CreateCell(16);
                                            //SetCellValue(cell, pro.CndPressureDrop[pro.PercentLoad[0]], workbook, 2);
                                            SetCellValue(cell, double.Parse(pro.CndPressureDrop[pro.PercentLoad[0]]));
                                            nEndRow++;
                                            List<string> listPl = pro.PercentLoad;
                                            //添加用户自定义列
                                            if (userType == "0")
                                            {
                                                cell = row.CreateCell(17);
                                                SetCellValue(cell, pro.V1RunTimes.ToString(), defStyle);
                                                cell = row.CreateCell(18);
                                                SetCellValue(cell, pro.V2RunTimes.ToString(), defStyle);
                                                cell = row.CreateCell(19);
                                                SetCellValue(cell, pro.ProjectName.ToString(), defStyle);
                                                cell = row.CreateCell(20);
                                                SetCellValue(cell, pro.FileName, defStyle);
                                            }
                                            for (int p = 1; p < listPl.Count; p++)
                                            {
                                                row = sheet.CreateRow(nEndRow);
                                                CreateDefaultCell(cell, row);
                                                //11.PercentLoad
                                                cell = row.CreateCell(13);
                                                SetCellValue(cell, listPl[p], defStyle);

                                                if (pro.ChillerCOPR[pro.PercentLoad[p]] == "GT" || pro.ChillerCOPR[pro.PercentLoad[p]] == "CM")
                                                {
                                                    cell = row.CreateCell(14);
                                                    SetCellValue(cell, GetErrorDescByFlg(pro.ChillerCOPR[pro.PercentLoad[p]], pro.PercentLoad[p]), greenStyle);                                                   
                                                    cell = row.CreateCell(15);
                                                    cell = row.CreateCell(16);
                                                    MergeCells(sheet, nEndRow, nEndRow, 14, 16);
                                                }
                                                else
                                                {                                                    
                                                    //14.ChillerCOPR
                                                    cell = row.CreateCell(14);                                                    
                                                    SetCellValue(cell, double.Parse(pro.ChillerCOPR[listPl[p]]));
                                                    //15.ClrPressureDrop
                                                    cell = row.CreateCell(15);                                                    
                                                    SetCellValue(cell, double.Parse(pro.ClrPressureDrop[listPl[p]]));
                                                    
                                                    //16.CndPressureDrop
                                                    cell = row.CreateCell(16);                                                    
                                                    SetCellValue(cell, double.Parse(pro.CndPressureDrop[listPl[p]]));
                                                }
                                               
                                                nEndRow++;
                                            }
                                       
                                    }
                                   
                                    //合并单元格
                                    MergeDataCells(sheet, 3, 12, nStartRow, nEndRow - 1);
                                    MergeDataCells(sheet, 17, 20, nStartRow, nEndRow - 1);
                                  
                                }
                                //合并产品单元格
                                MergeDataCells(sheet, 2, 2, nProStartNum, nEndRow - 1);
                                nProStartNum = nEndRow;
                            }
                            //合并产品类型单元格
                            MergeDataCells(sheet, 1, 1, nProTypeStartNum, nEndRow - 1);
                            nProTypeStartNum = nEndRow;
                        }
                        //合并模式单元格
                        MergeDataCells(sheet, 0, 0, nOpStartNum, nEndRow - 1);
                        nOpStartNum = nEndRow;
                    }

                    //保存文件
                    using (fs = File.OpenWrite(savePath))
                    {
                        workbook.Write(fs);//向打开的这个xls文件中写入数据
                        result = true;
                    }
                }
              
                return result;
            //}
            //catch (Exception ex)
            //{
            //    return false;
            //}
            //finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
        }

        public static ICellStyle GetTitleStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            IFont font = workbook.CreateFont();
            //font.FontHeightInPoints = 16;
            font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;           
            style.SetFont(font);//HEAD 样式
            style.VerticalAlignment = VerticalAlignment.Center;            
            return style;
        }

        public static void SetCellValue(ICell cell, string value, ICellStyle cStyle)
        {
            cell.SetCellValue(value);
          
            cell.CellStyle = cStyle;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="value"></param>
        /// <param name="workbook"></param>
        /// <param name="flag">0:默认;1:Success/Fail;2:.00%</param>
        public static void SetCellValue(ICell cell, string value, HSSFWorkbook workbook, int flag = 0)
        {
            cell.SetCellValue(value);              
            if (flag ==1)
            {
                if (value != "Success")
                {
                    cell.CellStyle = defStyle;//
                }
                else
                {
                    cell.CellStyle = defStyle;
                }
     
            }
            else if (flag == 2)
            {
                if (value != ".00")
                {
                    cell.CellStyle = failStyle;
                }
                else
                {
                    cell.CellStyle = defStyle;
                }
            }
            else
            {
                cell.CellStyle = defStyle;
            }
        }

        public static void SetCellValue(ICell cell, double value)
        {           
            if (value <= 100)
            {                
                cell.SetCellValue(value);
                cell.CellStyle = doubleStyle;
            }
            else
            {
                cell.SetCellValue(value);
            }
        }

        public static ICellStyle GetDefaultStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            style.VerticalAlignment = VerticalAlignment.Center;
            return style;
        }

        public static ICellStyle GetFailStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            style.VerticalAlignment = VerticalAlignment.Center;
            style.FillForegroundColor = HSSFColor.Red.Index;
            style.FillPattern = FillPattern.SolidForeground;
            return style;
        
        }

        public static ICellStyle GetGreenStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            style.VerticalAlignment = VerticalAlignment.Center;
            style.FillForegroundColor = HSSFColor.Lime.Index;
            style.FillPattern = FillPattern.SolidForeground;
            return style;

        }

        public static ICellStyle GetOrangeStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            style.VerticalAlignment = VerticalAlignment.Center;
            style.FillForegroundColor = HSSFColor.LightOrange.Index;
            style.FillPattern = FillPattern.SolidForeground;
            return style;

        }

        public static ICellStyle GetDoubleStyle(HSSFWorkbook workbook)
        {
            ICellStyle style = workbook.CreateCellStyle();
            style.Alignment = HorizontalAlignment.Center;
            style.WrapText = true;
            style.VerticalAlignment = VerticalAlignment.Center;
            style.DataFormat = HSSFDataFormat.GetBuiltinFormat("0.00%");
            return style;
        }

        public static void CreateDefaultCell(ICell cell, IRow row)
        {
            cell = row.CreateCell(0);//空前两个用于合并
            cell = row.CreateCell(1);

            //2.tagName
            cell = row.CreateCell(2);
           
            //3.ChillerModel
            cell = row.CreateCell(3);
           
            //4.StarterVFd
            cell = row.CreateCell(4);            
            //5.HighSideValue
            cell = row.CreateCell(5);           
            //6.LowSideValue
            cell = row.CreateCell(6);           
            //7.FlascOrifice
            cell = row.CreateCell(7);
            //8.TotalOperatingWeight
            cell = row.CreateCell(8);           
            //9.TotalRiggingWeight
            cell = row.CreateCell(9);           
            //10.RefrigerantWeight
            cell = row.CreateCell(10);
            //11.PercentLoad
            cell = row.CreateCell(11);
            ////12.ChillerCapacity
            cell = row.CreateCell(12);
           
        }


        public static void MergeCells(ISheet sheet,int startRow,int endRow,int startCol,int endCol)
        { 
            //CellRangeAddress四个参数为：起始行，结束行，起始列，结束列
            sheet.AddMergedRegion(new CellRangeAddress(startRow, endRow, startCol, endCol));
        
        }

        public static void MergeDataCells(ISheet sheet, int startIndex, int endIndex,int startRow,int endRow)
        {
            for (int i = startIndex; i <= endIndex; i++)
            {
                sheet.AddMergedRegion(new CellRangeAddress(startRow, endRow, i, i));
            }
        }

        private static string GetErrorDescByFlg(string flg,string pload)
        {
            string formatStr1 = "This case exists percent load group {0} in groundtruth.";
            string formatStr2 = "This case exists percent load group {0} in validation.";
            if (flg == "GT")
            {
                return string.Format(formatStr1, pload,pload);
            }
            else 
            {
                return string.Format(formatStr2, pload, pload);
            }
        }

        public static bool ListSelectionsModelToExcel(List<OutSelectionsModel> listOut, string savePath, HSSFWorkbook workbook)
        {
            bool result = false;

            FileStream fs = null;
            IRow row = null;
            ISheet sheet = null;
            ICell cell = null;
            int nStartRow = 0;
            int nEndRow = 0;
            titleStyle = GetTitleStyle(workbook);
            defStyle = GetDefaultStyle(workbook);
            doubleStyle = GetDoubleStyle(workbook);
            try
            {
                if (listOut != null && listOut.Count > 0)
                {
                    #region Summary                   
                    
                    sheet = workbook.CreateSheet("Summary");//创建Summary Sheet
                    //设置列头
                    row = sheet.CreateRow(nStartRow);//excel第一行设为列头
                    List<string> lstColName = DataProcess.GetSelectionsSumColumnName();
                    for (int c = 0; c < lstColName.Count; c++)
                    {
                        cell = row.CreateCell(c);
                        SetCellValue(cell, lstColName[c], titleStyle);
                        sheet.SetColumnWidth(c, 20 * 256);
                    }
                    cell = row.CreateCell(6);
                    SetCellValue(cell, lstColName[5], titleStyle);
                    sheet.SetColumnWidth(6, 20 * 256);
                    nStartRow++;
                    row = sheet.CreateRow(nStartRow);
                    cell = row.CreateCell(0);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 1, 0, 0));
                    cell = row.CreateCell(1);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 1, 1, 1));
                    cell = row.CreateCell(2);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 1, 2, 2));
                    cell = row.CreateCell(3);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 1, 3, 3));
                    cell = row.CreateCell(4);
                    SetCellValue(cell,"V1", titleStyle);
                    cell = row.CreateCell(5);
                    SetCellValue(cell, "V2", titleStyle);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 0, 4, 5));
                    cell = row.CreateCell(6);
                    SetCellValue(cell, "Pass Selections", titleStyle);
                    cell = row.CreateCell(7);
                    SetCellValue(cell, "Pass Perf", titleStyle);
                    sheet.AddMergedRegion(new CellRangeAddress(0, 0, 6, 7));
                    nStartRow++;
                    //填充sum sheet Data
                    IEnumerable<IGrouping<string, OutSelectionsModel>> query = listOut.GroupBy(x => x.ProjectName);
                    foreach (IGrouping<string, OutSelectionsModel> info in query)
                    {
                        List<OutSelectionsModel> sl = info.ToList<OutSelectionsModel>();//分组后的集合
                        nEndRow = nStartRow;
                        foreach (OutSelectionsModel item in sl)
                        {
                            row = sheet.CreateRow(nStartRow);
                            //ProjectName
                            cell = row.CreateCell(0);
                            SetCellValue(cell, item.ProjectName, defStyle);
                            //Sequence
                            cell = row.CreateCell(1);
                            SetCellValue(cell, item.Seq, defStyle);
                            //Tag
                            cell = row.CreateCell(2);
                            SetCellValue(cell, item.TagName, defStyle);

                            if (item.WaringType == "0")
                            {
                                //Common Candidates
                                cell = row.CreateCell(3);
                                SetCellValue(cell, item.CommonCandidatates.ToString(), defStyle);
                                //V1
                                cell = row.CreateCell(4);
                                SetCellValue(cell, item.V1.ToString(), defStyle);
                                //V2
                                cell = row.CreateCell(5);
                                SetCellValue(cell, item.V2.ToString(), defStyle);
                                //Pass Selections
                                cell = row.CreateCell(6);
                                SetCellValue(cell, item.IsPassSelections.ToString(), defStyle);
                                //Pass Perf
                                cell = row.CreateCell(7);
                                SetCellValue(cell, item.IsPassPerf.ToString(), defStyle);
                                
                            }
                            else if (item.WaringType == "1")
                            {
                                //显示错误信息                                 
                                cell = row.CreateCell(3);
                                SetCellValue(cell, "This tag in groundtruth ,not found in validation ", defStyle);
                                cell = row.CreateCell(4);
                                cell = row.CreateCell(5);
                                cell = row.CreateCell(6);
                                cell = row.CreateCell(7);
                                sheet.AddMergedRegion(new CellRangeAddress(nStartRow, nStartRow, 3, 7));
                            }
                            else if (item.WaringType == "2")
                            {
                                //显示错误信息
                                cell = row.CreateCell(3);
                                SetCellValue(cell, "This tag in validation ,not found in groundtruth ", defStyle);
                                cell = row.CreateCell(4);
                                cell = row.CreateCell(5);
                                cell = row.CreateCell(6);
                                cell = row.CreateCell(7);
                                sheet.AddMergedRegion(new CellRangeAddress(nStartRow, nStartRow, 3, 7));
                            }
                            //合并行单元格
                            sheet.AddMergedRegion(new CellRangeAddress(nEndRow, nStartRow, 0, 0));
                            nStartRow++;
                        }
                       
                    }
                    #endregion

                    #region TagSheet
                    //创建Tag Sheet
                     IEnumerable<IGrouping<string, OutSelectionsModel>> queryModel = listOut.GroupBy(x => x.ProjectName);
                     foreach (IGrouping<string, OutSelectionsModel> info in queryModel)
                     {
                         List<OutSelectionsModel> sl = info.ToList<OutSelectionsModel>();//分组后的集合
                        
                         foreach (OutSelectionsModel item in sl)
                         {
                             if (item.WaringType == "0" &&(item.IsPassPerf!="1" || item.IsPassSelections!="1"))//只创建有交集的对比sheet
                             { 
                                 //创建sheet
                                 sheet = workbook.CreateSheet(item.Seq);//创建Tag Sheet                                 
                                 nStartRow = 0;
                                 nEndRow = 0;
                                 //创建tag sheet Title
                                 lstColName = DataProcess.GetTagSheetColumnName();
                                 row = sheet.CreateRow(nStartRow);//excel第一行设为列头                                
                                 for (int c = 0; c < lstColName.Count; c++)
                                 {
                                     cell = row.CreateCell(c);
                                     SetCellValue(cell, lstColName[c], titleStyle);
                                     sheet.SetColumnWidth(c, 20 * 256);
                                 }
                                 nStartRow++;
                                 var querySel = item.ListSelections.Where(x => x.OutModel == "0").ToList();//先输出交集
                                 foreach (var sel in querySel)
                                 {
                                     row = sheet.CreateRow(nStartRow);
                                     //Model
                                     cell = row.CreateCell(0);
                                     SetCellValue(cell, sel.ChillerModel, defStyle);
                                     //Capacity
                                     cell = row.CreateCell(1);
                                     SetCellValue(cell, sel.Capacity, defStyle);
                                     //Cooler Pass
                                     cell = row.CreateCell(2);
                                     SetCellValue(cell, sel.ClrPass, defStyle);
                                     //Condenser Pass
                                     cell = row.CreateCell(3);
                                     SetCellValue(cell, sel.CndPass, defStyle);
                                     //full load kW/Ton
                                     cell = row.CreateCell(4);
                                     SetCellValue(cell, double.Parse(sel.FullLoad));                                    
                                     //IPLV Kw/Ton
                                     cell = row.CreateCell(5);
                                     SetCellValue(cell, double.Parse(sel.IPLV));                                                 
                                     //Cooler Pressure Drop
                                     cell = row.CreateCell(6);
                                     SetCellValue(cell, double.Parse(sel.ClrPressDrop));  
                                     //Condenser Pressure Drop
                                     cell = row.CreateCell(7);
                                     SetCellValue(cell, double.Parse(sel.CndPressDrop));  
                                     //Price   
                                     cell = row.CreateCell(8);
                                     SetCellValue(cell, double.Parse(sel.Price));   
                                     nStartRow++;
                                 }

                                 //输出描述
                                 querySel = item.ListSelections.Where(x => x.OutModel == "1").OrderBy(y=>y.ChillerModel).ToList();
                                 if (querySel.Count > 0)
                                 {
                                     row = sheet.CreateRow(nStartRow);
                                     cell = row.CreateCell(0);
                                     SetCellValue(cell, "In GT", titleStyle);
                                     nStartRow++;

                                     foreach (var sel in querySel)
                                     {
                                         row = sheet.CreateRow(nStartRow);
                                         cell = row.CreateCell(0);
                                         SetCellValue(cell, sel.ChillerModel, defStyle);
                                         nStartRow++;
                                     }
                                 }
                                 querySel = item.ListSelections.Where(x => x.OutModel == "2").OrderBy(y => y.ChillerModel).ToList();
                                 if (querySel.Count > 0)
                                 {
                                     row = sheet.CreateRow(nStartRow);
                                     cell = row.CreateCell(0);
                                     SetCellValue(cell, "In Val", titleStyle);
                                     nStartRow++;

                                     foreach (var sel in querySel)
                                     {
                                         row = sheet.CreateRow(nStartRow);
                                         cell = row.CreateCell(0);
                                         SetCellValue(cell, sel.ChillerModel, defStyle);
                                         nStartRow++;
                                     }
                                 }
                             }
                             //
                         }
                     }
                    #endregion
                    //保存文件
                    using (fs = File.OpenWrite(savePath))
                    {
                        workbook.Write(fs);//向打开的这个xls文件中写入数据
                        result = true;
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
        }

        /// <summary>
        /// 保存perf 统计报表数据
        /// </summary>
        /// <param name="listV1"></param>
        /// <param name="listV2"></param>
        /// <param name="savePath"></param>
        /// <param name="workbook"></param>
        /// <param name="sheetName"></param>
        /// <returns></returns>
        public static bool ListPerfSummaryToExcel(List<OutSummaryPerfModel> listOut, string savePath, HSSFWorkbook workbook, string sheetName = "Summary")
        {
            FileStream fs = null;
            IRow row = null;
            ISheet sheet = null;
            ICell cell = null;
            defStyle = GetDefaultStyle(workbook);
            titleStyle = GetTitleStyle(workbook);

            int nStartRow = 4;
            int nOpStartNum = 4;
            int nProTypeNum = 4;
            int nEndRow = 0;
            if (listOut.Count > 0)
            {
                //try
                {
                    sheet = workbook.CreateSheet(sheetName);//创建一个名称为Sheet0的表
                    //workbook.Insert(0, sheet);
                    #region 设置列头
                    row = sheet.CreateRow(nEndRow);//  0行
                    CreateTitleCell(row, 0, "Summary", sheet);
                    MergeCells(sheet, 0, 0, 0, 22);
                    CreateEmptyCell(11, 22, row);
                    nEndRow++;
                    row = sheet.CreateRow(nEndRow);//  1行
                    CreateTitleCell(row, 0, "OperationType", sheet);
                    CreateTitleCell(row, 1, "ProductType", sheet);
                    CreateTitleCell(row, 2, "ProductName", sheet);
                    CreateTitleCell(row, 3, "Test Tag Count", sheet);
                    CreateEmptyCell(4, 12, row);
                    CreateTitleCell(row, 13, "Total Time", sheet);
                    CreateEmptyCell(14, 22, row);
                    MergeCells(sheet, 1, 1, 3, 12);
                    MergeCells(sheet, 1, 1, 13, 22);
                    nEndRow++;
                    row = sheet.CreateRow(nEndRow);//  2行
                    CreateEmptyCell(0, 2, row);                 
                    CreateTitleCell(row, 3, "V1", sheet);
                    CreateEmptyCell(4, 7, row);
                    CreateTitleCell(row, 8, "V2", sheet);
                    CreateEmptyCell(9, 12, row);
                    CreateTitleCell(row, 13, "V1", sheet);
                    CreateEmptyCell(14, 17, row);
                    CreateTitleCell(row, 18, "V2", sheet);
                    CreateEmptyCell(19, 22, row);
                    MergeCells(sheet, 2, 2, 3, 7);
                    MergeCells(sheet, 2, 2, 8, 12);
                    MergeCells(sheet, 2, 2, 13, 17);
                    MergeCells(sheet, 2, 2, 18, 22);
                    nEndRow++;
                    row = sheet.CreateRow(nEndRow);//  3行
                    CreateEmptyCell(0, 2, row);                   
                    MergeCells(sheet, 1, nEndRow, 0, 0);
                    MergeCells(sheet, 1, nEndRow, 1, 1);
                    MergeCells(sheet, 1, nEndRow, 2, 2);
                    int k = 3;
                    string[] strName = new string[5] { "APO_Eng", "APO_Sales", "NAO_Eng", "NAO_Sales", "Sum" };
                    for (int i = 0; i < 4; i++)
                    {
                        
                        for (int j = 0; j < strName.Length; j++)
                        {
                            CreateTitleCell(row, k, strName[j], sheet);
                            k++;
                        }
                    }
                    nEndRow++;
                    #endregion

                    #region Content
                    //过滤分类
                    List<string> listOperation = listOut.Select(t => t.OperationType).ToList().Distinct().ToList();
                    //排序listOperation
                    listOperation.Sort();
                    for (int i = 0; i < listOperation.Count; i++)
                    {
                        List<OutSummaryPerfModel> listOperationModel = listOut.Where(t => t.OperationType == listOperation[i]).ToList();
                        List<string> listProType = listOperationModel.Select(t => t.ProductType).ToList().Distinct().ToList();
                       
                        listProType.Sort();
                        foreach (var proType in listProType)
                        {
                            List<OutSummaryPerfModel> listProTypeModel = listOperationModel.Where(t => t.ProductType == proType).ToList();
                            List<string> listProName = listProTypeModel.Select(t => t.ProductName).Distinct().ToList();
                            listProName.Sort();
                            
                            foreach (var proName in listProName)
                            {
                                List<OutSummaryPerfModel> listProNameModel = listProTypeModel.Where(t => t.ProductName == proName).ToList();
                               
                                foreach (var model in listProNameModel)
                                {
                                    #region content
                                    row = sheet.CreateRow(nEndRow);
                                    cell = row.CreateCell(0);//空前两个用于合并
                                    SetCellValue(cell, model.OperationType, defStyle);
                                    cell = row.CreateCell(1);
                                    SetCellValue(cell, model.ProductType, defStyle);
                                    cell = row.CreateCell(2);
                                    SetCellValue(cell, model.ProductName, defStyle);

                                    cell = row.CreateCell(3);
                                    cell.SetCellValue(model.V1APO_EngCount);
                                    cell = row.CreateCell(4);
                                    cell.SetCellValue(model.V1APO_SalesCount);
                                    cell = row.CreateCell(5);
                                    cell.SetCellValue(model.V1NAO_EngCount);
                                    cell = row.CreateCell(6);
                                    cell.SetCellValue(model.V1NAO_SalesCount);
                                    cell = row.CreateCell(7);
                                    cell.SetCellValue(model.V1SumCount);


                                    cell = row.CreateCell(8);
                                    cell.SetCellValue(model.V2APO_EngCount);
                                    cell = row.CreateCell(9);
                                    cell.SetCellValue(model.V2APO_SalesCount);
                                    cell = row.CreateCell(10);
                                    cell.SetCellValue(model.V2NAO_EngCount);
                                    cell = row.CreateCell(11);
                                    cell.SetCellValue(model.V2NAO_SalesCount);
                                    cell = row.CreateCell(12);
                                    cell.SetCellValue(model.V2SumCount);

                                    cell = row.CreateCell(13);
                                    cell.SetCellValue( model.V1APO_EngTimes);
                                    cell = row.CreateCell(14);
                                    cell.SetCellValue( model.V1APO_SalesTimes);
                                    cell = row.CreateCell(15);
                                    cell.SetCellValue( model.V1NAO_EngTimes);
                                    cell = row.CreateCell(16);
                                    cell.SetCellValue( model.V1NAO_SalesTimes);
                                    cell = row.CreateCell(17);
                                    cell.SetCellValue(  model.V1SumTimes);

                                    cell = row.CreateCell(18);
                                    cell.SetCellValue( model.V2APO_EngTimes);
                                    cell = row.CreateCell(19);
                                    cell.SetCellValue(model.V2APO_SalesTimes);
                                    cell = row.CreateCell(20);
                                    cell.SetCellValue( model.V2NAO_EngTimes);
                                    cell = row.CreateCell(21);
                                    cell.SetCellValue( model.V2NAO_SalesTimes);
                                    cell = row.CreateCell(22);
                                    cell.SetCellValue( model.V2SumTimes);
                                    #endregion  
                                    nEndRow++;
                                }
                                ////产品类型
                                MergeDataCells(sheet, 2, 2, nStartRow, nEndRow-1);
                                nStartRow = nEndRow;
                            }
                            //产品类型
                            MergeDataCells(sheet, 1, 1, nProTypeNum, nEndRow-1);
                            nProTypeNum = nEndRow;
                        }
                        //模式
                        MergeDataCells(sheet, 0, 0, nOpStartNum, nEndRow-1);
                        nOpStartNum = nEndRow;
                    }
                    #endregion

                    #region 保存文件
                    using (fs = File.OpenWrite(savePath))
                    {
                        workbook.Write(fs);//向打开的这个xls文件中写入数据                       
                    }
                    #endregion
                }
                //catch (Exception ex)
                //{
                //    return false;
                //}
                //finally
                //{
                    if (fs != null)
                    {
                        fs.Close();
                    }
               // }
            }
            return true;
           
        }

        public static void CreateTitleCell(IRow row,int index ,string value,ISheet sheet)
        {
            ICell cell = row.CreateCell(index);
            SetCellValue(cell, value, titleStyle);
            sheet.SetColumnWidth(index, 15 * 256);
        }

        public static void CreateEmptyCell(int startindex, int endindex,IRow row)
        {
            for (int i = startindex; i <= endindex; i++)
            {
                ICell cell= row.CreateCell(i);
                cell.SetCellValue("");
            }
        }
    }
}