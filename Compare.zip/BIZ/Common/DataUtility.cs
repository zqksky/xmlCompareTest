﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;

namespace BIZ
{
    /// <summary>
    /// DataTable与实体类互相转换 
    /// DataTable dt = new ModelHandler<TagModel>().FillDataTable(listGT);
    /// </summary>
    /// <typeparam name="T">实体类</typeparam>
    public class ModelHandler<T> where T : new()
    {
        #region DataTable转换成实体类

        /// <summary>
        /// 填充对象列表：用DataSet的第一个表填充实体类
        /// </summary>
        /// <param name="ds">DataSet</param>
        /// <returns></returns>
        public List<T> FillModel(DataSet ds)
        {
            if (ds == null || ds.Tables[0] == null || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            else
            {
                return FillModel(ds.Tables[0]);
            }
        }

        /// <summary>  
        /// 填充对象列表：用DataSet的第index个表填充实体类
        /// </summary>  
        public List<T> FillModel(DataSet ds, int index)
        {
            if (ds == null || ds.Tables.Count <= index || ds.Tables[index].Rows.Count == 0)
            {
                return null;
            }
            else
            {
                return FillModel(ds.Tables[index]);
            }
        }

        /// <summary>  
        /// 填充对象列表：用DataTable填充实体类
        /// </summary>  
        public List<T> FillModel(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return null;
            }
            List<T> modelList = new List<T>();
            foreach (DataRow dr in dt.Rows)
            {
                //T model = (T)Activator.CreateInstance(typeof(T));  
                T model = new T();
                for (int i = 0; i < dr.Table.Columns.Count; i++)
                {
                    PropertyInfo propertyInfo = model.GetType().GetProperty(dr.Table.Columns[i].ColumnName);
                    if (propertyInfo != null && dr[i] != DBNull.Value)
                        propertyInfo.SetValue(model, dr[i], null);
                }

                modelList.Add(model);
            }
            return modelList;
        }

        /// <summary>  
        /// 填充对象：用DataRow填充实体类
        /// </summary>  
        public T FillModel(DataRow dr)
        {
            if (dr == null)
            {
                return default(T);
            }

            //T model = (T)Activator.CreateInstance(typeof(T));  
            T model = new T();

            for (int i = 0; i < dr.Table.Columns.Count; i++)
            {
                PropertyInfo propertyInfo = model.GetType().GetProperty(dr.Table.Columns[i].ColumnName);
                if (propertyInfo != null && dr[i] != DBNull.Value)
                    propertyInfo.SetValue(model, dr[i], null);
            }
            return model;
        }

        #endregion

        #region 实体类转换成DataTable

        /// <summary>
        /// 实体类转换成DataSet
        /// </summary>
        /// <param name="modelList">实体类列表</param>
        /// <returns></returns>
        public DataSet FillDataSet(List<T> modelList)
        {
            if (modelList == null || modelList.Count == 0)
            {
                return null;
            }
            else
            {
                DataSet ds = new DataSet();
                ds.Tables.Add(FillDataTable(modelList));
                return ds;
            }
        }

        /// <summary>
        /// 实体类转换成DataTable
        /// </summary>
        /// <param name="modelList">实体类列表</param>
        /// <returns></returns>
        public DataTable FillDataTable(List<T> modelList)
        {
            if (modelList == null || modelList.Count == 0)
            {
                return null;
            }
            DataTable dt = CreateData(modelList[0]);

            foreach (T model in modelList)
            {
                DataRow dataRow = dt.NewRow();
                foreach (PropertyInfo propertyInfo in typeof(T).GetProperties())
                {
                    dataRow[propertyInfo.Name] = propertyInfo.GetValue(model, null);
                }
                dt.Rows.Add(dataRow);
            }
            return dt;
        }

        /// <summary>
        /// 根据实体类得到表结构
        /// </summary>
        /// <param name="model">实体类</param>
        /// <returns></returns>
        private DataTable CreateData(T model)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            foreach (PropertyInfo propertyInfo in typeof(T).GetProperties())
            {
                //if (propertyInfo.PropertyType.Name != "List`1")
                dataTable.Columns.Add(new DataColumn(propertyInfo.Name, propertyInfo.PropertyType));
            }
            return dataTable;
        }

        #endregion
    }


    public static class DataUtility
    {

        public static string MoveInvalidCharBefore(string value, char mvChar)
        {
            int pos = value.IndexOf(mvChar);
            if (pos >= 0)
                return value.Substring(0, pos).Trim();
            else
                return value;
        }

        public static string MoveInvalidCharAfter(string value, char mvChar)
        {
            int pos = value.IndexOf(mvChar);
            if (pos >= 0)
                return value.Substring(pos+1).Trim();
            else
                return value;
        }

        /// <summary>
        /// 截取Tab字符之前的数据
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string MoveInvalidTabChar(string value)
        {
            return MoveInvalidCharBefore(value, '\t');
        }

        /// <summary>
        /// 截取空格字符之前的数据
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string MoveInvalidSpaceChar(string value)
        {
            return MoveInvalidCharBefore(value, ' ');
        }

        /// <summary>
        /// 将字符串转换成数值型
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static double StringPraseToDouble(string value)
        {
            double rn = 0;
            if (!double.TryParse(value.Trim(), out rn))
                rn = -1;
            return rn;
        }
    }


    public static class DataProcess
    {
        /// <summary>
        /// 根据压缩机尺寸获取产品名称
        /// </summary>
        /// <param name="cmpSize"></param>
        /// <returns></returns>
        public static string GetProductName(string cmpSize)
        {
            if (string.IsNullOrEmpty(cmpSize)|| cmpSize.Length<3)
            {
                return "Null";
            }
            string firstChar = cmpSize.Substring(0, 1);
            string secondeChar = cmpSize.Substring(1, 1);
            string thirstChar = cmpSize.Substring(2, 1);
            string rtn="";
            switch (firstChar)
            { 
                case "2":
                    rtn = "XR2";
                    break;
                case "3":
                    double d=0;
                    if (double.TryParse(thirstChar, out d) && double.TryParse(secondeChar, out d))
                        rtn = "XR3";
                    else if(thirstChar=="E" || thirstChar=="H")
                        rtn = "XR3_IMP";
                    break;
                case "4":
                    if (double.TryParse(secondeChar, out d))
                        rtn = "XR4";
                    else 
                        rtn = "XR4_SRD";
                    break;
                case "5":
                    rtn = "XR5";
                    break;
                case "C":
                    rtn = "XRC";
                    break;
                case "E":
                    rtn = "XRE";
                    break;
                case "6":
                    if (double.TryParse(secondeChar, out d))
                        rtn = "XR6";
                    else
                        rtn = "XR6_HL";
                    break;
                case "7":
                    if (double.TryParse(secondeChar, out d))
                        rtn = "XR7";
                    else
                        rtn = "XR7_HL";
                    break;                                       
                default:
                    rtn = "23XR";
                    break;
            }

            return rtn;
        
        }

        public static string GetProductType(string ProductName)
        {
            string ProductType = "";
            if (ProductName == "23XR")//暂时逻辑，以后优化
            {
                ProductType = "23XR";
            }
            else
            {
                ProductType = "19XR";
            }
            return ProductType;
        }

        public static List<string> GetPerfExcelColumnName()
        {
            List<string> lst = new List<string>();
            lst.Add("OperationType");
            lst.Add("ProductType");
            lst.Add("ProductName");
            lst.Add("TagName");
            lst.Add("ChilerModel");
            lst.Add("ChillerCapacity");
            lst.Add("StarterVFD");
            lst.Add("HighSideValue");
            lst.Add("LowSideValue");
            lst.Add("FlascOrifice");
            lst.Add("TotalOperatingWeight");
            lst.Add("TotalRiggingWeight");
            lst.Add("RefrigerantWeight");
            lst.Add("PercentLoad");           
            lst.Add("ChillerCOPR");
            lst.Add("ClrPressureDrop");
            lst.Add("CndPressureDrop");
            return lst;
        }

        public static List<string> GetCustomPerfExcelColumnName()
        {
            List<string> lst = new List<string>();
            lst.Add("V1RunTimes");
            lst.Add("V2RunTimes");
            lst.Add("ProjectName");
            lst.Add("FileName");
            return lst;
        }

        public static List<string> GetCustomExcelColumnName()
        {
            List<string> lst = new List<string>();
            lst.Add("RunTimes");
            lst.Add("ProjectName");
            lst.Add("FileName");
            return lst;
        }

        public static List<string> GetSelectionsSumColumnName()
        {
            List<string> lst = new List<string>();
            lst.Add("ProjectName");
            lst.Add("Sequence");
            lst.Add("Tag");
            lst.Add("Common Candidates");
            lst.Add("Different");
            lst.Add("Pass");            
            return lst;
        }

        public static List<string> GetTagSheetColumnName()
        {
            List<string> lst = new List<string>();
            lst.Add("Model");
            lst.Add("Capacity");
            lst.Add("Cooler Pass");
            lst.Add("Condenser Pass");
            lst.Add("Full Load Kw/Ton");
            lst.Add("IPLV Kw/Ton");
            lst.Add("Cooler Pressure Drop");
            lst.Add("Condenser Pressure Drop");
            lst.Add("Price");
            return lst;
        }
    }
}
