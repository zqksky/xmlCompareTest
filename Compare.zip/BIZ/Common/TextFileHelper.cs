﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BIZ
{
    public class TextFileHelper
    {
        public static List<FileInfo> GetFolderTxtFiles(string path, string fileType = "*.txt")
        {
            //DirectoryInfo folder = new DirectoryInfo(path);            
            //return folder.GetFiles(fileType).ToList();
            List<FileInfo> listFileinfo=new List<FileInfo> ();
            listDirectory(path, listFileinfo);
            return listFileinfo;
        }

        public static bool FolderIsExists(string path)
        {
            if (Directory.Exists(path))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 列出path路径对应的文件夹中的子文件夹和文件
        /// 然后再递归列出子文件夹内的文件和文件夹
        /// </summary>
        /// <param name="path">需要列出内容的文件夹的路径</param>      
        private static void listDirectory(string path, List<FileInfo> listFileinfo, string fileType = "*.txt")
        {
            DirectoryInfo theFolder = new DirectoryInfo(@path);
            if (theFolder.Exists)
            {
                listFileinfo.AddRange(theFolder.GetFiles().ToList());

                //遍历文件夹
                foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
                {
                    listDirectory(NextFolder.FullName, listFileinfo);
                }
            }
        }
    }
}
