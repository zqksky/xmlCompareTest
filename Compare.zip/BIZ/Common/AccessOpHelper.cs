﻿
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Data.OleDb;
using System.Data;



namespace BIZ
{

    public class AccessOpHelper
    {

        private static string connStr = @"Provider = Microsoft.Ace.OLEDB.12.0;Data Source = ";



        public static OleDbConnection GetConn(string path="")
        {

            OleDbConnection tempconn = new OleDbConnection(connStr + path);
            tempconn.Open();
            return (tempconn);

        }

        /// <summary>

        /// 执行增加、删除、修改指令

        /// </summary>

        /// <param name="sql">增加、删除、修改的sql语句</param>

        /// <param name="param">sql语句的参数</param>

        /// <returns></returns>

        public static int ExecuteNonQuery(OleDbConnection conn, string sql, params OleDbParameter[] param)
        {   
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                   
                if (param != null)
                {

                    cmd.Parameters.AddRange(param);

                }
                return (cmd.ExecuteNonQuery());

            }
        }



        /// <summary>

        /// 执行查询指令，获取返回的首行首列的值

        /// </summary>

        /// <param name="sql">查询sql语句</param>

        /// <param name="param">sql语句的参数</param>

        /// <returns></returns>

        public static object ExecuteScalar(OleDbConnection conn, string sql, params OleDbParameter[] param)
        {         
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (param != null)
                    {

                        cmd.Parameters.AddRange(param);

                    }
                    return (cmd.ExecuteScalar());
                }

        }



        /// <summary>

        /// 执行查询指令，获取返回的datareader

        /// </summary>

        /// <param name="sql">查询sql语句</param>

        /// <param name="param">sql语句的参数</param>

        /// <returns></returns>

        public static OleDbDataReader ExecuteReader(OleDbConnection conn, string sql, params OleDbParameter[] param)
        {

          

            OleDbCommand cmd = conn.CreateCommand();

            cmd.CommandText = sql;

            cmd.CommandType = CommandType.Text;

            if (param != null)
            {

                cmd.Parameters.AddRange(param);

            }
            return (cmd.ExecuteReader(CommandBehavior.CloseConnection));



        }



        /// <summary>

        /// 执行查询指令，获取返回datatable

        /// </summary>

        /// <param name="sql">查询sql语句</param>

        /// <param name="param">sql语句的参数</param>

        /// <returns></returns>

        public static DataTable ExecuteDatable(OleDbConnection conn, string sql, params OleDbParameter[] param)
        {

          
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {

                if (param != null)
                {

                    cmd.Parameters.AddRange(param);

                }

                DataTable dt = new DataTable();

                OleDbDataAdapter sda = new OleDbDataAdapter(cmd);

                sda.Fill(dt);

                return (dt);

            }
        }


        public static int ExecuteNonQuery(OleDbConnection conn, string sql)
        {
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {  
                return (cmd.ExecuteNonQuery());
            }
        }

    }

}