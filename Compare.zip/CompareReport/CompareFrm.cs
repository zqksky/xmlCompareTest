﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BIZ;
using System.Configuration;

namespace CompareReport
{
    public partial class CompareFrm : Form
    {
        public CompareFrm()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            string flist= ConfigurationManager.AppSettings["FloderName"];
            string userType = ConfigurationManager.AppSettings["UserType"];
            ResultModel rm= BizProcess.ProcessPer(txtGT.Text.Trim(), txtVal.Text.Trim(), flist, txtOut.Text.Trim(),userType);

            MessageBox.Show(rm.ResultDesc);
           
        
        }

        private void CompareFrm_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog path = new FolderBrowserDialog();
            if (path.ShowDialog() == DialogResult.OK)
            {
                txtGT.Text = path.SelectedPath;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog path = new FolderBrowserDialog();
            if (path.ShowDialog() == DialogResult.OK)
            {
                txtVal.Text = path.SelectedPath;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Excel files (*.xls)|*.xls";
            if (sf.ShowDialog() == DialogResult.OK)
            {
                txtOut.Text = sf.FileName;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
