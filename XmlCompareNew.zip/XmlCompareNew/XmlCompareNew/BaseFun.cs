﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace XmlCompareNew
{
    class BaseFun
    {
        private const string XML_FILE = "*.xml";
        public static List<string> strListSummary = new List<string>();

        #region 获取xml文件中的数据到Hashtable
        public static Hashtable GetXmlDataToHashtable(string xmlPath)
        {
            Hashtable ht = new Hashtable();

            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
                                             select ele;
            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("CHARC").Value;
                strValue = ele.Attribute("VALUE").Value;
                if (ele.LastAttribute.Name == "VALUE_TXT")
                {
                    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                }
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);
                ht.Add(strKey, strValue);
            }
            return ht;
        }
        #endregion

        #region 根据hashtable中的值获取键值
        public static string GetHashtableKey(Hashtable txtMapHashtable,string strValue)
        {
            string strKey = "";
            foreach (DictionaryEntry de in txtMapHashtable)
            {
                if (de.Value.ToString() == strValue)
                {
                    strKey = de.Key.ToString();
                }
            }
            return strKey;
        }
        #endregion

        #region 合并两个Hashtable
        public static Hashtable MergeTwoHashtable(Hashtable ht1, Hashtable ht2)
        {
            Hashtable htMerge = new Hashtable();
            foreach (DictionaryEntry de in ht1)
            {
                htMerge.Add(de.Key, de.Value);
            }
            foreach (DictionaryEntry de in ht2)
            {
                if (htMerge.ContainsKey(de.Key))
                {
                }
                else
                {
                    htMerge.Add(de.Key, de.Value);
                }
            }
            return htMerge;
        }
        #endregion
        
        #region 
        public static Hashtable DiffTwoHashtable(Hashtable ht1, Hashtable ht2)
        {
            Hashtable htDiff = new Hashtable();
            foreach (DictionaryEntry de in ht1)
            {
                htDiff.Add(de.Key, de.Value);
            }
            foreach (DictionaryEntry de in ht2)
            {
                if (htDiff.ContainsKey(de.Key))
                {
                    htDiff.Remove(de.Key);
                }
            }
            return htDiff;
        }
        #endregion

        #region 比较两个Hashtable中的数据
        public static bool CompareHashtable(Hashtable oldHashtable, Hashtable newHashtable, Hashtable NameMapHashtable, string strCsvSaveFilePath)
        {
            bool flagSame = false;

            List<string> strListPublic = new List<string>();
            List<string> strListOnlyOldXml = new List<string>();
            List<string> strListOnlyNewXml = new List<string>();

            foreach (DictionaryEntry de in oldHashtable)
            {
                if (newHashtable.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == newHashtable[de.Key].ToString())
                    {
                        newHashtable.Remove(de.Key);
                    }
                    else
                    {
                        strListPublic.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + newHashtable[de.Key].ToString().Replace(",", ""));
                        newHashtable.Remove(de.Key);
                    }
                }
                else
                {
                    strListOnlyOldXml.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ""));
                }
            }
            foreach (DictionaryEntry de in newHashtable)
            {
                //strList3.Add(de.Key.ToString() + "," + de.Value.ToString());
                strListOnlyNewXml.Add(de.Key.ToString() + "," + "," + de.Value.ToString().Replace(",", ""));
            }
            if ((strListPublic.Count + strListOnlyOldXml.Count + strListOnlyNewXml.Count) > 0)
            {
                string strName;
                string strProjectTagName;

                strName = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                strName =strName.Substring(0, strName.IndexOf(".csv"));
                strProjectTagName = GetHashtableKey(NameMapHashtable, strName);

                using (FileStream fs = new FileStream(strCsvSaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    sw.WriteLine(strProjectTagName + "," + strName);
                    sw.WriteLine("");

                    sw.WriteLine("Key,TxtValue,XmlValue");
                    if (strListPublic.Count > 0)
                    {
                        strListSummary.Add(strProjectTagName);
                        strListPublic.Sort();
                        //sw.WriteLine("");
                        sw.WriteLine("xml not same");
                        //sw.WriteLine("两个xml文件中不相同的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListPublic)
                        {
                            sw.WriteLine(s);
                            strListSummary.Add(s);
                        }
                        strListSummary.Add(" ");
                    }
                    if (strListOnlyOldXml.Count > 0)
                    {
                        strListOnlyOldXml.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in old xml file");
                        //sw.WriteLine("xml文件1中有而2中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListOnlyOldXml)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strListOnlyNewXml.Count > 0)
                    {
                        strListOnlyNewXml.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in new xml file");
                        //sw.WriteLine("xml文件2中有而1中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListOnlyNewXml)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }
        #endregion

        #region 获取Hashtable中的数据到CSV文件中
        public static void HastableToCsv(Hashtable ht, string strCsvFileName, string strFirstLine)
        {
            List<string> strListCsvFileValue = new List<string>();

            if (ht.Count > 0)
            {
                foreach (DictionaryEntry de in ht)
                {
                    strListCsvFileValue.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ";"));
                }
                strListCsvFileValue.Sort();
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine(strFirstLine);   //开始写入
                    foreach (var str in strListCsvFileValue)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
            }
        }
        #endregion

        #region 获取List<string>中的数据到CSV文件中
        public static void ListToCsv(List<string> strList, string strCsvFileName)
        {
            if (strList.Count > 0)
            {
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    foreach (var str in strList)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine("The result all same!");   //开始写入

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
        }
        #endregion

        #region 根据集合中的路径生成相应的CSV文件,并把路劲下的txt或xml文件复制到指定路径
        public static Hashtable ListOldXmlPathToCsv(List<string> strPathList, string strCsvPath, string strCopyPath, int pathLength)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = GetXmlDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (!htNameMap.ContainsKey(strFileName))
                        {
                            pTagNum++;
                            strSaveName = "PN" + pTagNum;
                            htNameMap.Add(strFileName, strSaveName);
                        }
                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv", "Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htNameMap;
        }

        public static Hashtable ListNewXmlPathToCsv(List<string> strPathList, Hashtable htOldNameMap, string strCsvPath, string strCopyPath, int pathLength)
        {
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htNewNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = GetXmlDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (htOldNameMap.ContainsKey(strFileName))
                        {
                            strSaveName = htOldNameMap[strFileName].ToString();
                            //htNewNameMap.Add(strFileName, strSaveName);
                        }
                        else
                        {
                            strSaveName = ht["TAG_NAME"].ToString();
                        }
                        htNewNameMap.Add(strFileName, strSaveName);

                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv", "Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htOldNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htNewNameMap;
        }

        public static Hashtable ListNewXmlPathToCsv(List<string> strPathList, Hashtable htOldNameMap, ref Hashtable htSameFile, ref Hashtable htOnlyNewFile, string strCsvPath, string strCopyPath, int pathLength)
        {
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htNewNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = GetXmlDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (htOldNameMap.ContainsKey(strFileName))
                        {
                            strSaveName = htOldNameMap[strFileName].ToString();
                            //htNewNameMap.Add(strFileName, strSaveName);
                            htSameFile.Add(strFileName, strSaveName);
                        }
                        else
                        {
                            strSaveName = ht["TAG_NAME"].ToString();
                            htOnlyNewFile.Add(strFileName, strSaveName);
                        }
                        htNewNameMap.Add(strFileName, strSaveName);

                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv", "Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htOldNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htNewNameMap;
        }

        #endregion

        #region 批量比较xml
        public static List<string> CompareTxtAndXml(string strOldXmlPath, string strNewXmlPath, string strCsvFilePath, Hashtable htNameMap)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strOldXmlPath == "" || strNewXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strOldXmlPath), XML_FILE))
            {
                MessageBox.Show("Old xml File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strNewXmlPath), XML_FILE))
            {
                MessageBox.Show("New xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strXmlTemp;
                Hashtable htOldXml = new Hashtable();
                Hashtable htNewXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strOldXmlPath, XML_FILE);
                strPathList2 = FileHelper.GetFiles(strNewXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    strXmlTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";

                    if (strPathList2.Contains(strXmlTemp))
                    {
                        htOldXml = GetXmlDataToHashtable(strOldXmlPath + "\\" + str);
                        htNewXml = GetXmlDataToHashtable(strNewXmlPath + "\\" + strXmlTemp);

                        flagSame = CompareHashtable(htOldXml, htNewXml, htNameMap, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }
        #endregion

        #region 主方法
        public static void RunFun(string strOldXmlPath, string strNewXmlPath)
        {
            //strTxtPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";
            //strXmlPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";

            Hashtable htOldXmlMap = new Hashtable();
            Hashtable htNewXmlMap = new Hashtable();

            Hashtable htSameFile = new Hashtable();
            Hashtable htOnlyOldFile = new Hashtable();
            Hashtable htOnlyNewFile = new Hashtable();

            string strExcelPath = @"D:\XmlCompareTest\result.xlsx";

            string strCsvPath = @"D:\XmlCompareTest\ComPareCsvFile";
            string strOldSavePath = @"D:\XmlCompareTest\xmlOldCsvFile";
            string strNewSavePath = @"D:\XmlCompareTest\xmlNewCsvFile";
            string strOldXmlPathCopy = @"D:\XmlCompareTest\xmlOldFileCopy";
            string strNewXmlPathCopy = @"D:\XmlCompareTest\xmlNewFileCopy";

            List<string> strListOldXmlPath = new List<string>();
            List<string> strListNewXmlPath = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strOldSavePath);
            FileHelper.CleanFolder(strNewSavePath);
            FileHelper.CleanFolder(strOldXmlPathCopy);
            FileHelper.CleanFolder(strNewXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strOldXmlPath), XML_FILE, ref strListOldXmlPath);
            FileHelper.GetFiles(new DirectoryInfo(strNewXmlPath), XML_FILE, ref strListNewXmlPath);

            htOldXmlMap = ListOldXmlPathToCsv(strListOldXmlPath, strOldSavePath, strOldXmlPathCopy, strOldXmlPath.Length);
            //htNewXmlMap = ListNewXmlPathToCsv(strListNewXmlPath, htOldXmlMap, strNewSavePath, strNewXmlPathCopy, strNewXmlPath.Length);

            htNewXmlMap = ListNewXmlPathToCsv(strListNewXmlPath, htOldXmlMap, ref htSameFile, ref htOnlyNewFile, strNewSavePath, strNewXmlPathCopy, strNewXmlPath.Length);
            htOnlyOldFile = DiffTwoHashtable(htOldXmlMap, htSameFile);

            strListSummary.Clear();
            strListCsvFileName = CompareTxtAndXml(strOldXmlPathCopy, strNewXmlPathCopy, strCsvPath,MergeTwoHashtable(htOldXmlMap,htNewXmlMap));

            if (htOldXmlMap.Count > 0)
            {
                HastableToCsv(htOldXmlMap, strCsvPath + "\\xmlOldMap.csv", "ProjectName,TagName,Value");
                strListCsvFileName.Add("xmlOldMap.csv");
            }
            if (htNewXmlMap.Count > 0)
            {
                HastableToCsv(htNewXmlMap, strCsvPath + "\\xmlNewMap.csv", "ProjectName,TagName,Value");
                strListCsvFileName.Add("xmlNewMap.csv");
            }
            if (htOnlyOldFile.Count > 0)
            {
                HastableToCsv(htOnlyOldFile, strCsvPath + "\\onlyOldFile.csv", "ProjectName,TagName,Value");
                strListCsvFileName.Add("onlyOldFile.csv");
            }
            if (htOnlyNewFile.Count > 0)
            {
                HastableToCsv(htOnlyNewFile, strCsvPath + "\\onlyNewFile.csv", "ProjectName,TagName,Value");
                strListCsvFileName.Add("onlyNewFile.csv");
            }

            ListToCsv(strListSummary, strCsvPath + "\\Sumary.csv");  
            strListCsvFileName.Add("Sumary.csv");

            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);
        }
        #endregion
    }
}
