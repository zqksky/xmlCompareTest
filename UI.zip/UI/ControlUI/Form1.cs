﻿using ControlUI.Comman;
using ControlUI.Present.PresentOVL;
using Infragistics.UltraChart.Resources.Appearance;
using Infragistics.UltraChart.Shared.Styles;
using Infragistics.Win;
using Infragistics.Win.Misc;
using Infragistics.Win.UltraWinChart;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI
{
    public partial class frmMain : Form
    {
        #region Param
        private float frmLocationX;
        private float frmLocationY;

        int iRunCount;
        bool bToolVendorASML;
        bool bChuckOne;
        string strChuckId;
        string strReticleId;
        string strToolVendor;
        string strOVLModelType;

        string strDomainName;
        string strUserName = "XNi160297";
        string strPassword;
        string strServiceAddres = "localhost";

        string strCurrentModule= "LITHO";
        string strCurrentProduct;
        string strCurrentStage;
        string strCurrentLayer;
        string strCurrentController;
        string strCurrentTool;
        string strArea;

        List<string> strListR2RContexts = new List<string>();

        List<string> strListChuckDedicationColumnName = new List<string>();
        List<string> strListChuckDedicationValue = new List<string>();

        List<string> strListColNumTest = new List<string>() { "Module", "Product", "Layer", "Tool" };
        List<string> strListColNum = new List<string>();
        List<string> strListModule = new List<string>();
        List<string> strListProduct = new List<string>();
        List<string> strListStage = new List<string>();
        List<string> strListLayer = new List<string>();
        List<string> strListController = new List<string>();
        List<string> strListTool = new List<string>();

        List<UltraChart> ctlListChart = new List<UltraChart>();

        int nReticle = 2;
        List<string> strReticle = new List<string>() { "1", "2", "3", "4" };
        List<string> strReticle2 = new List<string>() { "1", "2", "3", "4" };
        #endregion

        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        #endregion

        public frmMain()
        {
            #region Login 
            //frmLogin frm = new frmLogin();
            //if (frm.ShowDialog() != DialogResult.OK)
            //{
            //    System.Environment.Exit(0);
            //}
            //LoginFun.LoginManage(frm.strUserName, frm.strPassword, frm.strDomainName, false);
            //strDomainName = frm.strDomainName;
            //strUserName = frm.strUserName;
            //strPassword = frm.strPassword;
            //strServiceAddres = frm.strServerAddress;
            ////LoginFun.LoginManage("XNi160297", "Amat2018.", "amat", false);
            #endregion

            #region UIService
            InitParam();
            strListModule = UIServiceFun.R2R_UI_GetModule(strUserName, strServiceAddres);
            #endregion

            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            #region  frmAutoSize
            //this.Resize += new EventHandler(frmMain_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //FrmAutoSize.setTag(this);
            #endregion

            #region init
            InitControl();
            InitGrdOptContext();
            #endregion
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            #region frmAutoSize
            float newx = (this.Width) / frmLocationX;
            float newy = this.Height / frmLocationY;
            FrmAutoSize.setControls(newx, newy, this);
            #endregion
        }

        #region Set Control
        private void InitParam()
        {
            strListModule.Clear();
            strListProduct.Clear();
            strListStage.Clear();
            strListLayer.Clear();
            strListController.Clear();
            strListTool.Clear();
        }

        private void InitControl()
        {
            bChuckOne = true;
            rdoList.CheckedIndex = 0;
            rdoChuck.CheckedIndex = 0;
            rdoChuck.Enabled = false;

            tabSub.Tabs[4].Visible = false;
            tabSub.Tabs[5].Visible = false;

            iRunCount = int.Parse(txtLots.Value.ToString());

            SetControlShow(false, false, false, false, false);
        }

        private void ClearControl()
        {
            grdOptContextGroup.DataSource = null;
            grdOptLinear.DataSource = null;
            grdOptHOPC.DataSource = null;
            grdOptIHOPC.DataSource = null;
            grdOptCPE.DataSource = null;
            grdOptCD.DataSource = null;
            grdOptFocus.DataSource = null;
            panOptPicture.ClientArea.Controls.Clear();//清空panel
        }

        private void SetChuckType(string strChuckId)
        {
            if (strChuckId == "C1")
            {
                rdoChuck.CheckedIndex = 0;
            }
            else
            {
                rdoChuck.CheckedIndex = 1;
            }
        }

        private void rdoChuck_ValueChanged(object sender, EventArgs e)
        {
            if (rdoChuck.CheckedIndex == 0)
            {
                bChuckOne = true;
                strChuckId = "C1";
                //MessageBox.Show("chuck1");
            }
            else if (rdoChuck.CheckedIndex == 1)
            {
                bChuckOne = false;
                strChuckId = "C2";
                //MessageBox.Show("chuck2");
            }
        }

        private void SetControlShow(bool flgRdoList, bool flgRdoChuck, bool flgBtnOptReset, bool flgBtnOptMode, bool flgBtnOptUpdate)
        {
            if (flgRdoList)
            {
                rdoList.Show();
            }
            else
            {
                rdoList.Hide();
            }
            rdoChuck.Enabled = flgRdoChuck;
            btnOptReset.Enabled = flgBtnOptReset;
            btnOptMode.Enabled = flgBtnOptMode;
            btnOptUpdate.Enabled = flgBtnOptUpdate;
        }

        private void SetTabSubShow(string strController)
        {
            if (strController.Equals("PH_OVL_ASML_R2R_Model"))
            {
                tabSub.Tabs[0].Visible = true;
                tabSub.Tabs[1].Visible = true;
                tabSub.Tabs[2].Visible = true;
                tabSub.Tabs[3].Visible = true;
                tabSub.Tabs[4].Visible = false;
                tabSub.Tabs[5].Visible = false;
            }
            else if (strController.Equals("PH_CD_R2R_Model"))
            {
                tabSub.Tabs[4].Visible = true;
                tabSub.Tabs[5].Visible = true;
                tabSub.Tabs[0].Visible = false;
                tabSub.Tabs[1].Visible = false;
                tabSub.Tabs[2].Visible = false;
                tabSub.Tabs[3].Visible = false;
            }
            else if (strController.Equals("PH_Focus_R2R_Model"))
            {
                tabSub.Tabs[4].Visible = true;
                tabSub.Tabs[5].Visible = true;
                tabSub.Tabs[0].Visible = false;
                tabSub.Tabs[1].Visible = false;
                tabSub.Tabs[2].Visible = false;
                tabSub.Tabs[3].Visible = false;
            }
        }

        private void InitGrid(UltraGrid ctlGrid, DataTable tb)
        {
            ctlGrid.DataSource = tb;

            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //ctlGrid.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //ctlGrid.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //ctlGrid.DisplayLayout.Override.ColumnAutoSizeMode = ColumnAutoSizeMode.VisibleRows;
            //ctlGrid.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //ctlGrid.Rows[0].PerformAutoSize();
            //ctlGrid.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
        }

        private void InitDbChuckDeditation(DataTable db, int rowIndex)
        {
            strListChuckDedicationValue.Clear();
            strListChuckDedicationColumnName.Clear();
            for (int i = 0; i < db.Columns.Count; i++)
            {
                strListChuckDedicationValue.Add(grdOptContextGroup.Rows[rowIndex].Cells[i].Value.ToString());
            }
            foreach (DataColumn dc in dbGetContext.Columns)
            {
                strListChuckDedicationColumnName.Add(dc.ColumnName.ToString());
            }
            dbChuckDeditation = DataTableHelp.CreateChuckDedicationTable(strListChuckDedicationColumnName, strListChuckDedicationValue);
        }
        #endregion

        #region txtLots Event 
        private string strRunCount = "20";
        private string strPattern = @"^[0-9]*$";//只允许输入数字
        private void txtLots_ValueChanged(object sender, EventArgs e)
        {
            Match m = Regex.Match(this.txtLots.Text, strPattern);   // 匹配正则表达式

            if (!m.Success)   // 输入的不是数字
            {
                this.txtLots.Text = strRunCount;   // textBox内容不变

                // 将光标定位到文本框的最后
                this.txtLots.SelectionStart = this.txtLots.Text.Length;
                //MessageBox.Show("Please input a number!");
            }
            else   // 输入的是数字
            {
                strRunCount = this.txtLots.Text;   // 将现在textBox的值保存下来
            }
        }

        private void txtLots_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//如果输入的是回车键
            {
                this.btnOptRun_Click(sender, e);//触发button事件
            }
        }
        #endregion

        #region btnRun Event
        DataTable dbGetContext = new DataTable("GetContext");
        private void btnOptRun_Click(object sender, EventArgs e)
        {
            #region test Chart
            //UltraChart ctlChart = new UltraChart();
            //AddControlHelp.CreateLineChart(panOptPicture, ref ctlChart);
            //AddControlHelp.CreateColumnChart(panOptPicture, ref ctlChart);

            //AddControlHelp.CreateLineChart(panOptPicture, ref ctlChart, DataTableHelp.GetLineChartData());
            //AddControlHelp.CreateColumnChart(panOptPicture, ref ctlChart, DataTableHelp.GetColumnChartDataTest());

            //AddControlHelp.CreateChart(panOptPicture, ref ctlListChart, 1, 4);
            //ctlListChart[0].ChartDataClicked += chart_DataClicked;
            #endregion
            try
            {
                #region GetR2RContext
                iRunCount = int.Parse(txtLots.Value.ToString());
                //if (strCurrentProduct == null || strCurrentLayer == null || strCurrentController == null || strCurrentTool == null || iRunCount == 0)
                if (grdOptContext.Rows[0].Cells[1].Value.ToString().Equals("") || grdOptContext.Rows[1].Cells[1].Value.ToString().Equals("") || grdOptContext.Rows[2].Cells[1].Value.ToString().Equals("") || grdOptContext.Rows[3].Cells[1].Value.ToString().Equals("") || grdOptContext.Rows[4].Cells[1].Value.ToString().Equals("") || grdOptContext.Rows[5].Cells[1].Value.ToString().Equals("") || iRunCount == 0)
                {
                    MessageBox.Show("The parameter cannot be empty");
                }
                else
                {
                    UIServiceFun.structGetR2RContext structR2RContextNull = new UIServiceFun.structGetR2RContext();
                    UIServiceFun.structGetR2RContext structR2RContext = new UIServiceFun.structGetR2RContext();
                    structR2RContext = UIServiceFun.R2R_UI_GetR2RContext(strServiceAddres, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, iRunCount);

                    if (structR2RContext.Equals(structR2RContextNull))
                    {
                        //MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        dbGetContext = DataTableHelp.CreateContextGroupTable(structR2RContext);

                        DataTable dbContextGroup = new DataTable("ContextGroup");
                        List<string> strListColumn = new List<string>(structR2RContext.strListContexts);
                        dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

                        InitGrid(grdOptContextGroup, dbContextGroup);
                        //InitGrdOptContextGroup(structR2RContext);  

                        InitDbChuckDeditation(dbGetContext, 0);


                        if (structR2RContext.strListChuckIds.Count > 1)
                        {
                            rdoChuck.Enabled = true;
                        }
                        else
                        {
                            rdoChuck.Enabled = false;
                        }
                        strChuckId = structR2RContext.strListChuckIds[0];
                        SetChuckType(strChuckId);
                    }
                }
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }
        #endregion

        #region testChart Event
        private void chart_DataClicked(object sender, Infragistics.UltraChart.Shared.Events.ChartDataEventArgs e)
        {
            MessageBox.Show(e.DataValue.ToString());
        }
        #endregion

        #region InitGrdOptContextGroup
        private void InitGrdOptContextGroup(UIServiceFun.structGetR2RContext structR2RContext)
        {
            DataTable dataTable = new DataTable("ContextGroupTable");
            dataTable = DataTableHelp.CreateContextGroupTable(structR2RContext);

            //List<string> strListColumn = new List<string>() { "LAYER", "RETICLE" };
            List<string> strListColumn = new List<string>(structR2RContext.strListContexts);

            //显示全数据
            //grdOptContextGroup.DataSource = DataTableHelp.CreateContextGroupTable(structR2RContext);

            //显示去重后的数据
            //grdOptContextGroup.DataSource = DataTableHelp.GetDistinctTable(dataTable);
            grdOptContextGroup.DataSource = DataTableHelp.GetDistinctTable(dataTable, strListColumn);

            //grdOptContextGroup.DataSource = DataTableHelp.DistinctSomeColumn(dataTable, strListColumn);
            //grdOptContextGroup.DataSource = DataTableHelp.DistinctSomeColumn(dataTable, strListColumn.ToArray());

            grdOptContextGroup.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;

        }
        #endregion

        #region InitGrdOptContext
        private void InitGrdOptContext()
        {
            //this.grdOptContext.DataSource = DataTableHelp.CreateContextTable();

            this.grdOptContext.BeginUpdate();
            this.optContextDataSource.Rows.Clear();
            this.optContextDataSource.Rows.SetCount(6);
            this.grdOptContext.DataSource = this.optContextDataSource;

            this.grdOptContext.Rows[0].Cells["Name"].Value = "Module";
            this.grdOptContext.Rows[1].Cells["Name"].Value = "Product";
            this.grdOptContext.Rows[2].Cells["Name"].Value = "Stage";
            this.grdOptContext.Rows[3].Cells["Name"].Value = "Layer";
            this.grdOptContext.Rows[4].Cells["Name"].Value = "Control System";
            this.grdOptContext.Rows[5].Cells["Name"].Value = "Tool";

            this.grdOptContext.Rows[0].Cells["Value"].Value = "";
            this.grdOptContext.Rows[1].Cells["Value"].Value = "";
            this.grdOptContext.Rows[2].Cells["Value"].Value = "";
            this.grdOptContext.Rows[3].Cells["Value"].Value = "";
            this.grdOptContext.Rows[4].Cells["Value"].Value = "";
            this.grdOptContext.Rows[5].Cells["Value"].Value = "";

            this.grdOptContext.DataBind();
            this.grdOptContext.EndUpdate();

            //冻结行，禁止排序
            this.grdOptContext.DisplayLayout.Override.FixedRowStyle = FixedRowStyle.Top;
            for (int i = 0; i < 6; i++)
            {
                this.grdOptContext.Rows.FixedRows.Add(this.grdOptContext.Rows[i]);
                this.grdOptContext.Rows[i].Fixed = true;
            }
            this.grdOptContext.DisplayLayout.Override.FixedRowIndicator = FixedRowIndicator.Button;

            //禁止编辑
            this.grdOptContext.DisplayLayout.Bands[0].Columns[0].CellActivation = Activation.NoEdit;

            this.grdOptContext.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;

            InitContextModule();
        }
        private void InitContextModule()
        {
            if (this.grdOptContext.DisplayLayout.ValueLists.Exists("valueModule"))
            {
                this.grdOptContext.DisplayLayout.ValueLists.Remove("valueModule");
            }
            Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add("valueModule");
            foreach (var str in strListModule)
            {
                valueLists.ValueListItems.Add(str);
            }
            this.grdOptContext.Rows[0].Cells["Value"].ValueList = valueLists;

            //this.grdTab1Context.Rows[0].Cells["Value"].Value = strListModule[0];
            //this.grdTab1Context.Rows[0].Cells["Value"].Value = valueLists.ValueListItems.GetItem(0).ToString();
            //string strSelectModule = grdTab1Context.Rows[0].Cells["Value"].Text;
            //if (strSelectModule.CompareTo("Etch") == 0)
            //{
            //    this.grdTab1Context.Rows[3].Cells["Name"].Value = "Step";
            //}
            //else if (strSelectModule.Equals("Litho"))
            //{
            //    this.grdTab1Context.Rows[3].Cells["Name"].Value = "Layer";
            //}
        }

        private void InitContextProduct()
        {
            if (this.grdOptContext.DisplayLayout.ValueLists.Exists("valueProduct"))
            {
                this.grdOptContext.DisplayLayout.ValueLists.Remove("valueProduct");
            }
            Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add("valueProduct");
            foreach (var str in strListProduct)
            {
                valueLists.ValueListItems.Add(str);
            }
            this.grdOptContext.Rows[1].Cells["Value"].ValueList = valueLists;
            //this.grdOptContext.Rows[1].Cells["Value"].Value = strListProduct[0];
        }

        private void InitContextStage()
        {
            if (this.grdOptContext.DisplayLayout.ValueLists.Exists("Values2"))
            {
                this.grdOptContext.DisplayLayout.ValueLists.Remove("Values2");
            }
            Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add("Values2");
            //foreach (var str in strListProduct)
            //{
            valueLists.ValueListItems.Add("*");
            //}
            this.grdOptContext.Rows[2].Cells["Value"].ValueList = valueLists;
            //this.grdOptContext.Rows[1].Cells["Value"].Value = "*";
        }

        private void InitGrdOptContextValues(List<string> strList, int rowIndex, bool bInit)
        {
            if (this.grdOptContext.DisplayLayout.ValueLists.Exists("Values" + rowIndex))
            {
                this.grdOptContext.DisplayLayout.ValueLists.Remove("Values" + rowIndex);
            }
            Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add("Values" + rowIndex);
            foreach (var str in strList)
            {
                valueLists.ValueListItems.Add(str);
            }
            this.grdOptContext.Rows[rowIndex].Cells["Value"].ValueList = valueLists;
            if (bInit)
            {
                this.grdOptContext.Rows[rowIndex].Cells["Value"].Value = strList[0];
            }
            //this.grdOptContext.DisplayLayout.ValueLists.Remove("Values" + rowIndex);
        }

        private void InitGrdOptContextValues(List<string> strList, string strValueListName, int rowIndex, bool bDisplay)
        {
            if (this.grdOptContext.DisplayLayout.ValueLists.Exists(strValueListName))
            {
                this.grdOptContext.DisplayLayout.ValueLists.Remove(strValueListName);
            }
            Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add(strValueListName);
            foreach (var str in strList)
            {
                valueLists.ValueListItems.Add(str);
            }
            this.grdOptContext.Rows[rowIndex].Cells["Value"].ValueList = valueLists;
            if (bDisplay)
            {
                this.grdOptContext.Rows[rowIndex].Cells["Value"].Value = strList[0];
            }
            //this.grdTab1Context.DisplayLayout.ValueLists.Remove("Values" + rowIndex);
        }

        private void ClearGrdOptContextValues(int rowIndex)
        {
            for (int i = rowIndex; i < 6; i++)
            {
                if (this.grdOptContext.DisplayLayout.ValueLists.Exists("Values" + i))
                {
                    this.grdOptContext.DisplayLayout.ValueLists.Remove("Values" + i);
                }
                Infragistics.Win.ValueList valueLists = this.grdOptContext.DisplayLayout.ValueLists.Add("Values" + i);
                valueLists.ValueListItems.Add("");
                this.grdOptContext.Rows[i].Cells["Value"].ValueList = valueLists;
                this.grdOptContext.Rows[i].Cells["Value"].Value = "";
            }
        }
        #endregion

        #region grdOptContext Event
        private void grdOptContext_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

            #region 设置列格式为DropDownList
            //Infragistics.Win.ValueList valueLists = this.grdTab1ContextGroup.DisplayLayout.ValueLists.Add("Values");
            ////e.Layout.ValueLists.Add("Values");
            ////e.Layout.ValueLists.Add("Values").ValueListItems.Add(1, "1");
            //e.Layout.Bands[0].Columns[1].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            //e.Layout.Bands[0].Columns[1].ValueList = e.Layout.ValueLists["Values"];
            //e.Layout.Bands["Context"].Columns["Value"].ValueList = e.Layout.ValueLists["Values"];

            //e.Layout.Bands[0].Columns[0].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.CheckBox;
            #endregion

            #region 设置颜色
            //this.grdOptContext.DisplayLayout.Bands[0].Header.Appearance.BackColor = SystemColors.ActiveCaption;
            //this.grdOptContext.DisplayLayout.Bands[0].Header.Appearance.ForeColor = SystemColors.ActiveCaptionText;

            this.grdOptContext.DisplayLayout.Bands[0].Header.Appearance.BackColor = Color.Blue;
            this.grdOptContext.DisplayLayout.Bands[0].Header.Appearance.ForeColor = Color.Red;

            //this.grdOptContext.DisplayLayout.Override.ActiveRowAppearance.BackColor = Color.Blue;
            //this.grdOptContext.DisplayLayout.Override.ActiveRowAppearance.ForeColor = Color.White;
            //this.grdOptContext.DisplayLayout.Override.RowSelectorAppearance.BackColor = Color.Blue;
            //this.grdOptContext.DisplayLayout.Override.RowSelectorAppearance.ForeColor = Color.White;

            //this.grdOptContext.DisplayLayout.Override.SelectedRowAppearance.BackColor = Color.SteelBlue;
            #endregion

            #region 设置列格式
            this.grdOptContext.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //this.grdOptContext.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //this.grdOptContext.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //this.grdOptContext.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //this.grdOptContext.DisplayLayout.Override.ColumnAutoSizeMode =ColumnAutoSizeMode.VisibleRows;
            //this.grdOptContext.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //this.grdOptContext.Rows[0].PerformAutoSize();
            //this.grdOptContext.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
            #endregion

            #region 冻结列
            //this.grdOptContext.DisplayLayout.UseFixedHeaders = true;
            //this.grdOptContext.DisplayLayout.Bands[0].Columns[0].Header.Fixed = true;
            //this.grdOptContext.DisplayLayout.Bands[0].Columns[0].Header.FixedHeaderIndicator = FixedHeaderIndicator.None;
            //this.grdOptContext.DisplayLayout.Override.FixedHeaderAppearance.BackColor = Color.LightYellow;
            //this.grdOptContext.DisplayLayout.Override.FixedCellAppearance.BackColor = Color.LightYellow;
            //this.grdOptContext.DisplayLayout.Override.FixedCellSeparatorColor = Color.Red;
            #endregion

            #region 数据过滤器
            //e.Layout.Override.AllowRowFiltering = DefaultableBoolean.True;
            e.Layout.Override.AllowRowFiltering = DefaultableBoolean.False;
            e.Layout.Override.RowFilterAction = RowFilterAction.AppearancesOnly;
            e.Layout.Override.FilteredInCellAppearance.ForeColor = Color.DarkGreen;
            e.Layout.Override.FilteredOutCellAppearance.ForeColor = Color.DarkRed;
            #endregion
        }

        private void grdOptContext_CellListSelect(object sender, CellEventArgs e)
        {
            //MessageBox.Show("CellListSelect");   
            try
            {
                #region 
                string strValueListName = e.Cell.ValueList.ToString();
                this.Cursor = Cursors.WaitCursor;
                switch (strValueListName)
                {
                    case "valueModule":
                        ClearGrdOptContextValues(1);
                        strCurrentModule = grdOptContext.Rows[0].Cells["Value"].Text;
                        if (strCurrentModule.Equals("LITHO"))
                        {
                            this.grdOptContext.Rows[3].Cells["Name"].Value = "Layer";
                        }
                        else
                        {
                            this.grdOptContext.Rows[3].Cells["Name"].Value = "Step";
                        }
                        strListProduct = UIServiceFun.R2R_UI_GetProduct(strUserName, strServiceAddres, strCurrentModule);
                        InitGrdOptContextValues(strListProduct, 1, false);
                        //MessageBox.Show("valueModule");
                        break;
                    case "Values1":
                        ClearGrdOptContextValues(2);
                        strCurrentProduct = grdOptContext.Rows[1].Cells["Value"].Text;
                        //strListStage = UIServiceFun.GetStage(strUserName, strServiceAddres, strCurrentModule, strCurrentProduct);
                        //InitContextValues(strListStage, 2);
                        //grdTab1Context.Rows[2].Cells["Value"].Value = "*";
                        //strCurrentStage = grdTab1Context.Rows[2].Cells["Value"].Text;
                        //MessageBox.Show("valueProduct");
                        InitContextStage();
                        break;
                    case "Values2":
                        ClearGrdOptContextValues(3);
                        strCurrentStage = grdOptContext.Rows[2].Cells["Value"].Text;
                        strListLayer = UIServiceFun.R2R_UI_GetLayerOrStep(strUserName, strServiceAddres, strCurrentModule, strCurrentProduct, strCurrentStage);
                        InitGrdOptContextValues(strListLayer, 3, false);
                        //MessageBox.Show("ValueStage");
                        break;
                    case "Values3":
                        ClearGrdOptContextValues(4);
                        strCurrentLayer = grdOptContext.Rows[3].Cells["Value"].Text;
                        strListController = UIServiceFun.R2R_UI_GetController(strUserName, strServiceAddres, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer);
                        InitGrdOptContextValues(strListController, 4, false);
                        //MessageBox.Show("ValueControlSys");
                        break;
                    case "Values4":
                        ClearGrdOptContextValues(5);
                        strCurrentController = grdOptContext.Rows[4].Cells["Value"].Text;

                        SetTabSubShow(strCurrentController);

                        strListTool = UIServiceFun.R2R_UI_GetTool(strUserName, strServiceAddres, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer, strCurrentController);
                        InitGrdOptContextValues(strListTool, 5, false);
                        //MessageBox.Show("ValueTool");
                        break;
                    default:
                        break;
                }
                ClearControl();
                SetControlShow(false, false, false, false, false);
                strCurrentTool = grdOptContext.Rows[5].Cells["Value"].Text;
                this.Cursor = Cursors.Default;
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
                this.Cursor = Cursors.Default;
            }
        }

        private void grdOptContext_CellChange(object sender, CellEventArgs e)
        {
            //MessageBox.Show("cellChange");
        }

        private void grdOptContext_ClickCell(object sender, ClickCellEventArgs e)
        {
            //MessageBox.Show(e.Cell.Column.Index.ToString());
            //MessageBox.Show(e.Cell.Row.Index.ToString());
        }
        #endregion

        #region TabSub Event
        private void tabSub_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            int tabIndex = 0;
            tabIndex = tabSub.SelectedTab.Index;
            switch (tabIndex)
            {
                case 0:
                    //rdoList.Hide();   rdoChuck.Enabled = true;    btnOptReset.Enabled = true; btnOptMode.Enabled = false; btnOptUpdate.Enabled = false;
                    SetControlShow(false, true, true, false, false);
                    //MessageBox.Show("tab0-Linear");
                    break;
                case 1:
                    SetControlShow(false, true, true, false, false);
                    //MessageBox.Show("tab1-HOPC");
                    break;
                case 2:
                    SetControlShow(false, true, true, false, false);
                    //MessageBox.Show("tab2-IHOPC");
                    break;
                case 3:
                    //rdoList.Hide();   rdoChuck.Enabled = true;    btnOptReset.Enabled = false;    btnOptMode.Enabled = true;  btnOptUpdate.Enabled = false;
                    SetControlShow(false, true, false, true, false);
                    //MessageBox.Show("tab3-CPE");
                    break;
                case 4:
                    //rdoList.Show();   rdoChuck.Enabled = true;    btnOptReset.Enabled = true; btnOptMode.Enabled = true;  btnOptUpdate.Enabled = false;
                    SetControlShow(true, true, true, true, false);
                    //MessageBox.Show("tab4-CD");
                    break;
                case 5:
                    //rdoList.Hide();   rdoChuck.Enabled = true;    btnOptReset.Enabled = false;    btnOptMode.Enabled = false; btnOptUpdate.Enabled = true;
                    SetControlShow(false, true, false, false, true);
                    //MessageBox.Show("tab5-Focus");
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region Button Event
        private void btnQueryLotInfo_Click(object sender, EventArgs e)
        {
            frmChuckDedication frm = new frmChuckDedication(strServiceAddres, dbChuckDeditation);
            frm.ShowDialog();
        }

        private void btnOptManualRun_Click(object sender, EventArgs e)
        {
            frmManualRun frm = new frmManualRun(strReticle, strReticle2, nReticle);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show(frm.strListCurrent[0]);
            }
            else
            {

            }
        }

        private void btnOptBatchOperation_Click(object sender, EventArgs e)
        {
            //strArea = "LITHO";
            strArea = strCurrentModule;
            #region PH_OVL_Batch_GetContexts
            UIServiceFun.structPH_OVL_Batch_GetContexts structDataNull = new UIServiceFun.structPH_OVL_Batch_GetContexts();
            UIServiceFun.structPH_OVL_Batch_GetContexts structData = new UIServiceFun.structPH_OVL_Batch_GetContexts();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetContexts(strServiceAddres, strArea);
            
            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmBatchOperation frm = new frmBatchOperation(strServiceAddres, strArea, structData);
                frm.ShowDialog();
            }
            #endregion
        }

        private void btnOptMode_Click(object sender, EventArgs e)
        {
            int tabIndex = 0;
            tabIndex = tabSub.SelectedTab.Index;
            switch (tabIndex)
            {
                case 3:
                    #region OVLMode
                    //UIServiceFun.structOVLMode structOVLModeNull = new UIServiceFun.structOVLMode();
                    //UIServiceFun.structOVLMode structOVLMode = new UIServiceFun.structOVLMode();
                    //structOVLMode = UIServiceFun.R2R_UI_OVLMode(strUserName, strServiceAddres, strCurrentProduct, strCurrentStage, strCurrentLayer, strCurrentController, strCurrentTool);

                    //if (structOVLMode.Equals(structOVLModeNull))
                    //{
                    //    //MessageBox.Show("Data is empty!");
                    //}
                    //else
                    //{
                    //    frmCPEMode frm = new frmCPEMode();
                    //    if (frm.ShowDialog() == DialogResult.OK)
                    //    {
                    //        //MessageBox.Show(frm.strListCurrent[0]);
                    //    }
                    //    else
                    //    {

                    //    }
                    //}
                    #endregion
                    break;
                case 4:
                    #region PH_CD_GetDoseSettings
                    UIServiceFun.structPH_CD_GetDoseSettings structSettingsNull = new UIServiceFun.structPH_CD_GetDoseSettings();
                    UIServiceFun.structPH_CD_GetDoseSettings structSettings = new UIServiceFun.structPH_CD_GetDoseSettings();
                    structSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseSettings(strServiceAddres, strListR2RContexts);

                    if (structSettings.Equals(structSettingsNull))
                    {
                        //MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        frmCDMode frm = new frmCDMode(strServiceAddres, strListR2RContexts, structSettings);
                        if (frm.ShowDialog() == DialogResult.OK)
                        {
                            //MessageBox.Show(frm.strListCurrent[0]);
                        }
                        else
                        {

                        }
                    }
                    #endregion
                    break;
                default:
                    break;
            }
        }

        private void btnOptReset_Click(object sender, EventArgs e)
        {
            int tabIndex = 0;
            tabIndex = tabSub.SelectedTab.Index;
            switch (tabIndex)
            {
                case 0:
                    #region PH_OVL_GetResetValues
                    strOVLModelType = "LINEAR";
                    //strReticleId = "RETICLE1";
                    UIServiceFun.structPH_OVL_GetResetValues structResetValuesNull = new UIServiceFun.structPH_OVL_GetResetValues();
                    UIServiceFun.structPH_OVL_GetResetValues structResetValues = new UIServiceFun.structPH_OVL_GetResetValues();
                    structResetValues = UIServiceFun.R2R_UI_PH_OVL_GetResetValues(strServiceAddres, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, strOVLModelType, strChuckId, strReticleId);

                    if (structResetValues.Equals(structResetValuesNull))
                    {
                        //MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        frmLinearReset frm = new frmLinearReset(strServiceAddres, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, strChuckId, structResetValues);
                        if (frm.ShowDialog() == DialogResult.OK)
                        {
                            //MessageBox.Show(frm.strListCurrent[0]);
                        }
                        else
                        {

                        }
                    }
                    #endregion
                    break;
                case 4:
                    #region PH_CD_GetDoseResetSettings
                    UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettingsNull = new UIServiceFun.structPH_CD_GetDoseResetSettings();
                    UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettings = new UIServiceFun.structPH_CD_GetDoseResetSettings();
                    structResetSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseResetSettings(strServiceAddres, strListR2RContexts);
                    
                    if (structResetSettings.Equals(structResetSettingsNull))
                    {
                        //MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        frmCDReset frm = new frmCDReset(strServiceAddres, strListR2RContexts, structResetSettings);
                        if (frm.ShowDialog() == DialogResult.OK)
                        {
                            //MessageBox.Show(frm.strListCurrent[0]);
                        }
                        else
                        {

                        }
                    }
                    #endregion
                    break;
                default:
                    break;
            }
        }

        private void btnOptUpdate_Click(object sender, EventArgs e)
        {
            double dValue = 0.0;
            #region R2R_UI_PH_Focus_GetFocusSettings
            dValue = UIServiceFun.R2R_UI_PH_Focus_GetFocusSettings(strServiceAddres, strListR2RContexts);

            frmFocusUpdate frm = new frmFocusUpdate(strServiceAddres, strListR2RContexts, dValue);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show(frm.strListCurrent[0]);
            }
            else
            {

            }
            #endregion
        }

        #endregion

        #region Menu
        private void menuManage_ToolClick(object sender, Infragistics.Win.UltraWinToolbars.ToolClickEventArgs e)
        {
            switch (e.Tool.Key)
            {
                case "Exit":
                    this.Close();
                    break;
                case "Chuck Dedication":
                    frmChuckDedication frm = new frmChuckDedication(strServiceAddres, dbChuckDeditation);
                    frm.ShowDialog();
                    //MessageBox.Show("Show frmChuckDedication");
                    break;
                case "test1":
                    MessageBox.Show("test1");
                    break;
                case "test2":
                    MessageBox.Show("test2");
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region Grid Event
        private void grdOptContextGroup_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }

        private void grdOptContextGroup_DoubleClickRow(object sender, DoubleClickRowEventArgs e)
        {
            //MessageBox.Show(grdOptContextGroup.Rows[e.Row.VisibleIndex].Cells[0].Value.ToString());
            int chartColumn;
            int chartNumber;
            int iOutputSize = 0;
            int iOutputCount = 0;
            int iOutputStartIndex = 0;

            DataTable dbOVL = null;
            List<string> strListItemNames = new List<string>();
            List<string> strListItemValues = new List<string>();
            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();
            List<List<double>> dListItemValuesResult = new List<List<double>>();

            strListR2RContexts.Clear();
            for (int i = 0; i < dbGetContext.Columns.Count; i++)
            {
                strListR2RContexts.Add(grdOptContextGroup.Rows[e.Row.VisibleIndex].Cells[i].Value.ToString());
            }
            strReticleId = grdOptContextGroup.Rows[e.Row.VisibleIndex].Cells["RETICLE"].Value.ToString();
            //strCurrentController = "PH_OVL_ASML_R2R_Model";
            //strListR2RContexts = new List<string>() { "Tool_Id1", "PRODUCT","LAYER3","RETICLE2","PRELAYER_TOOL2","PRELAYER_RETICLE1","NA", "NA", "NA", "ALIGNMENT_TOOL1", "ALIGNMENT_RETICLE1","PREAREA_TOOL1"};
            try
            {
                switch (strCurrentController)
                {
                    case "PH_OVL_ASML_R2R_Model":
                        #region PH_OVL_GetLotRunHistory 
                        UIServiceFun.structPH_OVL_GetLotRunHistory structOVLLotRunHistoryNull = new UIServiceFun.structPH_OVL_GetLotRunHistory();
                        UIServiceFun.structPH_OVL_GetLotRunHistory structOVLLotRunHistory = new UIServiceFun.structPH_OVL_GetLotRunHistory();
                        structOVLLotRunHistory = UIServiceFun.R2R_UI_PH_OVL_GetLotRunHistory(strServiceAddres, strCurrentController, strListR2RContexts);

                        if (structOVLLotRunHistory.Equals(structOVLLotRunHistoryNull))
                        {
                            //MessageBox.Show("Data is empty!");
                        }
                        else
                        {
                            if (structOVLLotRunHistory.bLinearMode)
                            {
                                btnOptReset.Enabled = true;
                                tabSub.SelectedTab = tabSub.Tabs[0];

                                strListLotIds = new List<string>(structOVLLotRunHistory.strListLinear_LotIds);
                                strListUsedTimeStamps = new List<string>(structOVLLotRunHistory.strListLinear_UsedTimeStamps);
                                dbOVL = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps);
                                InitGrid(grdOptLinear, dbOVL);

                                iOutputSize = structOVLLotRunHistory.iLinear_OutputSize;
                                strToolVendor = structOVLLotRunHistory.strToolVendor;
                                strListItemNames = new List<string>(structOVLLotRunHistory.strListLinear_ItemNames_PostMetrology);
                                strListItemValues = new List<string>(structOVLLotRunHistory.strListLinear_ItemValues_PostMetrology);
                            }
                            if (structOVLLotRunHistory.bHOPCMode)
                            {
                                btnOptReset.Enabled = true;
                                tabSub.SelectedTab = tabSub.Tabs[1];

                                strListLotIds = new List<string>(structOVLLotRunHistory.strListHOPC_LotIds);
                                strListUsedTimeStamps = new List<string>(structOVLLotRunHistory.strListHOPC_UsedTimeStamps);
                                dbOVL = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps);
                                InitGrid(grdOptHOPC, dbOVL);

                                iOutputSize = structOVLLotRunHistory.iHOPC_OutputSize;
                                strToolVendor = structOVLLotRunHistory.strToolVendor;
                                strListItemNames = new List<string>(structOVLLotRunHistory.strListHOPC_ItemNames_PostMetrology);
                                strListItemValues = new List<string>(structOVLLotRunHistory.strListHOPC_ItemValues_PostMetrology);
                            }
                            if (structOVLLotRunHistory.bIHOPCMode)
                            {
                                btnOptReset.Enabled = true;
                                tabSub.SelectedTab = tabSub.Tabs[2];

                                strListLotIds = new List<string>(structOVLLotRunHistory.strListIHOPC_LotIds);
                                strListUsedTimeStamps = new List<string>(structOVLLotRunHistory.strListIHOPC_UsedTimeStamps);
                                InitGrid(grdOptIHOPC, dbOVL);

                                iOutputSize = structOVLLotRunHistory.iIHOPC_OutputSize;
                                strToolVendor = structOVLLotRunHistory.strToolVendor;
                                strListItemNames = new List<string>(structOVLLotRunHistory.strListIHOPC_ItemNames_PostMetrology);
                                strListItemValues = new List<string>(structOVLLotRunHistory.strListIHOPC_ItemValues_PostMetrology);
                            }
                            //if (structOVLLotRunHistory.bCPEMode)
                            //{
                            //    btnOptMode.Enabled = true;
                            //    tabSub.SelectedTab = tabSub.Tabs[3];

                            //    iOutputSize = structOVLLotRunHistory.iCPE_OutputSize;
                            //    strToolVendor = structOVLLotRunHistory.strToolVendor;

                            //    strListLotIds = new List<string>(structOVLLotRunHistory.strListCPE_LotIds);
                            //    strListUsedTimeStamps = new List<string>(structOVLLotRunHistory.strListCPE_UsedTimeStamps);
                            //    InitGrid(grdOptCPE, dbOVL);
                            //}
                            #endregion

                            #region Create Chart  
                            if (strToolVendor.Equals("ASML"))
                            {
                                bToolVendorASML = true;
                                iOutputCount = iOutputSize / 2;

                                //iOutputStartIndex = bChuckOne ? 0 : iOutputSize / 2;
                                if (bChuckOne)
                                {
                                    iOutputStartIndex = 0;
                                }
                                else
                                {
                                    iOutputStartIndex = iOutputSize / 2;
                                }
                            }
                            else
                            {
                                bToolVendorASML = false;
                                iOutputCount = iOutputSize;
                                iOutputStartIndex = 0;
                            }
                            dListItemValuesResult.Clear();
                            dListItemValuesResult = BaseFun.GetItemValues(strListItemValues, iOutputStartIndex, iOutputCount);

                            chartColumn = 1;
                            chartNumber = strListItemNames.Count();
                            panOptPicture.ClientArea.Controls.Clear();//清空panel
                            AddControlHelp.AddChartToPanel(panOptPicture, ref ctlListChart, chartColumn, chartNumber, strListItemNames, dListItemValuesResult, strListLotIds);

                            if (ctlListChart.Count > 0)
                            {
                                for (int i = 0; i < ctlListChart.Count; i++)
                                {
                                    ctlListChart[i].ChartDataClicked += chart_DataClicked;
                                }
                            }
                            //AddControlHelp.CreateChart(panOptPicture, ref ctlListChart, chartColumn, chartNumber, strListItemNames, dListItemValuesResult, strListLotIds);
                            //List<DataTable> dbList = new List<DataTable>();
                            //dbList = DataTableHelp.CreatChartDataTable(strListItemValuesResult, strListLotIds);
                            //AddControlHelp.CreateChart(panOptPicture, ref ctlListChart, chartColumn, chartNumber, strListItemNames, dbList);
                        }
                        #endregion

                        break;
                    case "PH_CD_R2R_Model":
                        #region PH_CD_GetLotRunHistory
                        UIServiceFun.structPH_CD_GetLotRunHistory structCDHistoryNull = new UIServiceFun.structPH_CD_GetLotRunHistory();
                        UIServiceFun.structPH_CD_GetLotRunHistory structCDHistory = new UIServiceFun.structPH_CD_GetLotRunHistory();
                        structCDHistory = UIServiceFun.R2R_UI_PH_CD_GetLotRunHistory(strServiceAddres, strListR2RContexts);

                        if (structCDHistory.Equals(structCDHistoryNull))
                        {
                            //MessageBox.Show("Data is empty!");
                        }
                        else
                        {
                            btnOptReset.Enabled = true;
                            btnOptMode.Enabled = true;
                            tabSub.SelectedTab = tabSub.Tabs[4];

                            strListLotIds = new List<string>(structCDHistory.strListLotIds);
                            strListUsedTimeStamps = new List<string>(structCDHistory.strListUsedTimeStamps);
                            dbOVL = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps);
                            InitGrid(grdOptCD, dbOVL);

                            List<string> strListCD = new List<string>(structCDHistory.strListCD);
                            List<string> strListDose = new List<string>(structCDHistory.strListDose);
                            dListItemValuesResult.Clear();
                            dListItemValuesResult = BaseFun.GetItemValues(strListCD);

                            chartColumn = 1;
                            chartNumber = dListItemValuesResult.Count();
                            panOptPicture.ClientArea.Controls.Clear();//清空panel
                            AddControlHelp.AddChartToPanel(panOptPicture, ref ctlListChart, chartColumn, chartNumber, strListLotIds, dListItemValuesResult, strListLotIds);
                        }
                        #endregion

                        break;
                    case "PH_Focus_R2R_Model":
                        #region PH_Focus_GetLotRunHistory
                        UIServiceFun.structPH_Focus_GetLotRunHistory structFocusHistoryNull = new UIServiceFun.structPH_Focus_GetLotRunHistory();
                        UIServiceFun.structPH_Focus_GetLotRunHistory structFocusHistory = new UIServiceFun.structPH_Focus_GetLotRunHistory();
                        structFocusHistory = UIServiceFun.R2R_UI_PH_Focus_GetLotRunHistory(strServiceAddres, strListR2RContexts);

                        if (structFocusHistory.Equals(structFocusHistoryNull))
                        {
                            //MessageBox.Show("Data is empty!");
                        }
                        else
                        {
                            tabSub.SelectedTab = tabSub.Tabs[5];

                            strListLotIds = new List<string>(structFocusHistory.strListLotIds);
                            strListUsedTimeStamps = new List<string>(structFocusHistory.strListUsedTimeStamps);
                            dbOVL = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps);
                            InitGrid(grdOptFocus, dbOVL);
                        }
                        #endregion
                        break;
                    default:
                        break;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        public DataTable dbChuckDeditation = new DataTable();
        private void grdOptContextGroup_ClickCell(object sender, ClickCellEventArgs e)
        {
            //MessageBox.Show(e.Cell.Column.Index.ToString());
            //MessageBox.Show(e.Cell.Row.Index.ToString());

            InitDbChuckDeditation(dbGetContext, e.Cell.Row.Index);
        }

        private void grdOptContextGroup_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            #region test
            //try
            //{
            //    string strReticle = grdOptContextGroup.Rows[e.Row.VisibleIndex].Cells[3].Value.ToString();
            //    string strPrealayerTool = grdOptContextGroup.Rows[e.Row.VisibleIndex].Cells[4].Value.ToString();
            //    var query =
            //    from p in dbGetContext.AsEnumerable()
            //    where p.Field<string>(dbGetContext.Columns[3]) == strReticle && p.Field<string>(dbGetContext.Columns[4]) == strPrealayerTool
            //    select p;

            //    ////通过CopyToDataTable()方法创建新的副本
            //    DataTable dbLinear = query.CopyToDataTable<DataRow>();

            //    ////foreach (var item in dbLinear.AsEnumerable())
            //    ////{
            //    ////    MessageBox.Show(item["Recipe"].ToString());
            //    ////}

            //    InitGrid(grdOptLinear, dbLinear);
            //    //InitGrdOptLinear(grdOptLinear, LinearTable);
            //}
            //catch(Exception err)
            //{
            //    MessageBox.Show(err.Message);
            //}
            #endregion

            //MessageBox.Show(e.Cell.Column.Index.ToString());
            //MessageBox.Show(e.Cell.Row.Index.ToString());
        }

        private void grdOptCD_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }

        private void grdOptCD_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            #region PH_CD_GetWaferLevelMeasurement
            UIServiceFun.structPH_CD_GetWaferLevelMeasurement structDataNull = new UIServiceFun.structPH_CD_GetWaferLevelMeasurement();
            UIServiceFun.structPH_CD_GetWaferLevelMeasurement structData = new UIServiceFun.structPH_CD_GetWaferLevelMeasurement();
            structData = UIServiceFun.R2R_UI_PH_CD_GetWaferLevelMeasurement(strServiceAddres, strListR2RContexts);
            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
            }
            #endregion
        }

        private void grdOptFocus_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }

        private void grdOptFocus_DoubleClickCell(object sender, DoubleClickCellEventArgs e)
        {
            #region PH_Focus_GetWaferLevelMeasurement
            UIServiceFun.structPH_Focus_GetWaferLevelMeasurement structDataNull = new UIServiceFun.structPH_Focus_GetWaferLevelMeasurement();
            UIServiceFun.structPH_Focus_GetWaferLevelMeasurement structData = new UIServiceFun.structPH_Focus_GetWaferLevelMeasurement();
            structData = UIServiceFun.R2R_UI_PH_Focus_GetWaferLevelMeasurement(strServiceAddres, strListR2RContexts);

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
            }
            #endregion
        }
        #endregion
    }
}
