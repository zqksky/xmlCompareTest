﻿namespace ControlUI
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            this.panLogin = new Infragistics.Win.Misc.UltraPanel();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.chkAutoLogin = new Infragistics.Win.UltraWinEditors.UltraCheckEditor();
            this.txtDomainName = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.cmbServerAddress = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.txtUserName = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraLabel4 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel3 = new Infragistics.Win.Misc.UltraLabel();
            this.txtPassword = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.btnLogin = new Infragistics.Win.Misc.UltraButton();
            this.panBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.panTxt = new Infragistics.Win.Misc.UltraPanel();
            this.panLogin.ClientArea.SuspendLayout();
            this.panLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutoLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDomainName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbServerAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword)).BeginInit();
            this.panBtn.ClientArea.SuspendLayout();
            this.panBtn.SuspendLayout();
            this.panTxt.ClientArea.SuspendLayout();
            this.panTxt.SuspendLayout();
            this.SuspendLayout();
            // 
            // panLogin
            // 
            // 
            // panLogin.ClientArea
            // 
            this.panLogin.ClientArea.Controls.Add(this.panTxt);
            this.panLogin.ClientArea.Controls.Add(this.panBtn);
            this.panLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panLogin.Location = new System.Drawing.Point(0, 0);
            this.panLogin.Name = "panLogin";
            this.panLogin.Size = new System.Drawing.Size(504, 325);
            this.panLogin.TabIndex = 0;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Location = new System.Drawing.Point(61, 47);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(84, 14);
            this.ultraLabel1.TabIndex = 23;
            this.ultraLabel1.Text = "Domain Name*:";
            // 
            // chkAutoLogin
            // 
            this.chkAutoLogin.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkAutoLogin.Location = new System.Drawing.Point(55, 235);
            this.chkAutoLogin.Name = "chkAutoLogin";
            this.chkAutoLogin.Size = new System.Drawing.Size(86, 23);
            this.chkAutoLogin.TabIndex = 34;
            this.chkAutoLogin.Text = "Auto Login";
            // 
            // txtDomainName
            // 
            this.txtDomainName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDomainName.Location = new System.Drawing.Point(173, 43);
            this.txtDomainName.Name = "txtDomainName";
            this.txtDomainName.Size = new System.Drawing.Size(256, 21);
            this.txtDomainName.TabIndex = 27;
            this.txtDomainName.Text = "Amat";
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Location = new System.Drawing.Point(76, 93);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(69, 14);
            this.ultraLabel2.TabIndex = 24;
            this.ultraLabel2.Text = "User Name*:";
            // 
            // cmbServerAddress
            // 
            this.cmbServerAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            valueListItem1.DataValue = "ValueListItem0";
            valueListItem1.DisplayText = "localhost";
            this.cmbServerAddress.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1});
            this.cmbServerAddress.Location = new System.Drawing.Point(173, 190);
            this.cmbServerAddress.Name = "cmbServerAddress";
            this.cmbServerAddress.Size = new System.Drawing.Size(256, 21);
            this.cmbServerAddress.TabIndex = 33;
            this.cmbServerAddress.Text = "localhost";
            // 
            // txtUserName
            // 
            this.txtUserName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUserName.Location = new System.Drawing.Point(173, 89);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(256, 21);
            this.txtUserName.TabIndex = 29;
            this.txtUserName.Text = "XNi160297";
            // 
            // ultraLabel4
            // 
            this.ultraLabel4.AutoSize = true;
            this.ultraLabel4.Location = new System.Drawing.Point(55, 190);
            this.ultraLabel4.Name = "ultraLabel4";
            this.ultraLabel4.Size = new System.Drawing.Size(90, 14);
            this.ultraLabel4.TabIndex = 26;
            this.ultraLabel4.Text = "Server Address*:";
            // 
            // ultraLabel3
            // 
            this.ultraLabel3.AutoSize = true;
            this.ultraLabel3.Location = new System.Drawing.Point(84, 142);
            this.ultraLabel3.Name = "ultraLabel3";
            this.ultraLabel3.Size = new System.Drawing.Size(61, 14);
            this.ultraLabel3.TabIndex = 25;
            this.ultraLabel3.Text = "Password*:";
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.Location = new System.Drawing.Point(173, 138);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(256, 21);
            this.txtPassword.TabIndex = 31;
            this.txtPassword.Text = "Amat2018.";
            // 
            // btnLogin
            // 
            this.btnLogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogin.Location = new System.Drawing.Point(271, 12);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 35;
            this.btnLogin.Text = "OK";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // panBtn
            // 
            // 
            // panBtn.ClientArea
            // 
            this.panBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panBtn.ClientArea.Controls.Add(this.btnLogin);
            this.panBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtn.Location = new System.Drawing.Point(0, 280);
            this.panBtn.Name = "panBtn";
            this.panBtn.Size = new System.Drawing.Size(504, 45);
            this.panBtn.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(377, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 36;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panTxt
            // 
            // 
            // panTxt.ClientArea
            // 
            this.panTxt.ClientArea.Controls.Add(this.txtDomainName);
            this.panTxt.ClientArea.Controls.Add(this.txtPassword);
            this.panTxt.ClientArea.Controls.Add(this.chkAutoLogin);
            this.panTxt.ClientArea.Controls.Add(this.ultraLabel1);
            this.panTxt.ClientArea.Controls.Add(this.ultraLabel3);
            this.panTxt.ClientArea.Controls.Add(this.ultraLabel4);
            this.panTxt.ClientArea.Controls.Add(this.txtUserName);
            this.panTxt.ClientArea.Controls.Add(this.ultraLabel2);
            this.panTxt.ClientArea.Controls.Add(this.cmbServerAddress);
            this.panTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panTxt.Location = new System.Drawing.Point(0, 0);
            this.panTxt.Name = "panTxt";
            this.panTxt.Size = new System.Drawing.Size(504, 280);
            this.panTxt.TabIndex = 35;
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 325);
            this.Controls.Add(this.panLogin);
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmLogin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLogin_FormClosing);
            this.Load += new System.EventHandler(this.frmLogin_Load);
            this.Resize += new System.EventHandler(this.frmLogin_Resize);
            this.panLogin.ClientArea.ResumeLayout(false);
            this.panLogin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkAutoLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDomainName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbServerAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword)).EndInit();
            this.panBtn.ClientArea.ResumeLayout(false);
            this.panBtn.ResumeLayout(false);
            this.panTxt.ClientArea.ResumeLayout(false);
            this.panTxt.ClientArea.PerformLayout();
            this.panTxt.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panLogin;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor cmbServerAddress;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtPassword;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtUserName;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtDomainName;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.Misc.UltraLabel ultraLabel3;
        private Infragistics.Win.Misc.UltraLabel ultraLabel4;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnLogin;
        private Infragistics.Win.UltraWinEditors.UltraCheckEditor chkAutoLogin;
        private Infragistics.Win.Misc.UltraPanel panBtn;
        private Infragistics.Win.Misc.UltraPanel panTxt;
    }
}