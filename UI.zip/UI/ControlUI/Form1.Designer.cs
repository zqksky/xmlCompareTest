﻿namespace ControlUI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab12 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab13 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab14 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab15 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab16 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab17 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance88 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance92 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance93 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance94 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance95 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance96 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance97 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance98 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance99 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance100 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance101 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance102 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance103 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance104 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinGrid.UltraGridBand ultraGridBand1 = new Infragistics.Win.UltraWinGrid.UltraGridBand("Context", -1);
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn1 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Name", -1, null, 0, Infragistics.Win.UltraWinGrid.SortIndicator.Ascending, false);
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn2 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Value");
            Infragistics.Win.Appearance appearance105 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance106 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance107 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance108 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance109 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance110 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance111 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance112 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance113 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance114 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance115 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn1 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Name");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn2 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Value");
            Infragistics.Win.Appearance appearance116 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance117 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance118 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance119 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem7 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance120 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance121 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab3 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance90 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel1 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel2 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance91 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel3 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel4 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance89 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinToolbars.UltraToolbar ultraToolbar1 = new Infragistics.Win.UltraWinToolbars.UltraToolbar("UltraToolbar1");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool13 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("File");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool14 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Edit");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool15 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Help");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool16 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("File");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool5 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Exit");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool11 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Open");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool17 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Edit");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool12 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Copy");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool14 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Past");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool13 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Save");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool18 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Help");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool1 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Help");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool32 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("GridRightClick");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool4 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Chuck Dedication");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool1 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Exit");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool2 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Chuck Dedication");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool3 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Save");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool6 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Open");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool7 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Copy");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool8 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Past");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool2 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("test");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool17 = new Infragistics.Win.UltraWinToolbars.ButtonTool("test1");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool18 = new Infragistics.Win.UltraWinToolbars.ButtonTool("test2");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool15 = new Infragistics.Win.UltraWinToolbars.ButtonTool("test1");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool16 = new Infragistics.Win.UltraWinToolbars.ButtonTool("test2");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn3 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("colName");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn4 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("colValue");
            this.ultraTabPageControl4 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panSubTab1 = new Infragistics.Win.Misc.UltraPanel();
            this.panSubTab1_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptLinear = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panSubTab1_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl5 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panSubTab2 = new Infragistics.Win.Misc.UltraPanel();
            this.panSubTab2_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptHOPC = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panSubTab2_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl6 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraPanel3 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraPanel3_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptIHOPC = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.ultraPanel3_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor6 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl7 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panSubTab4 = new Infragistics.Win.Misc.UltraPanel();
            this.panCPE_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptCPE = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panCPE_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor5 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl8 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panSubTab5 = new Infragistics.Win.Misc.UltraPanel();
            this.panSubTab5_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptCD = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panSubTab5_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor3 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl9 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panSubTab6 = new Infragistics.Win.Misc.UltraPanel();
            this.panSubTab6_2 = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptFocus = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panSubTab6_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor4 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panOpt = new Infragistics.Win.Misc.UltraPanel();
            this.panOptPicture = new Infragistics.Win.Misc.UltraPanel();
            this.ultraSplitter5 = new Infragistics.Win.Misc.UltraSplitter();
            this.ultraSplitter2 = new Infragistics.Win.Misc.UltraSplitter();
            this.panTab1Lots = new Infragistics.Win.Misc.UltraPanel();
            this.panOptLotsGrid = new Infragistics.Win.Misc.UltraPanel();
            this.tabSub = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage2 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.ultraSplitter4 = new Infragistics.Win.Misc.UltraSplitter();
            this.panOptSubControl = new Infragistics.Win.Misc.UltraPanel();
            this.rdoList = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.btnOptUpdate = new Infragistics.Win.Misc.UltraButton();
            this.btnOptMode = new Infragistics.Win.Misc.UltraButton();
            this.btnOptReset = new Infragistics.Win.Misc.UltraButton();
            this.ultraTextEditor17 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor18 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor19 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraSplitter1 = new Infragistics.Win.Misc.UltraSplitter();
            this.panTab1GroupText = new Infragistics.Win.Misc.UltraPanel();
            this.panTab1Group = new Infragistics.Win.Misc.UltraPanel();
            this.panOptContextGroup = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptContextGroup = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.ultraSplitter8 = new Infragistics.Win.Misc.UltraSplitter();
            this.panTab1ContextGroup = new Infragistics.Win.Misc.UltraPanel();
            this.panOptContextGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdOptContext = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.optContextDataSource = new Infragistics.Win.UltraWinDataSource.UltraDataSource(this.components);
            this.panOptBtnRun = new Infragistics.Win.Misc.UltraPanel();
            this.btnOptRun = new Infragistics.Win.Misc.UltraButton();
            this.ultraTextEditor14 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtLots = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraSplitter3 = new Infragistics.Win.Misc.UltraSplitter();
            this.panOptContextControl = new Infragistics.Win.Misc.UltraPanel();
            this.btnQueryLotInfo = new Infragistics.Win.Misc.UltraButton();
            this.rdoChuck = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.btnOptBatchOperation = new Infragistics.Win.Misc.UltraButton();
            this.btnOptManualRun = new Infragistics.Win.Misc.UltraButton();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panCfg = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTabPageControl3 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panRpt = new Infragistics.Win.Misc.UltraPanel();
            this.panelFirst = new Infragistics.Win.Misc.UltraPanel();
            this.panTab = new Infragistics.Win.Misc.UltraPanel();
            this.tabMain = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.panTab1Group_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraStatusBar1 = new Infragistics.Win.UltraWinStatusBar.UltraStatusBar();
            this.menuMainManage = new Infragistics.Win.UltraWinToolbars.UltraToolbarsManager(this.components);
            this._frmMain_Toolbars_Dock_Area_Left = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmMain_Toolbars_Dock_Area_Right = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmMain_Toolbars_Dock_Area_Top = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmMain_Toolbars_Dock_Area_Bottom = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this.ultraDataSource1 = new Infragistics.Win.UltraWinDataSource.UltraDataSource(this.components);
            this.ultraDataSource2 = new Infragistics.Win.UltraWinDataSource.UltraDataSource(this.components);
            this.ultraTabPageControl4.SuspendLayout();
            this.panSubTab1.ClientArea.SuspendLayout();
            this.panSubTab1.SuspendLayout();
            this.panSubTab1_2.ClientArea.SuspendLayout();
            this.panSubTab1_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).BeginInit();
            this.panSubTab1_1.ClientArea.SuspendLayout();
            this.panSubTab1_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            this.ultraTabPageControl5.SuspendLayout();
            this.panSubTab2.ClientArea.SuspendLayout();
            this.panSubTab2.SuspendLayout();
            this.panSubTab2_2.ClientArea.SuspendLayout();
            this.panSubTab2_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).BeginInit();
            this.panSubTab2_1.ClientArea.SuspendLayout();
            this.panSubTab2_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor2)).BeginInit();
            this.ultraTabPageControl6.SuspendLayout();
            this.ultraPanel3.ClientArea.SuspendLayout();
            this.ultraPanel3.SuspendLayout();
            this.ultraPanel3_2.ClientArea.SuspendLayout();
            this.ultraPanel3_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).BeginInit();
            this.ultraPanel3_1.ClientArea.SuspendLayout();
            this.ultraPanel3_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor6)).BeginInit();
            this.ultraTabPageControl7.SuspendLayout();
            this.panSubTab4.ClientArea.SuspendLayout();
            this.panSubTab4.SuspendLayout();
            this.panCPE_2.ClientArea.SuspendLayout();
            this.panCPE_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCPE)).BeginInit();
            this.panCPE_1.ClientArea.SuspendLayout();
            this.panCPE_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor5)).BeginInit();
            this.ultraTabPageControl8.SuspendLayout();
            this.panSubTab5.ClientArea.SuspendLayout();
            this.panSubTab5.SuspendLayout();
            this.panSubTab5_2.ClientArea.SuspendLayout();
            this.panSubTab5_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).BeginInit();
            this.panSubTab5_1.ClientArea.SuspendLayout();
            this.panSubTab5_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor3)).BeginInit();
            this.ultraTabPageControl9.SuspendLayout();
            this.panSubTab6.ClientArea.SuspendLayout();
            this.panSubTab6.SuspendLayout();
            this.panSubTab6_2.ClientArea.SuspendLayout();
            this.panSubTab6_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).BeginInit();
            this.panSubTab6_1.ClientArea.SuspendLayout();
            this.panSubTab6_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).BeginInit();
            this.ultraTabPageControl1.SuspendLayout();
            this.panOpt.ClientArea.SuspendLayout();
            this.panOpt.SuspendLayout();
            this.panOptPicture.ClientArea.SuspendLayout();
            this.panOptPicture.SuspendLayout();
            this.panTab1Lots.ClientArea.SuspendLayout();
            this.panTab1Lots.SuspendLayout();
            this.panOptLotsGrid.ClientArea.SuspendLayout();
            this.panOptLotsGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabSub)).BeginInit();
            this.tabSub.SuspendLayout();
            this.panOptSubControl.ClientArea.SuspendLayout();
            this.panOptSubControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor19)).BeginInit();
            this.panTab1GroupText.ClientArea.SuspendLayout();
            this.panTab1GroupText.SuspendLayout();
            this.panTab1Group.ClientArea.SuspendLayout();
            this.panTab1Group.SuspendLayout();
            this.panOptContextGroup.ClientArea.SuspendLayout();
            this.panOptContextGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).BeginInit();
            this.panTab1ContextGroup.ClientArea.SuspendLayout();
            this.panTab1ContextGroup.SuspendLayout();
            this.panOptContextGrid.ClientArea.SuspendLayout();
            this.panOptContextGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.optContextDataSource)).BeginInit();
            this.panOptBtnRun.ClientArea.SuspendLayout();
            this.panOptBtnRun.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLots)).BeginInit();
            this.panOptContextControl.ClientArea.SuspendLayout();
            this.panOptContextControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoChuck)).BeginInit();
            this.ultraTabPageControl2.SuspendLayout();
            this.panCfg.SuspendLayout();
            this.ultraTabPageControl3.SuspendLayout();
            this.panRpt.SuspendLayout();
            this.panelFirst.ClientArea.SuspendLayout();
            this.panelFirst.SuspendLayout();
            this.panTab.ClientArea.SuspendLayout();
            this.panTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabMain)).BeginInit();
            this.tabMain.SuspendLayout();
            this.panTab1Group_1.ClientArea.SuspendLayout();
            this.panTab1Group_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraStatusBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuMainManage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraTabPageControl4
            // 
            this.ultraTabPageControl4.Controls.Add(this.panSubTab1);
            this.ultraTabPageControl4.Location = new System.Drawing.Point(2, 25);
            this.ultraTabPageControl4.Name = "ultraTabPageControl4";
            this.ultraTabPageControl4.Size = new System.Drawing.Size(1099, 183);
            // 
            // panSubTab1
            // 
            // 
            // panSubTab1.ClientArea
            // 
            this.panSubTab1.ClientArea.Controls.Add(this.panSubTab1_2);
            this.panSubTab1.ClientArea.Controls.Add(this.panSubTab1_1);
            this.panSubTab1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab1.Location = new System.Drawing.Point(0, 0);
            this.panSubTab1.Name = "panSubTab1";
            this.panSubTab1.Size = new System.Drawing.Size(1099, 183);
            this.panSubTab1.TabIndex = 0;
            // 
            // panSubTab1_2
            // 
            this.panSubTab1_2.AutoScroll = true;
            this.panSubTab1_2.AutoSize = true;
            // 
            // panSubTab1_2.ClientArea
            // 
            this.panSubTab1_2.ClientArea.Controls.Add(this.grdOptLinear);
            this.panSubTab1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab1_2.Location = new System.Drawing.Point(0, 32);
            this.panSubTab1_2.Name = "panSubTab1_2";
            this.panSubTab1_2.Size = new System.Drawing.Size(1099, 151);
            this.panSubTab1_2.TabIndex = 2;
            // 
            // grdOptLinear
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptLinear.DisplayLayout.Appearance = appearance1;
            this.grdOptLinear.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptLinear.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptLinear.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptLinear.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdOptLinear.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptLinear.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptLinear.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdOptLinear.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptLinear.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptLinear.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptLinear.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdOptLinear.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptLinear.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptLinear.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptLinear.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdOptLinear.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptLinear.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptLinear.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdOptLinear.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdOptLinear.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptLinear.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdOptLinear.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdOptLinear.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptLinear.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdOptLinear.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptLinear.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptLinear.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptLinear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptLinear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptLinear.Location = new System.Drawing.Point(0, 0);
            this.grdOptLinear.Name = "grdOptLinear";
            this.grdOptLinear.Size = new System.Drawing.Size(1099, 151);
            this.grdOptLinear.TabIndex = 0;
            this.grdOptLinear.Text = "List of Lots";
            // 
            // panSubTab1_1
            // 
            // 
            // panSubTab1_1.ClientArea
            // 
            this.panSubTab1_1.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panSubTab1_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panSubTab1_1.Location = new System.Drawing.Point(0, 0);
            this.panSubTab1_1.Name = "panSubTab1_1";
            this.panSubTab1_1.Size = new System.Drawing.Size(1099, 32);
            this.panSubTab1_1.TabIndex = 1;
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor1.Appearance = appearance13;
            this.ultraTextEditor1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor1.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor1.TabIndex = 8;
            this.ultraTextEditor1.Text = "Context Group:";
            // 
            // ultraTabPageControl5
            // 
            this.ultraTabPageControl5.Controls.Add(this.panSubTab2);
            this.ultraTabPageControl5.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl5.Name = "ultraTabPageControl5";
            this.ultraTabPageControl5.Size = new System.Drawing.Size(1099, 183);
            // 
            // panSubTab2
            // 
            // 
            // panSubTab2.ClientArea
            // 
            this.panSubTab2.ClientArea.Controls.Add(this.panSubTab2_2);
            this.panSubTab2.ClientArea.Controls.Add(this.panSubTab2_1);
            this.panSubTab2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab2.Location = new System.Drawing.Point(0, 0);
            this.panSubTab2.Name = "panSubTab2";
            this.panSubTab2.Size = new System.Drawing.Size(1099, 183);
            this.panSubTab2.TabIndex = 0;
            // 
            // panSubTab2_2
            // 
            // 
            // panSubTab2_2.ClientArea
            // 
            this.panSubTab2_2.ClientArea.Controls.Add(this.grdOptHOPC);
            this.panSubTab2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab2_2.Location = new System.Drawing.Point(0, 32);
            this.panSubTab2_2.Name = "panSubTab2_2";
            this.panSubTab2_2.Size = new System.Drawing.Size(1099, 151);
            this.panSubTab2_2.TabIndex = 3;
            // 
            // grdOptHOPC
            // 
            appearance14.BackColor = System.Drawing.SystemColors.Window;
            appearance14.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptHOPC.DisplayLayout.Appearance = appearance14;
            this.grdOptHOPC.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptHOPC.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance15.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance15.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptHOPC.DisplayLayout.GroupByBox.Appearance = appearance15;
            appearance16.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptHOPC.DisplayLayout.GroupByBox.BandLabelAppearance = appearance16;
            this.grdOptHOPC.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptHOPC.DisplayLayout.GroupByBox.Hidden = true;
            appearance17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance17.BackColor2 = System.Drawing.SystemColors.Control;
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance17.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptHOPC.DisplayLayout.GroupByBox.PromptAppearance = appearance17;
            this.grdOptHOPC.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptHOPC.DisplayLayout.MaxRowScrollRegions = 1;
            appearance18.BackColor = System.Drawing.SystemColors.Window;
            appearance18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptHOPC.DisplayLayout.Override.ActiveCellAppearance = appearance18;
            appearance19.BackColor = System.Drawing.SystemColors.Highlight;
            appearance19.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptHOPC.DisplayLayout.Override.ActiveRowAppearance = appearance19;
            this.grdOptHOPC.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptHOPC.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance20.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptHOPC.DisplayLayout.Override.CardAreaAppearance = appearance20;
            appearance21.BorderColor = System.Drawing.Color.Silver;
            appearance21.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptHOPC.DisplayLayout.Override.CellAppearance = appearance21;
            this.grdOptHOPC.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptHOPC.DisplayLayout.Override.CellPadding = 0;
            appearance22.BackColor = System.Drawing.SystemColors.Control;
            appearance22.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance22.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance22.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptHOPC.DisplayLayout.Override.GroupByRowAppearance = appearance22;
            appearance23.TextHAlignAsString = "Left";
            this.grdOptHOPC.DisplayLayout.Override.HeaderAppearance = appearance23;
            this.grdOptHOPC.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptHOPC.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance24.BackColor = System.Drawing.SystemColors.Window;
            appearance24.BorderColor = System.Drawing.Color.Silver;
            this.grdOptHOPC.DisplayLayout.Override.RowAppearance = appearance24;
            this.grdOptHOPC.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptHOPC.DisplayLayout.Override.TemplateAddRowAppearance = appearance25;
            this.grdOptHOPC.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptHOPC.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptHOPC.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptHOPC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptHOPC.Name = "grdOptHOPC";
            this.grdOptHOPC.Size = new System.Drawing.Size(1099, 151);
            this.grdOptHOPC.TabIndex = 1;
            this.grdOptHOPC.Text = "List of Lots";
            // 
            // panSubTab2_1
            // 
            // 
            // panSubTab2_1.ClientArea
            // 
            this.panSubTab2_1.ClientArea.Controls.Add(this.ultraTextEditor2);
            this.panSubTab2_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panSubTab2_1.Location = new System.Drawing.Point(0, 0);
            this.panSubTab2_1.Name = "panSubTab2_1";
            this.panSubTab2_1.Size = new System.Drawing.Size(1099, 32);
            this.panSubTab2_1.TabIndex = 2;
            // 
            // ultraTextEditor2
            // 
            this.ultraTextEditor2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance26.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor2.Appearance = appearance26;
            this.ultraTextEditor2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor2.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor2.Name = "ultraTextEditor2";
            this.ultraTextEditor2.ReadOnly = true;
            this.ultraTextEditor2.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor2.TabIndex = 9;
            this.ultraTextEditor2.Text = "Context Group:";
            // 
            // ultraTabPageControl6
            // 
            this.ultraTabPageControl6.Controls.Add(this.ultraPanel3);
            this.ultraTabPageControl6.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl6.Name = "ultraTabPageControl6";
            this.ultraTabPageControl6.Size = new System.Drawing.Size(1099, 183);
            // 
            // ultraPanel3
            // 
            // 
            // ultraPanel3.ClientArea
            // 
            this.ultraPanel3.ClientArea.Controls.Add(this.ultraPanel3_2);
            this.ultraPanel3.ClientArea.Controls.Add(this.ultraPanel3_1);
            this.ultraPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraPanel3.Location = new System.Drawing.Point(0, 0);
            this.ultraPanel3.Name = "ultraPanel3";
            this.ultraPanel3.Size = new System.Drawing.Size(1099, 183);
            this.ultraPanel3.TabIndex = 0;
            // 
            // ultraPanel3_2
            // 
            // 
            // ultraPanel3_2.ClientArea
            // 
            this.ultraPanel3_2.ClientArea.Controls.Add(this.grdOptIHOPC);
            this.ultraPanel3_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraPanel3_2.Location = new System.Drawing.Point(0, 32);
            this.ultraPanel3_2.Name = "ultraPanel3_2";
            this.ultraPanel3_2.Size = new System.Drawing.Size(1099, 151);
            this.ultraPanel3_2.TabIndex = 4;
            // 
            // grdOptIHOPC
            // 
            appearance27.BackColor = System.Drawing.SystemColors.Window;
            appearance27.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptIHOPC.DisplayLayout.Appearance = appearance27;
            this.grdOptIHOPC.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptIHOPC.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance28.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance28.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance28.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptIHOPC.DisplayLayout.GroupByBox.Appearance = appearance28;
            appearance29.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptIHOPC.DisplayLayout.GroupByBox.BandLabelAppearance = appearance29;
            this.grdOptIHOPC.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptIHOPC.DisplayLayout.GroupByBox.Hidden = true;
            appearance30.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance30.BackColor2 = System.Drawing.SystemColors.Control;
            appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance30.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptIHOPC.DisplayLayout.GroupByBox.PromptAppearance = appearance30;
            this.grdOptIHOPC.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptIHOPC.DisplayLayout.MaxRowScrollRegions = 1;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            appearance31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptIHOPC.DisplayLayout.Override.ActiveCellAppearance = appearance31;
            appearance32.BackColor = System.Drawing.SystemColors.Highlight;
            appearance32.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptIHOPC.DisplayLayout.Override.ActiveRowAppearance = appearance32;
            this.grdOptIHOPC.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptIHOPC.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance33.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptIHOPC.DisplayLayout.Override.CardAreaAppearance = appearance33;
            appearance34.BorderColor = System.Drawing.Color.Silver;
            appearance34.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptIHOPC.DisplayLayout.Override.CellAppearance = appearance34;
            this.grdOptIHOPC.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptIHOPC.DisplayLayout.Override.CellPadding = 0;
            appearance35.BackColor = System.Drawing.SystemColors.Control;
            appearance35.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance35.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance35.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptIHOPC.DisplayLayout.Override.GroupByRowAppearance = appearance35;
            appearance36.TextHAlignAsString = "Left";
            this.grdOptIHOPC.DisplayLayout.Override.HeaderAppearance = appearance36;
            this.grdOptIHOPC.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptIHOPC.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance37.BackColor = System.Drawing.SystemColors.Window;
            appearance37.BorderColor = System.Drawing.Color.Silver;
            this.grdOptIHOPC.DisplayLayout.Override.RowAppearance = appearance37;
            this.grdOptIHOPC.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance38.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptIHOPC.DisplayLayout.Override.TemplateAddRowAppearance = appearance38;
            this.grdOptIHOPC.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptIHOPC.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptIHOPC.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptIHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptIHOPC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptIHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptIHOPC.Name = "grdOptIHOPC";
            this.grdOptIHOPC.Size = new System.Drawing.Size(1099, 151);
            this.grdOptIHOPC.TabIndex = 2;
            this.grdOptIHOPC.Text = "List of Lots";
            // 
            // ultraPanel3_1
            // 
            // 
            // ultraPanel3_1.ClientArea
            // 
            this.ultraPanel3_1.ClientArea.Controls.Add(this.ultraTextEditor6);
            this.ultraPanel3_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraPanel3_1.Location = new System.Drawing.Point(0, 0);
            this.ultraPanel3_1.Name = "ultraPanel3_1";
            this.ultraPanel3_1.Size = new System.Drawing.Size(1099, 32);
            this.ultraPanel3_1.TabIndex = 3;
            // 
            // ultraTextEditor6
            // 
            this.ultraTextEditor6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance39.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor6.Appearance = appearance39;
            this.ultraTextEditor6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor6.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor6.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor6.Name = "ultraTextEditor6";
            this.ultraTextEditor6.ReadOnly = true;
            this.ultraTextEditor6.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor6.TabIndex = 10;
            this.ultraTextEditor6.Text = "Context Group:";
            // 
            // ultraTabPageControl7
            // 
            this.ultraTabPageControl7.Controls.Add(this.panSubTab4);
            this.ultraTabPageControl7.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl7.Name = "ultraTabPageControl7";
            this.ultraTabPageControl7.Size = new System.Drawing.Size(1099, 183);
            // 
            // panSubTab4
            // 
            // 
            // panSubTab4.ClientArea
            // 
            this.panSubTab4.ClientArea.Controls.Add(this.panCPE_2);
            this.panSubTab4.ClientArea.Controls.Add(this.panCPE_1);
            this.panSubTab4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab4.Location = new System.Drawing.Point(0, 0);
            this.panSubTab4.Name = "panSubTab4";
            this.panSubTab4.Size = new System.Drawing.Size(1099, 183);
            this.panSubTab4.TabIndex = 0;
            // 
            // panCPE_2
            // 
            // 
            // panCPE_2.ClientArea
            // 
            this.panCPE_2.ClientArea.Controls.Add(this.grdOptCPE);
            this.panCPE_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCPE_2.Location = new System.Drawing.Point(0, 32);
            this.panCPE_2.Name = "panCPE_2";
            this.panCPE_2.Size = new System.Drawing.Size(1099, 151);
            this.panCPE_2.TabIndex = 7;
            // 
            // grdOptCPE
            // 
            appearance40.BackColor = System.Drawing.SystemColors.Window;
            appearance40.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptCPE.DisplayLayout.Appearance = appearance40;
            this.grdOptCPE.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptCPE.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance41.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance41.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance41.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptCPE.DisplayLayout.GroupByBox.Appearance = appearance41;
            appearance42.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptCPE.DisplayLayout.GroupByBox.BandLabelAppearance = appearance42;
            this.grdOptCPE.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptCPE.DisplayLayout.GroupByBox.Hidden = true;
            appearance43.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance43.BackColor2 = System.Drawing.SystemColors.Control;
            appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance43.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptCPE.DisplayLayout.GroupByBox.PromptAppearance = appearance43;
            this.grdOptCPE.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptCPE.DisplayLayout.MaxRowScrollRegions = 1;
            appearance44.BackColor = System.Drawing.SystemColors.Window;
            appearance44.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptCPE.DisplayLayout.Override.ActiveCellAppearance = appearance44;
            appearance45.BackColor = System.Drawing.SystemColors.Highlight;
            appearance45.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptCPE.DisplayLayout.Override.ActiveRowAppearance = appearance45;
            this.grdOptCPE.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptCPE.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance46.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptCPE.DisplayLayout.Override.CardAreaAppearance = appearance46;
            appearance47.BorderColor = System.Drawing.Color.Silver;
            appearance47.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptCPE.DisplayLayout.Override.CellAppearance = appearance47;
            this.grdOptCPE.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptCPE.DisplayLayout.Override.CellPadding = 0;
            appearance48.BackColor = System.Drawing.SystemColors.Control;
            appearance48.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance48.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance48.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptCPE.DisplayLayout.Override.GroupByRowAppearance = appearance48;
            appearance49.TextHAlignAsString = "Left";
            this.grdOptCPE.DisplayLayout.Override.HeaderAppearance = appearance49;
            this.grdOptCPE.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptCPE.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance50.BackColor = System.Drawing.SystemColors.Window;
            appearance50.BorderColor = System.Drawing.Color.Silver;
            this.grdOptCPE.DisplayLayout.Override.RowAppearance = appearance50;
            this.grdOptCPE.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance51.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptCPE.DisplayLayout.Override.TemplateAddRowAppearance = appearance51;
            this.grdOptCPE.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptCPE.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptCPE.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptCPE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCPE.Location = new System.Drawing.Point(0, 0);
            this.grdOptCPE.Name = "grdOptCPE";
            this.grdOptCPE.Size = new System.Drawing.Size(1099, 151);
            this.grdOptCPE.TabIndex = 0;
            this.grdOptCPE.Text = "List of Lots";
            // 
            // panCPE_1
            // 
            // 
            // panCPE_1.ClientArea
            // 
            this.panCPE_1.ClientArea.Controls.Add(this.ultraTextEditor5);
            this.panCPE_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCPE_1.Location = new System.Drawing.Point(0, 0);
            this.panCPE_1.Name = "panCPE_1";
            this.panCPE_1.Size = new System.Drawing.Size(1099, 32);
            this.panCPE_1.TabIndex = 6;
            // 
            // ultraTextEditor5
            // 
            this.ultraTextEditor5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance52.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor5.Appearance = appearance52;
            this.ultraTextEditor5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor5.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor5.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor5.Name = "ultraTextEditor5";
            this.ultraTextEditor5.ReadOnly = true;
            this.ultraTextEditor5.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor5.TabIndex = 10;
            this.ultraTextEditor5.Text = "Context Group:";
            // 
            // ultraTabPageControl8
            // 
            this.ultraTabPageControl8.Controls.Add(this.panSubTab5);
            this.ultraTabPageControl8.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl8.Name = "ultraTabPageControl8";
            this.ultraTabPageControl8.Size = new System.Drawing.Size(1099, 183);
            // 
            // panSubTab5
            // 
            // 
            // panSubTab5.ClientArea
            // 
            this.panSubTab5.ClientArea.Controls.Add(this.panSubTab5_2);
            this.panSubTab5.ClientArea.Controls.Add(this.panSubTab5_1);
            this.panSubTab5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab5.Location = new System.Drawing.Point(0, 0);
            this.panSubTab5.Name = "panSubTab5";
            this.panSubTab5.Size = new System.Drawing.Size(1099, 183);
            this.panSubTab5.TabIndex = 0;
            // 
            // panSubTab5_2
            // 
            // 
            // panSubTab5_2.ClientArea
            // 
            this.panSubTab5_2.ClientArea.Controls.Add(this.grdOptCD);
            this.panSubTab5_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab5_2.Location = new System.Drawing.Point(0, 32);
            this.panSubTab5_2.Name = "panSubTab5_2";
            this.panSubTab5_2.Size = new System.Drawing.Size(1099, 151);
            this.panSubTab5_2.TabIndex = 5;
            // 
            // grdOptCD
            // 
            appearance53.BackColor = System.Drawing.SystemColors.Window;
            appearance53.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptCD.DisplayLayout.Appearance = appearance53;
            this.grdOptCD.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptCD.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance54.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance54.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance54.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptCD.DisplayLayout.GroupByBox.Appearance = appearance54;
            appearance55.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptCD.DisplayLayout.GroupByBox.BandLabelAppearance = appearance55;
            this.grdOptCD.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptCD.DisplayLayout.GroupByBox.Hidden = true;
            appearance56.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance56.BackColor2 = System.Drawing.SystemColors.Control;
            appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance56.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptCD.DisplayLayout.GroupByBox.PromptAppearance = appearance56;
            this.grdOptCD.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptCD.DisplayLayout.MaxRowScrollRegions = 1;
            appearance57.BackColor = System.Drawing.SystemColors.Window;
            appearance57.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptCD.DisplayLayout.Override.ActiveCellAppearance = appearance57;
            appearance58.BackColor = System.Drawing.SystemColors.Highlight;
            appearance58.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptCD.DisplayLayout.Override.ActiveRowAppearance = appearance58;
            this.grdOptCD.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptCD.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance59.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptCD.DisplayLayout.Override.CardAreaAppearance = appearance59;
            appearance60.BorderColor = System.Drawing.Color.Silver;
            appearance60.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptCD.DisplayLayout.Override.CellAppearance = appearance60;
            this.grdOptCD.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptCD.DisplayLayout.Override.CellPadding = 0;
            appearance61.BackColor = System.Drawing.SystemColors.Control;
            appearance61.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance61.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance61.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptCD.DisplayLayout.Override.GroupByRowAppearance = appearance61;
            appearance62.TextHAlignAsString = "Left";
            this.grdOptCD.DisplayLayout.Override.HeaderAppearance = appearance62;
            this.grdOptCD.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptCD.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance63.BackColor = System.Drawing.SystemColors.Window;
            appearance63.BorderColor = System.Drawing.Color.Silver;
            this.grdOptCD.DisplayLayout.Override.RowAppearance = appearance63;
            this.grdOptCD.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance64.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptCD.DisplayLayout.Override.TemplateAddRowAppearance = appearance64;
            this.grdOptCD.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptCD.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptCD.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptCD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCD.Location = new System.Drawing.Point(0, 0);
            this.grdOptCD.Name = "grdOptCD";
            this.grdOptCD.Size = new System.Drawing.Size(1099, 151);
            this.grdOptCD.TabIndex = 3;
            this.grdOptCD.Text = "List of Lots";
            this.grdOptCD.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdOptCD_InitializeLayout);
            this.grdOptCD.DoubleClickCell += new Infragistics.Win.UltraWinGrid.DoubleClickCellEventHandler(this.grdOptCD_DoubleClickCell);
            // 
            // panSubTab5_1
            // 
            // 
            // panSubTab5_1.ClientArea
            // 
            this.panSubTab5_1.ClientArea.Controls.Add(this.ultraTextEditor3);
            this.panSubTab5_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panSubTab5_1.Location = new System.Drawing.Point(0, 0);
            this.panSubTab5_1.Name = "panSubTab5_1";
            this.panSubTab5_1.Size = new System.Drawing.Size(1099, 32);
            this.panSubTab5_1.TabIndex = 4;
            // 
            // ultraTextEditor3
            // 
            this.ultraTextEditor3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance65.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor3.Appearance = appearance65;
            this.ultraTextEditor3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor3.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor3.Name = "ultraTextEditor3";
            this.ultraTextEditor3.ReadOnly = true;
            this.ultraTextEditor3.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor3.TabIndex = 10;
            this.ultraTextEditor3.Text = "Context Group:";
            // 
            // ultraTabPageControl9
            // 
            this.ultraTabPageControl9.Controls.Add(this.panSubTab6);
            this.ultraTabPageControl9.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl9.Name = "ultraTabPageControl9";
            this.ultraTabPageControl9.Size = new System.Drawing.Size(1099, 183);
            // 
            // panSubTab6
            // 
            // 
            // panSubTab6.ClientArea
            // 
            this.panSubTab6.ClientArea.Controls.Add(this.panSubTab6_2);
            this.panSubTab6.ClientArea.Controls.Add(this.panSubTab6_1);
            this.panSubTab6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab6.Location = new System.Drawing.Point(0, 0);
            this.panSubTab6.Name = "panSubTab6";
            this.panSubTab6.Size = new System.Drawing.Size(1099, 183);
            this.panSubTab6.TabIndex = 0;
            // 
            // panSubTab6_2
            // 
            // 
            // panSubTab6_2.ClientArea
            // 
            this.panSubTab6_2.ClientArea.Controls.Add(this.grdOptFocus);
            this.panSubTab6_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSubTab6_2.Location = new System.Drawing.Point(0, 32);
            this.panSubTab6_2.Name = "panSubTab6_2";
            this.panSubTab6_2.Size = new System.Drawing.Size(1099, 151);
            this.panSubTab6_2.TabIndex = 6;
            // 
            // grdOptFocus
            // 
            appearance66.BackColor = System.Drawing.SystemColors.Window;
            appearance66.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptFocus.DisplayLayout.Appearance = appearance66;
            this.grdOptFocus.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptFocus.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance67.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance67.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance67.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptFocus.DisplayLayout.GroupByBox.Appearance = appearance67;
            appearance68.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptFocus.DisplayLayout.GroupByBox.BandLabelAppearance = appearance68;
            this.grdOptFocus.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptFocus.DisplayLayout.GroupByBox.Hidden = true;
            appearance69.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance69.BackColor2 = System.Drawing.SystemColors.Control;
            appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance69.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptFocus.DisplayLayout.GroupByBox.PromptAppearance = appearance69;
            this.grdOptFocus.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptFocus.DisplayLayout.MaxRowScrollRegions = 1;
            appearance70.BackColor = System.Drawing.SystemColors.Window;
            appearance70.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptFocus.DisplayLayout.Override.ActiveCellAppearance = appearance70;
            appearance71.BackColor = System.Drawing.SystemColors.Highlight;
            appearance71.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptFocus.DisplayLayout.Override.ActiveRowAppearance = appearance71;
            this.grdOptFocus.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptFocus.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance72.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptFocus.DisplayLayout.Override.CardAreaAppearance = appearance72;
            appearance73.BorderColor = System.Drawing.Color.Silver;
            appearance73.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptFocus.DisplayLayout.Override.CellAppearance = appearance73;
            this.grdOptFocus.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptFocus.DisplayLayout.Override.CellPadding = 0;
            appearance74.BackColor = System.Drawing.SystemColors.Control;
            appearance74.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance74.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance74.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptFocus.DisplayLayout.Override.GroupByRowAppearance = appearance74;
            appearance75.TextHAlignAsString = "Left";
            this.grdOptFocus.DisplayLayout.Override.HeaderAppearance = appearance75;
            this.grdOptFocus.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdOptFocus.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance76.BackColor = System.Drawing.SystemColors.Window;
            appearance76.BorderColor = System.Drawing.Color.Silver;
            this.grdOptFocus.DisplayLayout.Override.RowAppearance = appearance76;
            this.grdOptFocus.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance77.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptFocus.DisplayLayout.Override.TemplateAddRowAppearance = appearance77;
            this.grdOptFocus.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptFocus.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptFocus.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptFocus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptFocus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptFocus.Location = new System.Drawing.Point(0, 0);
            this.grdOptFocus.Name = "grdOptFocus";
            this.grdOptFocus.Size = new System.Drawing.Size(1099, 151);
            this.grdOptFocus.TabIndex = 3;
            this.grdOptFocus.Text = "List of Lots";
            this.grdOptFocus.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdOptFocus_InitializeLayout);
            this.grdOptFocus.DoubleClickCell += new Infragistics.Win.UltraWinGrid.DoubleClickCellEventHandler(this.grdOptFocus_DoubleClickCell);
            // 
            // panSubTab6_1
            // 
            // 
            // panSubTab6_1.ClientArea
            // 
            this.panSubTab6_1.ClientArea.Controls.Add(this.ultraTextEditor4);
            this.panSubTab6_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panSubTab6_1.Location = new System.Drawing.Point(0, 0);
            this.panSubTab6_1.Name = "panSubTab6_1";
            this.panSubTab6_1.Size = new System.Drawing.Size(1099, 32);
            this.panSubTab6_1.TabIndex = 5;
            // 
            // ultraTextEditor4
            // 
            this.ultraTextEditor4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance78.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor4.Appearance = appearance78;
            this.ultraTextEditor4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor4.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor4.Location = new System.Drawing.Point(432, 7);
            this.ultraTextEditor4.Name = "ultraTextEditor4";
            this.ultraTextEditor4.ReadOnly = true;
            this.ultraTextEditor4.Size = new System.Drawing.Size(250, 22);
            this.ultraTextEditor4.TabIndex = 10;
            this.ultraTextEditor4.Text = "Context Group:";
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.panOpt);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(2, 29);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(1439, 747);
            // 
            // panOpt
            // 
            // 
            // panOpt.ClientArea
            // 
            this.panOpt.ClientArea.Controls.Add(this.panOptPicture);
            this.panOpt.ClientArea.Controls.Add(this.ultraSplitter2);
            this.panOpt.ClientArea.Controls.Add(this.panTab1Lots);
            this.panOpt.ClientArea.Controls.Add(this.ultraSplitter1);
            this.panOpt.ClientArea.Controls.Add(this.panTab1GroupText);
            this.panOpt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOpt.Location = new System.Drawing.Point(0, 0);
            this.panOpt.Name = "panOpt";
            this.panOpt.Size = new System.Drawing.Size(1439, 747);
            this.panOpt.TabIndex = 0;
            // 
            // panOptPicture
            // 
            this.panOptPicture.AutoScroll = true;
            // 
            // panOptPicture.ClientArea
            // 
            this.panOptPicture.ClientArea.Controls.Add(this.ultraSplitter5);
            this.panOptPicture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptPicture.Location = new System.Drawing.Point(0, 484);
            this.panOptPicture.Name = "panOptPicture";
            this.panOptPicture.Size = new System.Drawing.Size(1439, 263);
            this.panOptPicture.TabIndex = 4;
            // 
            // ultraSplitter5
            // 
            this.ultraSplitter5.Location = new System.Drawing.Point(0, 0);
            this.ultraSplitter5.Name = "ultraSplitter5";
            this.ultraSplitter5.RestoreExtent = 0;
            this.ultraSplitter5.Size = new System.Drawing.Size(0, 263);
            this.ultraSplitter5.TabIndex = 1;
            // 
            // ultraSplitter2
            // 
            this.ultraSplitter2.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter2.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraSplitter2.Location = new System.Drawing.Point(0, 478);
            this.ultraSplitter2.Name = "ultraSplitter2";
            this.ultraSplitter2.RestoreExtent = 210;
            this.ultraSplitter2.Size = new System.Drawing.Size(1439, 6);
            this.ultraSplitter2.TabIndex = 3;
            // 
            // panTab1Lots
            // 
            // 
            // panTab1Lots.ClientArea
            // 
            this.panTab1Lots.ClientArea.Controls.Add(this.panOptLotsGrid);
            this.panTab1Lots.ClientArea.Controls.Add(this.ultraSplitter4);
            this.panTab1Lots.ClientArea.Controls.Add(this.panOptSubControl);
            this.panTab1Lots.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTab1Lots.Location = new System.Drawing.Point(0, 268);
            this.panTab1Lots.Name = "panTab1Lots";
            this.panTab1Lots.Size = new System.Drawing.Size(1439, 210);
            this.panTab1Lots.TabIndex = 2;
            // 
            // panOptLotsGrid
            // 
            // 
            // panOptLotsGrid.ClientArea
            // 
            this.panOptLotsGrid.ClientArea.Controls.Add(this.tabSub);
            this.panOptLotsGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptLotsGrid.Location = new System.Drawing.Point(0, 0);
            this.panOptLotsGrid.Name = "panOptLotsGrid";
            this.panOptLotsGrid.Size = new System.Drawing.Size(1103, 210);
            this.panOptLotsGrid.TabIndex = 2;
            // 
            // tabSub
            // 
            this.tabSub.Controls.Add(this.ultraTabSharedControlsPage2);
            this.tabSub.Controls.Add(this.ultraTabPageControl4);
            this.tabSub.Controls.Add(this.ultraTabPageControl6);
            this.tabSub.Controls.Add(this.ultraTabPageControl7);
            this.tabSub.Controls.Add(this.ultraTabPageControl8);
            this.tabSub.Controls.Add(this.ultraTabPageControl9);
            this.tabSub.Controls.Add(this.ultraTabPageControl5);
            this.tabSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSub.Location = new System.Drawing.Point(0, 0);
            this.tabSub.Name = "tabSub";
            this.tabSub.SharedControlsPage = this.ultraTabSharedControlsPage2;
            this.tabSub.Size = new System.Drawing.Size(1103, 210);
            this.tabSub.TabIndex = 0;
            ultraTab12.TabPage = this.ultraTabPageControl4;
            ultraTab12.Text = "Linear";
            ultraTab13.TabPage = this.ultraTabPageControl5;
            ultraTab13.Text = "HOPC";
            ultraTab14.TabPage = this.ultraTabPageControl6;
            ultraTab14.Text = "IHOPC";
            ultraTab15.TabPage = this.ultraTabPageControl7;
            ultraTab15.Text = "CPE";
            ultraTab16.TabPage = this.ultraTabPageControl8;
            ultraTab16.Text = "CD";
            ultraTab17.TabPage = this.ultraTabPageControl9;
            ultraTab17.Text = "Focus";
            this.tabSub.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab12,
            ultraTab13,
            ultraTab14,
            ultraTab15,
            ultraTab16,
            ultraTab17});
            this.tabSub.SelectedTabChanged += new Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventHandler(this.tabSub_SelectedTabChanged);
            // 
            // ultraTabSharedControlsPage2
            // 
            this.ultraTabSharedControlsPage2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage2.Name = "ultraTabSharedControlsPage2";
            this.ultraTabSharedControlsPage2.Size = new System.Drawing.Size(1099, 183);
            // 
            // ultraSplitter4
            // 
            this.ultraSplitter4.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter4.Dock = System.Windows.Forms.DockStyle.Right;
            this.ultraSplitter4.Location = new System.Drawing.Point(1103, 0);
            this.ultraSplitter4.Name = "ultraSplitter4";
            this.ultraSplitter4.RestoreExtent = 398;
            this.ultraSplitter4.Size = new System.Drawing.Size(6, 210);
            this.ultraSplitter4.TabIndex = 1;
            // 
            // panOptSubControl
            // 
            // 
            // panOptSubControl.ClientArea
            // 
            this.panOptSubControl.ClientArea.Controls.Add(this.rdoList);
            this.panOptSubControl.ClientArea.Controls.Add(this.btnOptUpdate);
            this.panOptSubControl.ClientArea.Controls.Add(this.btnOptMode);
            this.panOptSubControl.ClientArea.Controls.Add(this.btnOptReset);
            this.panOptSubControl.ClientArea.Controls.Add(this.ultraTextEditor17);
            this.panOptSubControl.ClientArea.Controls.Add(this.ultraTextEditor18);
            this.panOptSubControl.ClientArea.Controls.Add(this.ultraTextEditor19);
            this.panOptSubControl.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptSubControl.Location = new System.Drawing.Point(1109, 0);
            this.panOptSubControl.Name = "panOptSubControl";
            this.panOptSubControl.Size = new System.Drawing.Size(330, 210);
            this.panOptSubControl.TabIndex = 0;
            // 
            // rdoList
            // 
            appearance79.BackColor = System.Drawing.SystemColors.Control;
            appearance79.FontData.BoldAsString = "False";
            appearance79.FontData.ItalicAsString = "False";
            appearance79.FontData.SizeInPoints = 10F;
            this.rdoList.Appearance = appearance79;
            this.rdoList.BackColor = System.Drawing.SystemColors.Control;
            this.rdoList.BackColorInternal = System.Drawing.Color.NavajoWhite;
            this.rdoList.CheckedIndex = 0;
            this.rdoList.ItemOrigin = new System.Drawing.Point(10, 10);
            valueListItem5.CheckState = System.Windows.Forms.CheckState.Checked;
            valueListItem5.DataValue = "Default Item";
            valueListItem5.DisplayText = "List Lots With Metrology";
            valueListItem6.DataValue = "ValueListItem1";
            valueListItem6.DisplayText = "List All Lots";
            this.rdoList.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem5,
            valueListItem6});
            this.rdoList.Location = new System.Drawing.Point(21, 6);
            this.rdoList.Name = "rdoList";
            this.rdoList.Size = new System.Drawing.Size(288, 38);
            this.rdoList.TabIndex = 16;
            this.rdoList.Text = "List Lots With Metrology";
            // 
            // btnOptUpdate
            // 
            appearance80.BackColor = System.Drawing.SystemColors.Control;
            appearance80.BackColor2 = System.Drawing.Color.White;
            this.btnOptUpdate.Appearance = appearance80;
            this.btnOptUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            appearance81.ForeColor = System.Drawing.Color.Red;
            appearance81.ForeColorDisabled = System.Drawing.Color.Red;
            this.btnOptUpdate.HotTrackAppearance = appearance81;
            this.btnOptUpdate.Location = new System.Drawing.Point(227, 182);
            this.btnOptUpdate.Name = "btnOptUpdate";
            this.btnOptUpdate.Size = new System.Drawing.Size(81, 29);
            this.btnOptUpdate.TabIndex = 12;
            this.btnOptUpdate.Text = "Update";
            this.btnOptUpdate.Click += new System.EventHandler(this.btnOptUpdate_Click);
            // 
            // btnOptMode
            // 
            appearance82.BackColor = System.Drawing.SystemColors.Control;
            appearance82.BackColor2 = System.Drawing.Color.White;
            this.btnOptMode.Appearance = appearance82;
            this.btnOptMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            appearance83.ForeColor = System.Drawing.Color.Red;
            appearance83.ForeColorDisabled = System.Drawing.Color.Red;
            this.btnOptMode.HotTrackAppearance = appearance83;
            this.btnOptMode.Location = new System.Drawing.Point(21, 182);
            this.btnOptMode.Name = "btnOptMode";
            this.btnOptMode.Size = new System.Drawing.Size(81, 29);
            this.btnOptMode.TabIndex = 11;
            this.btnOptMode.Text = "Mode";
            this.btnOptMode.Click += new System.EventHandler(this.btnOptMode_Click);
            // 
            // btnOptReset
            // 
            appearance84.BackColor = System.Drawing.SystemColors.Control;
            appearance84.BackColor2 = System.Drawing.Color.White;
            this.btnOptReset.Appearance = appearance84;
            this.btnOptReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            appearance85.ForeColor = System.Drawing.Color.Red;
            appearance85.ForeColorDisabled = System.Drawing.Color.Red;
            this.btnOptReset.HotTrackAppearance = appearance85;
            this.btnOptReset.Location = new System.Drawing.Point(124, 182);
            this.btnOptReset.Name = "btnOptReset";
            this.btnOptReset.Size = new System.Drawing.Size(81, 29);
            this.btnOptReset.TabIndex = 10;
            this.btnOptReset.Text = "Reset";
            this.btnOptReset.Click += new System.EventHandler(this.btnOptReset_Click);
            // 
            // ultraTextEditor17
            // 
            appearance86.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor17.Appearance = appearance86;
            this.ultraTextEditor17.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor17.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor17.Location = new System.Drawing.Point(21, 142);
            this.ultraTextEditor17.Name = "ultraTextEditor17";
            this.ultraTextEditor17.ReadOnly = true;
            this.ultraTextEditor17.Size = new System.Drawing.Size(288, 26);
            this.ultraTextEditor17.TabIndex = 9;
            this.ultraTextEditor17.Text = "Current Reset:OFF";
            // 
            // ultraTextEditor18
            // 
            appearance87.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor18.Appearance = appearance87;
            this.ultraTextEditor18.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor18.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor18.Location = new System.Drawing.Point(21, 100);
            this.ultraTextEditor18.Name = "ultraTextEditor18";
            this.ultraTextEditor18.ReadOnly = true;
            this.ultraTextEditor18.Size = new System.Drawing.Size(288, 26);
            this.ultraTextEditor18.TabIndex = 8;
            this.ultraTextEditor18.Text = "Current Run Mode:Active";
            // 
            // ultraTextEditor19
            // 
            appearance88.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor19.Appearance = appearance88;
            this.ultraTextEditor19.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor19.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor19.Location = new System.Drawing.Point(21, 56);
            this.ultraTextEditor19.Name = "ultraTextEditor19";
            this.ultraTextEditor19.ReadOnly = true;
            this.ultraTextEditor19.Size = new System.Drawing.Size(288, 26);
            this.ultraTextEditor19.TabIndex = 7;
            this.ultraTextEditor19.Text = "Current OVL Mode:Linear+CPE";
            // 
            // ultraSplitter1
            // 
            this.ultraSplitter1.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraSplitter1.Location = new System.Drawing.Point(0, 262);
            this.ultraSplitter1.Name = "ultraSplitter1";
            this.ultraSplitter1.RestoreExtent = 262;
            this.ultraSplitter1.Size = new System.Drawing.Size(1439, 6);
            this.ultraSplitter1.TabIndex = 1;
            // 
            // panTab1GroupText
            // 
            // 
            // panTab1GroupText.ClientArea
            // 
            this.panTab1GroupText.ClientArea.Controls.Add(this.panTab1Group);
            this.panTab1GroupText.ClientArea.Controls.Add(this.ultraSplitter8);
            this.panTab1GroupText.ClientArea.Controls.Add(this.panTab1ContextGroup);
            this.panTab1GroupText.ClientArea.Controls.Add(this.ultraSplitter3);
            this.panTab1GroupText.ClientArea.Controls.Add(this.panOptContextControl);
            this.panTab1GroupText.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTab1GroupText.Location = new System.Drawing.Point(0, 0);
            this.panTab1GroupText.Name = "panTab1GroupText";
            this.panTab1GroupText.Size = new System.Drawing.Size(1439, 262);
            this.panTab1GroupText.TabIndex = 0;
            // 
            // panTab1Group
            // 
            // 
            // panTab1Group.ClientArea
            // 
            this.panTab1Group.ClientArea.Controls.Add(this.panOptContextGroup);
            this.panTab1Group.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panTab1Group.Location = new System.Drawing.Point(311, 0);
            this.panTab1Group.Name = "panTab1Group";
            this.panTab1Group.Size = new System.Drawing.Size(792, 262);
            this.panTab1Group.TabIndex = 4;
            // 
            // panOptContextGroup
            // 
            this.panOptContextGroup.AutoScroll = true;
            this.panOptContextGroup.AutoSize = true;
            // 
            // panOptContextGroup.ClientArea
            // 
            this.panOptContextGroup.ClientArea.Controls.Add(this.grdOptContextGroup);
            this.panOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptContextGroup.Location = new System.Drawing.Point(0, 0);
            this.panOptContextGroup.Name = "panOptContextGroup";
            this.panOptContextGroup.Size = new System.Drawing.Size(792, 262);
            this.panOptContextGroup.TabIndex = 2;
            // 
            // grdOptContextGroup
            // 
            this.menuMainManage.SetContextMenuUltra(this.grdOptContextGroup, "GridRightClick");
            appearance92.BackColor = System.Drawing.SystemColors.Window;
            appearance92.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptContextGroup.DisplayLayout.Appearance = appearance92;
            this.grdOptContextGroup.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptContextGroup.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance93.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance93.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance93.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptContextGroup.DisplayLayout.GroupByBox.Appearance = appearance93;
            appearance94.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptContextGroup.DisplayLayout.GroupByBox.BandLabelAppearance = appearance94;
            this.grdOptContextGroup.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptContextGroup.DisplayLayout.GroupByBox.Hidden = true;
            appearance95.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance95.BackColor2 = System.Drawing.SystemColors.Control;
            appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance95.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptContextGroup.DisplayLayout.GroupByBox.PromptAppearance = appearance95;
            this.grdOptContextGroup.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptContextGroup.DisplayLayout.MaxRowScrollRegions = 1;
            appearance96.BackColor = System.Drawing.SystemColors.Window;
            appearance96.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptContextGroup.DisplayLayout.Override.ActiveCellAppearance = appearance96;
            appearance97.BackColor = System.Drawing.SystemColors.Highlight;
            appearance97.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptContextGroup.DisplayLayout.Override.ActiveRowAppearance = appearance97;
            this.grdOptContextGroup.DisplayLayout.Override.AllowRowFiltering = Infragistics.Win.DefaultableBoolean.False;
            this.grdOptContextGroup.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptContextGroup.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance98.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptContextGroup.DisplayLayout.Override.CardAreaAppearance = appearance98;
            appearance99.BorderColor = System.Drawing.Color.Silver;
            appearance99.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptContextGroup.DisplayLayout.Override.CellAppearance = appearance99;
            this.grdOptContextGroup.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptContextGroup.DisplayLayout.Override.CellPadding = 0;
            appearance100.BackColor = System.Drawing.SystemColors.Control;
            appearance100.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance100.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance100.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptContextGroup.DisplayLayout.Override.GroupByRowAppearance = appearance100;
            appearance101.TextHAlignAsString = "Left";
            this.grdOptContextGroup.DisplayLayout.Override.HeaderAppearance = appearance101;
            this.grdOptContextGroup.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortSingle;
            this.grdOptContextGroup.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance102.BackColor = System.Drawing.SystemColors.Window;
            appearance102.BorderColor = System.Drawing.Color.Silver;
            this.grdOptContextGroup.DisplayLayout.Override.RowAppearance = appearance102;
            this.grdOptContextGroup.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance103.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptContextGroup.DisplayLayout.Override.TemplateAddRowAppearance = appearance103;
            this.grdOptContextGroup.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptContextGroup.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptContextGroup.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptContextGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptContextGroup.Location = new System.Drawing.Point(0, 0);
            this.grdOptContextGroup.Name = "grdOptContextGroup";
            this.grdOptContextGroup.Size = new System.Drawing.Size(792, 262);
            this.grdOptContextGroup.TabIndex = 0;
            this.grdOptContextGroup.Text = "List of Context Group";
            this.grdOptContextGroup.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdOptContextGroup_InitializeLayout);
            this.grdOptContextGroup.ClickCell += new Infragistics.Win.UltraWinGrid.ClickCellEventHandler(this.grdOptContextGroup_ClickCell);
            this.grdOptContextGroup.DoubleClickCell += new Infragistics.Win.UltraWinGrid.DoubleClickCellEventHandler(this.grdOptContextGroup_DoubleClickCell);
            this.grdOptContextGroup.DoubleClickRow += new Infragistics.Win.UltraWinGrid.DoubleClickRowEventHandler(this.grdOptContextGroup_DoubleClickRow);
            // 
            // ultraSplitter8
            // 
            this.ultraSplitter8.Location = new System.Drawing.Point(305, 0);
            this.ultraSplitter8.Name = "ultraSplitter8";
            this.ultraSplitter8.RestoreExtent = 0;
            this.ultraSplitter8.Size = new System.Drawing.Size(6, 262);
            this.ultraSplitter8.TabIndex = 3;
            // 
            // panTab1ContextGroup
            // 
            // 
            // panTab1ContextGroup.ClientArea
            // 
            this.panTab1ContextGroup.ClientArea.Controls.Add(this.panOptContextGrid);
            this.panTab1ContextGroup.ClientArea.Controls.Add(this.panOptBtnRun);
            this.panTab1ContextGroup.Dock = System.Windows.Forms.DockStyle.Left;
            this.panTab1ContextGroup.Location = new System.Drawing.Point(0, 0);
            this.panTab1ContextGroup.Name = "panTab1ContextGroup";
            this.panTab1ContextGroup.Size = new System.Drawing.Size(305, 262);
            this.panTab1ContextGroup.TabIndex = 2;
            // 
            // panOptContextGrid
            // 
            // 
            // panOptContextGrid.ClientArea
            // 
            this.panOptContextGrid.ClientArea.Controls.Add(this.grdOptContext);
            this.panOptContextGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptContextGrid.Location = new System.Drawing.Point(0, 0);
            this.panOptContextGrid.Name = "panOptContextGrid";
            this.panOptContextGrid.Size = new System.Drawing.Size(305, 217);
            this.panOptContextGrid.TabIndex = 2;
            // 
            // grdOptContext
            // 
            this.grdOptContext.DataSource = this.optContextDataSource;
            appearance104.BackColor = System.Drawing.SystemColors.Window;
            appearance104.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdOptContext.DisplayLayout.Appearance = appearance104;
            this.grdOptContext.DisplayLayout.AutoFitStyle = Infragistics.Win.UltraWinGrid.AutoFitStyle.ExtendLastColumn;
            ultraGridColumn1.Header.VisiblePosition = 0;
            ultraGridColumn1.Width = 109;
            ultraGridColumn2.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            ultraGridColumn2.Header.Fixed = true;
            ultraGridColumn2.Header.FixedHeaderIndicator = Infragistics.Win.UltraWinGrid.FixedHeaderIndicator.None;
            ultraGridColumn2.Header.VisiblePosition = 1;
            ultraGridColumn2.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            ultraGridColumn2.Width = 194;
            ultraGridBand1.Columns.AddRange(new object[] {
            ultraGridColumn1,
            ultraGridColumn2});
            this.grdOptContext.DisplayLayout.BandsSerializer.Add(ultraGridBand1);
            this.grdOptContext.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptContext.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance105.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance105.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance105.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptContext.DisplayLayout.GroupByBox.Appearance = appearance105;
            appearance106.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptContext.DisplayLayout.GroupByBox.BandLabelAppearance = appearance106;
            this.grdOptContext.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdOptContext.DisplayLayout.GroupByBox.Hidden = true;
            appearance107.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance107.BackColor2 = System.Drawing.SystemColors.Control;
            appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance107.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdOptContext.DisplayLayout.GroupByBox.PromptAppearance = appearance107;
            this.grdOptContext.DisplayLayout.MaxColScrollRegions = 1;
            this.grdOptContext.DisplayLayout.MaxRowScrollRegions = 1;
            appearance108.BackColor = System.Drawing.SystemColors.Window;
            appearance108.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdOptContext.DisplayLayout.Override.ActiveCellAppearance = appearance108;
            appearance109.BackColor = System.Drawing.SystemColors.Highlight;
            appearance109.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdOptContext.DisplayLayout.Override.ActiveRowAppearance = appearance109;
            this.grdOptContext.DisplayLayout.Override.AllowColSwapping = Infragistics.Win.UltraWinGrid.AllowColSwapping.NotAllowed;
            this.grdOptContext.DisplayLayout.Override.AllowRowFiltering = Infragistics.Win.DefaultableBoolean.False;
            this.grdOptContext.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdOptContext.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance110.BackColor = System.Drawing.SystemColors.Window;
            this.grdOptContext.DisplayLayout.Override.CardAreaAppearance = appearance110;
            appearance111.BorderColor = System.Drawing.Color.Silver;
            appearance111.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdOptContext.DisplayLayout.Override.CellAppearance = appearance111;
            this.grdOptContext.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdOptContext.DisplayLayout.Override.CellPadding = 0;
            this.grdOptContext.DisplayLayout.Override.FilterUIType = Infragistics.Win.UltraWinGrid.FilterUIType.HeaderIcons;
            this.grdOptContext.DisplayLayout.Override.FixedRowIndicator = Infragistics.Win.UltraWinGrid.FixedRowIndicator.None;
            this.grdOptContext.DisplayLayout.Override.FixedRowSortOrder = Infragistics.Win.UltraWinGrid.FixedRowSortOrder.FixOrder;
            appearance112.BackColor = System.Drawing.SystemColors.Control;
            appearance112.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance112.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance112.BorderColor = System.Drawing.SystemColors.Window;
            this.grdOptContext.DisplayLayout.Override.GroupByRowAppearance = appearance112;
            appearance113.TextHAlignAsString = "Left";
            this.grdOptContext.DisplayLayout.Override.HeaderAppearance = appearance113;
            this.grdOptContext.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortSingle;
            this.grdOptContext.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance114.BackColor = System.Drawing.SystemColors.Window;
            appearance114.BorderColor = System.Drawing.Color.Silver;
            this.grdOptContext.DisplayLayout.Override.RowAppearance = appearance114;
            this.grdOptContext.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            this.grdOptContext.DisplayLayout.Override.RowSizing = Infragistics.Win.UltraWinGrid.RowSizing.AutoFixed;
            appearance115.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdOptContext.DisplayLayout.Override.TemplateAddRowAppearance = appearance115;
            this.grdOptContext.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdOptContext.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdOptContext.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdOptContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptContext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grdOptContext.Location = new System.Drawing.Point(0, 0);
            this.grdOptContext.Name = "grdOptContext";
            this.grdOptContext.Size = new System.Drawing.Size(305, 217);
            this.grdOptContext.TabIndex = 1;
            this.grdOptContext.Text = "Context Group";
            this.grdOptContext.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdOptContext_InitializeLayout);
            this.grdOptContext.CellChange += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.grdOptContext_CellChange);
            this.grdOptContext.CellListSelect += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.grdOptContext_CellListSelect);
            this.grdOptContext.ClickCell += new Infragistics.Win.UltraWinGrid.ClickCellEventHandler(this.grdOptContext_ClickCell);
            // 
            // optContextDataSource
            // 
            this.optContextDataSource.Band.Columns.AddRange(new object[] {
            ultraDataColumn1,
            ultraDataColumn2});
            this.optContextDataSource.Band.Key = "Context";
            // 
            // panOptBtnRun
            // 
            // 
            // panOptBtnRun.ClientArea
            // 
            this.panOptBtnRun.ClientArea.Controls.Add(this.btnOptRun);
            this.panOptBtnRun.ClientArea.Controls.Add(this.ultraTextEditor14);
            this.panOptBtnRun.ClientArea.Controls.Add(this.txtLots);
            this.panOptBtnRun.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panOptBtnRun.Location = new System.Drawing.Point(0, 217);
            this.panOptBtnRun.Name = "panOptBtnRun";
            this.panOptBtnRun.Size = new System.Drawing.Size(305, 45);
            this.panOptBtnRun.TabIndex = 2;
            // 
            // btnOptRun
            // 
            appearance116.BackColor = System.Drawing.SystemColors.Control;
            this.btnOptRun.Appearance = appearance116;
            this.btnOptRun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOptRun.Location = new System.Drawing.Point(211, 6);
            this.btnOptRun.Name = "btnOptRun";
            this.btnOptRun.Size = new System.Drawing.Size(76, 32);
            this.btnOptRun.TabIndex = 0;
            this.btnOptRun.Text = "Run";
            this.btnOptRun.Click += new System.EventHandler(this.btnOptRun_Click);
            // 
            // ultraTextEditor14
            // 
            appearance117.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor14.Appearance = appearance117;
            this.ultraTextEditor14.BackColor = System.Drawing.SystemColors.Control;
            this.ultraTextEditor14.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraTextEditor14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor14.Location = new System.Drawing.Point(10, 9);
            this.ultraTextEditor14.Name = "ultraTextEditor14";
            this.ultraTextEditor14.ReadOnly = true;
            this.ultraTextEditor14.Size = new System.Drawing.Size(100, 26);
            this.ultraTextEditor14.TabIndex = 11;
            this.ultraTextEditor14.Text = "List of Runs";
            // 
            // txtLots
            // 
            this.txtLots.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLots.Location = new System.Drawing.Point(126, 8);
            this.txtLots.Name = "txtLots";
            this.txtLots.Size = new System.Drawing.Size(69, 28);
            this.txtLots.TabIndex = 12;
            this.txtLots.Text = "20";
            this.txtLots.ValueChanged += new System.EventHandler(this.txtLots_ValueChanged);
            this.txtLots.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLots_KeyDown);
            // 
            // ultraSplitter3
            // 
            this.ultraSplitter3.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter3.Dock = System.Windows.Forms.DockStyle.Right;
            this.ultraSplitter3.Location = new System.Drawing.Point(1103, 0);
            this.ultraSplitter3.Name = "ultraSplitter3";
            this.ultraSplitter3.RestoreExtent = 398;
            this.ultraSplitter3.Size = new System.Drawing.Size(6, 262);
            this.ultraSplitter3.TabIndex = 1;
            // 
            // panOptContextControl
            // 
            // 
            // panOptContextControl.ClientArea
            // 
            this.panOptContextControl.ClientArea.Controls.Add(this.btnQueryLotInfo);
            this.panOptContextControl.ClientArea.Controls.Add(this.rdoChuck);
            this.panOptContextControl.ClientArea.Controls.Add(this.btnOptBatchOperation);
            this.panOptContextControl.ClientArea.Controls.Add(this.btnOptManualRun);
            this.panOptContextControl.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptContextControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panOptContextControl.Location = new System.Drawing.Point(1109, 0);
            this.panOptContextControl.Name = "panOptContextControl";
            this.panOptContextControl.Size = new System.Drawing.Size(330, 262);
            this.panOptContextControl.TabIndex = 0;
            // 
            // btnQueryLotInfo
            // 
            appearance118.BackColor = System.Drawing.SystemColors.Control;
            this.btnQueryLotInfo.Appearance = appearance118;
            this.btnQueryLotInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQueryLotInfo.Location = new System.Drawing.Point(75, 16);
            this.btnQueryLotInfo.Name = "btnQueryLotInfo";
            this.btnQueryLotInfo.Size = new System.Drawing.Size(175, 37);
            this.btnQueryLotInfo.TabIndex = 16;
            this.btnQueryLotInfo.Text = "Query Lot Info";
            this.btnQueryLotInfo.Click += new System.EventHandler(this.btnQueryLotInfo_Click);
            // 
            // rdoChuck
            // 
            appearance119.BackColor = System.Drawing.SystemColors.Control;
            appearance119.FontData.SizeInPoints = 10F;
            this.rdoChuck.Appearance = appearance119;
            this.rdoChuck.BackColor = System.Drawing.SystemColors.Control;
            this.rdoChuck.BackColorInternal = System.Drawing.Color.NavajoWhite;
            this.rdoChuck.CheckedIndex = 0;
            this.rdoChuck.Enabled = false;
            this.rdoChuck.ItemOrigin = new System.Drawing.Point(10, 10);
            valueListItem4.CheckState = System.Windows.Forms.CheckState.Checked;
            valueListItem4.DataValue = "Default Item";
            valueListItem4.DisplayText = "Chuck1";
            valueListItem7.DataValue = "ValueListItem1";
            valueListItem7.DisplayText = "Chuck2";
            this.rdoChuck.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem4,
            valueListItem7});
            this.rdoChuck.Location = new System.Drawing.Point(75, 163);
            this.rdoChuck.Name = "rdoChuck";
            this.rdoChuck.Size = new System.Drawing.Size(175, 44);
            this.rdoChuck.TabIndex = 15;
            this.rdoChuck.Text = "Chuck1";
            this.rdoChuck.ValueChanged += new System.EventHandler(this.rdoChuck_ValueChanged);
            // 
            // btnOptBatchOperation
            // 
            appearance120.BackColor = System.Drawing.SystemColors.Control;
            this.btnOptBatchOperation.Appearance = appearance120;
            this.btnOptBatchOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOptBatchOperation.Location = new System.Drawing.Point(75, 114);
            this.btnOptBatchOperation.Name = "btnOptBatchOperation";
            this.btnOptBatchOperation.Size = new System.Drawing.Size(175, 37);
            this.btnOptBatchOperation.TabIndex = 14;
            this.btnOptBatchOperation.Text = "Batch Operation";
            this.btnOptBatchOperation.Click += new System.EventHandler(this.btnOptBatchOperation_Click);
            // 
            // btnOptManualRun
            // 
            appearance121.BackColor = System.Drawing.SystemColors.Control;
            this.btnOptManualRun.Appearance = appearance121;
            this.btnOptManualRun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOptManualRun.Location = new System.Drawing.Point(75, 65);
            this.btnOptManualRun.Name = "btnOptManualRun";
            this.btnOptManualRun.Size = new System.Drawing.Size(175, 37);
            this.btnOptManualRun.TabIndex = 13;
            this.btnOptManualRun.Text = "Manual Run";
            this.btnOptManualRun.Click += new System.EventHandler(this.btnOptManualRun_Click);
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.panCfg);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(1439, 747);
            // 
            // panCfg
            // 
            this.panCfg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCfg.Location = new System.Drawing.Point(0, 0);
            this.panCfg.Name = "panCfg";
            this.panCfg.Size = new System.Drawing.Size(1439, 747);
            this.panCfg.TabIndex = 0;
            // 
            // ultraTabPageControl3
            // 
            this.ultraTabPageControl3.Controls.Add(this.panRpt);
            this.ultraTabPageControl3.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl3.Name = "ultraTabPageControl3";
            this.ultraTabPageControl3.Size = new System.Drawing.Size(1439, 747);
            // 
            // panRpt
            // 
            this.panRpt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panRpt.Location = new System.Drawing.Point(0, 0);
            this.panRpt.Name = "panRpt";
            this.panRpt.Size = new System.Drawing.Size(1439, 747);
            this.panRpt.TabIndex = 0;
            // 
            // panelFirst
            // 
            // 
            // panelFirst.ClientArea
            // 
            this.panelFirst.ClientArea.Controls.Add(this.panTab);
            this.panelFirst.ClientArea.Controls.Add(this.panTab1Group_1);
            this.panelFirst.ClientArea.Controls.Add(this.ultraStatusBar1);
            this.panelFirst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFirst.Location = new System.Drawing.Point(0, 23);
            this.panelFirst.Name = "panelFirst";
            this.panelFirst.Size = new System.Drawing.Size(1443, 838);
            this.panelFirst.TabIndex = 0;
            // 
            // panTab
            // 
            // 
            // panTab.ClientArea
            // 
            this.panTab.ClientArea.Controls.Add(this.tabMain);
            this.panTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panTab.Location = new System.Drawing.Point(0, 37);
            this.panTab.Name = "panTab";
            this.panTab.Size = new System.Drawing.Size(1443, 778);
            this.panTab.TabIndex = 11;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabMain.Controls.Add(this.ultraTabPageControl1);
            this.tabMain.Controls.Add(this.ultraTabPageControl2);
            this.tabMain.Controls.Add(this.ultraTabPageControl3);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabMain.Size = new System.Drawing.Size(1443, 778);
            this.tabMain.TabIndex = 2;
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "Operation";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "Config";
            ultraTab3.TabPage = this.ultraTabPageControl3;
            ultraTab3.Text = "Report";
            this.tabMain.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2,
            ultraTab3});
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(1439, 747);
            // 
            // panTab1Group_1
            // 
            appearance90.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panTab1Group_1.Appearance = appearance90;
            this.panTab1Group_1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            // 
            // panTab1Group_1.ClientArea
            // 
            this.panTab1Group_1.ClientArea.Controls.Add(this.ultraLabel1);
            this.panTab1Group_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTab1Group_1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panTab1Group_1.Location = new System.Drawing.Point(0, 0);
            this.panTab1Group_1.Name = "panTab1Group_1";
            this.panTab1Group_1.Size = new System.Drawing.Size(1443, 37);
            this.panTab1Group_1.TabIndex = 10;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(462, 5);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(620, 21);
            this.ultraLabel1.TabIndex = 11;
            this.ultraLabel1.Text = "For Litho Module ,There are three control system:OVL,CD,Focus.This UI for OVL";
            // 
            // ultraStatusBar1
            // 
            this.ultraStatusBar1.Location = new System.Drawing.Point(0, 815);
            this.ultraStatusBar1.Name = "ultraStatusBar1";
            ultraStatusPanel1.SizingMode = Infragistics.Win.UltraWinStatusBar.PanelSizingMode.Spring;
            appearance91.BackColor = System.Drawing.Color.NavajoWhite;
            ultraStatusPanel2.Appearance = appearance91;
            ultraStatusPanel2.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.Progress;
            ultraStatusPanel3.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.Date;
            ultraStatusPanel4.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.Time;
            this.ultraStatusBar1.Panels.AddRange(new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel[] {
            ultraStatusPanel1,
            ultraStatusPanel2,
            ultraStatusPanel3,
            ultraStatusPanel4});
            this.ultraStatusBar1.Size = new System.Drawing.Size(1443, 23);
            this.ultraStatusBar1.TabIndex = 0;
            this.ultraStatusBar1.Text = "ultraStatusBar1";
            // 
            // menuMainManage
            // 
            appearance89.FontData.SizeInPoints = 10F;
            this.menuMainManage.Appearance = appearance89;
            this.menuMainManage.DesignerFlags = 1;
            this.menuMainManage.DockWithinContainer = this;
            this.menuMainManage.DockWithinContainerBaseType = typeof(System.Windows.Forms.Form);
            this.menuMainManage.Office2007UICompatibility = false;
            this.menuMainManage.ShowFullMenusDelay = 500;
            ultraToolbar1.DockedColumn = 0;
            ultraToolbar1.DockedRow = 0;
            ultraToolbar1.NonInheritedTools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            popupMenuTool13,
            popupMenuTool14,
            popupMenuTool15});
            ultraToolbar1.Text = "UltraToolbar1";
            this.menuMainManage.Toolbars.AddRange(new Infragistics.Win.UltraWinToolbars.UltraToolbar[] {
            ultraToolbar1});
            popupMenuTool16.SharedPropsInternal.Caption = "File";
            popupMenuTool16.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            buttonTool5,
            buttonTool11});
            popupMenuTool17.SharedPropsInternal.Caption = "Edit";
            popupMenuTool17.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            buttonTool12,
            buttonTool14,
            buttonTool13});
            popupMenuTool18.SharedPropsInternal.Caption = "Help";
            popupMenuTool18.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            popupMenuTool1});
            popupMenuTool32.SharedPropsInternal.Caption = "GridRightClick";
            popupMenuTool32.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            buttonTool4});
            buttonTool1.SharedPropsInternal.Caption = "Exit";
            buttonTool2.SharedPropsInternal.Caption = "Chuck Dedication";
            buttonTool3.SharedPropsInternal.Caption = "Save";
            buttonTool6.SharedPropsInternal.Caption = "Open";
            buttonTool7.SharedPropsInternal.Caption = "Copy";
            buttonTool8.SharedPropsInternal.Caption = "Past";
            popupMenuTool2.SharedPropsInternal.Caption = "test";
            popupMenuTool2.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            buttonTool17,
            buttonTool18});
            buttonTool15.SharedPropsInternal.Caption = "test1";
            buttonTool16.SharedPropsInternal.Caption = "test2";
            this.menuMainManage.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            popupMenuTool16,
            popupMenuTool17,
            popupMenuTool18,
            popupMenuTool32,
            buttonTool1,
            buttonTool2,
            buttonTool3,
            buttonTool6,
            buttonTool7,
            buttonTool8,
            popupMenuTool2,
            buttonTool15,
            buttonTool16});
            this.menuMainManage.ToolClick += new Infragistics.Win.UltraWinToolbars.ToolClickEventHandler(this.menuManage_ToolClick);
            // 
            // _frmMain_Toolbars_Dock_Area_Left
            // 
            this._frmMain_Toolbars_Dock_Area_Left.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmMain_Toolbars_Dock_Area_Left.BackColor = System.Drawing.SystemColors.Control;
            this._frmMain_Toolbars_Dock_Area_Left.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Left;
            this._frmMain_Toolbars_Dock_Area_Left.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmMain_Toolbars_Dock_Area_Left.Location = new System.Drawing.Point(0, 23);
            this._frmMain_Toolbars_Dock_Area_Left.Name = "_frmMain_Toolbars_Dock_Area_Left";
            this._frmMain_Toolbars_Dock_Area_Left.Size = new System.Drawing.Size(0, 838);
            this._frmMain_Toolbars_Dock_Area_Left.ToolbarsManager = this.menuMainManage;
            // 
            // _frmMain_Toolbars_Dock_Area_Right
            // 
            this._frmMain_Toolbars_Dock_Area_Right.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmMain_Toolbars_Dock_Area_Right.BackColor = System.Drawing.SystemColors.Control;
            this._frmMain_Toolbars_Dock_Area_Right.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Right;
            this._frmMain_Toolbars_Dock_Area_Right.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmMain_Toolbars_Dock_Area_Right.Location = new System.Drawing.Point(1443, 23);
            this._frmMain_Toolbars_Dock_Area_Right.Name = "_frmMain_Toolbars_Dock_Area_Right";
            this._frmMain_Toolbars_Dock_Area_Right.Size = new System.Drawing.Size(0, 838);
            this._frmMain_Toolbars_Dock_Area_Right.ToolbarsManager = this.menuMainManage;
            // 
            // _frmMain_Toolbars_Dock_Area_Top
            // 
            this._frmMain_Toolbars_Dock_Area_Top.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmMain_Toolbars_Dock_Area_Top.BackColor = System.Drawing.SystemColors.Control;
            this._frmMain_Toolbars_Dock_Area_Top.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Top;
            this._frmMain_Toolbars_Dock_Area_Top.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmMain_Toolbars_Dock_Area_Top.Location = new System.Drawing.Point(0, 0);
            this._frmMain_Toolbars_Dock_Area_Top.Name = "_frmMain_Toolbars_Dock_Area_Top";
            this._frmMain_Toolbars_Dock_Area_Top.Size = new System.Drawing.Size(1443, 23);
            this._frmMain_Toolbars_Dock_Area_Top.ToolbarsManager = this.menuMainManage;
            // 
            // _frmMain_Toolbars_Dock_Area_Bottom
            // 
            this._frmMain_Toolbars_Dock_Area_Bottom.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmMain_Toolbars_Dock_Area_Bottom.BackColor = System.Drawing.SystemColors.Control;
            this._frmMain_Toolbars_Dock_Area_Bottom.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Bottom;
            this._frmMain_Toolbars_Dock_Area_Bottom.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmMain_Toolbars_Dock_Area_Bottom.Location = new System.Drawing.Point(0, 861);
            this._frmMain_Toolbars_Dock_Area_Bottom.Name = "_frmMain_Toolbars_Dock_Area_Bottom";
            this._frmMain_Toolbars_Dock_Area_Bottom.Size = new System.Drawing.Size(1443, 0);
            this._frmMain_Toolbars_Dock_Area_Bottom.ToolbarsManager = this.menuMainManage;
            // 
            // ultraDataSource1
            // 
            this.ultraDataSource1.Band.ReadOnly = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ultraDataSource2
            // 
            this.ultraDataSource2.Band.Columns.AddRange(new object[] {
            ultraDataColumn3,
            ultraDataColumn4});
            this.ultraDataSource2.Band.Key = "Context";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1443, 861);
            this.Controls.Add(this.panelFirst);
            this.Controls.Add(this._frmMain_Toolbars_Dock_Area_Left);
            this.Controls.Add(this._frmMain_Toolbars_Dock_Area_Right);
            this.Controls.Add(this._frmMain_Toolbars_Dock_Area_Bottom);
            this.Controls.Add(this._frmMain_Toolbars_Dock_Area_Top);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1440, 846);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.ultraTabPageControl4.ResumeLayout(false);
            this.panSubTab1.ClientArea.ResumeLayout(false);
            this.panSubTab1.ClientArea.PerformLayout();
            this.panSubTab1.ResumeLayout(false);
            this.panSubTab1_2.ClientArea.ResumeLayout(false);
            this.panSubTab1_2.ResumeLayout(false);
            this.panSubTab1_2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).EndInit();
            this.panSubTab1_1.ClientArea.ResumeLayout(false);
            this.panSubTab1_1.ClientArea.PerformLayout();
            this.panSubTab1_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            this.ultraTabPageControl5.ResumeLayout(false);
            this.panSubTab2.ClientArea.ResumeLayout(false);
            this.panSubTab2.ResumeLayout(false);
            this.panSubTab2_2.ClientArea.ResumeLayout(false);
            this.panSubTab2_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).EndInit();
            this.panSubTab2_1.ClientArea.ResumeLayout(false);
            this.panSubTab2_1.ClientArea.PerformLayout();
            this.panSubTab2_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor2)).EndInit();
            this.ultraTabPageControl6.ResumeLayout(false);
            this.ultraPanel3.ClientArea.ResumeLayout(false);
            this.ultraPanel3.ResumeLayout(false);
            this.ultraPanel3_2.ClientArea.ResumeLayout(false);
            this.ultraPanel3_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).EndInit();
            this.ultraPanel3_1.ClientArea.ResumeLayout(false);
            this.ultraPanel3_1.ClientArea.PerformLayout();
            this.ultraPanel3_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor6)).EndInit();
            this.ultraTabPageControl7.ResumeLayout(false);
            this.panSubTab4.ClientArea.ResumeLayout(false);
            this.panSubTab4.ResumeLayout(false);
            this.panCPE_2.ClientArea.ResumeLayout(false);
            this.panCPE_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCPE)).EndInit();
            this.panCPE_1.ClientArea.ResumeLayout(false);
            this.panCPE_1.ClientArea.PerformLayout();
            this.panCPE_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor5)).EndInit();
            this.ultraTabPageControl8.ResumeLayout(false);
            this.panSubTab5.ClientArea.ResumeLayout(false);
            this.panSubTab5.ResumeLayout(false);
            this.panSubTab5_2.ClientArea.ResumeLayout(false);
            this.panSubTab5_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).EndInit();
            this.panSubTab5_1.ClientArea.ResumeLayout(false);
            this.panSubTab5_1.ClientArea.PerformLayout();
            this.panSubTab5_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor3)).EndInit();
            this.ultraTabPageControl9.ResumeLayout(false);
            this.panSubTab6.ClientArea.ResumeLayout(false);
            this.panSubTab6.ResumeLayout(false);
            this.panSubTab6_2.ClientArea.ResumeLayout(false);
            this.panSubTab6_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).EndInit();
            this.panSubTab6_1.ClientArea.ResumeLayout(false);
            this.panSubTab6_1.ClientArea.PerformLayout();
            this.panSubTab6_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).EndInit();
            this.ultraTabPageControl1.ResumeLayout(false);
            this.panOpt.ClientArea.ResumeLayout(false);
            this.panOpt.ResumeLayout(false);
            this.panOptPicture.ClientArea.ResumeLayout(false);
            this.panOptPicture.ResumeLayout(false);
            this.panTab1Lots.ClientArea.ResumeLayout(false);
            this.panTab1Lots.ResumeLayout(false);
            this.panOptLotsGrid.ClientArea.ResumeLayout(false);
            this.panOptLotsGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabSub)).EndInit();
            this.tabSub.ResumeLayout(false);
            this.panOptSubControl.ClientArea.ResumeLayout(false);
            this.panOptSubControl.ClientArea.PerformLayout();
            this.panOptSubControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor19)).EndInit();
            this.panTab1GroupText.ClientArea.ResumeLayout(false);
            this.panTab1GroupText.ResumeLayout(false);
            this.panTab1Group.ClientArea.ResumeLayout(false);
            this.panTab1Group.ClientArea.PerformLayout();
            this.panTab1Group.ResumeLayout(false);
            this.panOptContextGroup.ClientArea.ResumeLayout(false);
            this.panOptContextGroup.ResumeLayout(false);
            this.panOptContextGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).EndInit();
            this.panTab1ContextGroup.ClientArea.ResumeLayout(false);
            this.panTab1ContextGroup.ResumeLayout(false);
            this.panOptContextGrid.ClientArea.ResumeLayout(false);
            this.panOptContextGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.optContextDataSource)).EndInit();
            this.panOptBtnRun.ClientArea.ResumeLayout(false);
            this.panOptBtnRun.ClientArea.PerformLayout();
            this.panOptBtnRun.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLots)).EndInit();
            this.panOptContextControl.ClientArea.ResumeLayout(false);
            this.panOptContextControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoChuck)).EndInit();
            this.ultraTabPageControl2.ResumeLayout(false);
            this.panCfg.ResumeLayout(false);
            this.ultraTabPageControl3.ResumeLayout(false);
            this.panRpt.ResumeLayout(false);
            this.panelFirst.ClientArea.ResumeLayout(false);
            this.panelFirst.ResumeLayout(false);
            this.panTab.ClientArea.ResumeLayout(false);
            this.panTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabMain)).EndInit();
            this.tabMain.ResumeLayout(false);
            this.panTab1Group_1.ClientArea.ResumeLayout(false);
            this.panTab1Group_1.ClientArea.PerformLayout();
            this.panTab1Group_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraStatusBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuMainManage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panelFirst;
        private Infragistics.Win.UltraWinStatusBar.UltraStatusBar ultraStatusBar1;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsManager menuMainManage;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmMain_Toolbars_Dock_Area_Left;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmMain_Toolbars_Dock_Area_Right;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmMain_Toolbars_Dock_Area_Bottom;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmMain_Toolbars_Dock_Area_Top;
        private Infragistics.Win.UltraWinDataSource.UltraDataSource ultraDataSource1;
        private Infragistics.Win.UltraWinDataSource.UltraDataSource ultraDataSource2;
        private Infragistics.Win.UltraWinDataSource.UltraDataSource optContextDataSource;
        private Infragistics.Win.Misc.UltraPanel panTab;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabMain;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private Infragistics.Win.Misc.UltraPanel panOpt;
        private Infragistics.Win.Misc.UltraPanel panOptPicture;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter5;
        private Infragistics.Win.Misc.UltraPanel panTab1Lots;
        private Infragistics.Win.Misc.UltraPanel panOptLotsGrid;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabSub;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage2;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl4;
        private Infragistics.Win.Misc.UltraPanel panSubTab1;
        private Infragistics.Win.Misc.UltraPanel panSubTab1_2;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptLinear;
        private Infragistics.Win.Misc.UltraPanel panSubTab1_1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl6;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptIHOPC;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl7;
        private Infragistics.Win.Misc.UltraPanel panSubTab4;
        private Infragistics.Win.Misc.UltraPanel panCPE_2;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptCPE;
        private Infragistics.Win.Misc.UltraPanel panCPE_1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl8;
        private Infragistics.Win.Misc.UltraPanel panSubTab5;
        private Infragistics.Win.Misc.UltraPanel panSubTab5_2;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptCD;
        private Infragistics.Win.Misc.UltraPanel panSubTab5_1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl9;
        private Infragistics.Win.Misc.UltraPanel panSubTab6;
        private Infragistics.Win.Misc.UltraPanel panSubTab6_2;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptFocus;
        private Infragistics.Win.Misc.UltraPanel panSubTab6_1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl5;
        private Infragistics.Win.Misc.UltraPanel panSubTab2;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptHOPC;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter4;
        private Infragistics.Win.Misc.UltraPanel panOptSubControl;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoList;
        private Infragistics.Win.Misc.UltraButton btnOptUpdate;
        private Infragistics.Win.Misc.UltraButton btnOptMode;
        private Infragistics.Win.Misc.UltraButton btnOptReset;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor17;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor18;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor19;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter1;
        private Infragistics.Win.Misc.UltraPanel panTab1GroupText;
        private Infragistics.Win.Misc.UltraPanel panTab1Group;
        private Infragistics.Win.Misc.UltraPanel panOptContextGroup;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptContextGroup;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter8;
        private Infragistics.Win.Misc.UltraPanel panTab1ContextGroup;
        private Infragistics.Win.Misc.UltraPanel panOptBtnRun;
        private Infragistics.Win.Misc.UltraButton btnOptRun;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdOptContext;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter3;
        private Infragistics.Win.Misc.UltraPanel panOptContextControl;
        private Infragistics.Win.Misc.UltraButton btnOptBatchOperation;
        private Infragistics.Win.Misc.UltraButton btnOptManualRun;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtLots;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor14;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.Misc.UltraPanel panCfg;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl3;
        private Infragistics.Win.Misc.UltraPanel panRpt;
        private Infragistics.Win.Misc.UltraPanel panTab1Group_1;
        private Infragistics.Win.Misc.UltraPanel panOptContextGrid;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoChuck;
        private Infragistics.Win.Misc.UltraPanel panSubTab2_2;
        private Infragistics.Win.Misc.UltraPanel panSubTab2_1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor2;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3_2;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3_1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor6;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor5;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor3;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor4;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter2;
        private Infragistics.Win.Misc.UltraButton btnQueryLotInfo;
    }
}

