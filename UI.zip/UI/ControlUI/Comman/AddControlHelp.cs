﻿using Infragistics.UltraChart.Core.Layers;
using Infragistics.UltraChart.Resources.Appearance;
using Infragistics.UltraChart.Shared.Styles;
using Infragistics.Win.Misc;
using Infragistics.Win.UltraWinChart;
using Infragistics.Win.UltraWinEditors;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Comman
{
    class AddControlHelp
    {
        #region Add Chart
        public static void AddChartToPanel(UltraPanel ctlPanel, ref List<UltraChart> listChart, int chartNum, List<string> strListChartName, List<List<double>> dListValues, List<string> strListChartColumn)
        {
            listChart.Clear();

            int locationX = 0;
            int locationY = 0;
            int chartWidth = 0;
            for (int n = 0; n < chartNum; n++)
            {
                UltraChart chart = new UltraChart();
                chart = UltraChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strListChartColumn);
                //chart = UltraChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strListChartColumn);
                //chart = CreateChart(dListValues[n], strListChartName[n], strListChartColumn);

                if (n == 0)
                {
                    locationX = chart.Location.X;
                    locationY = chart.Location.Y;
                    chartWidth = chart.Width + 10;
                }
                else
                {
                    locationX = locationX + chartWidth;
                    locationY = chart.Location.Y;
                    chart.Location = new Point(locationX, locationY);
                }
                chart.Name = "chartPanNum" + n;
                ctlPanel.ClientArea.Controls.Add(chart);
                listChart.Add(chart);
            }
        }

        public static void AddChartToPanel(UltraPanel ctlPanel, ref List<UltraChart> listChart, int colNum, int chartNum, List<string> strListChartName, List<List<double>> dListValues, List<string> strListChartColumn)
        {
            listChart.Clear();
            if (colNum == 1)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    //chart = UltraChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strListChartColumn);
                    chart = UltraChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strListChartColumn);
                    //chart = UltraChartHelp.CreateLineChart(DataTableHelp.GetLineChartDataTest(), "Label Column", "Value Column1", "Title");
                    //chart = CreateChart(dListValues[n], strListChartName[n], strListChartColumn);

                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                    }
                    chart.Name = "chartPanNum" + n;
                    ctlPanel.ClientArea.Controls.Add(chart);
                    listChart.Add(chart);
                }
            }
            else if (colNum == 2)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                int chartHeight = 0;

                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart = CreateChart(dListValues[n], strListChartName[n], strListChartColumn);
                    chart.Height = (ctlPanel.Height - 5) / 2;
                    chartHeight = chart.Height;

                    UltraChart chart2 = new UltraChart();
                    chart2 = CreateChart(dListValues[n], strListChartName[n], strListChartColumn);
                    chart2.Height = chartHeight;

                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);  
                    }
                    chart.Name = "chartPanCol1_" + n;
                    ctlPanel.ClientArea.Controls.Add(chart);
                    chart2.Location = new Point(locationX, chartHeight + 10);
                    chart2.Name = "chartPanCol2_" + n;
                    ctlPanel.ClientArea.Controls.Add(chart2);
                }
            }
        }
        #endregion

        #region Add Control
        public static void AutoAddLableControl(List<string> strListName, ref List<UltraTextEditor> strListControl, UltraTextEditor txtControl, UltraPanel panControl)
        {
            int locationX = 0;
            int locationY = 0;
            int width = 0;

            string str;
            //str = strListName[0] + ":";
            locationX = txtControl.Location.X;
            locationY = txtControl.Location.Y + txtControl.Height + 10;
            width = txtControl.Width;
            txtControl.Text = strListName[0];
            txtControl.RightToLeft = RightToLeft.Yes;
            txtControl.AutoSize = true;
            txtControl.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            strListControl.Clear();
            if (strListName.Count > 1)
            {
                for (int i = 1; i < strListName.Count; i++)
                {
                    UltraTextEditor ctlNew = new UltraTextEditor();
                    ctlNew.Location = new Point(locationX, locationY);
                    ctlNew.Width = width;
                    ctlNew.ReadOnly = true;
                    ctlNew.RightToLeft = RightToLeft.Yes;
                    ctlNew.Text = strListName[i];               
                    ctlNew.AutoSize = true;
                    ctlNew.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
                    strListControl.Add(ctlNew);
                    panControl.ClientArea.Controls.Add(ctlNew);
                    locationY = ctlNew.Location.Y + ctlNew.Height + 10;
                }
            }
        }

        public static void AutoAddTextControl(List<double> dListValue, ref List<UltraTextEditor> strListControl, UltraTextEditor txtControl, UltraPanel panControl, bool bIsReadOnly)
        {
            int locationX = 0;
            int locationY = 0;
            int width = 0;

            locationX = txtControl.Location.X;
            locationY = txtControl.Location.Y + txtControl.Height + 10;
            width = txtControl.Width;

            txtControl.Text = dListValue[0].ToString();
            txtControl.ReadOnly = bIsReadOnly;
            txtControl.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            strListControl.Clear();
            if (dListValue.Count > 1)
            {
                for (int i = 1; i < dListValue.Count; i++)
                {
                    UltraTextEditor ctlNew = new UltraTextEditor();
                    ctlNew.Location = new Point(locationX, locationY);
                    ctlNew.Width = width;
                    ctlNew.ReadOnly = false;
                    ctlNew.Text = dListValue[i].ToString();
                    ctlNew.ReadOnly = bIsReadOnly;
                    ctlNew.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
                    strListControl.Add(ctlNew);
                    panControl.ClientArea.Controls.Add(ctlNew);
                    locationY = ctlNew.Location.Y + ctlNew.Height + 10;
                }
            }
        }
        #endregion

        #region Add Control Test
        public static void AutoAddNewTxtControl(List<double> dList, ref List<NumericUpDown> strListControl, NumericUpDown txtControl, UltraPanel panControl)
        {
            int locationX = 0;
            int locationY = 0;
            int width = 0;

            locationX = txtControl.Location.X;
            locationY = txtControl.Location.Y + txtControl.Height + 10;
            width = txtControl.Width;

            txtControl.Text = dList[0].ToString();
            strListControl.Clear();

            if (dList.Count > 1)
            {
                for (int i = 1; i < dList.Count; i++)
                {
                    NumericUpDown ctlNew = new NumericUpDown();
                    ctlNew.Location = new Point(locationX, locationY);
                    //labTxtNew.Name = "updoneNew" + (i + 1);
                    ctlNew.Width = width;
                    ctlNew.ReadOnly = false;
                    ctlNew.Text = dList[i].ToString();
                    strListControl.Add(ctlNew);
                    //panLinearResetSubTab.ClientArea.Controls.Add(ctlNew);
                    panControl.ClientArea.Controls.Add(ctlNew);
                    locationY = ctlNew.Location.Y + ctlNew.Height + 10;
                }
            }
        }
        public static void AutoAddNewTxtControl(List<string> strList, ref List<NumericUpDown> strListControl, NumericUpDown txtControl, UltraPanel panControl)
        {
            int locationX = 0;
            int locationY = 0;
            int width = 0;

            locationX = txtControl.Location.X;
            locationY = txtControl.Location.Y + txtControl.Height + 10;
            width = txtControl.Width;

            txtControl.Text = strList[0];
            strListControl.Clear();

            if (strList.Count > 1)
            {
                for (int i = 1; i < strList.Count; i++)
                {
                    NumericUpDown ctlNew = new NumericUpDown();
                    ctlNew.Location = new Point(locationX, locationY);
                    //labTxtNew.Name = "updoneNew" + (i + 1);
                    ctlNew.Width = width;
                    ctlNew.ReadOnly = false;
                    ctlNew.Text = strList[i];
                    strListControl.Add(ctlNew);
                    //panLinearResetSubTab.ClientArea.Controls.Add(ctlNew);
                    panControl.ClientArea.Controls.Add(ctlNew);
                    locationY = ctlNew.Location.Y + ctlNew.Height + 10;
                }
            }
        }

        public static void AutoAddCurrentTxtControl(List<string> strList, ref List<UltraTextEditor> strListControl, UltraTextEditor txtControl, UltraPanel panControl)
        {
            int locationX = 0;
            int locationY = 0;
            int width = 0;

            locationX = txtControl.Location.X;
            locationY = txtControl.Location.Y + txtControl.Height + 10;
            width = txtControl.Width;

            txtControl.Text = strList[0];
            strListControl.Clear();
            if (strList.Count > 1)
            {
                for (int i = 1; i < strList.Count; i++)
                {
                    UltraTextEditor ctlNew = new UltraTextEditor();
                    ctlNew.Location = new Point(locationX, locationY);
                    //labTxtNew.Name = "txtCurrent" + (i + 1);
                    ctlNew.Width = width;
                    ctlNew.ReadOnly = false;
                    ctlNew.Text = strList[i];
                    strListControl.Add(ctlNew);
                    //panLinearResetSubTab.ClientArea.Controls.Add(ctlNew);
                    panControl.ClientArea.Controls.Add(ctlNew);
                    locationY = ctlNew.Location.Y + ctlNew.Height + 10;
                }
            }
        }
        public static void AutoAddControlTest(List<string> strList, ref List<UltraTextEditor> lblListControl, ref List<NumericUpDown> updListControl, ref List<UltraTextEditor> txtListControl, UltraPanel panControl)
        {
            int lblX = 0;
            int lblY = 0;

            int txtNewX = 0;
            int txtNewY = 0;

            int txtCurrentX = 0;
            int txtCurrentY = 0;

            lblX = panControl.Location.X + 20;
            lblY = panControl.Location.Y + 45;

            for (int i = 0; i < strList.Count; i++)
            {
                UltraTextEditor lblCtlNew = new UltraTextEditor();
                lblCtlNew.Location = new Point(lblX, lblY);
                //ctlNew.Name = "lblTxt" + (i + 1);
                //lblCtlNew.Width = lblWidth;
                lblCtlNew.ReadOnly = true;
                lblCtlNew.Text = "Input" + (i + 1);
                lblListControl.Add(lblCtlNew);
                panControl.ClientArea.Controls.Add(lblCtlNew);

                txtNewX = lblX + lblCtlNew.Width + 20;
                txtNewY = lblY;
                NumericUpDown updCtlNew = new NumericUpDown();
                updCtlNew.Location = new Point(txtNewX, txtNewY);
                //ctlNew.Name = "lblTxt" + (i + 1);
                //txtCtlNew.Width = txtWidth;
                updCtlNew.ReadOnly = false;
                updCtlNew.Text = strList[i];
                updListControl.Add(updCtlNew);
                panControl.ClientArea.Controls.Add(updCtlNew);

                txtCurrentX = txtNewX + updCtlNew.Width + 20;
                txtCurrentY = lblY;
                UltraTextEditor txtCtlNew = new UltraTextEditor();
                txtCtlNew.Location = new Point(txtCurrentX, txtCurrentY);
                //ctlNew.Name = "lblTxt" + (i + 1);
                //txtCtlNew.Width = txtWidth;
                txtCtlNew.ReadOnly = false;
                txtCtlNew.Text = strList[i];
                txtListControl.Add(txtCtlNew);
                panControl.ClientArea.Controls.Add(txtCtlNew);

                lblY = lblCtlNew.Location.Y + lblCtlNew.Height + 10;
            }
        }
        #endregion

        #region Add Chart test
        private static string GetItemFormat(double dValue)
        {
            string strTemp;
            string strFormat = "";
            strTemp = dValue.ToString();
            strTemp = strTemp.Substring(strTemp.IndexOf("."));
            for (int i = 0; i < strTemp.Length; i++)
            {
                strFormat += "#";
            }
            strFormat = "<DATA_VALUE:0." + strFormat + ">";
            return strFormat;
        }
        private static NumericSeries GetNumericSeriesUnBound(List<double> dList, List<string> strList)
        {
            NumericSeries series = new NumericSeries();

            //series.Label = "Series A";

            for (int i = 0; i < dList.Count; i++)
            {
                series.Points.Add(new NumericDataPoint(dList[i], strList[i], false));
            }

            return series;
        }
        public static UltraChart CreateChart(List<double> dList, string strChartName, List<string> strListChartColumn)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.LineChart;

            //ChartArea myChartArea = new ChartArea();
            //myChartArea.BoundsMeasureType = MeasureType.Percentage;
            //myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            //myChartArea.Border.Thickness = 0;
            //chart.CompositeChart.ChartAreas.Add(myChartArea);


            NumericSeries seriesLine = new NumericSeries();
            if (dList.Count > 0)
            {
                seriesLine = GetNumericSeriesUnBound(dList, strListChartColumn);
                seriesLine.DataBind();
                chart.Series.Add(seriesLine);
                chart.Axis.Y.Labels.ItemFormatString = "<DATA_VALUE:0.0000>";
                //chart.Axis.Y.Labels.ItemFormatString = "<DATA_VALUE>";
                //chart.Axis.Y.Labels.ItemFormatString = GetItemFormat(dList[0]);
                //chart.Axis.Y.Labels.ItemFormat = AxisItemLabelFormat.Custom;
            }

            chart.Data.DataBind();

            chart.Tooltips.FormatString = "<DATA_VALUE>";
            chart.Tooltips.TooltipControl = null;
            chart.Tooltips.UseControl = false;
            chart.TitleTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            chart.TitleTop.FontColor = System.Drawing.Color.Red;
            chart.TitleTop.HorizontalAlign = System.Drawing.StringAlignment.Near;
            //chart.TitleTop.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.TitleTop.Text = strChartName;

            return chart;
        }

        public static void CreateChart(UltraPanel ctlPanel, ref List<UltraChart> listChart, int colNum, int chartNum, List<string> strListChartName, List<List<double>> dListValues, List<string> strListChartColumn)
        {
            listChart.Clear();
            if (colNum == 1)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);

                    List<double> dListSeriesLine2 = new List<double>(dListValues[n]);
                    NumericSeries seriesLine2 = new NumericSeries();
                    seriesLine2 = GetNumericSeriesUnBound(dListSeriesLine2, strListChartColumn);
                    seriesLine2.DataBind();
                    chart.Series.Add(seriesLine2);

                    chart.Data.DataBind();
                    chart.TitleTop.Text = strListChartName[n];

                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }

                }
            }
            else if (colNum == 2)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    chart.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);

                    UltraChart chart2 = new UltraChart();
                    chart2.ChartType = ChartType.LineChart;
                    chart2.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea2 = new ChartArea();
                    myChartArea2.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea2.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea2.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea2);
                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart.Height + 10);
                        chart2.Name = "chartPanCol2_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart2.Height + 10);
                        chart2.Name = "chartPanCol2_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                }
            }
        }

        public static void CreateChart(UltraPanel ctlPanel, ref List<UltraChart> listChart, int colNum, int chartNum,List<string> strListChartName, List<DataTable> dbList)
        {
            listChart.Clear();
            if (colNum == 1)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);
                    chart.Data.DataSource = dbList[n];
                    chart.Data.DataBind();
                    chart.TitleTop.Text = strListChartName[n];

                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }

                }
            }
            else if (colNum == 2)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    chart.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);

                    UltraChart chart2 = new UltraChart();
                    chart2.ChartType = ChartType.LineChart;
                    chart2.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea2 = new ChartArea();
                    myChartArea2.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea2.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea2.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea2);
                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart.Height + 10);
                        chart.Name = "chartPanCol2_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart2.Height + 10);
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                }
            }
        }

        public static void CreateLineChart(UltraPanel ctlPanel, ref UltraChart ctlChart)
        {
            UltraChart chartNew = new UltraChart();
            chartNew.ChartType = ChartType.LineChart;
            ChartArea myChartArea = new ChartArea();
            myChartArea.BoundsMeasureType = MeasureType.Percentage;
            myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            myChartArea.Border.Thickness = 0;
            chartNew.CompositeChart.ChartAreas.Add(myChartArea);

            //NumericSeries seriesLine1 = new NumericSeries();
            //seriesLine1 = GetNumericSeriesUnBound();
            //seriesLine1.DataBind();
            //chartNew.Series.Add(seriesLine1);

            List<double> dListMax = new List<double>() { 6.0, 6.0, 6.0, 6.0 };
            NumericSeries seriesMax = new NumericSeries();
            seriesMax = GetNumericSeriesUnBound(dListMax);
            seriesMax.DataBind();
            chartNew.Series.Add(seriesMax);

            List<double> dLisAvg = new List<double>() { 3.0, 3.0, 3.0, 3.0 };
            NumericSeries seriesAvg = new NumericSeries();
            seriesAvg = GetNumericSeriesUnBound(dLisAvg);
            seriesAvg.DataBind();
            chartNew.Series.Add(seriesAvg);


            List<double> dListMin = new List<double>() { 1.0, 1.0, 1.0, 1.0 };
            NumericSeries seriesMin = new NumericSeries();
            seriesMin = GetNumericSeriesUnBound(dListMin);
            seriesMin.DataBind();
            chartNew.Series.Add(seriesMin);

            List<double> dListSeriesLine1 = new List<double>() { 4.0, 2.0, 5.0, 1.7 };
            NumericSeries seriesLine1 = new NumericSeries();
            seriesLine1 = GetNumericSeriesUnBound(dListSeriesLine1);
            seriesLine1.DataBind();
            chartNew.Series.Add(seriesLine1);

            List<double> dListSeriesLine2 = new List<double>() { 5.0, 3.0, 5.3, 4.5 };
            NumericSeries seriesLine2 = new NumericSeries();
            seriesLine2 = GetNumericSeriesUnBound(dListSeriesLine2);
            seriesLine2.DataBind();
            chartNew.Series.Add(seriesLine2);

            chartNew.Data.DataBind();
            chartNew.TitleTop.Text = "TEXT";

            ctlChart = chartNew;
            ctlPanel.ClientArea.Controls.Add(chartNew);
        }

        public static void CreateLineChart(UltraPanel ctlPanel, ref UltraChart ctlChart, DataTable chartSource)
        {
            UltraChart chartNew = new UltraChart();
            chartNew.ChartType = ChartType.LineChart;
            ChartArea myChartArea = new ChartArea();
            myChartArea.BoundsMeasureType = MeasureType.Percentage;
            myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            myChartArea.Border.Thickness = 0;
            chartNew.CompositeChart.ChartAreas.Add(myChartArea);

            NumericSeries seriesLine1 = new NumericSeries();
            seriesLine1 = GetNumericSeriesBound(chartSource, "Value Column1");
            seriesLine1.DataBind();
            chartNew.Series.Add(seriesLine1);

            //NumericSeries seriesLine2 = new NumericSeries();
            //seriesLine2 = GetNumericSeriesBound(chartSource, "Value Column2");
            //seriesLine2.DataBind();
            //chartNew.Series.Add(seriesLine2);

            //chartNew.Data.DataSource = chartSource;

            chartNew.Data.DataBind();
            chartNew.TitleTop.Text = "TEXT";

            ctlChart = chartNew;
            ctlPanel.ClientArea.Controls.Add(chartNew);
        }

        public static void CreateColumnChart(UltraPanel ctlPanel, ref UltraChart ctlChart)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.ColumnChart;
            ChartArea myChartArea = new ChartArea();
            myChartArea.BoundsMeasureType = MeasureType.Percentage;
            myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            myChartArea.Border.Thickness = 0;
            chart.CompositeChart.ChartAreas.Add(myChartArea);

            chart.Data.SwapRowsAndColumns = true;//行列交换

            List<double> dListSerice1 = new List<double>() { 6.0, 3.0,5.0, 2.0 };
            NumericSeries seriesMax = new NumericSeries();
            seriesMax = GetNumericSeriesUnBound(dListSerice1);
            seriesMax.DataBind();
            chart.Series.Add(seriesMax);

            //List<double> dListSerice2 = new List<double>() { 3.0, 4.0, 2.0, 5.0 };
            //NumericSeries seriesAvg = new NumericSeries();
            //seriesAvg = GetNumericSeriesUnBound(dListSerice2);
            //seriesAvg.DataBind();
            //chartNew.Series.Add(seriesAvg);

            chart.Data.DataBind();
            chart.TitleTop.Text = "TEXT";

            ctlChart = chart;
            ctlPanel.ClientArea.Controls.Add(chart);

        }
        public static void CreateColumnChart(UltraPanel ctlPanel, ref UltraChart ctlChart, DataTable chartSource)
        {
            UltraChart chartNew = new UltraChart();
            chartNew.ChartType = ChartType.ColumnChart;
            ChartArea myChartArea = new ChartArea();
            myChartArea.BoundsMeasureType = MeasureType.Percentage;
            myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            myChartArea.Border.Thickness = 0;
            chartNew.CompositeChart.ChartAreas.Add(myChartArea);


            //NumericSeries seriesLable = new NumericSeries();
            //seriesLable = GetNumericSeriesBound(chartSource, "Label Column");
            //seriesLable.DataBind();
            //chartNew.Series.Add(seriesLable);

            //NumericSeries seriesLine2 = new NumericSeries();
            //seriesLine2 = GetNumericSeriesBound(chartSource, "Value Min");
            //seriesLine2.DataBind();
            //chartNew.Series.Add(seriesLine2);

            chartNew.Data.DataSource = chartSource;

            chartNew.Data.DataBind();
            chartNew.TitleTop.Text = "TEXT";

            ctlChart = chartNew;
            ctlPanel.ClientArea.Controls.Add(chartNew);
        }

        private static NumericSeries GetNumericSeriesBound(DataTable dt, string colName)
        {
            NumericSeries seriesLine = new NumericSeries();
            seriesLine.Data.DataSource = dt;

            //轴线上显示的标签信息
            seriesLine.Data.LabelColumn = "Label Column";

            //图表上要显示的值
            seriesLine.Data.ValueColumn = colName;
            //seriesLine.DataBind();

            return seriesLine;
        }

        /// <summary>
        /// 绑定数据
        /// </summary>
        private static NumericSeries GetNumericSeriesUnBound()
        {
            NumericSeries series = new NumericSeries();

            series.Label = "Series A";

            //series.Points.Add(new NumericDataPoint(0.0, "Column", false));
            series.Points.Add(new NumericDataPoint(5.0, "Point A", false));
            series.Points.Add(new NumericDataPoint(4.0, "Point B", false));
            series.Points.Add(new NumericDataPoint(3.0, "Point C", false));
            series.Points.Add(new NumericDataPoint(2.0, "Point D", false));
            series.Points.Add(new NumericDataPoint(1.0, "Point E", false));
            return series;
        }
        /// <summary>
        /// 绑定数据
        /// </summary>
        private static NumericSeries GetNumericSeriesUnBound(List<double> dList)
        {
            NumericSeries series = new NumericSeries();

            //series.Label = "Series A";

            for (int i = 0; i < dList.Count; i++)
            {
                series.Points.Add(new NumericDataPoint(dList[i],"A", false));
            }

            return series;
        }

        public static void CreateChart(UltraPanel ctlPanel, ref List<UltraChart> listChart, int colNum, int chartNum)
        {
            listChart.Clear();
            if (colNum == 1)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);
                    chart.Data.DataSource = DataTableHelp.GetLineChartDataTest();
                    chart.Data.DataBind();
                    chart.TitleTop.Text = "TEXT";

                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanNum" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        listChart.Add(chart);
                    }

                }
            }
            else if (colNum == 2)
            {
                int locationX = 0;
                int locationY = 0;
                int chartWidth = 0;
                for (int n = 0; n < chartNum; n++)
                {
                    UltraChart chart = new UltraChart();
                    chart.ChartType = ChartType.LineChart;
                    chart.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea = new ChartArea();
                    myChartArea.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea);

                    UltraChart chart2 = new UltraChart();
                    chart2.ChartType = ChartType.LineChart;
                    chart2.Height = (ctlPanel.Height - 5) / 2;
                    ChartArea myChartArea2 = new ChartArea();
                    myChartArea2.BoundsMeasureType = MeasureType.Percentage;
                    myChartArea2.Bounds = new Rectangle(0, 0, 100, 80);
                    myChartArea2.Border.Thickness = 0;
                    chart.CompositeChart.ChartAreas.Add(myChartArea2);
                    if (n == 0)
                    {
                        locationX = chart.Location.X;
                        locationY = chart.Location.Y;
                        chartWidth = chart.Width + 10;
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart.Height + 10);
                        chart.Name = "chartPanCol2_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                    else
                    {
                        locationX = locationX + chartWidth;
                        locationY = chart.Location.Y;
                        chart.Location = new Point(locationX, locationY);
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart);
                        chart2.Location = new Point(locationX, chart2.Height + 10);
                        chart.Name = "chartPanCol1_" + n;
                        ctlPanel.ClientArea.Controls.Add(chart2);
                    }
                }
            }
        }
        #endregion
    }
}
