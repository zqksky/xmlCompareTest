﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Comman
{
    class FrmAutoSize
    {
        #region
        public static void setTag(Control cons)
        {
            foreach (Control con in cons.Controls)
            {
                con.Tag = con.Width + ":" + con.Height + ":" + con.Left + ":" + con.Top + ":" + con.Font.Size;
                if (con.Controls.Count > 0)
                {
                    setTag(con);
                }
            }
        }
        public static void setControls(float newx, float newy, Control cons)
        {
            foreach (Control con in cons.Controls)
            {

                string[] mytag = con.Tag.ToString().Split(new char[] { ':' });
                float a = Convert.ToSingle(mytag[0]) * newx;
                con.Width = (int)a;
                a = Convert.ToSingle(mytag[1]) * newy;
                con.Height = (int)(a);
                a = Convert.ToSingle(mytag[2]) * newx;
                con.Left = (int)(a);
                a = Convert.ToSingle(mytag[3]) * newy;
                con.Top = (int)(a);
                Single currentSize = Convert.ToSingle(mytag[4]) * Math.Min(newx, newy);
                con.Font = new Font(con.Font.Name, currentSize, con.Font.Style, con.Font.Unit);
                if (con.Controls.Count > 0)
                {
                    setControls(newx, newy, con);
                }
            }
        }

        //Form frm = new Form();
        //private float frmLocationX;
        //private float frmLocationY;
        //private void Form_Load(object sender, EventArgs e)
        //{
        //    #region  frmAutoSize
        //    this.Resize += new EventHandler(Form_Resize);
        //    frmLocationX = this.Width;
        //    frmLocationY = this.Height;
        //    FrmAutoSize.setTag(this);
        //    //Form_Resize(new object(), new EventArgs());//x,y可在实例化时赋值,最后这句是新加的，在MDI时有用
        //    #endregion
        //}

        //private void Form_Resize(object sender, EventArgs e)
        //{
        //    #region
        //    float newx = (this.Width) / frmLocationX;
        //    float newy = this.Height / frmLocationY;
        //    FrmAutoSize.setControls(newx, newy, this);
        //    //this.Text = this.Width.ToString() + " " + this.Height.ToString();
        //    #endregion
        //}
        #endregion
    }
}
