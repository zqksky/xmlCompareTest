﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlUI.Comman
{
    class DataTableHelp
    {
        #region CreateLinearResetTable
        public static DataTable CreateLinearResetTable(UIServiceFun.structPH_OVL_GetResetValues structData)
        {
            DataTable db = new DataTable("LinearReset");

            db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_NAME", Type.GetType("System.String"));
            db.Columns.Add("RETICLE_ID", Type.GetType("System.String"));
            db.Columns.Add("INPUT_VALUE", Type.GetType("System.Double"));
            
            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][1] = structData.strListInputNames[i];
                db.Rows[i][2] = structData.strListReticleIds[i];
                db.Rows[i][3] = structData.dListInputValues[i];
            }

            return db;
        }
        #endregion

        #region CreateBatchPMOffsetTable
        public static DataTable CreateBatchPMOffsetTable(UIServiceFun.structPH_OVL_Batch_GetPMOffsets structData)
        {
            DataTable db = new DataTable("BatchPMOffset");

            db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_NAME", Type.GetType("System.String"));
            db.Columns.Add("INPUT_MODEL", Type.GetType("System.String"));
            db.Columns.Add("PM_OFFSETS", Type.GetType("System.Double"));

            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][1] = structData.strListInputNames[i];
                db.Rows[i][2] = structData.strListInputModels[i];
                db.Rows[i][3] = structData.dListPMOffsets[i];
            }

            return db;
        }
        #endregion

        #region CreateBatchOVLModelTable
        public static DataTable CreateBatchOVLModelTable(UIServiceFun.structPH_OVL_Batch_GetOVLModel structData)
        {
            DataTable db = new DataTable("BatchOVLModel");

            db.Columns.Add("PRODUCT", Type.GetType("System.String"));
            db.Columns.Add("LAYER", Type.GetType("System.String"));
            db.Columns.Add("TOOLS", Type.GetType("System.String"));
            db.Columns.Add("OVL_MODELS", Type.GetType("System.String"));
            db.Columns.Add("CPE_MODEL_ON", Type.GetType("System.String"));
            db.Columns.Add("R2R_MODEL", Type.GetType("System.String"));

            for (int i = 0; i < structData.strListProducts.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.strListProducts[i];
                db.Rows[i][1] = structData.strListLayers[i];
                db.Rows[i][2] = structData.strListTools[i];
                db.Rows[i][3] = structData.strListOVLModels[i];
                db.Rows[i][4] = structData.bListIsCPEModelOn[i];
                db.Rows[i][5] = structData.strListR2RMode[i];
            }

            return db;
        }
        #endregion

        #region CreateChuckDedicationTable
        public static DataTable CreateChuckDedicationTable(List<string> strListColumnName, List<string> strListVaue)
        {
            DataTable db = new DataTable("Chuck");

            foreach (var str in strListColumnName)
            {
                db.Columns.Add(str, Type.GetType("System.String"));
            }

            db.Rows.Add();
            for (int i = 0; i < strListVaue.Count; i++)
            {
                db.Rows[0][i] = strListVaue[i];
            }

            return db;
        }

        public static DataTable CreateQueryLotInfoTable(UIServiceFun.structPH_OVL_QueryLotInfo structData)
        {
            DataTable db = new DataTable("QueryLotInfo");

            db.Columns.Add("WAFER_ID", Type.GetType("System.String"));
            db.Columns.Add("SLOT_ID", Type.GetType("System.String"));
            db.Columns.Add("CHUCK", Type.GetType("System.String"));
  
            for (int i = 0; i < structData.strListWaferIds.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.strListWaferIds[i];
                db.Rows[i][1] = structData.strListSlotIds[i];
                db.Rows[i][2] = structData.strListChuckIds[i];
            }

            return db;
        }

        #endregion

        #region CreatChartDataTable
        public static List<DataTable> CreatChartDataTable(List<List<double>> strListItemValues, List<string> strListColName)
        {
            List<DataTable> dbs = new List<DataTable>();

            for (int i = 0; i < strListItemValues.Count; i++)
            {
                DataTable db = new DataTable();
                db = ListToDataTable(strListItemValues[i], strListColName);
                dbs.Add(db);
            }
 
            return dbs;
        }
        public static DataTable ListToDataTable(List<double> strList, List<string> strListColName)
        {
            DataTable db = new DataTable();
            if (strList.Count>0)
            {
                db.Columns.Add("LOT_ID", Type.GetType("System.String"));
                for (int i = 0; i < strList.Count; i++)
                {
                    db.Columns.Add(strListColName[i], Type.GetType("System.Double"));
                }

                object[] colValue = new object[strList.Count + 1];
                colValue[0] = "LOT_ID";
                for (int i = 0; i < strList.Count; i++)
                {
                    colValue[i + 1] = strList[i];
                }
                db.Rows.Add(colValue);
            }
           
            return db;
        }
        #endregion

        #region CreateLinearTable
        public static DataTable CreateOVLTable(List<string>strListColumn1, List<string> strListColumn2)
        {
            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));

            for (int i=0;i< strListColumn1.Count;i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListColumn1[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListColumn2[i];
            }

            return db;
        }
        #endregion

        #region datatable去重 只保留筛选列的数据
        public static DataTable FilterRepeatTable(DataTable tb, string strColumn1, string strColumn2)
        {
            DataTable dataTable = tb.Clone();

            foreach (DataRow row in dataTable.Rows)
            {
                int rowCount = (from DataRow q in dataTable.Rows where q[strColumn1].ToString() == row[strColumn1].ToString() && q[strColumn2].ToString() == row[strColumn2].ToString() select q).ToList().Count();
                if (rowCount == 0)
                {
                    DataRow _row = dataTable.NewRow();
                    _row.ItemArray = row.ItemArray;
                    dataTable.Rows.Add(_row);
                }
            }
            return dataTable;
        }
        #endregion

        #region datatable去重 
        public static DataTable GetDistinctTable(DataTable dtSource, List<string> strListColumnName)
        {
            DataTable distinctTable = dtSource.Clone();
            try
            {
                if (dtSource != null && dtSource.Rows.Count > 0)
                {
                    DataView dv = new DataView(dtSource);
                    distinctTable = dv.ToTable(true, strListColumnName.ToArray());
                }
            }
            catch (Exception ee)
            {
                //MessageBox.Show(ee.ToString());
            }
            return distinctTable;
        }

        public static DataTable GetDistinctTable(DataTable dtSource)
        {
            DataTable distinctTable = null;
            try
            {
                if (dtSource != null && dtSource.Rows.Count > 0)
                {
                    string[] columnNames = GetTableColumnName(dtSource);
                    DataView dv = new DataView(dtSource);
                    distinctTable = dv.ToTable(true, columnNames);
                }
            }
            catch (Exception ee)
            {
                //MessageBox.Show(ee.ToString());
            }
            return distinctTable;
        }

        //获取表中所有列名
        public static string[] GetTableColumnName(DataTable dt)
        {
            string cols = string.Empty;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                cols += (dt.Columns[i].ColumnName + ",");
            }
            cols = cols.TrimEnd(',');
            return cols.Split(',');
        }
        #endregion

        #region datatable根据列条件去重
        public static DataTable DistinctSomeColumn(DataTable sourceTable, List<string> strListColumnName)
        {
            return sourceTable.AsEnumerable().GroupBy(row =>
            {
                StringBuilder s = new StringBuilder();
                strListColumnName.ForEach(p => s.Append(row[p].ToString()));
                return s.ToString();
            }).Select(p => p.First()).CopyToDataTable<DataRow>();
        }

        //public static DataTable DistinctSomeColumn(DataTable sourceTable, params string[] fieldName)
        //{
        //    if (fieldName == null || fieldName.Length == 0) return sourceTable;
        //    return sourceTable.AsEnumerable().Distinct(new ColumnEquals(fieldName)).CopyToDataTable();
        //}

        //public class ColumnEquals : IEqualityComparer<DataRow>
        //{
        //    public ColumnEquals(string[] sArr)
        //    {
        //        _sArr = sArr;
        //    }

        //    private string[] _sArr;
        //    public bool Equals(DataRow x, DataRow y)
        //    {
        //        return !_sArr.Any(p => !x[p].Equals(y[p]));
        //    }

        //    public int GetHashCode(DataRow obj)
        //    {
        //        return obj.ToString().GetHashCode();
        //    }
        //}
        #endregion

        #region CreateContextTable
        public static DataTable CreateContextTable()
        {
            DataTable db = new DataTable("TabContextGroup");

            db.Columns.Add("Name", Type.GetType("System.String"));
            db.Columns.Add("Value", Type.GetType("System.String"));

            db.Rows[0]["Name"] = "Module";
            db.Rows[0]["Name"] = "Product";
            db.Rows[0]["Name"] = "Stage";
            db.Rows[0]["Name"] = "Layer";
            db.Rows[0]["Name"] = "Control System";
            db.Rows[0]["Name"] = "Tool";

            db.Rows[0]["Value"] = "";
            db.Rows[0]["Value"] = "";
            db.Rows[0]["Value"] = "";
            db.Rows[0]["Value"] = "";
            db.Rows[0]["Value"] = "";
            db.Rows[0]["Value"] = "";

            return db;
        }
        #endregion

        #region CreateContextGroupTable
        public static List<string> GetStructGetR2RContextColumn(UIServiceFun.structGetR2RContext structData, int index)
        {
            List<string> strList = new List<string>();
            switch (index)
            {
                case 0:
                    return structData.strListData_Context1;
                case 1:
                    return structData.strListData_Context2;
                case 2:
                    return structData.strListData_Context3;
                case 3:
                    return structData.strListData_Context4;
                case 4:
                    return structData.strListData_Context5;
                case 5:
                    return structData.strListData_Context6;
                case 6:
                    return structData.strListData_Context7;
                case 7:
                    return structData.strListData_Context8;
                case 8:
                    return structData.strListData_Context9;
                case 9:
                    return structData.strListData_Context10;
                case 10:
                    return structData.strListData_Context11;
                case 11:
                    return structData.strListData_Context12;
                case 12:
                    return structData.strListData_Context13;
                case 13:
                    return structData.strListData_Context14;
                case 14:
                    return structData.strListData_Context15;
                case 15:
                    return structData.strListData_Context16;
                case 16:
                    return structData.strListData_Context17;
                case 17:
                    return structData.strListData_Context18;
                case 18:
                    return structData.strListData_Context19;
                case 19:
                    return structData.strListData_Context20;
                default:
                    return strList;
            }
        }
        public static DataTable CreateContextGroupTable(UIServiceFun.structGetR2RContext structData)
        {
            string strColumnName;
            List<string> strListColumnValue = new List<string>();

            DataTable db = new DataTable("TabContextGroup");
            if (structData.strListContexts.Count > 0)
            {
                for (int i = 0; i < structData.strListContexts.Count; i++)
                {
                    strColumnName = structData.strListContexts[i];
                    db.Columns.Add(strColumnName, Type.GetType("System.String"));
                    strListColumnValue = GetStructGetR2RContextColumn(structData, i);
                    for (int m = 0; m < strListColumnValue.Count; m++)
                    {
                        if (db.Rows.Count < m + 1)
                        {
                            db.Rows.Add();
                        }
                        db.Rows[m][strColumnName] = strListColumnValue[m];
                    }
                }
            }
            return db;
        }
        #endregion

        #region test
        public static DataTable CreateContextGroupTable(List<string> strList)
        {
            DataTable dataTable = new DataTable("TabContextGroup");
            if (strList.Count > 0)
            {
                foreach (var str in strList)
                {
                    dataTable.Columns.Add(str, Type.GetType("System.String"));
                }
            }
            dataTable.Rows.Add(new object[] { "1", "a", "b", "b1" });
            dataTable.Rows.Add(new object[] { "1", "a", "b", "b2" });
            dataTable.Rows.Add(new object[] { "1", "a", "c", "c1" });
            dataTable.Rows.Add(new object[] { "1", "a", "c", "c2" });
            dataTable.Rows.Add(new object[] { "1", "a", "d", "d" });


            //var rows = dataTable.AsEnumerable()
            //    .Where(p => p.Field<string>("ReticleId") == "b")
            //    .Select(p => new
            //    {
            //        Product = p.Field<string>("Product"),
            //        ToolId = p.Field<string>("ToolId"),
            //        ReticleId = p.Field<string>("ReticleId"),
            //        Recipe = p.Field<string>("Recipe")
            //    });
            //foreach (var row in rows)
            //{
            //    //MessageBox.Show(row.Recipe);
            //}

            return dataTable;
        }

        public static DataTable GetLineChartDataTest()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Label Column", Type.GetType("System.String"));
            table.Columns.Add("Value Column1", Type.GetType("System.Double"));
            table.Columns.Add("Value Column2", Type.GetType("System.Double"));
            table.Columns.Add("Value Column3", Type.GetType("System.Double"));
            table.Columns.Add("Value Column4", Type.GetType("System.Double"));
            table.Rows.Add(new object[] { "Max", 6.0, 6.0, 6.0, 6.0 });
            table.Rows.Add(new object[] { "Median", 3.0, 3.0, 3.0, 3.0 });
            table.Rows.Add(new object[] { "Min", 1.0, 1.0, 1.0, 1.0 });
            table.Rows.Add(new object[] { "Point A", 4.0, 2.0, 1.5, 3.0 });
            table.Rows.Add(new object[] { "Point B", 5.0, 3.0, 2.8, 3.7 });
            table.Rows.Add(new object[] { "Point C", 4.0, 3.0, 3.6, 2.9 });
            return table;
        }

        public static DataTable GetColumnChartDataTest()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Label Column", Type.GetType("System.String"));
            table.Columns.Add("Value Max", Type.GetType("System.Double"));
            table.Columns.Add("Value Avg", Type.GetType("System.Double"));
            table.Columns.Add("Value Min", Type.GetType("System.Double"));
            table.Columns.Add("Value Serice1", Type.GetType("System.Double"));
            table.Columns.Add("Value Serice2", Type.GetType("System.Double"));
            table.Rows.Add(new object[] { "", 6.0, 3.0, 1.0, 5.0, 4.0 });
            //table.Rows.Add(new object[] { "", 6.0, 3.0, 1.0, 3.0, 3.8 });
            //table.Rows.Add(new object[] { "", 6.0, 3.0, 1.0, 2.0, 5.3 });
            //table.Rows.Add(new object[] { "", 6.0, 3.0, 1.0, 1.7, 2.0 });
            return table;
        }

        public static DataTable CreateDataTable()
        {
            DataTable dataTable = new DataTable("TableTest");

            // Create and add a CustomerID column 
            DataColumn colContextGroup = new DataColumn("Context Group", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colContextGroup);
            DataColumn colProduct = new DataColumn("Product", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colProduct);
            DataColumn colFlow = new DataColumn("Flow", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colFlow);
            DataColumn colStep = new DataColumn("Step", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colStep);
            DataColumn colTool = new DataColumn("Tool", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colTool);
            DataColumn colRecipe = new DataColumn("Recipe", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colRecipe);
            DataColumn colLastRun = new DataColumn("Last Run", System.Type.GetType("System.String"));
            dataTable.Columns.Add(colLastRun);

            //// Add CustomerID column to key array and bind to DataTable 
            //DataColumn[] Keys = new DataColumn[1];
            //Keys[0] = colContextGroup;
            //dataTable.PrimaryKey = Keys;

            //// Create and add a CustomerName column 
            //colContextGroup = new DataColumn("CustomerName", System.Type.GetType("System.String"));
            //colContextGroup.MaxLength = 50;
            //dataTable.Columns.Add(colContextGroup);

            //// Create and add a LastOrderDate column 
            //colContextGroup = new DataColumn("LastOrderDate", System.Type.GetType("System.DateTime"));
            //dataTable.Columns.Add(colContextGroup);

            // Add a row 
            DataRow row = dataTable.NewRow();
            row["Context Group"] = "G1";
            row["Product"] = "11";
            row["Flow"] = "21";
            row["Step"] = "31";
            row["Tool"] = "41";
            row["Recipe"] = "51";
            row["Last Run"] = "61";
            dataTable.Rows.Add(row);

            // Add another row 
            row = dataTable.NewRow();
            row["Context Group"] = "G2";
            row["Product"] = "12";
            row["Flow"] = "22";
            row["Step"] = "32";
            row["Tool"] = "42";
            row["Recipe"] = "52";
            row["Last Run"] = "62";
            dataTable.Rows.Add(row);

            // Bind the table to the grid 
            //this.ultraGrid1.DataSource = dataTable;

            return dataTable;
        }
        #endregion
    }
}
