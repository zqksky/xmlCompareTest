﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ControlUI.Comman
{
    class BaseFun
    {
        public static List<List<double>> GetItemValues(List<string> strList)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> strListResult = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strList);
            strListResult.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = 0; n < strListTemp[0].Count; n++)
                {
                    List<double> strListValue = new List<double>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        strListValue.Add(double.Parse(strListTemp[i][n]));
                    }
                    strListResult.Add(strListValue);
                }
            }
            return strListResult;
        }

        public static List<List<double>> GetItemValues(List<string> strList, int index, int count)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> strListResult = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strList);
            strListResult.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = index; n < index + count; n++)
                {
                    List<double> strListValue = new List<double>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        strListValue.Add(double.Parse(strListTemp[i][n]));
                    }
                    strListResult.Add(strListValue);
                }
            }
            return strListResult;
        }

        //public static List<List<string>> GetItemValues(List<string> strList,int index,int count)
        //{
        //    List<List<string>> strListTemp = new List<List<string>>();
        //    List<List<string>> strListResult = new List<List<string>>();

        //    strListTemp = GetItemValuesTemp(strList);
        //    strListResult.Clear();
        //    if (strListTemp.Count > 0)
        //    {
        //        for (int n= 0; n < count; n++)
        //        {
        //            List<string> strListValue = new List<string>();
        //            for (int i = index; i < strListTemp.Count; i++)
        //            {
        //                strListValue.Add(strListTemp[i][n]);
        //            }
        //            strListResult.Add(strListValue);
        //        }
        //    }
        //    return strListResult;
        //}

        public static List<List<string>> GetItemValuesTemp(List<string> strList)
        {
            List<string> strListTemp = new List<string>();
            List<string> strListFormat = new List<string>();
            List<List<string>> strListResult = new List<List<string>>();
            if (strList.Count > 0)
            {
                strListFormat = FormatItemValues(strList);
                foreach (var str in strListFormat)
                {
                    strListTemp = SplitString(str);
                    strListResult.Add(strListTemp);
                }
            }
            return strListResult;
        }

        public static List<string> FormatItemValues(List<string> strList)
        {
            List<string> strListResult = new List<string>();
            if (strList.Count > 0)
            {
                string str;
                for (int i = 0; i < strList.Count; i++)
                {
                    str = strList[i].TrimEnd(']');
                    str = str.TrimStart('[');
                    strListResult.Add(str.Trim());
                }
            }
            return strListResult;
        }

        public static List<string> SplitString(string str)
        {
            List<string> strList = new List<string>();
            if (str != "")
            {
                string[] strArray = str.Split(new char[] { ' ' });
                strList = new List<string>(strArray);
            }
            return strList;
        }

        public static List<string> MergeKeyValue(List<string> strListKey, List<string> strListValue)
        {
            List<string> strList = new List<string>();
            if (strListKey.Count > 0 && strListValue.Count > 0 && strListKey.Count == strListValue.Count)
            {
                for (int i = 0; i < strListKey.Count; i++)
                {
                    strList.Add(strListKey[i] + ";" + strListValue[i]);
                }
            }
            return strList;
        }

        public static List<string> GetChangeValue(List<string> strListOld, List<string> strListNew)
        {
            if (strListOld.Count > 0 && strListNew.Count > 0 && strListOld.Count == strListNew.Count)
            {
                foreach (var str in strListOld)
                {
                    if (strListNew.Contains(str))
                    {
                        strListNew.Remove(str);
                    }
                }
            }
            return strListNew;
        }

        public static void SplitKeyValue(List<string> strList, ref List<string> strListKey, ref List<string> strListValue)
        {
            if (strList.Count > 0)
            {
                for (int i = 0; i < strList.Count; i++)
                {
                    string str = strList[i];
                    strListKey.Add(str.Substring(0, str.IndexOf(";")));
                    strListValue.Add(str.Substring(str.IndexOf(";") + 1));
                }
            }
        }

        public static Hashtable MergeKeyValueToHashtable(List<string> strListKey, List<string> strListValue)
        {
            Hashtable ht = new Hashtable();
            if (strListKey.Count > 0 && strListValue.Count > 0 && strListKey.Count == strListValue.Count)
            {
                for (int i = 0; i < strListKey.Count; i++)
                {
                    ht.Add(strListKey[i], strListValue[i]);
                }
            }
            return ht;
        }

        public static Hashtable GetChangeValue(Hashtable htOld, Hashtable htNew)
        {
            try
            {
                if (htOld.Count > 0 && htNew.Count > 0 && htOld.Count == htNew.Count)
                {
                    foreach (DictionaryEntry de in htOld)
                    {
                        if (htNew.ContainsKey(de.Key))
                        {
                            if (de.Value.ToString() == htNew[de.Key].ToString())
                            {
                                htNew.Remove(de.Key);
                            }
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
            return htNew;
        }

        public static void SplitHashTableToKeyValue(Hashtable ht, ref List<string> strListKey, ref List<string> strListValue)
        {
            var length = ht.Count;
            if (length > 0)
            {
                string[] strArrayKey = new string[length];
                string[] strArrayValue = new string[length];

                ht.Keys.CopyTo(strArrayKey, 0);
                ht.Values.CopyTo(strArrayValue, 0);

                strListKey = new List<string>(strArrayKey);
                strListValue = new List<string>(strArrayValue);
            }
        }

        #region
        /// <summary>
        /// 移除前缀字符串
        /// </summary>
        /// <param name="val">原字符串</param>
        /// <param name="str">要移除的前缀字符串</param>
        /// <returns></returns>
        private string GetRemovePrefixString(string val, string str)
        {
            string strRegex = @"^(" + str + ")";
            return Regex.Replace(val, strRegex, "");
        }
        /// <summary>
        /// 移除后缀字符串
        /// </summary>
        /// <param name="val">原字符串</param>
        /// <param name="str">要移除的后缀字符串</param>
        /// <returns></returns>
        private string GetRemoveSuffixString(string val, string str)
        {
            string strRegex = @"(" + str + ")" + "$";
            return Regex.Replace(val, strRegex, "");
        }
        #endregion
    }
}
