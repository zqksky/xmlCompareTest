﻿using Infragistics.UltraChart.Core.Layers;
using Infragistics.UltraChart.Resources.Appearance;
using Infragistics.UltraChart.Shared.Styles;
using Infragistics.Win.UltraWinChart;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlUI.Comman
{
    class UltraChartHelp
    {
        #region
        public static UltraChart CreateColumnChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.ColumnChart;

            chart.Axis.Y.RangeMin = 0;
            chart.Axis.Y.RangeMax = 1;
            chart.Axis.Y.Extent = 1;

            //chart.Data.SwapRowsAndColumns = true;//行列交换

            //dListValue = new List<double>() { 6.0, 3.0, 5.0, 2.0 };
            NumericSeries series = new NumericSeries();
            if (dListValue.Count > 0)
            {
                series = GetNumericSeries(dListValue, strListChartColumn);
                series.DataBind();
                chart.Series.Add(series);
            }

            chart.Data.DataBind();
            SetChartTitle(chart, strChartTitle);

            return chart;
        }

        public static UltraChart CreateLineChart(DataTable dt, string strChartTitle)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.LineChart;
            //chart.ChartType = ChartType.ColumnChart;

            chart.Data.DataSource = dt;
            //chart.Data.DataSource = CreateDataTableTest();

            chart.Data.DataBind();
            SetChartTitle(chart, strChartTitle);

            return chart;
        }

        public static UltraChart CreateLineChart(DataTable dt, string strColumnName, string strColumnValueName, string strChartTitle)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.LineChart;
            //chart.ChartType = ChartType.ColumnChart;

            NumericSeries seriesLable = new NumericSeries();
            seriesLable = GetNumericSeries(dt, strColumnName, strColumnValueName);
            seriesLable.DataBind();
            chart.Series.Add(seriesLable);

            chart.Data.DataBind();
            SetChartTitle(chart, strChartTitle);

            return chart;
        }

        public static UltraChart CreateLineChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.LineChart;

            NumericSeries series = new NumericSeries();
            if (dListValue.Count > 0)
            {
                series = GetNumericSeries(dListValue, strListChartColumn);
                series.DataBind();
                chart.Series.Add(series);
                chart.Axis.Y.Labels.ItemFormatString = "<DATA_VALUE:0.0000>";
                //chart.Axis.Y.Labels.ItemFormatString = "<DATA_VALUE>";
                //chart.Axis.Y.Labels.ItemFormatString = GetItemFormat(dList[0]);
                //chart.Axis.Y.Labels.ItemFormat = AxisItemLabelFormat.Custom;
            }

            chart.Data.DataBind();

            chart.ColorModel.CustomPalette = new Color[] { Color.Green, Color.Blue, Color.Gold, Color.Red, Color.Gray, Color.DarkRed, Color.LightBlue, Color.LightGray };

            //List<Color> colorList = new List<Color>() { Color.Red, Color.Yellow };
            //chart.ColorModel.CustomPalette = colorList.ToArray();//线的颜色
            chart.ColorModel.AlphaLevel = ((byte)(255));
            chart.ColorModel.ModelStyle = Infragistics.UltraChart.Shared.Styles.ColorModels.CustomLinear;


            SetChartTitle(chart, strChartTitle);

            return chart;
        }

        private static void SetChartTitle(UltraChart chart,string strChartTitle)
        {
            chart.Tooltips.FormatString = "<DATA_VALUE>";//鼠标悬停提示数据格式！
            chart.Tooltips.TooltipControl = null;
            chart.Tooltips.UseControl = false;
            chart.TitleTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            chart.TitleTop.FontColor = System.Drawing.Color.Red;
            chart.TitleTop.HorizontalAlign = System.Drawing.StringAlignment.Near;
            //chart.TitleTop.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.TitleTop.Text = strChartTitle;
        }

        private static void SetChartArea(UltraChart chart)
        {
            ChartArea chartArea = new ChartArea();
            chartArea.BoundsMeasureType = MeasureType.Percentage;
            chartArea.Bounds = new Rectangle(0, 0, 100, 80);
            chartArea.Border.Thickness = 0;
            chart.CompositeChart.ChartAreas.Add(chartArea);
        }

        private static NumericSeries GetNumericSeries(List<double> dListValue)
        {
            NumericSeries series = new NumericSeries();

            //series.Label = "Series A";

            for (int i = 0; i < dListValue.Count; i++)
            {
                series.Points.Add(new NumericDataPoint(dListValue[i], "", false));
            }

            return series;
        }

        private static NumericSeries GetNumericSeries(List<double> dListValue, List<string> strListColumnName)
        {
            NumericSeries series = new NumericSeries();

            //series.Label = "Series A";

            for (int i = 0; i < dListValue.Count; i++)
            {
                series.Points.Add(new NumericDataPoint(dListValue[i], strListColumnName[i], false));
            }

            return series;
        }

        private static NumericSeries GetNumericSeries(DataTable dt, string strColumnName,string strColumnValueName)
        {
            NumericSeries seriesLine = new NumericSeries();
            
            //seriesLine.Data.DataSource = dt;
            seriesLine.Data.DataSource = CreateDataTableTest();

            //轴线上显示的标签信息
            seriesLine.Data.LabelColumn = strColumnName;
            //seriesLine.Data.LabelColumn = "Label Column";

            //图表上要显示的值
            seriesLine.Data.ValueColumn = strColumnValueName;
            //seriesLine.Data.ValueColumn = "Value Column1";

            //seriesLine.DataBind();

            return seriesLine;
        }

        private static DataTable CreateDataTableTest()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Label Column", Type.GetType("System.String"));
            table.Columns.Add("Value Column1", Type.GetType("System.Double"));
            table.Columns.Add("Value Column2", Type.GetType("System.Double"));
            table.Columns.Add("Value Column3", Type.GetType("System.Double"));
            table.Columns.Add("Value Column4", Type.GetType("System.Double"));
            table.Rows.Add(new object[] { "Max", 6.0, 6.0, 6.0, 6.0 });
            table.Rows.Add(new object[] { "Median", 3.0, 3.0, 3.0, 3.0 });
            table.Rows.Add(new object[] { "Min", 1.0, 1.0, 1.0, 1.0 });
            table.Rows.Add(new object[] { "Point A", 4.0, 2.0, 1.5, 3.0 });
            table.Rows.Add(new object[] { "Point B", 5.0, 3.0, 2.8, 3.7 });
            table.Rows.Add(new object[] { "Point C", 4.0, 3.0, 3.6, 2.9 });
            return table;
        }
        #endregion

        #region test
        public static void ChartToImg(UltraChart chart,string strSavePath)
        {

            //一定要先绑定UltraChart，如果先绑定，然后有点击图片导出，没有用的

            chart.SaveTo(strSavePath, System.Drawing.Imaging.ImageFormat.Jpeg);//这个是保存为图片的方法

            //System.IO.FileInfo file = new System.IO.FileInfo(strFileFullPath);

            //Response.Clear();

            //Response.AddHeader("Content-Disposition", "attachment; filename=" + strFileName);

            //Response.ContentType = "application/x-msdownload";

            //Response.WriteFile(strFileFullPath);

            //Response.Flush();

            //file.Delete();

            //Response.End();
        }

        public static void test()
        {
            UltraChart chart = new UltraChart();
            chart.ChartType = ChartType.LineChart;

            chart.TitleBottom.Visible = true;
            chart.TitleBottom.Text = "性能趋势图";
            chart.TitleBottom.HorizontalAlign= System.Drawing.StringAlignment.Center;
            chart.Legend.SpanPercentage = 15;
            chart.Legend.Visible = true;

            //创建绘图区域,表明ChartArea绘图区域占整个UltraChart的比例：宽100 %，高80 %，位置呢从左顶点(0, 0)起
            ChartArea myChartArea = new ChartArea();
            myChartArea.BoundsMeasureType = MeasureType.Percentage;
            myChartArea.Bounds = new Rectangle(0, 0, 100, 80);
            myChartArea.Border.Thickness = 0;

            ChartTextAppearance text = new ChartTextAppearance();
            text.Column = -2;
            text.Row = -2;
            text.PositionFromRadius = 80;
            text.VerticalAlign = System.Drawing.StringAlignment.Far;
            text.ItemFormatString = "<DATA_VALUE:00.00000000>";
            text.Visible = true;
            chart.LineChart.ChartText.Add(text);

            ////创建X轴线,此处Extent决定着X轴线偏离绘图区域边界的大小，恰当设置轴线的Extent值可以调整图表区域的大小
            //AxisItem xAxis = new AxisItem();
            //xAxis.axisNumber = AxisNumber.X_Axis;
            //xAxis.Labels.Orientation = TextOrientation.VerticalLeftFacing;
            //xAxis.DataType = AxisDataType.String;
            //xAxis.SetLabelAxisType = SetLabelAxisType.GroupBySeries;
            //xAxis.Labels.ItemFormatString = "<ITEM_LABEL>";
            //xAxis.Extent = 10;
            //myChartArea.Axes.Add(xAxis);

            ////创建Y轴,Composite的ColumnChart和LineChart都需要
            //AxisItem yAxis = new AxisItem();
            //yAxis.OrientationType = AxisNumber.Y_Axis;
            //yAxis.DataType = AxisDataType.Numeric;
            //yAxis.Labels.ItemFormat = AxisItemLabelFormat.DataValue;
            //yAxis.RangeType = AxisRangeType.Custom;
            //yAxis.RangeMin = 0;
            //yAxis.RangeMax = 20;
            //yAxis.Extent = 20;
            //myChartArea.Axes.Add(xAxisLine);
            ////创建X2轴, Composite的LineChart需要
            //AxisItem xAxisLine = new AxisItem();
            //xAxisLine.OrientationType = AxisNumber.X2_Axis;
            //xAxisLine.DataType = AxisDataType.String;
            //xAxisLine.SetLabelAxisType = Infragistics.UltraChart.Core.Layers.SetLabelAxisType.ContinuousData;
            //xAxisLine.Labels.ItemFormat = AxisItemLabelFormat.ItemLabel;
            //xAxisLine.Extent = 20;
            //myChartArea.Axes.Add(yAxis);

            //chart.Axis.Y.Labels.SeriesLabels.FormatString = DateTime.Now.ToLongTimeString();
            //chart.Axis.X.Labels.SeriesLabels.FormatString = DateTime.Now.ToLongTimeString();


            chart.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                | System.Windows.Forms.AnchorStyles.Right)));

            chart.Axis.X.Extent = 45;
            chart.Axis.X.Labels.Flip = false;
            chart.Axis.X.Labels.HorizontalAlign = System.Drawing.StringAlignment.Near;
            chart.Axis.X.Labels.Orientation = Infragistics.UltraChart.Shared.Styles.TextOrientation.Horizontal;
            chart.Axis.X.Labels.OrientationAngle = 0;
            chart.Axis.X.Labels.SeriesLabels.Flip = false;
            chart.Axis.X.Labels.SeriesLabels.FormatString = DateTime.Now.ToLongTimeString();
            chart.Axis.X.Labels.SeriesLabels.HorizontalAlign = System.Drawing.StringAlignment.Center;
            chart.Axis.X.Labels.SeriesLabels.Orientation = Infragistics.UltraChart.Shared.Styles.TextOrientation.VerticalLeftFacing;
            chart.Axis.X.Labels.SeriesLabels.OrientationAngle = 0;
            chart.Axis.X.Labels.SeriesLabels.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.Axis.X.Labels.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.Axis.X.LineThickness = 1;
            chart.Axis.X.MajorGridLines.AlphaLevel = ((byte)(255));
            chart.Axis.X.MajorGridLines.Color = System.Drawing.Color.Gainsboro;
            chart.Axis.X.MajorGridLines.DrawStyle = Infragistics.UltraChart.Shared.Styles.LineDrawStyle.Dot;
            chart.Axis.X.MajorGridLines.Thickness = 1;
            chart.Axis.X.MajorGridLines.Visible = true;
            chart.Axis.X.MinorGridLines.AlphaLevel = ((byte)(255));
            chart.Axis.X.MinorGridLines.Color = System.Drawing.Color.LightGray;
            chart.Axis.X.MinorGridLines.DrawStyle = Infragistics.UltraChart.Shared.Styles.LineDrawStyle.Dot;
            chart.Axis.X.MinorGridLines.Thickness = 1;
            chart.Axis.X.MinorGridLines.Visible = false;
            chart.Axis.X.ScrollScale.Height = 10;
            chart.Axis.X.ScrollScale.Visible = false;
            chart.Axis.X.ScrollScale.Width = 15;
            chart.Axis.X.TickmarkInterval = 0;
            chart.Axis.X.Visible = true;

            chart.Axis.Y.Extent = 30;
            chart.Axis.Y.Labels.Flip = false;
            chart.Axis.Y.Labels.HorizontalAlign = System.Drawing.StringAlignment.Far;
            chart.Axis.Y.Labels.ItemFormatString = "<DATA_VALUE:00.##>";
            chart.Axis.Y.Labels.Orientation = Infragistics.UltraChart.Shared.Styles.TextOrientation.Horizontal;
            chart.Axis.Y.Labels.OrientationAngle = 0;
            chart.Axis.Y.Labels.SeriesLabels.Flip = false;
            chart.Axis.Y.Labels.SeriesLabels.FormatString = "";
            chart.Axis.Y.Labels.SeriesLabels.HorizontalAlign = System.Drawing.StringAlignment.Far;
            chart.Axis.Y.Labels.SeriesLabels.Orientation = Infragistics.UltraChart.Shared.Styles.TextOrientation.Horizontal;
            chart.Axis.Y.Labels.SeriesLabels.OrientationAngle = 0;
            chart.Axis.Y.Labels.SeriesLabels.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.Axis.Y.Labels.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.Axis.Y.LineThickness = 1;
            chart.Axis.Y.RangeMax = 1000;
            chart.Axis.Y.RangeType = Infragistics.UltraChart.Shared.Styles.AxisRangeType.Automatic;//Y轴最大值设置为自动
            chart.Axis.Y.MajorGridLines.AlphaLevel = ((byte)(255));
            chart.Axis.Y.MajorGridLines.Color = System.Drawing.Color.Gainsboro;
            chart.Axis.Y.MajorGridLines.DrawStyle = Infragistics.UltraChart.Shared.Styles.LineDrawStyle.Dot;
            chart.Axis.Y.MajorGridLines.Thickness = 1;
            chart.Axis.Y.MajorGridLines.Visible = true;
            chart.Axis.Y.MinorGridLines.AlphaLevel = ((byte)(255));
            chart.Axis.Y.MinorGridLines.Color = System.Drawing.Color.LightGray;
            chart.Axis.Y.MinorGridLines.DrawStyle = Infragistics.UltraChart.Shared.Styles.LineDrawStyle.Dot;
            chart.Axis.Y.MinorGridLines.Thickness = 1;
            chart.Axis.Y.MinorGridLines.Visible = true;
            chart.Axis.Y.ScrollScale.Height = 10;
            chart.Axis.Y.ScrollScale.Visible = false;
            chart.Axis.Y.ScrollScale.Width = 15;
            chart.Axis.Y.TickmarkInterval = 0;
            chart.Axis.Y.Visible = true;
            chart.Border.Color = System.Drawing.Color.Silver;
            chart.Border.CornerRadius = 5;
            chart.Border.Raised = true;

            chart.ColorModel.AlphaLevel = ((byte)(150));
            chart.ColorModel.ColorBegin = System.Drawing.Color.LimeGreen;
            chart.ColorModel.ColorEnd = System.Drawing.Color.Gold;
            chart.ColorModel.ModelStyle = Infragistics.UltraChart.Shared.Styles.ColorModels.LinearRange;
            chart.ColorModel.Scaling = Infragistics.UltraChart.Shared.Styles.ColorScaling.Increasing;

            chart.Data.EmptyStyle.LineStyle.DrawStyle = Infragistics.UltraChart.Shared.Styles.LineDrawStyle.Dash;
            chart.Data.EmptyStyle.LineStyle.EndStyle = Infragistics.UltraChart.Shared.Styles.LineCapStyle.NoAnchor;
            chart.Data.EmptyStyle.LineStyle.MidPointAnchors = false;
            chart.Data.EmptyStyle.LineStyle.StartStyle = Infragistics.UltraChart.Shared.Styles.LineCapStyle.NoAnchor;
            chart.Data.MaxValue = 500;
            chart.Data.MinValue = 0;
            chart.Data.SwapRowsAndColumns = true;

            chart.Legend.BackgroundColor = System.Drawing.Color.LemonChiffon;
            chart.Legend.BorderColor = System.Drawing.Color.DimGray;
            chart.Legend.DataAssociation = Infragistics.UltraChart.Shared.Styles.ChartTypeData.ColumnData;
            chart.Legend.Location = Infragistics.UltraChart.Shared.Styles.LegendLocation.Bottom;
            chart.Legend.SpanPercentage = 5;
            chart.Legend.Visible = true;

            chart.TitleBottom.Visible = false;
            chart.TitleTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            chart.TitleTop.FontColor = System.Drawing.Color.Red;
            chart.TitleTop.VerticalAlign = System.Drawing.StringAlignment.Center;
            chart.TitleTop.Text = "标题";

            chart.Tooltips.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            chart.Tooltips.TooltipControl = null;
            chart.Tooltips.UseControl = false;

            chart.Tooltips.FormatString = "<DATA_VALUE>"; //鼠标悬停有提示，非常精美！

            chart.ForeColor = System.Drawing.SystemColors.ControlText;
            chart.TabIndex = 10;
            chart.Name = "name";
            chart.Size = new System.Drawing.Size(400, 295);//图表的大小设置
            chart.Location = new System.Drawing.Point(5, 300);//设置画图表的位置
        }
        #endregion
    }
}
