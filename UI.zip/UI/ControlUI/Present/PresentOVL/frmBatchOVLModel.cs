﻿using ControlUI.Comman;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmBatchOVLModel : Form
    {
        public frmBatchOVLModel()
        {
            InitializeComponent();
        }

        public frmBatchOVLModel(string strServiceName, UIServiceFun.structPH_OVL_Batch_GetOVLModel structDataOVLModel)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            structData = structDataOVLModel;
            if (structData.strListProducts.Count > 0)
            {
                bListIsCPEModelOn = new List<bool>(structData.bListIsCPEModelOn);
                strListOVLModels = new List<string>(structData.strListOVLModels);
                strListProducts = new List<string>(structData.strListProducts);
                strListLayers = new List<string>(structData.strListLayers);
                strListTools = new List<string>(structData.strListTools);
                strListR2RMode = new List<string>(structData.strListR2RMode);
            }
        }

        #region Param
        string strServiceAddres;
        public List<bool> bListIsCPEModelOn = new List<bool>();
        public List<string> strListOVLModels = new List<string>();
        public List<string> strListProducts = new List<string>();
        public List<string> strListLayers = new List<string>();
        public List<string> strListTools = new List<string>();
        public List<string> strListR2RMode = new List<string>();

        List<int> iRowChangeIndex = new List<int>();
        public List<bool> bListIsCPEModelOnChange = new List<bool>();
        public List<string> strListOVLModelsChange = new List<string>();
        public List<string> strListProductsChange = new List<string>();
        public List<string> strListLayersChange = new List<string>();
        public List<string> strListToolsChange = new List<string>();
        public List<string> strListR2RModeChange = new List<string>();
        UIServiceFun.structPH_OVL_Batch_GetOVLModel structData = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
        #endregion

        private void ClearList()
        {
            iRowChangeIndex.Clear();
            bListIsCPEModelOnChange.Clear();
            strListOVLModelsChange.Clear();
            strListProductsChange.Clear();
            strListLayersChange.Clear();
            strListToolsChange.Clear();
            strListR2RModeChange.Clear();
        }

        private void InitGrid(UltraGrid ctlGrid, DataTable tb)
        {
            ctlGrid.DataSource = tb;

            //禁止编辑
            if (ctlGrid.DisplayLayout.Bands[0].Columns.Count > 3)
            {
                ctlGrid.DisplayLayout.Bands[0].Columns[0].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[1].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[2].CellActivation = Activation.NoEdit;
            }

            InitCPEModelOn();
            InitR2RModel();
            InitOVLModels();
            //InitValueList(strListOVLModels, "OVLModels", 3);
            //InitValueList(strListR2RMode, "R2RModel", 5);


            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //ctlGrid.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //ctlGrid.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //ctlGrid.DisplayLayout.Override.ColumnAutoSizeMode = ColumnAutoSizeMode.VisibleRows;
            //ctlGrid.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //ctlGrid.Rows[0].PerformAutoSize();
            //ctlGrid.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
        }

        private void InitCPEModelOn()
        {
            //this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[4].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.CheckBox;
            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[4].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            if (this.grdBatchOVLMode.DisplayLayout.ValueLists.Exists("CPEModelOn"))
            {
                this.grdBatchOVLMode.DisplayLayout.ValueLists.Remove("CPEModelOn");
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOVLMode.DisplayLayout.ValueLists.Add("CPEModelOn");
            valueLists.ValueListItems.Add(true);
            valueLists.ValueListItems.Add(false);
            #region
            //foreach (var str in bListIsCPEModelOn)
            //{
            //    valueLists.ValueListItems.Add(str);
            //}
            //if (!valueLists.ValueListItems.Contains(true))
            //{
            //    valueLists.ValueListItems.Add("True");
            //}
            //if (!valueLists.ValueListItems.Contains(false))
            //{
            //    valueLists.ValueListItems.Add("False");
            //}
            #endregion

            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns["CPE_MODEL_ON"].ValueList = valueLists;
        }

        private void InitR2RModel()
        {
            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[5].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            if (this.grdBatchOVLMode.DisplayLayout.ValueLists.Exists("R2RModel"))
            {
                this.grdBatchOVLMode.DisplayLayout.ValueLists.Remove("R2RModel");
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOVLMode.DisplayLayout.ValueLists.Add("R2RModel");
            valueLists.ValueListItems.Add("Fixed");
            valueLists.ValueListItems.Add("Active");
            #region
            //foreach (var str in strListR2RMode)
            //{
            //    valueLists.ValueListItems.Add(str);
            //}
            //if (!valueLists.ValueListItems.Contains("Fixed"))
            //{
            //    valueLists.ValueListItems.Add("Fixed");
            //}
            //if (!valueLists.ValueListItems.Contains("Active"))
            //{
            //    valueLists.ValueListItems.Add("Active");
            //}
            #endregion

            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns["R2R_MODEL"].ValueList = valueLists;
        }

        private void InitOVLModels()
        {
            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[3].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            if (this.grdBatchOVLMode.DisplayLayout.ValueLists.Exists("OVLModels"))
            {
                this.grdBatchOVLMode.DisplayLayout.ValueLists.Remove("OVLModels");
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOVLMode.DisplayLayout.ValueLists.Add("OVLModels");
            valueLists.ValueListItems.Add("LINEAR");
            valueLists.ValueListItems.Add("HOPC");
            valueLists.ValueListItems.Add("IHOPC");
            //valueLists.ValueListItems.Add("CPE");
            #region
            //foreach (var str in strListOVLModels)
            //{
            //    valueLists.ValueListItems.Add(str);
            //}
            //if (!valueLists.ValueListItems.Contains("LINEAR"))
            //{
            //    valueLists.ValueListItems.Add("LINEAR");
            //}
            //if (!valueLists.ValueListItems.Contains("HOPC"))
            //{
            //    valueLists.ValueListItems.Add("HOPC");
            //}
            //if (!valueLists.ValueListItems.Contains("IHOPC"))
            //{
            //    valueLists.ValueListItems.Add("IHOPC");
            //}
            //if (!valueLists.ValueListItems.Contains("CPE"))
            //{
            //    valueLists.ValueListItems.Add("CPE");
            //}
            #endregion

            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns["OVL_MODELS"].ValueList = valueLists;
        }
        private void InitValueList(List<string> strListValue, string strName, int colIndex)
        {
            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[colIndex].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;

            if (this.grdBatchOVLMode.DisplayLayout.ValueLists.Exists(strName))
            {
                this.grdBatchOVLMode.DisplayLayout.ValueLists.Remove(strName);
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOVLMode.DisplayLayout.ValueLists.Add(strName);
            foreach (var str in strListValue)
            {
                valueLists.ValueListItems.Add(str);
            }

            this.grdBatchOVLMode.DisplayLayout.Bands[0].Columns[colIndex].ValueList = valueLists;
        }

        private void frmBatchOVLMode_Load(object sender, EventArgs e)
        {
            InitGrid(grdBatchOVLMode, DataTableHelp.CreateBatchOVLModelTable(structData));
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            bool bSuccess;
            try
            {
                #region PH_OVL_Batch_UpdateOVLModel
                if (strListProductsChange.Count > 0)
                {
                    UIServiceFun.structPH_OVL_Batch_GetOVLModel structDataOVLModel = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
                    structDataOVLModel.strListProducts = new List<string>(strListProductsChange);
                    structDataOVLModel.strListLayers = new List<string>(strListLayersChange);
                    structDataOVLModel.strListTools = new List<string>(strListToolsChange);
                    structDataOVLModel.strListOVLModels = new List<string>(strListOVLModelsChange);
                    structDataOVLModel.bListIsCPEModelOn = new List<bool>(bListIsCPEModelOnChange);
                    structDataOVLModel.strListR2RMode = new List<string>(strListR2RModeChange);

                    bSuccess = UIServiceFun.R2R_UI_PH_OVL_Batch_UpdateOVLModel(strServiceAddres, structDataOVLModel);
                    if (bSuccess)
                    {
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Set Failed!");
                    }
                }
                else
                {
                }
                #endregion

                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grdBatchOVLMode_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }

        private bool IsCellValueChange(string strOVLMode, string strCPEModelOn, string strR2RMode, int rowIndex, int colIndex)
        {
            bool flagOVLMode = false;
            bool flagCPEModelOn = false;
            bool flagR2RMode = false;
            switch (colIndex)
            {
                case 3:
                    flagOVLMode = strOVLMode != strListOVLModels[rowIndex] ? true : false;
                    flagCPEModelOn = strCPEModelOn != bListIsCPEModelOn[rowIndex].ToString() ? true : false;
                    flagR2RMode = strR2RMode != bListIsCPEModelOn[rowIndex].ToString() ? true : false;
                    break;
                case 4:
                    flagOVLMode = strOVLMode != strListOVLModels[rowIndex] ? true : false;
                    flagCPEModelOn = strCPEModelOn != bListIsCPEModelOn[rowIndex].ToString() ? true : false;
                    flagR2RMode = strR2RMode != strListR2RMode[rowIndex] ? true : false;
                    break;
                case 5:
                    flagOVLMode = strOVLMode != strListOVLModels[rowIndex] ? true : false;
                    flagCPEModelOn = strCPEModelOn != bListIsCPEModelOn[rowIndex].ToString() ? true : false;
                    flagR2RMode = strR2RMode != strListR2RMode[rowIndex] ? true : false;
                    break;
                default:
                    break;
            }
            return flagOVLMode || flagCPEModelOn || flagR2RMode;
        }

        private void grdBatchOVLMode_AfterCellUpdate(object sender, CellEventArgs e)
        {
            //MessageBox.Show(e.Cell.Row.Index.ToString());
            //MessageBox.Show(e.Cell.Column.Index.ToString());
            if (iRowChangeIndex.Contains(e.Cell.Row.Index))
            {
                strListProductsChange.RemoveAt(e.Cell.Row.Index);
                strListLayersChange.RemoveAt(e.Cell.Row.Index);
                strListToolsChange.RemoveAt(e.Cell.Row.Index);
                strListOVLModelsChange.RemoveAt(e.Cell.Row.Index);
                bListIsCPEModelOnChange.RemoveAt(e.Cell.Row.Index);
                strListR2RModeChange.RemoveAt(e.Cell.Row.Index);
            }
            else
            {
                iRowChangeIndex.Add(e.Cell.Row.Index);
            }
            bool flag;
            string strOVLModel;
            string strCPEModeOn;
            string strR2RMode;
            strOVLModel = grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[3].Value.ToString();
            strCPEModeOn = grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[4].Value.ToString();
            strR2RMode = grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[5].Value.ToString();
            flag = IsCellValueChange(strOVLModel, strCPEModeOn, strR2RMode, e.Cell.Row.Index, e.Cell.Column.Index);
            if (flag)
            {
                strListProductsChange.Add(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[0].Value.ToString());
                strListLayersChange.Add(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[1].Value.ToString());
                strListToolsChange.Add(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[2].Value.ToString());
                strListOVLModelsChange.Add(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[3].Value.ToString());
                bListIsCPEModelOnChange.Add(bool.Parse(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[4].Value.ToString()));
                strListR2RModeChange.Add(grdBatchOVLMode.Rows[e.Cell.Row.Index].Cells[5].Value.ToString());
            }
        }
    }
}
