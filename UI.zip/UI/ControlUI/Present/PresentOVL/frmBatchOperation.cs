﻿using ControlUI.Comman;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmBatchOperation : Form
    {
        public frmBatchOperation()
        {
            InitializeComponent();
        }
        
        public frmBatchOperation(string strFrmServiceAddres,string strFrmArea)
        {
            InitializeComponent();

            strServiceAddres = strFrmServiceAddres;
        }

        public frmBatchOperation(string strFrmServiceAddres, string strFrmArea, UIServiceFun.structPH_OVL_Batch_GetContexts structContextData)
        {
            InitializeComponent();

            strArea = strFrmArea;
            strServiceAddres = strFrmServiceAddres;
            structData = structContextData;
            if (structData.strListProducts.Count > 0)
            {
                strListProduct = new List<string>(structData.strListProducts);
                strListLayer = new List<string>(structData.strListLayers);
                strListTool = new List<string>(structData.strListTools);
                //strListProduct.Remove("*");
                //strListLayer.Remove("*");
                //strListTool.Remove("*");
                strCurrentProduct = strListProduct[0]; 
                strCurrentLayer = strListLayer[0];
                strCurrentTool = strListTool[0];
            }
        }

        #region Param
        string strArea;
        string strServiceAddres;
        string strCurrentProduct;
        string strCurrentLayer;
        string strCurrentTool;
        List<string> strListProduct = new List<string>();
        List<string> strListLayer = new List<string>();
        List<string> strListTool = new List<string>();

        UIServiceFun.structPH_OVL_Batch_GetContexts structData = new UIServiceFun.structPH_OVL_Batch_GetContexts();
        #endregion

        private void frmBatchOperation_Load(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_GetContexts
            //UIServiceFun.structPH_OVL_Batch_GetContexts structData = new UIServiceFun.structPH_OVL_Batch_GetContexts();
            //structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetContexts(strServiceAddres, strArea);
            //strListProduct = structData.strListProducts;
            //strListLayer = structData.strListLayers;
            //strListTool = structData.strListTools;
            #endregion

            InitGrid();
        }

        #region init Grid
        private void InitGrid()
        {
            this.grdBatchOperation.BeginUpdate();
            this.batchOperationDataSource.Rows.Clear();
            this.batchOperationDataSource.Rows.SetCount(3);
            this.grdBatchOperation.DataSource = this.batchOperationDataSource;

            this.grdBatchOperation.Rows[0].Cells["Name"].Value = "Product";
            this.grdBatchOperation.Rows[1].Cells["Name"].Value = "Layer";
            this.grdBatchOperation.Rows[2].Cells["Name"].Value = "Tool";

            this.grdBatchOperation.Rows[0].Cells["Value"].Value = "";
            this.grdBatchOperation.Rows[1].Cells["Value"].Value = "";
            this.grdBatchOperation.Rows[2].Cells["Value"].Value = "";

            this.grdBatchOperation.DataBind();
            this.grdBatchOperation.EndUpdate();

            //冻结行，禁止排序
            this.grdBatchOperation.DisplayLayout.Override.FixedRowStyle = FixedRowStyle.Top;
            for (int i = 0; i < 3; i++)
            {
                this.grdBatchOperation.Rows.FixedRows.Add(this.grdBatchOperation.Rows[i]);
                this.grdBatchOperation.Rows[i].Fixed = true;
            }
            this.grdBatchOperation.DisplayLayout.Override.FixedRowIndicator = FixedRowIndicator.Button;

            //禁止编辑
            this.grdBatchOperation.DisplayLayout.Bands[0].Columns[0].CellActivation = Activation.NoEdit;


            if (strListProduct.Count > 0)
            {
                InitGrdBatchOperationValueList("valueProduct", strListProduct, 0);
            }
            if(strListLayer.Count>0)
            {
                InitGrdBatchOperationValueList("valueLayer", strListLayer, 1);
            }
            if (strListTool.Count > 0)
            {
                InitGrdBatchOperationValueList("valueTool", strListTool, 2);
            }
        }

        private void InitGrdBatchOperationValueList(string strValueListName,List<string> strList,int rowIndex)
        {
            if (this.grdBatchOperation.DisplayLayout.ValueLists.Exists(strValueListName))
            {
                this.grdBatchOperation.DisplayLayout.ValueLists.Remove(strValueListName);
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOperation.DisplayLayout.ValueLists.Add(strValueListName);
            foreach (var str in strList)
            {
                valueLists.ValueListItems.Add(str);
            }
            this.grdBatchOperation.Rows[rowIndex].Cells["Value"].ValueList = valueLists;
            this.grdBatchOperation.Rows[rowIndex].Cells["Value"].Value = strList[0];
        }

        private void ClearGrdBatchOperationValues(string strValueListName, int rowIndex)
        {
            if (this.grdBatchOperation.DisplayLayout.ValueLists.Exists(strValueListName))
            {
                this.grdBatchOperation.DisplayLayout.ValueLists.Remove(strValueListName);
            }
            Infragistics.Win.ValueList valueLists = this.grdBatchOperation.DisplayLayout.ValueLists.Add(strValueListName);
            valueLists.ValueListItems.Add("");
            this.grdBatchOperation.Rows[rowIndex].Cells["Value"].ValueList = valueLists;
            this.grdBatchOperation.Rows[rowIndex].Cells["Value"].Value = "";
        }
        #endregion

        private void btnBatchOVLMode_Click(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_GetOVLModel
            UIServiceFun.structPH_OVL_Batch_GetOVLModel structDataNull = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
            UIServiceFun.structPH_OVL_Batch_GetOVLModel structData = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetOVLModel(strServiceAddres, strCurrentProduct, strCurrentLayer, strCurrentTool);
            #endregion

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmBatchOVLModel frm = new frmBatchOVLModel(strServiceAddres, structData);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.ovlMode.ToString() + " " + frm.bCPE.ToString());
                }
                else
                {

                }
            }
        }

        private void btnBatchPMOffset_Click(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_GetPMOffsets
            UIServiceFun.structPH_OVL_Batch_GetPMOffsets structDataNull = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
            UIServiceFun.structPH_OVL_Batch_GetPMOffsets  structData = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetPMOffsets(strServiceAddres, strCurrentTool);
            #endregion

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmBatchPMOffset frm = new frmBatchPMOffset(strServiceAddres, strCurrentTool, structData);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }  
        }

        private void grdBatchOperation_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {

        }

        private void grdBatchOperation_CellListSelect(object sender, CellEventArgs e)
        {
            #region 
            try
            {
                string strValueListName = e.Cell.ValueList.ToString();
                this.Cursor = Cursors.WaitCursor;
                switch (strValueListName)
                {
                    case "valueProduct":
                        ClearGrdBatchOperationValues("valueLayer", 1);
                        ClearGrdBatchOperationValues("valueTool", 2);
                        strCurrentProduct = grdBatchOperation.Rows[0].Cells["Value"].Text;

                        //strListProduct = UIServiceFun.GetProduct(strUserName, strServiceAddres, strCurrentModule);
                        InitGrdBatchOperationValueList("valueLayer", strListLayer, 1);
                        break;
                    case "valueLayer":
                        ClearGrdBatchOperationValues("valueTool", 2);
                        strCurrentLayer = grdBatchOperation.Rows[1].Cells["Value"].Text;

                        InitGrdBatchOperationValueList("valueTool", strListTool, 2);
                        break;
                    case "valueTool":
                        strCurrentTool = grdBatchOperation.Rows[2].Cells["Value"].Text;
                        break;
                    default:
                        break;
                }
                this.Cursor = Cursors.Default;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
                this.Cursor = Cursors.Default;
            }
            #endregion
        }

        private void menuBatchOperation_ToolClick(object sender, Infragistics.Win.UltraWinToolbars.ToolClickEventArgs e)
        {
            switch (e.Tool.Key)
            {
                case "Batch OVL Mode":
                    btnBatchOVLMode_Click(sender, e);
                    //MessageBox.Show("Batch OVL Mode");
                    break;
                case "Batch PM Offset":
                    btnBatchPMOffset_Click(sender, e);
                    //MessageBox.Show("Batch PM Offset");
                    break;
                default:
                    break;
            }
        }
    }
}
