﻿using ControlUI.Comman;
using Infragistics.Win.UltraWinEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmCDReset : Form
    {
        public frmCDReset()
        {
            InitializeComponent();
        }
        public frmCDReset(string strServiceName, List<string> strListFrmR2RContexts, UIServiceFun.structPH_CD_GetDoseResetSettings structDataSetting)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strListR2RContexts = new List<string>(strListFrmR2RContexts);
            structData = structDataSetting;
            dDosePMValue = structDataSetting.dDosePMValue;
            dDoseResetValue = structDataSetting.dDoseResetValue;
        }
        public frmCDReset(List<string> strListReticle, List<string> strListReticle2, int num)
        {
            InitializeComponent();
            //nReticle = num;
            //strListCurrent = new List<string>(strListReticle);
            //if (nReticle > 1)
            //{
            //    strListCurrent_2 = new List<string>(strListReticle2);
            //}
        }

        #region Param
        bool bIsPM = true;
        bool bIsReset= false;

        public string strServiceAddress;
        public double dDoseValue;   
        public double dDoseResetValue;
        public double dDosePMValue;
        public List<string> strListR2RContexts = new List<string>();
        UIServiceFun.structPH_CD_GetDoseResetSettings structData = new UIServiceFun.structPH_CD_GetDoseResetSettings();
        UIServiceFun.structPH_CD_UpdateDoseResetSettings structDataUpdate = new UIServiceFun.structPH_CD_UpdateDoseResetSettings();

        public int nReticle;
        public List<string> strListNew = new List<string>();
        public List<string> strListCurrent = new List<string>();
        public List<string> strListNew_2 = new List<string>();
        public List<string> strListCurrent_2 = new List<string>();

        List<UltraTextEditor> ctlLableTxtControl = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlCurrentTxtControl = new List<UltraTextEditor>();
        List<NumericUpDown> ctlNewTxtControl = new List<NumericUpDown>();

        List<UltraTextEditor> ctlLableTxtControl_2 = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlCurrentTxtControl_2 = new List<UltraTextEditor>();
        List<NumericUpDown> ctlNewTxtControl_2 = new List<NumericUpDown>();
        #endregion

        private void InitValue()
        {
            rdoReset.CheckedIndex = 0;
            bIsPM = true;
            bIsReset = false;
            dDoseValue = dDosePMValue;

            txtCurrent1.Text = dDoseValue.ToString();
        }

        private void frmCDReset_Load(object sender, EventArgs e)
        {
            InitValue();

            #region
            //rdoActive.CheckedIndex = 0;
            //rdoTabActive.CheckedIndex = 0;
            //rdoTabActive2.CheckedIndex = 0;
            //tabReticle.Tabs[1].Visible = false;

            //AddControlHelp.AutoAddLableControl(strListCurrent, ref ctlLableTxtControl, lblTxt1, panReticle_1);
            //AddControlHelp.AutoAddNewTxtControl(strListCurrent, ref ctlNewTxtControl, updoneNew1, panReticle_1);
            //AddControlHelp.AutoAddCurrentTxtControl(strListCurrent, ref ctlCurrentTxtControl, txtCurrent1, panReticle_1);

            //if (nReticle > 1)
            //{
            //    tabReticle.Tabs[1].Visible = true;
            //    AddControlHelp.AutoAddLableControl(strListCurrent_2, ref ctlLableTxtControl_2, lblTxt1_2, panReticle_2);
            //    AddControlHelp.AutoAddNewTxtControl(strListCurrent_2, ref ctlNewTxtControl_2, updoneNew1_2, panReticle_2);
            //    AddControlHelp.AutoAddCurrentTxtControl(strListCurrent_2, ref ctlCurrentTxtControl_2, txtCurrent1_2, panReticle_2);
            //}
            //AddControlHelp.AutoAddControlTest(strListCurrent, ref ctlLableTxtControl, ref ctlNewTxtControl, ref ctlCurrentTxtControl, panBatchR2RModeTab_2);
            #endregion
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            bool bSuccess;
            try
            {
                #region PH_CD_GetDoseResetSettings
                dDoseValue = double.Parse(txtCurrent1.Text.ToString());
                structDataUpdate.bIsPM = bIsPM;
                structDataUpdate.bIsReset= bIsReset;
                structDataUpdate.dDoseDefaultValue = dDoseValue;
                bSuccess = UIServiceFun.R2R_UI_PH_CD_UpdateDoseResetSettings(strServiceAddress, strListR2RContexts, structDataUpdate);
                if (bSuccess)
                {
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Set Failed!");
                }
                this.DialogResult = DialogResult.OK;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            #region test
            //strListNew.Add(updoneNew1.Text.ToString());
            //if (ctlNewTxtControl.Count > 0)
            //{
            //    foreach (var ctl in ctlNewTxtControl)
            //    {
            //        strListNew.Add(ctl.Text.ToString());
            //    }
            //}
            //if (nReticle > 1)
            //{
            //    strListNew_2.Add(updoneNew1_2.Text.ToString());
            //    if (ctlNewTxtControl.Count > 0)
            //    {
            //        foreach (var ctl in ctlNewTxtControl_2)
            //        {
            //            strListNew.Add(ctl.Text.ToString());
            //        }
            //    }
            //}
            #endregion
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rdoReset_ValueChanged(object sender, EventArgs e)
        {
            if (rdoReset.CheckedIndex == 0)
            {
                bIsPM = true;
                bIsReset = false;
                dDoseValue = dDosePMValue;   
            }
            else if (rdoReset.CheckedIndex == 1)
            {
                bIsPM = false;
                bIsReset = true;
                dDoseValue = dDoseResetValue;
            }
            txtCurrent1.Text = dDoseValue.ToString();
        }
    }
}
