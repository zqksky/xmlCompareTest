﻿using ControlUI.Comman;
using Infragistics.UltraChart.Resources.Appearance;
using Infragistics.UltraChart.Shared.Styles;
using Infragistics.Win.Misc;
using Infragistics.Win.UltraWinChart;
using Infragistics.Win.UltraWinEditors;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ControlUI.Comman.UIServiceFun;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmLinearReset : Form
    {
        public frmLinearReset()
        {
            InitializeComponent();
        }

        public frmLinearReset(string strServiceName, string strCurrentProduct, string strCurrentLayer, string strCurrentController, string strCurrentTool, string strCurrentChuckId, UIServiceFun.structPH_OVL_GetResetValues structData)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strProduct = strCurrentProduct;
            strLayer = strCurrentLayer;
            strController = strCurrentController;
            strTool = strCurrentTool;
            strChuckId = strCurrentChuckId;

            structResetValues = structData;
            if (structData.iListInputIndex.Count > 0)
            {
                dListInputValues = new List<double>(structData.dListInputValues);
                iListInputIndex = new List<int>(structData.iListInputIndex);
                strListInputNames = new List<string>(structData.strListInputNames);
                strListReticleIds = new List<string>(structData.strListReticleIds);
            }
        }

        #region Param
        //public int nReticle;
        public string strServiceAddres;
        public string strProduct;
        public string strLayer;
        public string strController;
        public string strTool;
        public string strChuckId;

        public List<int> iListInputIndex = new List<int>();
        public List<double> dListInputValues = new List<double>();
        public List<string> strListInputNames = new List<string>();
        public List<string> strListReticleIds = new List<string>();

        public List<string> strListNew = new List<string>();
        public List<string> strListCurrent = new List<string>();

        List<UltraTextEditor> ctlLableTxtControl = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlCurrentTxtControl = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlNewTxtControl = new List<UltraTextEditor>();

        UIServiceFun.structPH_OVL_GetResetValues structResetValues = new UIServiceFun.structPH_OVL_GetResetValues();
        #endregion

        private void InitGrid(UltraGrid ctlGrid, DataTable tb)
        {
            ctlGrid.DataSource = tb;

            //禁止编辑
            if (ctlGrid.DisplayLayout.Bands[0].Columns.Count > 3)
            {
                ctlGrid.DisplayLayout.Bands[0].Columns[0].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[1].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[2].CellActivation = Activation.NoEdit;
            }

            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //ctlGrid.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //ctlGrid.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //ctlGrid.DisplayLayout.Override.ColumnAutoSizeMode = ColumnAutoSizeMode.VisibleRows;
            //ctlGrid.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //ctlGrid.Rows[0].PerformAutoSize();
            //ctlGrid.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
        }

        private void GetGridValue()
        {
            //int rowCount = 0;
            //rowCount = grdLinearReset.Rows.Count;
            //if (rowCount > 0)
            //{
            //    iListInputIndex.Clear();
            //    strListInputNames.Clear();
            //    strListReticleIds.Clear();
            //    dListInputValues.Clear();
            //    for (int i = 0; i < rowCount; i++)
            //    {
            //        iListInputIndex.Add(int.Parse(grdLinearReset.Rows[i].Cells[0].Value.ToString()));
            //        strListInputNames.Add(grdLinearReset.Rows[i].Cells[1].Value.ToString());
            //        strListReticleIds.Add(grdLinearReset.Rows[i].Cells[2].Value.ToString());
            //        dListInputValues.Add(double.Parse(grdLinearReset.Rows[i].Cells[3].Value.ToString()));
            //    }
            //}
            //structResetValues.iListInputIndex = new List<int>(iListInputIndex);
            //structResetValues.strListReticleIds = new List<string>(strListReticleIds);
            //structResetValues.strListInputNames = new List<string>(strListInputNames);
            //structResetValues.dListInputValues = new List<double>(dListInputValues);
        }

        private void frmLinearReset_Load(object sender, EventArgs e)
        {
            #region
            AddControlHelp.AutoAddLableControl(strListInputNames, ref ctlLableTxtControl, lblTxt1, panReset);
            AddControlHelp.AutoAddTextControl(dListInputValues, ref ctlCurrentTxtControl, txtCurrent, panReset, true);
            AddControlHelp.AutoAddTextControl(dListInputValues, ref ctlNewTxtControl, txtNew, panReset, false);
            #endregion

            //InitGrid(grdLinearReset, DataTableHelp.CreateLinearResetTable(structResetValues));
        }

        #region 
        private void textValueChanged()
        {
            structResetValues.dListInputValues = new List<double>();
            structResetValues.dListInputValues.Clear();
            structResetValues.dListInputValues.Add(double.Parse(txtNew.Text.ToString().Trim()));
            foreach (var ctl in ctlNewTxtControl)
            {
                structResetValues.dListInputValues.Add(double.Parse(ctl.Text.ToString().Trim()));
            }    
        }
        #endregion

        private void btnOk_Click(object sender, EventArgs e)
        {
            bool bSuccess;
            try
            {
                #region PH_OVL_ResetModel
                textValueChanged();
                //GetGridValue();
                if (dListInputValues.Count > 0)
                {
                    bSuccess = UIServiceFun.R2R_UI_PH_OVL_ResetModel(strServiceAddres, strProduct, strLayer, strController, strTool, strChuckId, structResetValues);
                    if (bSuccess)
                    {
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Set Failed!");
                    }
                }
                this.DialogResult = DialogResult.OK;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
