﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmChuckDedication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            this.panChuckDedication = new Infragistics.Win.Misc.UltraPanel();
            this.panChuckDedication_1 = new Infragistics.Win.Misc.UltraPanel();
            this.panChuckDedication_2 = new Infragistics.Win.Misc.UltraPanel();
            this.panChuckDedication_4 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraGrid2 = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.ultraSplitter2 = new Infragistics.Win.Misc.UltraSplitter();
            this.panChuckDedication_3 = new Infragistics.Win.Misc.UltraPanel();
            this.grdQueryLotInfo = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panChuckDedicationTxt = new Infragistics.Win.Misc.UltraPanel();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.txtLayer = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor4 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtLotId = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraSplitter1 = new Infragistics.Win.Misc.UltraSplitter();
            this.panChuckDedicationGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdContextGroup = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panChuckDedication.ClientArea.SuspendLayout();
            this.panChuckDedication.SuspendLayout();
            this.panChuckDedication_1.ClientArea.SuspendLayout();
            this.panChuckDedication_1.SuspendLayout();
            this.panChuckDedication_2.ClientArea.SuspendLayout();
            this.panChuckDedication_2.SuspendLayout();
            this.panChuckDedication_4.ClientArea.SuspendLayout();
            this.panChuckDedication_4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid2)).BeginInit();
            this.panChuckDedication_3.ClientArea.SuspendLayout();
            this.panChuckDedication_3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdQueryLotInfo)).BeginInit();
            this.panChuckDedicationTxt.ClientArea.SuspendLayout();
            this.panChuckDedicationTxt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtLayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLotId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            this.panChuckDedicationGrid.ClientArea.SuspendLayout();
            this.panChuckDedicationGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdContextGroup)).BeginInit();
            this.SuspendLayout();
            // 
            // panChuckDedication
            // 
            // 
            // panChuckDedication.ClientArea
            // 
            this.panChuckDedication.ClientArea.Controls.Add(this.panChuckDedication_1);
            this.panChuckDedication.ClientArea.Controls.Add(this.ultraSplitter1);
            this.panChuckDedication.ClientArea.Controls.Add(this.panChuckDedicationGrid);
            this.panChuckDedication.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChuckDedication.Location = new System.Drawing.Point(0, 0);
            this.panChuckDedication.Name = "panChuckDedication";
            this.panChuckDedication.Size = new System.Drawing.Size(603, 499);
            this.panChuckDedication.TabIndex = 0;
            // 
            // panChuckDedication_1
            // 
            // 
            // panChuckDedication_1.ClientArea
            // 
            this.panChuckDedication_1.ClientArea.Controls.Add(this.panChuckDedication_2);
            this.panChuckDedication_1.ClientArea.Controls.Add(this.panChuckDedicationTxt);
            this.panChuckDedication_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChuckDedication_1.Location = new System.Drawing.Point(0, 131);
            this.panChuckDedication_1.Name = "panChuckDedication_1";
            this.panChuckDedication_1.Size = new System.Drawing.Size(603, 368);
            this.panChuckDedication_1.TabIndex = 2;
            // 
            // panChuckDedication_2
            // 
            // 
            // panChuckDedication_2.ClientArea
            // 
            this.panChuckDedication_2.ClientArea.Controls.Add(this.panChuckDedication_4);
            this.panChuckDedication_2.ClientArea.Controls.Add(this.ultraSplitter2);
            this.panChuckDedication_2.ClientArea.Controls.Add(this.panChuckDedication_3);
            this.panChuckDedication_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChuckDedication_2.Location = new System.Drawing.Point(0, 44);
            this.panChuckDedication_2.Name = "panChuckDedication_2";
            this.panChuckDedication_2.Size = new System.Drawing.Size(603, 324);
            this.panChuckDedication_2.TabIndex = 1;
            // 
            // panChuckDedication_4
            // 
            // 
            // panChuckDedication_4.ClientArea
            // 
            this.panChuckDedication_4.ClientArea.Controls.Add(this.ultraGrid2);
            this.panChuckDedication_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChuckDedication_4.Location = new System.Drawing.Point(297, 0);
            this.panChuckDedication_4.Name = "panChuckDedication_4";
            this.panChuckDedication_4.Size = new System.Drawing.Size(306, 324);
            this.panChuckDedication_4.TabIndex = 2;
            // 
            // ultraGrid2
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.ultraGrid2.DisplayLayout.Appearance = appearance1;
            this.ultraGrid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraGrid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.ultraGrid2.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.ultraGrid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.ultraGrid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraGrid2.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.ultraGrid2.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.ultraGrid2.DisplayLayout.MaxColScrollRegions = 1;
            this.ultraGrid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ultraGrid2.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.ultraGrid2.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.ultraGrid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.ultraGrid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.ultraGrid2.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.ultraGrid2.DisplayLayout.Override.CellAppearance = appearance8;
            this.ultraGrid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.ultraGrid2.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.ultraGrid2.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.ultraGrid2.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.ultraGrid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.ultraGrid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.ultraGrid2.DisplayLayout.Override.RowAppearance = appearance11;
            this.ultraGrid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ultraGrid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.ultraGrid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.ultraGrid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.ultraGrid2.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.ultraGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraGrid2.Location = new System.Drawing.Point(0, 0);
            this.ultraGrid2.Name = "ultraGrid2";
            this.ultraGrid2.Size = new System.Drawing.Size(306, 324);
            this.ultraGrid2.TabIndex = 1;
            this.ultraGrid2.Text = "Calc Setting";
            // 
            // ultraSplitter2
            // 
            this.ultraSplitter2.Location = new System.Drawing.Point(291, 0);
            this.ultraSplitter2.Name = "ultraSplitter2";
            this.ultraSplitter2.RestoreExtent = 291;
            this.ultraSplitter2.Size = new System.Drawing.Size(6, 324);
            this.ultraSplitter2.TabIndex = 1;
            // 
            // panChuckDedication_3
            // 
            // 
            // panChuckDedication_3.ClientArea
            // 
            this.panChuckDedication_3.ClientArea.Controls.Add(this.grdQueryLotInfo);
            this.panChuckDedication_3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panChuckDedication_3.Location = new System.Drawing.Point(0, 0);
            this.panChuckDedication_3.Name = "panChuckDedication_3";
            this.panChuckDedication_3.Size = new System.Drawing.Size(291, 324);
            this.panChuckDedication_3.TabIndex = 0;
            // 
            // grdQueryLotInfo
            // 
            appearance13.BackColor = System.Drawing.SystemColors.Window;
            appearance13.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdQueryLotInfo.DisplayLayout.Appearance = appearance13;
            this.grdQueryLotInfo.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdQueryLotInfo.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance14.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance14.BorderColor = System.Drawing.SystemColors.Window;
            this.grdQueryLotInfo.DisplayLayout.GroupByBox.Appearance = appearance14;
            appearance15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdQueryLotInfo.DisplayLayout.GroupByBox.BandLabelAppearance = appearance15;
            this.grdQueryLotInfo.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdQueryLotInfo.DisplayLayout.GroupByBox.Hidden = true;
            appearance16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance16.BackColor2 = System.Drawing.SystemColors.Control;
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance16.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdQueryLotInfo.DisplayLayout.GroupByBox.PromptAppearance = appearance16;
            this.grdQueryLotInfo.DisplayLayout.MaxColScrollRegions = 1;
            this.grdQueryLotInfo.DisplayLayout.MaxRowScrollRegions = 1;
            appearance17.BackColor = System.Drawing.SystemColors.Window;
            appearance17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdQueryLotInfo.DisplayLayout.Override.ActiveCellAppearance = appearance17;
            appearance18.BackColor = System.Drawing.SystemColors.Highlight;
            appearance18.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdQueryLotInfo.DisplayLayout.Override.ActiveRowAppearance = appearance18;
            this.grdQueryLotInfo.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdQueryLotInfo.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance19.BackColor = System.Drawing.SystemColors.Window;
            this.grdQueryLotInfo.DisplayLayout.Override.CardAreaAppearance = appearance19;
            appearance20.BorderColor = System.Drawing.Color.Silver;
            appearance20.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdQueryLotInfo.DisplayLayout.Override.CellAppearance = appearance20;
            this.grdQueryLotInfo.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdQueryLotInfo.DisplayLayout.Override.CellPadding = 0;
            appearance21.BackColor = System.Drawing.SystemColors.Control;
            appearance21.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance21.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance21.BorderColor = System.Drawing.SystemColors.Window;
            this.grdQueryLotInfo.DisplayLayout.Override.GroupByRowAppearance = appearance21;
            appearance22.TextHAlignAsString = "Left";
            this.grdQueryLotInfo.DisplayLayout.Override.HeaderAppearance = appearance22;
            this.grdQueryLotInfo.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdQueryLotInfo.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance23.BackColor = System.Drawing.SystemColors.Window;
            appearance23.BorderColor = System.Drawing.Color.Silver;
            this.grdQueryLotInfo.DisplayLayout.Override.RowAppearance = appearance23;
            this.grdQueryLotInfo.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdQueryLotInfo.DisplayLayout.Override.TemplateAddRowAppearance = appearance24;
            this.grdQueryLotInfo.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdQueryLotInfo.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdQueryLotInfo.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdQueryLotInfo.Location = new System.Drawing.Point(0, 0);
            this.grdQueryLotInfo.Name = "grdQueryLotInfo";
            this.grdQueryLotInfo.Size = new System.Drawing.Size(291, 324);
            this.grdQueryLotInfo.TabIndex = 0;
            this.grdQueryLotInfo.Text = "Query Lot Info";
            this.grdQueryLotInfo.CellChange += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.grdQueryLotInfo_CellChange);
            // 
            // panChuckDedicationTxt
            // 
            // 
            // panChuckDedicationTxt.ClientArea
            // 
            this.panChuckDedicationTxt.ClientArea.Controls.Add(this.btnOk);
            this.panChuckDedicationTxt.ClientArea.Controls.Add(this.txtLayer);
            this.panChuckDedicationTxt.ClientArea.Controls.Add(this.ultraTextEditor4);
            this.panChuckDedicationTxt.ClientArea.Controls.Add(this.txtLotId);
            this.panChuckDedicationTxt.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panChuckDedicationTxt.Dock = System.Windows.Forms.DockStyle.Top;
            this.panChuckDedicationTxt.Location = new System.Drawing.Point(0, 0);
            this.panChuckDedicationTxt.Name = "panChuckDedicationTxt";
            this.panChuckDedicationTxt.Size = new System.Drawing.Size(603, 44);
            this.panChuckDedicationTxt.TabIndex = 0;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(476, 14);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // txtLayer
            // 
            this.txtLayer.Location = new System.Drawing.Point(302, 17);
            this.txtLayer.Name = "txtLayer";
            this.txtLayer.ReadOnly = true;
            this.txtLayer.Size = new System.Drawing.Size(100, 21);
            this.txtLayer.TabIndex = 3;
            // 
            // ultraTextEditor4
            // 
            this.ultraTextEditor4.Location = new System.Drawing.Point(230, 17);
            this.ultraTextEditor4.Name = "ultraTextEditor4";
            this.ultraTextEditor4.ReadOnly = true;
            this.ultraTextEditor4.Size = new System.Drawing.Size(46, 21);
            this.ultraTextEditor4.TabIndex = 2;
            this.ultraTextEditor4.Text = "Layer:";
            // 
            // txtLotId
            // 
            this.txtLotId.Location = new System.Drawing.Point(104, 17);
            this.txtLotId.Name = "txtLotId";
            this.txtLotId.Size = new System.Drawing.Size(100, 21);
            this.txtLotId.TabIndex = 1;
            this.txtLotId.Text = "LotId_31";
            this.txtLotId.ValueChanged += new System.EventHandler(this.txtLotId_ValueChanged);
            this.txtLotId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLotId_KeyDown);
            this.txtLotId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLotId_KeyPress);
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Location = new System.Drawing.Point(32, 17);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(46, 21);
            this.ultraTextEditor1.TabIndex = 0;
            this.ultraTextEditor1.Text = "Lot ID:";
            // 
            // ultraSplitter1
            // 
            this.ultraSplitter1.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraSplitter1.Location = new System.Drawing.Point(0, 125);
            this.ultraSplitter1.Name = "ultraSplitter1";
            this.ultraSplitter1.RestoreExtent = 125;
            this.ultraSplitter1.Size = new System.Drawing.Size(603, 6);
            this.ultraSplitter1.TabIndex = 1;
            // 
            // panChuckDedicationGrid
            // 
            // 
            // panChuckDedicationGrid.ClientArea
            // 
            this.panChuckDedicationGrid.ClientArea.Controls.Add(this.grdContextGroup);
            this.panChuckDedicationGrid.Dock = System.Windows.Forms.DockStyle.Top;
            this.panChuckDedicationGrid.Location = new System.Drawing.Point(0, 0);
            this.panChuckDedicationGrid.Name = "panChuckDedicationGrid";
            this.panChuckDedicationGrid.Size = new System.Drawing.Size(603, 125);
            this.panChuckDedicationGrid.TabIndex = 0;
            // 
            // grdContextGroup
            // 
            appearance25.BackColor = System.Drawing.SystemColors.Window;
            appearance25.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdContextGroup.DisplayLayout.Appearance = appearance25;
            this.grdContextGroup.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdContextGroup.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance26.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance26.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance26.BorderColor = System.Drawing.SystemColors.Window;
            this.grdContextGroup.DisplayLayout.GroupByBox.Appearance = appearance26;
            appearance27.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdContextGroup.DisplayLayout.GroupByBox.BandLabelAppearance = appearance27;
            this.grdContextGroup.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdContextGroup.DisplayLayout.GroupByBox.Hidden = true;
            appearance28.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance28.BackColor2 = System.Drawing.SystemColors.Control;
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance28.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdContextGroup.DisplayLayout.GroupByBox.PromptAppearance = appearance28;
            this.grdContextGroup.DisplayLayout.MaxColScrollRegions = 1;
            this.grdContextGroup.DisplayLayout.MaxRowScrollRegions = 1;
            appearance29.BackColor = System.Drawing.SystemColors.Window;
            appearance29.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdContextGroup.DisplayLayout.Override.ActiveCellAppearance = appearance29;
            appearance30.BackColor = System.Drawing.SystemColors.Highlight;
            appearance30.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdContextGroup.DisplayLayout.Override.ActiveRowAppearance = appearance30;
            this.grdContextGroup.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdContextGroup.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance31.BackColor = System.Drawing.SystemColors.Window;
            this.grdContextGroup.DisplayLayout.Override.CardAreaAppearance = appearance31;
            appearance32.BorderColor = System.Drawing.Color.Silver;
            appearance32.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdContextGroup.DisplayLayout.Override.CellAppearance = appearance32;
            this.grdContextGroup.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdContextGroup.DisplayLayout.Override.CellPadding = 0;
            appearance33.BackColor = System.Drawing.SystemColors.Control;
            appearance33.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance33.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance33.BorderColor = System.Drawing.SystemColors.Window;
            this.grdContextGroup.DisplayLayout.Override.GroupByRowAppearance = appearance33;
            appearance34.TextHAlignAsString = "Left";
            this.grdContextGroup.DisplayLayout.Override.HeaderAppearance = appearance34;
            this.grdContextGroup.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdContextGroup.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance35.BackColor = System.Drawing.SystemColors.Window;
            appearance35.BorderColor = System.Drawing.Color.Silver;
            this.grdContextGroup.DisplayLayout.Override.RowAppearance = appearance35;
            this.grdContextGroup.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance36.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdContextGroup.DisplayLayout.Override.TemplateAddRowAppearance = appearance36;
            this.grdContextGroup.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdContextGroup.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdContextGroup.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdContextGroup.Location = new System.Drawing.Point(0, 0);
            this.grdContextGroup.Name = "grdContextGroup";
            this.grdContextGroup.Size = new System.Drawing.Size(603, 125);
            this.grdContextGroup.TabIndex = 0;
            this.grdContextGroup.Text = "Context Group";
            this.grdContextGroup.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdContextGroup_InitializeLayout);
            // 
            // frmChuckDedication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 499);
            this.Controls.Add(this.panChuckDedication);
            this.Name = "frmChuckDedication";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChuckDedication";
            this.Load += new System.EventHandler(this.frmChuckDedication_Load);
            this.panChuckDedication.ClientArea.ResumeLayout(false);
            this.panChuckDedication.ResumeLayout(false);
            this.panChuckDedication_1.ClientArea.ResumeLayout(false);
            this.panChuckDedication_1.ResumeLayout(false);
            this.panChuckDedication_2.ClientArea.ResumeLayout(false);
            this.panChuckDedication_2.ResumeLayout(false);
            this.panChuckDedication_4.ClientArea.ResumeLayout(false);
            this.panChuckDedication_4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid2)).EndInit();
            this.panChuckDedication_3.ClientArea.ResumeLayout(false);
            this.panChuckDedication_3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdQueryLotInfo)).EndInit();
            this.panChuckDedicationTxt.ClientArea.ResumeLayout(false);
            this.panChuckDedicationTxt.ClientArea.PerformLayout();
            this.panChuckDedicationTxt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtLayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLotId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            this.panChuckDedicationGrid.ClientArea.ResumeLayout(false);
            this.panChuckDedicationGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdContextGroup)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panChuckDedication;
        private Infragistics.Win.Misc.UltraPanel panChuckDedicationGrid;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdContextGroup;
        private Infragistics.Win.Misc.UltraPanel panChuckDedication_1;
        private Infragistics.Win.Misc.UltraPanel panChuckDedication_2;
        private Infragistics.Win.Misc.UltraPanel panChuckDedication_4;
        private Infragistics.Win.UltraWinGrid.UltraGrid ultraGrid2;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter2;
        private Infragistics.Win.Misc.UltraPanel panChuckDedication_3;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdQueryLotInfo;
        private Infragistics.Win.Misc.UltraPanel panChuckDedicationTxt;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtLayer;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor4;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtLotId;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.Misc.UltraButton btnOk;
    }
}