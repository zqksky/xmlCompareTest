﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmCDMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panCDModeSubTab = new Infragistics.Win.Misc.UltraPanel();
            this.panReticle_1 = new Infragistics.Win.Misc.UltraPanel();
            this.rdoTabActive = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.updoneNew1 = new System.Windows.Forms.NumericUpDown();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.lblTxt1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtCurrent1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.panCDModeSubTab_chart = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panCDModeSubTab2 = new Infragistics.Win.Misc.UltraPanel();
            this.panReticle_2 = new Infragistics.Win.Misc.UltraPanel();
            this.rdoTabActive2 = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.updoneNew1_2 = new System.Windows.Forms.NumericUpDown();
            this.lblNew = new Infragistics.Win.Misc.UltraLabel();
            this.lblTxt1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtCurrent1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblCurrent = new Infragistics.Win.Misc.UltraLabel();
            this.panCDModeSubTab2_chart = new Infragistics.Win.Misc.UltraPanel();
            this.panCDMode = new Infragistics.Win.Misc.UltraPanel();
            this.panCDModeTab = new Infragistics.Win.Misc.UltraPanel();
            this.tabReticle = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.panCDModeBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.panCDModeRdo = new Infragistics.Win.Misc.UltraPanel();
            this.rdoActive = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.ultraTabPageControl1.SuspendLayout();
            this.panCDModeSubTab.ClientArea.SuspendLayout();
            this.panCDModeSubTab.SuspendLayout();
            this.panReticle_1.ClientArea.SuspendLayout();
            this.panReticle_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).BeginInit();
            this.panCDModeSubTab_chart.SuspendLayout();
            this.ultraTabPageControl2.SuspendLayout();
            this.panCDModeSubTab2.ClientArea.SuspendLayout();
            this.panCDModeSubTab2.SuspendLayout();
            this.panReticle_2.ClientArea.SuspendLayout();
            this.panReticle_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).BeginInit();
            this.panCDModeSubTab2_chart.SuspendLayout();
            this.panCDMode.ClientArea.SuspendLayout();
            this.panCDMode.SuspendLayout();
            this.panCDModeTab.ClientArea.SuspendLayout();
            this.panCDModeTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).BeginInit();
            this.tabReticle.SuspendLayout();
            this.panCDModeBtn.ClientArea.SuspendLayout();
            this.panCDModeBtn.SuspendLayout();
            this.panCDModeRdo.ClientArea.SuspendLayout();
            this.panCDModeRdo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoActive)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.panCDModeSubTab);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(2, 24);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(698, 300);
            // 
            // panCDModeSubTab
            // 
            // 
            // panCDModeSubTab.ClientArea
            // 
            this.panCDModeSubTab.ClientArea.Controls.Add(this.panReticle_1);
            this.panCDModeSubTab.ClientArea.Controls.Add(this.panCDModeSubTab_chart);
            this.panCDModeSubTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDModeSubTab.Location = new System.Drawing.Point(0, 0);
            this.panCDModeSubTab.Name = "panCDModeSubTab";
            this.panCDModeSubTab.Size = new System.Drawing.Size(698, 300);
            this.panCDModeSubTab.TabIndex = 0;
            // 
            // panReticle_1
            // 
            // 
            // panReticle_1.ClientArea
            // 
            this.panReticle_1.ClientArea.Controls.Add(this.rdoTabActive);
            this.panReticle_1.ClientArea.Controls.Add(this.updoneNew1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel2);
            this.panReticle_1.ClientArea.Controls.Add(this.lblTxt1);
            this.panReticle_1.ClientArea.Controls.Add(this.txtCurrent1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel1);
            this.panReticle_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_1.Location = new System.Drawing.Point(0, 0);
            this.panReticle_1.Name = "panReticle_1";
            this.panReticle_1.Size = new System.Drawing.Size(390, 300);
            this.panReticle_1.TabIndex = 2;
            // 
            // rdoTabActive
            // 
            this.rdoTabActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            valueListItem3.DataValue = "Default Item";
            valueListItem3.DisplayText = "Active";
            valueListItem4.DataValue = "ValueListItem1";
            valueListItem4.DisplayText = "Fixed";
            this.rdoTabActive.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.rdoTabActive.ItemSpacingHorizontal = 15;
            this.rdoTabActive.Location = new System.Drawing.Point(98, 13);
            this.rdoTabActive.Name = "rdoTabActive";
            this.rdoTabActive.Size = new System.Drawing.Size(149, 21);
            this.rdoTabActive.TabIndex = 17;
            // 
            // updoneNew1
            // 
            this.updoneNew1.Location = new System.Drawing.Point(98, 91);
            this.updoneNew1.Name = "updoneNew1";
            this.updoneNew1.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1.TabIndex = 16;
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel2.Location = new System.Drawing.Point(140, 57);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(32, 17);
            this.ultraLabel2.TabIndex = 14;
            this.ultraLabel2.Text = "New";
            // 
            // lblTxt1
            // 
            this.lblTxt1.Location = new System.Drawing.Point(15, 91);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.ReadOnly = true;
            this.lblTxt1.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1.TabIndex = 12;
            this.lblTxt1.Text = "Input 1";
            // 
            // txtCurrent1
            // 
            this.txtCurrent1.Location = new System.Drawing.Point(235, 91);
            this.txtCurrent1.Name = "txtCurrent1";
            this.txtCurrent1.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1.TabIndex = 13;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(266, 57);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(49, 17);
            this.ultraLabel1.TabIndex = 15;
            this.ultraLabel1.Text = "Current";
            // 
            // panCDModeSubTab_chart
            // 
            this.panCDModeSubTab_chart.Dock = System.Windows.Forms.DockStyle.Right;
            this.panCDModeSubTab_chart.Location = new System.Drawing.Point(390, 0);
            this.panCDModeSubTab_chart.Name = "panCDModeSubTab_chart";
            this.panCDModeSubTab_chart.Size = new System.Drawing.Size(308, 300);
            this.panCDModeSubTab_chart.TabIndex = 1;
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.panCDModeSubTab2);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(698, 300);
            // 
            // panCDModeSubTab2
            // 
            // 
            // panCDModeSubTab2.ClientArea
            // 
            this.panCDModeSubTab2.ClientArea.Controls.Add(this.panReticle_2);
            this.panCDModeSubTab2.ClientArea.Controls.Add(this.panCDModeSubTab2_chart);
            this.panCDModeSubTab2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDModeSubTab2.Location = new System.Drawing.Point(0, 0);
            this.panCDModeSubTab2.Name = "panCDModeSubTab2";
            this.panCDModeSubTab2.Size = new System.Drawing.Size(698, 300);
            this.panCDModeSubTab2.TabIndex = 0;
            // 
            // panReticle_2
            // 
            // 
            // panReticle_2.ClientArea
            // 
            this.panReticle_2.ClientArea.Controls.Add(this.rdoTabActive2);
            this.panReticle_2.ClientArea.Controls.Add(this.updoneNew1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblNew);
            this.panReticle_2.ClientArea.Controls.Add(this.lblTxt1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.txtCurrent1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblCurrent);
            this.panReticle_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_2.Location = new System.Drawing.Point(0, 0);
            this.panReticle_2.Name = "panReticle_2";
            this.panReticle_2.Size = new System.Drawing.Size(384, 300);
            this.panReticle_2.TabIndex = 2;
            // 
            // rdoTabActive2
            // 
            this.rdoTabActive2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            valueListItem1.DataValue = "Default Item";
            valueListItem1.DisplayText = "Active";
            valueListItem2.DataValue = "ValueListItem1";
            valueListItem2.DisplayText = "Fixed";
            this.rdoTabActive2.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.rdoTabActive2.ItemSpacingHorizontal = 15;
            this.rdoTabActive2.Location = new System.Drawing.Point(105, 19);
            this.rdoTabActive2.Name = "rdoTabActive2";
            this.rdoTabActive2.Size = new System.Drawing.Size(149, 21);
            this.rdoTabActive2.TabIndex = 18;
            // 
            // updoneNew1_2
            // 
            this.updoneNew1_2.Location = new System.Drawing.Point(105, 93);
            this.updoneNew1_2.Name = "updoneNew1_2";
            this.updoneNew1_2.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1_2.TabIndex = 17;
            // 
            // lblNew
            // 
            this.lblNew.AutoSize = true;
            this.lblNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew.Location = new System.Drawing.Point(147, 59);
            this.lblNew.Name = "lblNew";
            this.lblNew.Size = new System.Drawing.Size(32, 17);
            this.lblNew.TabIndex = 15;
            this.lblNew.Text = "New";
            // 
            // lblTxt1_2
            // 
            this.lblTxt1_2.Location = new System.Drawing.Point(22, 93);
            this.lblTxt1_2.Name = "lblTxt1_2";
            this.lblTxt1_2.ReadOnly = true;
            this.lblTxt1_2.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1_2.TabIndex = 13;
            this.lblTxt1_2.Text = "Input 1";
            // 
            // txtCurrent1_2
            // 
            this.txtCurrent1_2.Location = new System.Drawing.Point(242, 93);
            this.txtCurrent1_2.Name = "txtCurrent1_2";
            this.txtCurrent1_2.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1_2.TabIndex = 14;
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(273, 59);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(49, 17);
            this.lblCurrent.TabIndex = 16;
            this.lblCurrent.Text = "Current";
            // 
            // panCDModeSubTab2_chart
            // 
            this.panCDModeSubTab2_chart.Dock = System.Windows.Forms.DockStyle.Right;
            this.panCDModeSubTab2_chart.Location = new System.Drawing.Point(384, 0);
            this.panCDModeSubTab2_chart.Name = "panCDModeSubTab2_chart";
            this.panCDModeSubTab2_chart.Size = new System.Drawing.Size(314, 300);
            this.panCDModeSubTab2_chart.TabIndex = 1;
            // 
            // panCDMode
            // 
            // 
            // panCDMode.ClientArea
            // 
            this.panCDMode.ClientArea.Controls.Add(this.panCDModeTab);
            this.panCDMode.ClientArea.Controls.Add(this.panCDModeBtn);
            this.panCDMode.ClientArea.Controls.Add(this.panCDModeRdo);
            this.panCDMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDMode.Location = new System.Drawing.Point(0, 0);
            this.panCDMode.Name = "panCDMode";
            this.panCDMode.Size = new System.Drawing.Size(702, 428);
            this.panCDMode.TabIndex = 0;
            // 
            // panCDModeTab
            // 
            // 
            // panCDModeTab.ClientArea
            // 
            this.panCDModeTab.ClientArea.Controls.Add(this.tabReticle);
            this.panCDModeTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDModeTab.Location = new System.Drawing.Point(0, 54);
            this.panCDModeTab.Name = "panCDModeTab";
            this.panCDModeTab.Size = new System.Drawing.Size(702, 326);
            this.panCDModeTab.TabIndex = 2;
            // 
            // tabReticle
            // 
            this.tabReticle.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl2);
            this.tabReticle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabReticle.Location = new System.Drawing.Point(0, 0);
            this.tabReticle.Name = "tabReticle";
            this.tabReticle.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabReticle.Size = new System.Drawing.Size(702, 326);
            this.tabReticle.TabIndex = 0;
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "Reticle";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "Reticle2";
            this.tabReticle.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2});
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(698, 300);
            // 
            // panCDModeBtn
            // 
            // 
            // panCDModeBtn.ClientArea
            // 
            this.panCDModeBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panCDModeBtn.ClientArea.Controls.Add(this.btnOk);
            this.panCDModeBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panCDModeBtn.Location = new System.Drawing.Point(0, 380);
            this.panCDModeBtn.Name = "panCDModeBtn";
            this.panCDModeBtn.Size = new System.Drawing.Size(702, 48);
            this.panCDModeBtn.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(592, 13);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(498, 13);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panCDModeRdo
            // 
            // 
            // panCDModeRdo.ClientArea
            // 
            this.panCDModeRdo.ClientArea.Controls.Add(this.rdoActive);
            this.panCDModeRdo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCDModeRdo.Location = new System.Drawing.Point(0, 0);
            this.panCDModeRdo.Name = "panCDModeRdo";
            this.panCDModeRdo.Size = new System.Drawing.Size(702, 54);
            this.panCDModeRdo.TabIndex = 0;
            // 
            // rdoActive
            // 
            this.rdoActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.rdoActive.ItemOrigin = new System.Drawing.Point(5, 5);
            valueListItem5.CheckState = System.Windows.Forms.CheckState.Checked;
            valueListItem5.DataValue = "Default Item";
            valueListItem5.DisplayText = "Active";
            valueListItem6.DataValue = "ValueListItem1";
            valueListItem6.DisplayText = "Fixed";
            this.rdoActive.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem5,
            valueListItem6});
            this.rdoActive.ItemSpacingHorizontal = 15;
            this.rdoActive.Location = new System.Drawing.Point(228, 12);
            this.rdoActive.Name = "rdoActive";
            this.rdoActive.Size = new System.Drawing.Size(140, 27);
            this.rdoActive.TabIndex = 1;
            this.rdoActive.ValueChanged += new System.EventHandler(this.rdoActive_ValueChanged);
            // 
            // frmCDMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 428);
            this.Controls.Add(this.panCDMode);
            this.Name = "frmCDMode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CDMode";
            this.Load += new System.EventHandler(this.frmCDMode_Load);
            this.ultraTabPageControl1.ResumeLayout(false);
            this.panCDModeSubTab.ClientArea.ResumeLayout(false);
            this.panCDModeSubTab.ResumeLayout(false);
            this.panReticle_1.ClientArea.ResumeLayout(false);
            this.panReticle_1.ClientArea.PerformLayout();
            this.panReticle_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).EndInit();
            this.panCDModeSubTab_chart.ResumeLayout(false);
            this.ultraTabPageControl2.ResumeLayout(false);
            this.panCDModeSubTab2.ClientArea.ResumeLayout(false);
            this.panCDModeSubTab2.ResumeLayout(false);
            this.panReticle_2.ClientArea.ResumeLayout(false);
            this.panReticle_2.ClientArea.PerformLayout();
            this.panReticle_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).EndInit();
            this.panCDModeSubTab2_chart.ResumeLayout(false);
            this.panCDMode.ClientArea.ResumeLayout(false);
            this.panCDMode.ResumeLayout(false);
            this.panCDModeTab.ClientArea.ResumeLayout(false);
            this.panCDModeTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).EndInit();
            this.tabReticle.ResumeLayout(false);
            this.panCDModeBtn.ClientArea.ResumeLayout(false);
            this.panCDModeBtn.ResumeLayout(false);
            this.panCDModeRdo.ClientArea.ResumeLayout(false);
            this.panCDModeRdo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoActive)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panCDMode;
        private Infragistics.Win.Misc.UltraPanel panCDModeTab;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabReticle;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.Misc.UltraPanel panCDModeBtn;
        private Infragistics.Win.Misc.UltraPanel panCDModeRdo;
        private Infragistics.Win.Misc.UltraPanel panCDModeSubTab;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoActive;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.Misc.UltraPanel panCDModeSubTab2;
        private Infragistics.Win.Misc.UltraPanel panCDModeSubTab_chart;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoTabActive;
        private System.Windows.Forms.NumericUpDown updoneNew1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1;
        private Infragistics.Win.Misc.UltraPanel panCDModeSubTab2_chart;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoTabActive2;
        private System.Windows.Forms.NumericUpDown updoneNew1_2;
        private Infragistics.Win.Misc.UltraLabel lblCurrent;
        private Infragistics.Win.Misc.UltraLabel lblNew;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1_2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1_2;
        private Infragistics.Win.Misc.UltraPanel panReticle_1;
        private Infragistics.Win.Misc.UltraPanel panReticle_2;
    }
}