﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmManualRun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            this.tabManual = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panChamberA = new Infragistics.Win.Misc.UltraPanel();
            this.updoneNew1 = new System.Windows.Forms.NumericUpDown();
            this.lblCurrent = new Infragistics.Win.Misc.UltraLabel();
            this.lblNew = new Infragistics.Win.Misc.UltraLabel();
            this.txtCurrent1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblTxt1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panChamberB = new Infragistics.Win.Misc.UltraPanel();
            this.updoneNew1_2 = new System.Windows.Forms.NumericUpDown();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.txtCurrent1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblTxt1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panManualRun = new Infragistics.Win.Misc.UltraPanel();
            this.panManualRunTab = new Infragistics.Win.Misc.UltraPanel();
            this.tabManualRun = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.panManualRunBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.ultraSplitter1 = new Infragistics.Win.Misc.UltraSplitter();
            this.panManualRunGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdManualRun = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.tabManual.SuspendLayout();
            this.panChamberA.ClientArea.SuspendLayout();
            this.panChamberA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).BeginInit();
            this.ultraTabPageControl2.SuspendLayout();
            this.panChamberB.ClientArea.SuspendLayout();
            this.panChamberB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).BeginInit();
            this.panManualRun.ClientArea.SuspendLayout();
            this.panManualRun.SuspendLayout();
            this.panManualRunTab.ClientArea.SuspendLayout();
            this.panManualRunTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabManualRun)).BeginInit();
            this.tabManualRun.SuspendLayout();
            this.panManualRunBtn.ClientArea.SuspendLayout();
            this.panManualRunBtn.SuspendLayout();
            this.panManualRunGrid.ClientArea.SuspendLayout();
            this.panManualRunGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdManualRun)).BeginInit();
            this.SuspendLayout();
            // 
            // tabManual
            // 
            this.tabManual.Controls.Add(this.panChamberA);
            this.tabManual.Location = new System.Drawing.Point(-10000, -10000);
            this.tabManual.Name = "tabManual";
            this.tabManual.Size = new System.Drawing.Size(698, 278);
            // 
            // panChamberA
            // 
            // 
            // panChamberA.ClientArea
            // 
            this.panChamberA.ClientArea.Controls.Add(this.updoneNew1);
            this.panChamberA.ClientArea.Controls.Add(this.lblCurrent);
            this.panChamberA.ClientArea.Controls.Add(this.lblNew);
            this.panChamberA.ClientArea.Controls.Add(this.txtCurrent1);
            this.panChamberA.ClientArea.Controls.Add(this.lblTxt1);
            this.panChamberA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChamberA.Location = new System.Drawing.Point(0, 0);
            this.panChamberA.Name = "panChamberA";
            this.panChamberA.Size = new System.Drawing.Size(698, 278);
            this.panChamberA.TabIndex = 0;
            // 
            // updoneNew1
            // 
            this.updoneNew1.Location = new System.Drawing.Point(115, 63);
            this.updoneNew1.Name = "updoneNew1";
            this.updoneNew1.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1.TabIndex = 10;
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(283, 29);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(49, 17);
            this.lblCurrent.TabIndex = 9;
            this.lblCurrent.Text = "Current";
            // 
            // lblNew
            // 
            this.lblNew.AutoSize = true;
            this.lblNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew.Location = new System.Drawing.Point(157, 29);
            this.lblNew.Name = "lblNew";
            this.lblNew.Size = new System.Drawing.Size(32, 17);
            this.lblNew.TabIndex = 8;
            this.lblNew.Text = "New";
            // 
            // txtCurrent1
            // 
            this.txtCurrent1.Location = new System.Drawing.Point(252, 63);
            this.txtCurrent1.Name = "txtCurrent1";
            this.txtCurrent1.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1.TabIndex = 7;
            // 
            // lblTxt1
            // 
            this.lblTxt1.Location = new System.Drawing.Point(32, 63);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.ReadOnly = true;
            this.lblTxt1.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1.TabIndex = 6;
            this.lblTxt1.Text = "Input 1";
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.panChamberB);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(2, 24);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(698, 278);
            // 
            // panChamberB
            // 
            // 
            // panChamberB.ClientArea
            // 
            this.panChamberB.ClientArea.Controls.Add(this.updoneNew1_2);
            this.panChamberB.ClientArea.Controls.Add(this.ultraLabel1);
            this.panChamberB.ClientArea.Controls.Add(this.ultraLabel2);
            this.panChamberB.ClientArea.Controls.Add(this.txtCurrent1_2);
            this.panChamberB.ClientArea.Controls.Add(this.lblTxt1_2);
            this.panChamberB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panChamberB.Location = new System.Drawing.Point(0, 0);
            this.panChamberB.Name = "panChamberB";
            this.panChamberB.Size = new System.Drawing.Size(698, 278);
            this.panChamberB.TabIndex = 0;
            // 
            // updoneNew1_2
            // 
            this.updoneNew1_2.Location = new System.Drawing.Point(109, 58);
            this.updoneNew1_2.Name = "updoneNew1_2";
            this.updoneNew1_2.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1_2.TabIndex = 10;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(277, 24);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(49, 17);
            this.ultraLabel1.TabIndex = 9;
            this.ultraLabel1.Text = "Current";
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel2.Location = new System.Drawing.Point(151, 24);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(32, 17);
            this.ultraLabel2.TabIndex = 8;
            this.ultraLabel2.Text = "New";
            // 
            // txtCurrent1_2
            // 
            this.txtCurrent1_2.Location = new System.Drawing.Point(246, 58);
            this.txtCurrent1_2.Name = "txtCurrent1_2";
            this.txtCurrent1_2.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1_2.TabIndex = 7;
            // 
            // lblTxt1_2
            // 
            this.lblTxt1_2.Location = new System.Drawing.Point(26, 58);
            this.lblTxt1_2.Name = "lblTxt1_2";
            this.lblTxt1_2.ReadOnly = true;
            this.lblTxt1_2.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1_2.TabIndex = 6;
            this.lblTxt1_2.Text = "Input 1";
            // 
            // panManualRun
            // 
            // 
            // panManualRun.ClientArea
            // 
            this.panManualRun.ClientArea.Controls.Add(this.panManualRunTab);
            this.panManualRun.ClientArea.Controls.Add(this.panManualRunBtn);
            this.panManualRun.ClientArea.Controls.Add(this.ultraSplitter1);
            this.panManualRun.ClientArea.Controls.Add(this.panManualRunGrid);
            this.panManualRun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panManualRun.Location = new System.Drawing.Point(0, 0);
            this.panManualRun.Name = "panManualRun";
            this.panManualRun.Size = new System.Drawing.Size(702, 552);
            this.panManualRun.TabIndex = 0;
            // 
            // panManualRunTab
            // 
            // 
            // panManualRunTab.ClientArea
            // 
            this.panManualRunTab.ClientArea.Controls.Add(this.tabManualRun);
            this.panManualRunTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panManualRunTab.Location = new System.Drawing.Point(0, 192);
            this.panManualRunTab.Name = "panManualRunTab";
            this.panManualRunTab.Size = new System.Drawing.Size(702, 304);
            this.panManualRunTab.TabIndex = 3;
            // 
            // tabManualRun
            // 
            this.tabManualRun.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabManualRun.Controls.Add(this.tabManual);
            this.tabManualRun.Controls.Add(this.ultraTabPageControl2);
            this.tabManualRun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabManualRun.Location = new System.Drawing.Point(0, 0);
            this.tabManualRun.Name = "tabManualRun";
            this.tabManualRun.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabManualRun.Size = new System.Drawing.Size(702, 304);
            this.tabManualRun.TabIndex = 0;
            ultraTab1.TabPage = this.tabManual;
            ultraTab1.Text = "CHAMBER_A";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "CHAMBER_B";
            this.tabManualRun.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2});
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(698, 278);
            // 
            // panManualRunBtn
            // 
            // 
            // panManualRunBtn.ClientArea
            // 
            this.panManualRunBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panManualRunBtn.ClientArea.Controls.Add(this.btnOk);
            this.panManualRunBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panManualRunBtn.Location = new System.Drawing.Point(0, 496);
            this.panManualRunBtn.Name = "panManualRunBtn";
            this.panManualRunBtn.Size = new System.Drawing.Size(702, 56);
            this.panManualRunBtn.TabIndex = 2;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(582, 21);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(464, 21);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // ultraSplitter1
            // 
            this.ultraSplitter1.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraSplitter1.Location = new System.Drawing.Point(0, 186);
            this.ultraSplitter1.Name = "ultraSplitter1";
            this.ultraSplitter1.RestoreExtent = 186;
            this.ultraSplitter1.Size = new System.Drawing.Size(702, 6);
            this.ultraSplitter1.TabIndex = 1;
            // 
            // panManualRunGrid
            // 
            // 
            // panManualRunGrid.ClientArea
            // 
            this.panManualRunGrid.ClientArea.Controls.Add(this.grdManualRun);
            this.panManualRunGrid.Dock = System.Windows.Forms.DockStyle.Top;
            this.panManualRunGrid.Location = new System.Drawing.Point(0, 0);
            this.panManualRunGrid.Name = "panManualRunGrid";
            this.panManualRunGrid.Size = new System.Drawing.Size(702, 186);
            this.panManualRunGrid.TabIndex = 0;
            // 
            // grdManualRun
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdManualRun.DisplayLayout.Appearance = appearance1;
            this.grdManualRun.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdManualRun.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdManualRun.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdManualRun.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdManualRun.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdManualRun.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdManualRun.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdManualRun.DisplayLayout.MaxColScrollRegions = 1;
            this.grdManualRun.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdManualRun.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdManualRun.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdManualRun.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdManualRun.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdManualRun.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdManualRun.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdManualRun.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdManualRun.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdManualRun.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdManualRun.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdManualRun.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdManualRun.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdManualRun.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdManualRun.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdManualRun.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdManualRun.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdManualRun.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdManualRun.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdManualRun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdManualRun.Location = new System.Drawing.Point(0, 0);
            this.grdManualRun.Name = "grdManualRun";
            this.grdManualRun.Size = new System.Drawing.Size(702, 186);
            this.grdManualRun.TabIndex = 0;
            this.grdManualRun.Text = "ultraGrid1";
            // 
            // frmManualRun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 552);
            this.Controls.Add(this.panManualRun);
            this.Name = "frmManualRun";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmManualRun";
            this.Load += new System.EventHandler(this.frmManualRun_Load);
            this.tabManual.ResumeLayout(false);
            this.panChamberA.ClientArea.ResumeLayout(false);
            this.panChamberA.ClientArea.PerformLayout();
            this.panChamberA.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).EndInit();
            this.ultraTabPageControl2.ResumeLayout(false);
            this.panChamberB.ClientArea.ResumeLayout(false);
            this.panChamberB.ClientArea.PerformLayout();
            this.panChamberB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).EndInit();
            this.panManualRun.ClientArea.ResumeLayout(false);
            this.panManualRun.ResumeLayout(false);
            this.panManualRunTab.ClientArea.ResumeLayout(false);
            this.panManualRunTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabManualRun)).EndInit();
            this.tabManualRun.ResumeLayout(false);
            this.panManualRunBtn.ClientArea.ResumeLayout(false);
            this.panManualRunBtn.ResumeLayout(false);
            this.panManualRunGrid.ClientArea.ResumeLayout(false);
            this.panManualRunGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdManualRun)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panManualRun;
        private Infragistics.Win.Misc.UltraPanel panManualRunTab;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabManualRun;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl tabManual;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.Misc.UltraPanel panManualRunBtn;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter1;
        private Infragistics.Win.Misc.UltraPanel panManualRunGrid;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdManualRun;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.Misc.UltraPanel panChamberA;
        private Infragistics.Win.Misc.UltraPanel panChamberB;
        private System.Windows.Forms.NumericUpDown updoneNew1;
        private Infragistics.Win.Misc.UltraLabel lblCurrent;
        private Infragistics.Win.Misc.UltraLabel lblNew;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1;
        private System.Windows.Forms.NumericUpDown updoneNew1_2;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1_2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1_2;
    }
}