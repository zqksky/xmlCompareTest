﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmLinearReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCurrent = new Infragistics.Win.Misc.UltraLabel();
            this.lblNew = new Infragistics.Win.Misc.UltraLabel();
            this.txtCurrent = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblTxt1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panLinearReset = new Infragistics.Win.Misc.UltraPanel();
            this.panReset = new Infragistics.Win.Misc.UltraPanel();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.txtNew = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panLinearResetBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).BeginInit();
            this.panLinearReset.ClientArea.SuspendLayout();
            this.panLinearReset.SuspendLayout();
            this.panReset.ClientArea.SuspendLayout();
            this.panReset.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNew)).BeginInit();
            this.panLinearResetBtn.ClientArea.SuspendLayout();
            this.panLinearResetBtn.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(163, 22);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(49, 17);
            this.lblCurrent.TabIndex = 3;
            this.lblCurrent.Text = "Current";
            // 
            // lblNew
            // 
            this.lblNew.AutoSize = true;
            this.lblNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew.Location = new System.Drawing.Point(270, 22);
            this.lblNew.Name = "lblNew";
            this.lblNew.Size = new System.Drawing.Size(32, 17);
            this.lblNew.TabIndex = 2;
            this.lblNew.Text = "New";
            // 
            // txtCurrent
            // 
            this.txtCurrent.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            this.txtCurrent.Location = new System.Drawing.Point(144, 54);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent.TabIndex = 1;
            // 
            // lblTxt1
            // 
            this.lblTxt1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.lblTxt1.Location = new System.Drawing.Point(41, 55);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.ReadOnly = true;
            this.lblTxt1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTxt1.Size = new System.Drawing.Size(92, 19);
            this.lblTxt1.TabIndex = 0;
            this.lblTxt1.Text = "Input 1";
            // 
            // panLinearReset
            // 
            // 
            // panLinearReset.ClientArea
            // 
            this.panLinearReset.ClientArea.Controls.Add(this.panReset);
            this.panLinearReset.ClientArea.Controls.Add(this.panLinearResetBtn);
            this.panLinearReset.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panLinearReset.Location = new System.Drawing.Point(0, 0);
            this.panLinearReset.Name = "panLinearReset";
            this.panLinearReset.Size = new System.Drawing.Size(419, 452);
            this.panLinearReset.TabIndex = 0;
            // 
            // panReset
            // 
            this.panReset.AutoScroll = true;
            // 
            // panReset.ClientArea
            // 
            this.panReset.ClientArea.Controls.Add(this.ultraLabel1);
            this.panReset.ClientArea.Controls.Add(this.txtNew);
            this.panReset.ClientArea.Controls.Add(this.lblNew);
            this.panReset.ClientArea.Controls.Add(this.lblTxt1);
            this.panReset.ClientArea.Controls.Add(this.lblCurrent);
            this.panReset.ClientArea.Controls.Add(this.txtCurrent);
            this.panReset.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReset.Location = new System.Drawing.Point(0, 0);
            this.panReset.Name = "panReset";
            this.panReset.Size = new System.Drawing.Size(419, 403);
            this.panReset.TabIndex = 2;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(61, 22);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(41, 17);
            this.ultraLabel1.TabIndex = 5;
            this.ultraLabel1.Text = "Name";
            // 
            // txtNew
            // 
            this.txtNew.Location = new System.Drawing.Point(255, 54);
            this.txtNew.Name = "txtNew";
            this.txtNew.Size = new System.Drawing.Size(100, 21);
            this.txtNew.TabIndex = 4;
            // 
            // panLinearResetBtn
            // 
            // 
            // panLinearResetBtn.ClientArea
            // 
            this.panLinearResetBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panLinearResetBtn.ClientArea.Controls.Add(this.btnOk);
            this.panLinearResetBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panLinearResetBtn.Location = new System.Drawing.Point(0, 403);
            this.panLinearResetBtn.Name = "panLinearResetBtn";
            this.panLinearResetBtn.Size = new System.Drawing.Size(419, 49);
            this.panLinearResetBtn.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(312, 14);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(207, 14);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmLinearReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 452);
            this.Controls.Add(this.panLinearReset);
            this.Name = "frmLinearReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LinearReset";
            this.Load += new System.EventHandler(this.frmLinearReset_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).EndInit();
            this.panLinearReset.ClientArea.ResumeLayout(false);
            this.panLinearReset.ResumeLayout(false);
            this.panReset.ClientArea.ResumeLayout(false);
            this.panReset.ClientArea.PerformLayout();
            this.panReset.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtNew)).EndInit();
            this.panLinearResetBtn.ClientArea.ResumeLayout(false);
            this.panLinearResetBtn.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panLinearReset;
        private Infragistics.Win.Misc.UltraPanel panLinearResetBtn;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.Misc.UltraPanel panReset;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1;
        private Infragistics.Win.Misc.UltraLabel lblCurrent;
        private Infragistics.Win.Misc.UltraLabel lblNew;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtNew;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
    }
}