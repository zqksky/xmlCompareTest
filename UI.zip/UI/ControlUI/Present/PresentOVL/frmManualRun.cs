﻿using ControlUI.Comman;
using Infragistics.Win.UltraWinEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmManualRun : Form
    {
        public frmManualRun()
        {
            InitializeComponent();
        }

        public frmManualRun(List<string> strListReticle, List<string> strListReticle2, int num)
        {
            InitializeComponent();
            nReticle = num;
            strListCurrent = new List<string>(strListReticle);
            if (nReticle > 1)
            {
                strListCurrent_2 = new List<string>(strListReticle2);
            }
        }

        #region parm
        public int nReticle;
        public List<string> strListNew = new List<string>();
        public List<string> strListCurrent = new List<string>();
        public List<string> strListNew_2 = new List<string>();
        public List<string> strListCurrent_2 = new List<string>();

        List<UltraTextEditor> ctlLableTxtControl = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlCurrentTxtControl = new List<UltraTextEditor>();
        List<NumericUpDown> ctlNewTxtControl = new List<NumericUpDown>();

        List<UltraTextEditor> ctlLableTxtControl_2 = new List<UltraTextEditor>();
        List<UltraTextEditor> ctlCurrentTxtControl_2 = new List<UltraTextEditor>();
        List<NumericUpDown> ctlNewTxtControl_2 = new List<NumericUpDown>();
        #endregion

        private void frmManualRun_Load(object sender, EventArgs e)
        {
            #region
            tabManualRun.Tabs[1].Visible = false;

            AddControlHelp.AutoAddLableControl(strListCurrent, ref ctlLableTxtControl, lblTxt1, panChamberA);
            AddControlHelp.AutoAddNewTxtControl(strListCurrent, ref ctlNewTxtControl, updoneNew1, panChamberA);
            AddControlHelp.AutoAddCurrentTxtControl(strListCurrent, ref ctlCurrentTxtControl, txtCurrent1, panChamberA);

            if (nReticle > 1)
            {
                tabManualRun.Tabs[1].Visible = true;
                AddControlHelp.AutoAddLableControl(strListCurrent_2, ref ctlLableTxtControl_2, lblTxt1_2, panChamberB);
                AddControlHelp.AutoAddNewTxtControl(strListCurrent_2, ref ctlNewTxtControl_2, updoneNew1_2, panChamberB);
                AddControlHelp.AutoAddCurrentTxtControl(strListCurrent_2, ref ctlCurrentTxtControl_2, txtCurrent1_2, panChamberB);
            }
            //AddControlHelp.AutoAddControlTest(strListCurrent, ref ctlLableTxtControl, ref ctlNewTxtControl, ref ctlCurrentTxtControl, panBatchR2RModeTab_2);
            #endregion
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            strListNew.Add(updoneNew1.Text.ToString());
            if (ctlNewTxtControl.Count > 0)
            {
                foreach (var ctl in ctlNewTxtControl)
                {
                    strListNew.Add(ctl.Text.ToString());
                }
            }
            if (nReticle > 1)
            {
                strListNew_2.Add(updoneNew1_2.Text.ToString());
                if (ctlNewTxtControl.Count > 0)
                {
                    foreach (var ctl in ctlNewTxtControl_2)
                    {
                        strListNew.Add(ctl.Text.ToString());
                    }
                }
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
