﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmCPEMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panCPEMode = new Infragistics.Win.Misc.UltraPanel();
            this.panCPEModeBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.panCPEModeTxt = new Infragistics.Win.Misc.UltraPanel();
            this.txtLastDate = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtFileName = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panCPEMode.ClientArea.SuspendLayout();
            this.panCPEMode.SuspendLayout();
            this.panCPEModeBtn.ClientArea.SuspendLayout();
            this.panCPEModeBtn.SuspendLayout();
            this.panCPEModeTxt.ClientArea.SuspendLayout();
            this.panCPEModeTxt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtLastDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFileName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            this.SuspendLayout();
            // 
            // panCPEMode
            // 
            // 
            // panCPEMode.ClientArea
            // 
            this.panCPEMode.ClientArea.Controls.Add(this.panCPEModeBtn);
            this.panCPEMode.ClientArea.Controls.Add(this.panCPEModeTxt);
            this.panCPEMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCPEMode.Location = new System.Drawing.Point(0, 0);
            this.panCPEMode.Name = "panCPEMode";
            this.panCPEMode.Size = new System.Drawing.Size(371, 221);
            this.panCPEMode.TabIndex = 0;
            // 
            // panCPEModeBtn
            // 
            // 
            // panCPEModeBtn.ClientArea
            // 
            this.panCPEModeBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panCPEModeBtn.ClientArea.Controls.Add(this.btnOk);
            this.panCPEModeBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panCPEModeBtn.Location = new System.Drawing.Point(0, 174);
            this.panCPEModeBtn.Name = "panCPEModeBtn";
            this.panCPEModeBtn.Size = new System.Drawing.Size(371, 47);
            this.panCPEModeBtn.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(274, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(180, 12);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panCPEModeTxt
            // 
            // 
            // panCPEModeTxt.ClientArea
            // 
            this.panCPEModeTxt.ClientArea.Controls.Add(this.txtLastDate);
            this.panCPEModeTxt.ClientArea.Controls.Add(this.txtFileName);
            this.panCPEModeTxt.ClientArea.Controls.Add(this.ultraTextEditor2);
            this.panCPEModeTxt.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panCPEModeTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCPEModeTxt.Location = new System.Drawing.Point(0, 0);
            this.panCPEModeTxt.Name = "panCPEModeTxt";
            this.panCPEModeTxt.Size = new System.Drawing.Size(371, 221);
            this.panCPEModeTxt.TabIndex = 0;
            // 
            // txtLastDate
            // 
            this.txtLastDate.Location = new System.Drawing.Point(164, 88);
            this.txtLastDate.Name = "txtLastDate";
            this.txtLastDate.Size = new System.Drawing.Size(172, 21);
            this.txtLastDate.TabIndex = 3;
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(164, 46);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(172, 21);
            this.txtFileName.TabIndex = 2;
            // 
            // ultraTextEditor2
            // 
            this.ultraTextEditor2.Location = new System.Drawing.Point(32, 88);
            this.ultraTextEditor2.Name = "ultraTextEditor2";
            this.ultraTextEditor2.ReadOnly = true;
            this.ultraTextEditor2.Size = new System.Drawing.Size(100, 21);
            this.ultraTextEditor2.TabIndex = 1;
            this.ultraTextEditor2.Text = "Last Updates";
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Location = new System.Drawing.Point(32, 46);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(100, 21);
            this.ultraTextEditor1.TabIndex = 0;
            this.ultraTextEditor1.Text = "Current File Name";
            // 
            // frmCPEMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 221);
            this.Controls.Add(this.panCPEMode);
            this.Name = "frmCPEMode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CPEMode";
            this.Load += new System.EventHandler(this.frmCPEMode_Load);
            this.panCPEMode.ClientArea.ResumeLayout(false);
            this.panCPEMode.ResumeLayout(false);
            this.panCPEModeBtn.ClientArea.ResumeLayout(false);
            this.panCPEModeBtn.ResumeLayout(false);
            this.panCPEModeTxt.ClientArea.ResumeLayout(false);
            this.panCPEModeTxt.ClientArea.PerformLayout();
            this.panCPEModeTxt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtLastDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFileName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panCPEMode;
        private Infragistics.Win.Misc.UltraPanel panCPEModeBtn;
        private Infragistics.Win.Misc.UltraPanel panCPEModeTxt;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtLastDate;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtFileName;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
    }
}