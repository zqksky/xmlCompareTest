﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmBatchPMOffset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            this.panBatchPMOffsetBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.grdBatchPMOffet = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panBatchPMOffset = new Infragistics.Win.Misc.UltraPanel();
            this.panGrdBatchPMOffset = new Infragistics.Win.Misc.UltraPanel();
            this.panBatchPMOffsetBtn.ClientArea.SuspendLayout();
            this.panBatchPMOffsetBtn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchPMOffet)).BeginInit();
            this.panBatchPMOffset.ClientArea.SuspendLayout();
            this.panBatchPMOffset.SuspendLayout();
            this.panGrdBatchPMOffset.ClientArea.SuspendLayout();
            this.panGrdBatchPMOffset.SuspendLayout();
            this.SuspendLayout();
            // 
            // panBatchPMOffsetBtn
            // 
            // 
            // panBatchPMOffsetBtn.ClientArea
            // 
            this.panBatchPMOffsetBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panBatchPMOffsetBtn.ClientArea.Controls.Add(this.btnOk);
            this.panBatchPMOffsetBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBatchPMOffsetBtn.Location = new System.Drawing.Point(0, 265);
            this.panBatchPMOffsetBtn.Name = "panBatchPMOffsetBtn";
            this.panBatchPMOffsetBtn.Size = new System.Drawing.Size(523, 54);
            this.panBatchPMOffsetBtn.TabIndex = 4;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(406, 18);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 24);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(312, 18);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 24);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // grdBatchPMOffet
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdBatchPMOffet.DisplayLayout.Appearance = appearance1;
            this.grdBatchPMOffet.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchPMOffet.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchPMOffet.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchPMOffet.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdBatchPMOffet.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchPMOffet.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchPMOffet.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdBatchPMOffet.DisplayLayout.MaxColScrollRegions = 1;
            this.grdBatchPMOffet.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdBatchPMOffet.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdBatchPMOffet.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdBatchPMOffet.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdBatchPMOffet.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdBatchPMOffet.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdBatchPMOffet.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdBatchPMOffet.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdBatchPMOffet.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchPMOffet.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdBatchPMOffet.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdBatchPMOffet.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdBatchPMOffet.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdBatchPMOffet.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdBatchPMOffet.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdBatchPMOffet.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdBatchPMOffet.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdBatchPMOffet.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdBatchPMOffet.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdBatchPMOffet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdBatchPMOffet.Location = new System.Drawing.Point(0, 0);
            this.grdBatchPMOffet.Name = "grdBatchPMOffet";
            this.grdBatchPMOffet.Size = new System.Drawing.Size(523, 265);
            this.grdBatchPMOffet.TabIndex = 0;
            this.grdBatchPMOffet.Text = "List Of Context Group";
            this.grdBatchPMOffet.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdBatchPMOffet_InitializeLayout);
            this.grdBatchPMOffet.Error += new Infragistics.Win.UltraWinGrid.ErrorEventHandler(this.grdBatchPMOffet_Error);
            this.grdBatchPMOffet.CellDataError += new Infragistics.Win.UltraWinGrid.CellDataErrorEventHandler(this.grdBatchPMOffet_CellDataError);
            // 
            // panBatchPMOffset
            // 
            // 
            // panBatchPMOffset.ClientArea
            // 
            this.panBatchPMOffset.ClientArea.Controls.Add(this.panGrdBatchPMOffset);
            this.panBatchPMOffset.ClientArea.Controls.Add(this.panBatchPMOffsetBtn);
            this.panBatchPMOffset.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchPMOffset.Location = new System.Drawing.Point(0, 0);
            this.panBatchPMOffset.Name = "panBatchPMOffset";
            this.panBatchPMOffset.Size = new System.Drawing.Size(523, 319);
            this.panBatchPMOffset.TabIndex = 0;
            // 
            // panGrdBatchPMOffset
            // 
            // 
            // panGrdBatchPMOffset.ClientArea
            // 
            this.panGrdBatchPMOffset.ClientArea.Controls.Add(this.grdBatchPMOffet);
            this.panGrdBatchPMOffset.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panGrdBatchPMOffset.Location = new System.Drawing.Point(0, 0);
            this.panGrdBatchPMOffset.Name = "panGrdBatchPMOffset";
            this.panGrdBatchPMOffset.Size = new System.Drawing.Size(523, 265);
            this.panGrdBatchPMOffset.TabIndex = 5;
            // 
            // frmBatchPMOffset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 319);
            this.Controls.Add(this.panBatchPMOffset);
            this.Name = "frmBatchPMOffset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmBatchPMOffset";
            this.Load += new System.EventHandler(this.frmBatchPMOffset_Load);
            this.panBatchPMOffsetBtn.ClientArea.ResumeLayout(false);
            this.panBatchPMOffsetBtn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchPMOffet)).EndInit();
            this.panBatchPMOffset.ClientArea.ResumeLayout(false);
            this.panBatchPMOffset.ResumeLayout(false);
            this.panGrdBatchPMOffset.ClientArea.ResumeLayout(false);
            this.panGrdBatchPMOffset.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panBatchPMOffsetBtn;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdBatchPMOffet;
        private Infragistics.Win.Misc.UltraPanel panBatchPMOffset;
        private Infragistics.Win.Misc.UltraPanel panGrdBatchPMOffset;
    }
}