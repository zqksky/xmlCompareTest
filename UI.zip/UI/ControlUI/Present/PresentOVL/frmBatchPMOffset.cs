﻿using ControlUI.Comman;
using Infragistics.Win.Misc;
using Infragistics.Win.UltraWinEditors;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmBatchPMOffset : Form
    {
        public frmBatchPMOffset()
        {
            InitializeComponent();
        }

        public frmBatchPMOffset(string strServiceName, string strFrmTool,UIServiceFun.structPH_OVL_Batch_GetPMOffsets structDataPMOffset)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strTool = strFrmTool;
            structData = structDataPMOffset;

            if (structData.iListInputIndex.Count > 0)
            {
                iListInputIndex = new List<int>(structData.iListInputIndex);
                dListPMOffsets = new List<double>(structData.dListPMOffsets);
                strListInputNames = new List<string>(structData.strListInputNames);
                strListInputModels = new List<string>(structData.strListInputModels);
            }
        }

        #region Param
        public string strTool;
        public string strServiceAddres;

        public List<int> iListInputIndex;
        public List<double> dListPMOffsets;
        public List<string> strListInputNames;
        public List<string> strListInputModels;

        UIServiceFun.structPH_OVL_Batch_GetPMOffsets structData = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
        UIServiceFun.structPH_OVL_Batch_UpdatePMOffsets structDataUpdate = new UIServiceFun.structPH_OVL_Batch_UpdatePMOffsets();
        #endregion

        private void InitGrid(UltraGrid ctlGrid, DataTable tb)
        {
            ctlGrid.DataSource = tb;

            //禁止编辑
            if (ctlGrid.DisplayLayout.Bands[0].Columns.Count > 3)
            {
                ctlGrid.DisplayLayout.Bands[0].Columns[0].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[1].CellActivation = Activation.NoEdit;
                ctlGrid.DisplayLayout.Bands[0].Columns[2].CellActivation = Activation.NoEdit;
            }

            //ctlGrid.DisplayLayout.Bands[0].Columns[3].RegexPattern = @"^[0-9.]*$";

            //ctlGrid.DisplayLayout.Bands[0].Columns[3].DataType = typeof(double);

            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //ctlGrid.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //ctlGrid.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //ctlGrid.DisplayLayout.Override.ColumnAutoSizeMode = ColumnAutoSizeMode.VisibleRows;
            //ctlGrid.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //ctlGrid.Rows[0].PerformAutoSize();
            //ctlGrid.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
        }

        private void GetGridValue()
        {
            int rowCount = 0;
            rowCount = grdBatchPMOffet.Rows.Count;
            if (rowCount > 0)
            {
                strListInputNames.Clear();
                strListInputModels.Clear();
                dListPMOffsets.Clear();
                for (int i = 0; i < rowCount; i++)
                {
                    strListInputNames.Add(grdBatchPMOffet.Rows[i].Cells[1].Value.ToString());
                    strListInputModels.Add(grdBatchPMOffet.Rows[i].Cells[2].Value.ToString());
                    dListPMOffsets.Add(double.Parse(grdBatchPMOffet.Rows[i].Cells[3].Value.ToString()));
                }
            }
            structDataUpdate.strListInputModels = new List<string>(strListInputModels);
            structDataUpdate.strListInputNames = new List<string>(strListInputNames);
            structDataUpdate.dListPMOffset = new List<double>(dListPMOffsets);
        }

        private void frmBatchPMOffset_Load(object sender, EventArgs e)
        {
            InitGrid(grdBatchPMOffet, DataTableHelp.CreateBatchPMOffsetTable(structData));
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            bool bSuccess;
            try
            {
                #region PH_OVL_Batch_UpdatePMOffsets
                GetGridValue();
                if (dListPMOffsets.Count>0 && !structDataUpdate.dListPMOffset.SequenceEqual(structData.dListPMOffsets))
                {
                    bSuccess = UIServiceFun.R2R_UI_PH_OVL_Batch_UpdatePMOffsets(strServiceAddres, strTool, structDataUpdate);
                    if (bSuccess)
                    {
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Set Failed!");
                    }
                }
                
                this.DialogResult = DialogResult.OK;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grdBatchPMOffet_InitializeLayout(object sender, InitializeLayoutEventArgs e)
        {
            e.Layout.Override.InvalidValueBehavior = InvalidValueBehavior.RevertValue;
            e.Layout.Bands[0].Columns[3].InvalidValueBehavior = InvalidValueBehavior.RetainValueAndFocus;

        }

        private void grdBatchPMOffet_CellDataError(object sender, CellDataErrorEventArgs e)
        {
            //e.RaiseErrorEvent = false;       // 阻止弹出错误提示窗口
            e.RestoreOriginalValue = true;   // 恢复原始值
            e.StayInEditMode = true;         // 继续保留在编辑模式
        }

        private void grdBatchPMOffet_Error(object sender, ErrorEventArgs e)
        {
            e.Cancel = true;
            if (e.ErrorType == ErrorType.Data)
            {
                MessageBox.Show("That is not a valid number!!");
            }
        }
    }
}
