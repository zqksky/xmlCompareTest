﻿using ControlUI.Comman;
using Infragistics.Win.UltraWinGrid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI.Present.PresentOVL
{
    public partial class frmChuckDedication : Form
    {
        public frmChuckDedication()
        {
            InitializeComponent();
        }

        public frmChuckDedication(string strServiceName,DataTable db)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            dbContext = db;
            grdContextGroup.DataSource = dbContext;
        }

        #region Param
        public string strServiceAddress;
        public string strLotId;
        public string strLayer;
        public string strFabName;
        public DataTable dbContext;
        public List<string> strListSlotIds=new List<string>();
        public List<string> strListChuckIds=new List<string>();
        UIServiceFun.structPH_OVL_ChuckDedication structData = new UIServiceFun.structPH_OVL_ChuckDedication();
        #endregion

        private void InitGrid(UltraGrid ctlGrid, DataTable tb)
        {
            ctlGrid.DataSource = tb;

            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ExtendLastColumn;
            //ctlGrid.DisplayLayout.AutoFitStyle = AutoFitStyle.ResizeAllColumns;
            //ctlGrid.DisplayLayout.Override.AllowRowFiltering = DefaultableBoolean.True;

            //ctlGrid.DisplayLayout.Override.AllowColSizing = AllowColSizing.Free;
            //ctlGrid.DisplayLayout.Override.ColumnAutoSizeMode = ColumnAutoSizeMode.VisibleRows;
            //ctlGrid.DisplayLayout.Bands[0].Override.ColumnAutoSizeMode = ColumnAutoSizeMode.AllRowsInBand;

            //ctlGrid.Rows[0].PerformAutoSize();
            //ctlGrid.DisplayLayout.GroupByBox.ShowBandLabels = ShowBandLabels.All;
        }

        private void InitStruct()
        {
            if (grdQueryLotInfo.Rows.Count > 0)
            {
                strListSlotIds.Clear();
                strListChuckIds.Clear();
                structData.strListSlotIds = new List<string>();
                structData.strListChuckIds = new List<string>();

                for (int i = 0; i < grdQueryLotInfo.Rows.Count; i++)
                {
                    //MessageBox.Show(grdQueryLotInfo.Rows[i].Cells[1].Value.ToString());
                    //MessageBox.Show(grdQueryLotInfo.Rows[i].Cells[2].Value.ToString());
                    if (grdQueryLotInfo.Rows[i].Cells[1].Value.ToString().Equals(""))
                    {
                        //grdQueryLotInfo.Rows[i].Cells[1].Value = "NA";
                    }
                    if (grdQueryLotInfo.Rows[i].Cells[2].Value.ToString().Equals(""))
                    {
                        grdQueryLotInfo.Rows[i].Cells[2].Value = "NA";
                    }
                    strListSlotIds.Add(grdQueryLotInfo.Rows[i].Cells[1].Value.ToString());
                    strListChuckIds.Add(grdQueryLotInfo.Rows[i].Cells[2].Value.ToString());

                    structData.strListSlotIds.Add(grdQueryLotInfo.Rows[i].Cells[1].Value.ToString());
                    structData.strListChuckIds.Add(grdQueryLotInfo.Rows[i].Cells[2].Value.ToString());
                }
            }
        }

        private void SetTextBox()
        {
            ////让文本框获取焦点 
            //this.txtLotId.Focus();

            ////设置光标的位置到文本尾 
            //this.txtLotId.Select(this.txtLotId.TextLength, 0);

            ////滚动到控件光标处 
            //this.txtLotId.ScrollToCaret();
        }

        private void frmChuckDedication_Load(object sender, EventArgs e)
        {
            //AceptButton ＝[要响应回车的button Name]
            //CancelButton ＝[要取消的button]
            //this.KeyPreview = true;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            bool bSuccess;
            strLotId = txtLotId.Text.ToString().Trim();
            strLayer = txtLayer.Text.ToString().Trim();
            try
            {
                #region PH_OVL_ChuckDedication
                if (strLotId.Equals("") || strLayer.Equals(""))
                {
                    MessageBox.Show("The parameter cannot be empty");
                }
                else
                {
                    //bSuccess = UIServiceFun.R2R_UI_PH_OVL_ChuckDedication(strServiceAddress, strLotId, strLayer, strListSlotIds,strListChuckIds);
                    bSuccess = UIServiceFun.R2R_UI_PH_OVL_ChuckDedication(strServiceAddress, strLotId, strLayer, structData);
                    if (bSuccess)
                    {
                        //MessageBox.Show("Set Successed!");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Set Failed!");
                    }
                }
                this.DialogResult = DialogResult.OK;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

        }

        private void txtLotId_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtLotId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                //MessageBox.Show("Enter-key-press");
                //MessageBox.Show("Enter-key-down");
                //this.button1_Click(sender, e);//触发button事件
            }
        }

        private void txtLotId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//如果输入的是回车键
            {
                #region PH_OVL_QueryLotInfo
                strFabName = "FabName_50";
                //strLotId = "LotId_31";
                strLotId = txtLotId.Text.ToString().Trim();
                UIServiceFun.structPH_OVL_QueryLotInfo structData = new UIServiceFun.structPH_OVL_QueryLotInfo();
                structData = UIServiceFun.R2R_UI_PH_OVL_QueryLotInfo(strServiceAddress, strFabName, strLotId);

                strLayer = structData.strLayer;
                txtLayer.Text = strLayer;

                InitGrid(grdQueryLotInfo, DataTableHelp.CreateQueryLotInfoTable(structData));
                //grdQueryLotInfo.DataSource = DataTableHelp.CreateQueryLotInfoTable(structData);

                InitStruct();
                #endregion
            }
        }

        private void grdContextGroup_InitializeLayout(object sender, Infragistics.Win.UltraWinGrid.InitializeLayoutEventArgs e)
        {

        }

        private void grdQueryLotInfo_CellChange(object sender, CellEventArgs e)
        {
            InitStruct();
        }
    }
}
