﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmCDReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panCDResetSubTab = new Infragistics.Win.Misc.UltraPanel();
            this.panReticle_1 = new Infragistics.Win.Misc.UltraPanel();
            this.rdoTabActive = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.updoneNew1 = new System.Windows.Forms.NumericUpDown();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.lblTxt1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtCurrent1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.panCDResetSubTab_chart = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panCDResetSubTab2 = new Infragistics.Win.Misc.UltraPanel();
            this.panReticle_2 = new Infragistics.Win.Misc.UltraPanel();
            this.rdoTabActive2 = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.updoneNew1_2 = new System.Windows.Forms.NumericUpDown();
            this.lblNew = new Infragistics.Win.Misc.UltraLabel();
            this.lblTxt1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtCurrent1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblCurrent = new Infragistics.Win.Misc.UltraLabel();
            this.panCDResetSubTab2_chart = new Infragistics.Win.Misc.UltraPanel();
            this.panCDReset = new Infragistics.Win.Misc.UltraPanel();
            this.panCDResetTab = new Infragistics.Win.Misc.UltraPanel();
            this.tabReticle = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.panCDResetBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.panCDResetRdo = new Infragistics.Win.Misc.UltraPanel();
            this.rdoReset = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.ultraTabPageControl1.SuspendLayout();
            this.panCDResetSubTab.ClientArea.SuspendLayout();
            this.panCDResetSubTab.SuspendLayout();
            this.panReticle_1.ClientArea.SuspendLayout();
            this.panReticle_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).BeginInit();
            this.panCDResetSubTab_chart.SuspendLayout();
            this.ultraTabPageControl2.SuspendLayout();
            this.panCDResetSubTab2.ClientArea.SuspendLayout();
            this.panCDResetSubTab2.SuspendLayout();
            this.panReticle_2.ClientArea.SuspendLayout();
            this.panReticle_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).BeginInit();
            this.panCDResetSubTab2_chart.SuspendLayout();
            this.panCDReset.ClientArea.SuspendLayout();
            this.panCDReset.SuspendLayout();
            this.panCDResetTab.ClientArea.SuspendLayout();
            this.panCDResetTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).BeginInit();
            this.tabReticle.SuspendLayout();
            this.panCDResetBtn.ClientArea.SuspendLayout();
            this.panCDResetBtn.SuspendLayout();
            this.panCDResetRdo.ClientArea.SuspendLayout();
            this.panCDResetRdo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoReset)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.panCDResetSubTab);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(2, 24);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(688, 331);
            // 
            // panCDResetSubTab
            // 
            // 
            // panCDResetSubTab.ClientArea
            // 
            this.panCDResetSubTab.ClientArea.Controls.Add(this.panReticle_1);
            this.panCDResetSubTab.ClientArea.Controls.Add(this.panCDResetSubTab_chart);
            this.panCDResetSubTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDResetSubTab.Location = new System.Drawing.Point(0, 0);
            this.panCDResetSubTab.Name = "panCDResetSubTab";
            this.panCDResetSubTab.Size = new System.Drawing.Size(688, 331);
            this.panCDResetSubTab.TabIndex = 0;
            // 
            // panReticle_1
            // 
            // 
            // panReticle_1.ClientArea
            // 
            this.panReticle_1.ClientArea.Controls.Add(this.rdoTabActive);
            this.panReticle_1.ClientArea.Controls.Add(this.updoneNew1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel2);
            this.panReticle_1.ClientArea.Controls.Add(this.lblTxt1);
            this.panReticle_1.ClientArea.Controls.Add(this.txtCurrent1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel1);
            this.panReticle_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_1.Location = new System.Drawing.Point(0, 0);
            this.panReticle_1.Name = "panReticle_1";
            this.panReticle_1.Size = new System.Drawing.Size(366, 331);
            this.panReticle_1.TabIndex = 2;
            // 
            // rdoTabActive
            // 
            this.rdoTabActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            valueListItem3.DataValue = "Default Item";
            valueListItem3.DisplayText = "Active";
            valueListItem4.DataValue = "ValueListItem1";
            valueListItem4.DisplayText = "Fixed";
            this.rdoTabActive.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.rdoTabActive.ItemSpacingHorizontal = 15;
            this.rdoTabActive.Location = new System.Drawing.Point(96, 31);
            this.rdoTabActive.Name = "rdoTabActive";
            this.rdoTabActive.Size = new System.Drawing.Size(149, 21);
            this.rdoTabActive.TabIndex = 11;
            // 
            // updoneNew1
            // 
            this.updoneNew1.Location = new System.Drawing.Point(96, 109);
            this.updoneNew1.Name = "updoneNew1";
            this.updoneNew1.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1.TabIndex = 10;
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel2.Location = new System.Drawing.Point(138, 75);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(32, 17);
            this.ultraLabel2.TabIndex = 8;
            this.ultraLabel2.Text = "New";
            // 
            // lblTxt1
            // 
            this.lblTxt1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            this.lblTxt1.Location = new System.Drawing.Point(13, 109);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.ReadOnly = true;
            this.lblTxt1.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1.TabIndex = 6;
            this.lblTxt1.Text = "Does";
            // 
            // txtCurrent1
            // 
            this.txtCurrent1.Location = new System.Drawing.Point(233, 109);
            this.txtCurrent1.Name = "txtCurrent1";
            this.txtCurrent1.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1.TabIndex = 7;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(264, 75);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(49, 17);
            this.ultraLabel1.TabIndex = 9;
            this.ultraLabel1.Text = "Current";
            // 
            // panCDResetSubTab_chart
            // 
            this.panCDResetSubTab_chart.Dock = System.Windows.Forms.DockStyle.Right;
            this.panCDResetSubTab_chart.Location = new System.Drawing.Point(366, 0);
            this.panCDResetSubTab_chart.Name = "panCDResetSubTab_chart";
            this.panCDResetSubTab_chart.Size = new System.Drawing.Size(322, 331);
            this.panCDResetSubTab_chart.TabIndex = 1;
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.panCDResetSubTab2);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(688, 331);
            // 
            // panCDResetSubTab2
            // 
            // 
            // panCDResetSubTab2.ClientArea
            // 
            this.panCDResetSubTab2.ClientArea.Controls.Add(this.panReticle_2);
            this.panCDResetSubTab2.ClientArea.Controls.Add(this.panCDResetSubTab2_chart);
            this.panCDResetSubTab2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDResetSubTab2.Location = new System.Drawing.Point(0, 0);
            this.panCDResetSubTab2.Name = "panCDResetSubTab2";
            this.panCDResetSubTab2.Size = new System.Drawing.Size(688, 331);
            this.panCDResetSubTab2.TabIndex = 0;
            // 
            // panReticle_2
            // 
            // 
            // panReticle_2.ClientArea
            // 
            this.panReticle_2.ClientArea.Controls.Add(this.rdoTabActive2);
            this.panReticle_2.ClientArea.Controls.Add(this.updoneNew1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblNew);
            this.panReticle_2.ClientArea.Controls.Add(this.lblTxt1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.txtCurrent1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblCurrent);
            this.panReticle_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_2.Location = new System.Drawing.Point(0, 0);
            this.panReticle_2.Name = "panReticle_2";
            this.panReticle_2.Size = new System.Drawing.Size(363, 331);
            this.panReticle_2.TabIndex = 2;
            // 
            // rdoTabActive2
            // 
            this.rdoTabActive2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            valueListItem1.DataValue = "Default Item";
            valueListItem1.DisplayText = "Active";
            valueListItem2.DataValue = "ValueListItem1";
            valueListItem2.DisplayText = "Fixed";
            this.rdoTabActive2.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.rdoTabActive2.ItemSpacingHorizontal = 15;
            this.rdoTabActive2.Location = new System.Drawing.Point(106, 26);
            this.rdoTabActive2.Name = "rdoTabActive2";
            this.rdoTabActive2.Size = new System.Drawing.Size(149, 21);
            this.rdoTabActive2.TabIndex = 12;
            // 
            // updoneNew1_2
            // 
            this.updoneNew1_2.Location = new System.Drawing.Point(106, 100);
            this.updoneNew1_2.Name = "updoneNew1_2";
            this.updoneNew1_2.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1_2.TabIndex = 10;
            // 
            // lblNew
            // 
            this.lblNew.AutoSize = true;
            this.lblNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew.Location = new System.Drawing.Point(148, 66);
            this.lblNew.Name = "lblNew";
            this.lblNew.Size = new System.Drawing.Size(32, 17);
            this.lblNew.TabIndex = 8;
            this.lblNew.Text = "New";
            // 
            // lblTxt1_2
            // 
            this.lblTxt1_2.Location = new System.Drawing.Point(23, 100);
            this.lblTxt1_2.Name = "lblTxt1_2";
            this.lblTxt1_2.ReadOnly = true;
            this.lblTxt1_2.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1_2.TabIndex = 6;
            this.lblTxt1_2.Text = "Input 1";
            // 
            // txtCurrent1_2
            // 
            this.txtCurrent1_2.Location = new System.Drawing.Point(243, 100);
            this.txtCurrent1_2.Name = "txtCurrent1_2";
            this.txtCurrent1_2.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1_2.TabIndex = 7;
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(274, 66);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(49, 17);
            this.lblCurrent.TabIndex = 9;
            this.lblCurrent.Text = "Current";
            // 
            // panCDResetSubTab2_chart
            // 
            this.panCDResetSubTab2_chart.Dock = System.Windows.Forms.DockStyle.Right;
            this.panCDResetSubTab2_chart.Location = new System.Drawing.Point(363, 0);
            this.panCDResetSubTab2_chart.Name = "panCDResetSubTab2_chart";
            this.panCDResetSubTab2_chart.Size = new System.Drawing.Size(325, 331);
            this.panCDResetSubTab2_chart.TabIndex = 1;
            // 
            // panCDReset
            // 
            // 
            // panCDReset.ClientArea
            // 
            this.panCDReset.ClientArea.Controls.Add(this.panCDResetTab);
            this.panCDReset.ClientArea.Controls.Add(this.panCDResetBtn);
            this.panCDReset.ClientArea.Controls.Add(this.panCDResetRdo);
            this.panCDReset.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDReset.Location = new System.Drawing.Point(0, 0);
            this.panCDReset.Name = "panCDReset";
            this.panCDReset.Size = new System.Drawing.Size(692, 466);
            this.panCDReset.TabIndex = 0;
            // 
            // panCDResetTab
            // 
            // 
            // panCDResetTab.ClientArea
            // 
            this.panCDResetTab.ClientArea.Controls.Add(this.tabReticle);
            this.panCDResetTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCDResetTab.Location = new System.Drawing.Point(0, 57);
            this.panCDResetTab.Name = "panCDResetTab";
            this.panCDResetTab.Size = new System.Drawing.Size(692, 357);
            this.panCDResetTab.TabIndex = 2;
            // 
            // tabReticle
            // 
            this.tabReticle.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl2);
            this.tabReticle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabReticle.Location = new System.Drawing.Point(0, 0);
            this.tabReticle.Name = "tabReticle";
            this.tabReticle.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabReticle.Size = new System.Drawing.Size(692, 357);
            this.tabReticle.TabIndex = 0;
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "Reticle";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "Reticle2";
            this.tabReticle.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2});
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(688, 331);
            // 
            // panCDResetBtn
            // 
            // 
            // panCDResetBtn.ClientArea
            // 
            this.panCDResetBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panCDResetBtn.ClientArea.Controls.Add(this.btnOk);
            this.panCDResetBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panCDResetBtn.Location = new System.Drawing.Point(0, 414);
            this.panCDResetBtn.Name = "panCDResetBtn";
            this.panCDResetBtn.Size = new System.Drawing.Size(692, 52);
            this.panCDResetBtn.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(582, 17);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(488, 17);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panCDResetRdo
            // 
            // 
            // panCDResetRdo.ClientArea
            // 
            this.panCDResetRdo.ClientArea.Controls.Add(this.rdoReset);
            this.panCDResetRdo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCDResetRdo.Location = new System.Drawing.Point(0, 0);
            this.panCDResetRdo.Name = "panCDResetRdo";
            this.panCDResetRdo.Size = new System.Drawing.Size(692, 57);
            this.panCDResetRdo.TabIndex = 0;
            // 
            // rdoReset
            // 
            this.rdoReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.rdoReset.ItemOrigin = new System.Drawing.Point(5, 5);
            valueListItem5.DataValue = "Default Item";
            valueListItem5.DisplayText = "PM";
            valueListItem6.DataValue = "ValueListItem1";
            valueListItem6.DisplayText = "RESET";
            this.rdoReset.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem5,
            valueListItem6});
            this.rdoReset.ItemSpacingHorizontal = 15;
            this.rdoReset.Location = new System.Drawing.Point(238, 12);
            this.rdoReset.Name = "rdoReset";
            this.rdoReset.Size = new System.Drawing.Size(130, 27);
            this.rdoReset.TabIndex = 0;
            this.rdoReset.ValueChanged += new System.EventHandler(this.rdoReset_ValueChanged);
            // 
            // frmCDReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 466);
            this.Controls.Add(this.panCDReset);
            this.Name = "frmCDReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CDReset";
            this.Load += new System.EventHandler(this.frmCDReset_Load);
            this.ultraTabPageControl1.ResumeLayout(false);
            this.panCDResetSubTab.ClientArea.ResumeLayout(false);
            this.panCDResetSubTab.ResumeLayout(false);
            this.panReticle_1.ClientArea.ResumeLayout(false);
            this.panReticle_1.ClientArea.PerformLayout();
            this.panReticle_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).EndInit();
            this.panCDResetSubTab_chart.ResumeLayout(false);
            this.ultraTabPageControl2.ResumeLayout(false);
            this.panCDResetSubTab2.ClientArea.ResumeLayout(false);
            this.panCDResetSubTab2.ResumeLayout(false);
            this.panReticle_2.ClientArea.ResumeLayout(false);
            this.panReticle_2.ClientArea.PerformLayout();
            this.panReticle_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoTabActive2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).EndInit();
            this.panCDResetSubTab2_chart.ResumeLayout(false);
            this.panCDReset.ClientArea.ResumeLayout(false);
            this.panCDReset.ResumeLayout(false);
            this.panCDResetTab.ClientArea.ResumeLayout(false);
            this.panCDResetTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).EndInit();
            this.tabReticle.ResumeLayout(false);
            this.panCDResetBtn.ClientArea.ResumeLayout(false);
            this.panCDResetBtn.ResumeLayout(false);
            this.panCDResetRdo.ClientArea.ResumeLayout(false);
            this.panCDResetRdo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoReset)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panCDReset;
        private Infragistics.Win.Misc.UltraPanel panCDResetTab;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabReticle;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private Infragistics.Win.Misc.UltraPanel panCDResetSubTab;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.Misc.UltraPanel panCDResetBtn;
        private Infragistics.Win.Misc.UltraPanel panCDResetRdo;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoReset;
        private Infragistics.Win.Misc.UltraPanel panCDResetSubTab2;
        private Infragistics.Win.Misc.UltraPanel panCDResetSubTab_chart;
        private Infragistics.Win.Misc.UltraPanel panCDResetSubTab2_chart;
        private System.Windows.Forms.NumericUpDown updoneNew1_2;
        private Infragistics.Win.Misc.UltraLabel lblCurrent;
        private Infragistics.Win.Misc.UltraLabel lblNew;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1_2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1_2;
        private System.Windows.Forms.NumericUpDown updoneNew1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoTabActive;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoTabActive2;
        private Infragistics.Win.Misc.UltraPanel panReticle_1;
        private Infragistics.Win.Misc.UltraPanel panReticle_2;
    }
}