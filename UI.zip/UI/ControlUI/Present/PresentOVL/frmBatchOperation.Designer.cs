﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmBatchOperation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinGrid.UltraGridBand ultraGridBand1 = new Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1);
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn4 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Name");
            Infragistics.Win.UltraWinGrid.UltraGridColumn ultraGridColumn5 = new Infragistics.Win.UltraWinGrid.UltraGridColumn("Value");
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn1 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Name");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn2 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Value");
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn3 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Product");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn4 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Layer");
            Infragistics.Win.UltraWinDataSource.UltraDataColumn ultraDataColumn5 = new Infragistics.Win.UltraWinDataSource.UltraDataColumn("Tool");
            Infragistics.Win.UltraWinToolbars.PopupMenuTool popupMenuTool1 = new Infragistics.Win.UltraWinToolbars.PopupMenuTool("Batch Mode");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool4 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch OVL Mode");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool5 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch R2R Mode");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool6 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch PM Offset");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool1 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch OVL Mode");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool2 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch R2R Mode");
            Infragistics.Win.UltraWinToolbars.ButtonTool buttonTool3 = new Infragistics.Win.UltraWinToolbars.ButtonTool("Batch PM Offset");
            this.panBatchOperation = new Infragistics.Win.Misc.UltraPanel();
            this.panBatchOperation_2 = new Infragistics.Win.Misc.UltraPanel();
            this.panBatchOperationGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdBatchOperation = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.batchOperationDataSource = new Infragistics.Win.UltraWinDataSource.UltraDataSource(this.components);
            this.panBatchOperationBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnBatchPMOffset = new Infragistics.Win.Misc.UltraButton();
            this.btnBatchOVLMode = new Infragistics.Win.Misc.UltraButton();
            this.panBatchOperation_1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraDataSource1 = new Infragistics.Win.UltraWinDataSource.UltraDataSource(this.components);
            this.menuBatchOperation = new Infragistics.Win.UltraWinToolbars.UltraToolbarsManager(this.components);
            this._frmBatchOperation_Toolbars_Dock_Area_Left = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmBatchOperation_Toolbars_Dock_Area_Right = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmBatchOperation_Toolbars_Dock_Area_Top = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom = new Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea();
            this.panBatchOperation.ClientArea.SuspendLayout();
            this.panBatchOperation.SuspendLayout();
            this.panBatchOperation_2.ClientArea.SuspendLayout();
            this.panBatchOperation_2.SuspendLayout();
            this.panBatchOperationGrid.ClientArea.SuspendLayout();
            this.panBatchOperationGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchOperation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.batchOperationDataSource)).BeginInit();
            this.panBatchOperationBtn.ClientArea.SuspendLayout();
            this.panBatchOperationBtn.SuspendLayout();
            this.panBatchOperation_1.ClientArea.SuspendLayout();
            this.panBatchOperation_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBatchOperation)).BeginInit();
            this.SuspendLayout();
            // 
            // panBatchOperation
            // 
            // 
            // panBatchOperation.ClientArea
            // 
            this.panBatchOperation.ClientArea.Controls.Add(this.panBatchOperation_2);
            this.panBatchOperation.ClientArea.Controls.Add(this.panBatchOperation_1);
            this.panBatchOperation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchOperation.Location = new System.Drawing.Point(0, 0);
            this.panBatchOperation.Name = "panBatchOperation";
            this.panBatchOperation.Size = new System.Drawing.Size(474, 294);
            this.panBatchOperation.TabIndex = 0;
            // 
            // panBatchOperation_2
            // 
            // 
            // panBatchOperation_2.ClientArea
            // 
            this.panBatchOperation_2.ClientArea.Controls.Add(this.panBatchOperationGrid);
            this.panBatchOperation_2.ClientArea.Controls.Add(this.panBatchOperationBtn);
            this.panBatchOperation_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchOperation_2.Location = new System.Drawing.Point(0, 42);
            this.panBatchOperation_2.Name = "panBatchOperation_2";
            this.panBatchOperation_2.Size = new System.Drawing.Size(474, 252);
            this.panBatchOperation_2.TabIndex = 1;
            // 
            // panBatchOperationGrid
            // 
            // 
            // panBatchOperationGrid.ClientArea
            // 
            this.panBatchOperationGrid.ClientArea.Controls.Add(this.grdBatchOperation);
            this.panBatchOperationGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchOperationGrid.Location = new System.Drawing.Point(0, 0);
            this.panBatchOperationGrid.Name = "panBatchOperationGrid";
            this.panBatchOperationGrid.Size = new System.Drawing.Size(474, 166);
            this.panBatchOperationGrid.TabIndex = 3;
            // 
            // grdBatchOperation
            // 
            this.menuBatchOperation.SetContextMenuUltra(this.grdBatchOperation, "Batch Mode");
            this.grdBatchOperation.DataSource = this.batchOperationDataSource;
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdBatchOperation.DisplayLayout.Appearance = appearance1;
            ultraGridColumn4.Header.VisiblePosition = 0;
            ultraGridColumn5.Header.VisiblePosition = 1;
            ultraGridColumn5.Style = Infragistics.Win.UltraWinGrid.ColumnStyle.DropDownList;
            ultraGridBand1.Columns.AddRange(new object[] {
            ultraGridColumn4,
            ultraGridColumn5});
            this.grdBatchOperation.DisplayLayout.BandsSerializer.Add(ultraGridBand1);
            this.grdBatchOperation.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchOperation.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchOperation.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchOperation.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdBatchOperation.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchOperation.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchOperation.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdBatchOperation.DisplayLayout.MaxColScrollRegions = 1;
            this.grdBatchOperation.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdBatchOperation.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdBatchOperation.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdBatchOperation.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdBatchOperation.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdBatchOperation.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdBatchOperation.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdBatchOperation.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdBatchOperation.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchOperation.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdBatchOperation.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdBatchOperation.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdBatchOperation.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdBatchOperation.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdBatchOperation.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdBatchOperation.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdBatchOperation.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdBatchOperation.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdBatchOperation.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdBatchOperation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdBatchOperation.Location = new System.Drawing.Point(0, 0);
            this.grdBatchOperation.Name = "grdBatchOperation";
            this.grdBatchOperation.Size = new System.Drawing.Size(474, 166);
            this.grdBatchOperation.TabIndex = 0;
            this.grdBatchOperation.Text = "ultraGrid1";
            this.grdBatchOperation.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdBatchOperation_InitializeLayout);
            this.grdBatchOperation.CellListSelect += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.grdBatchOperation_CellListSelect);
            // 
            // batchOperationDataSource
            // 
            this.batchOperationDataSource.Band.Columns.AddRange(new object[] {
            ultraDataColumn1,
            ultraDataColumn2});
            // 
            // panBatchOperationBtn
            // 
            // 
            // panBatchOperationBtn.ClientArea
            // 
            this.panBatchOperationBtn.ClientArea.Controls.Add(this.btnBatchPMOffset);
            this.panBatchOperationBtn.ClientArea.Controls.Add(this.btnBatchOVLMode);
            this.panBatchOperationBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBatchOperationBtn.Location = new System.Drawing.Point(0, 166);
            this.panBatchOperationBtn.Name = "panBatchOperationBtn";
            this.panBatchOperationBtn.Size = new System.Drawing.Size(474, 86);
            this.panBatchOperationBtn.TabIndex = 1;
            // 
            // btnBatchPMOffset
            // 
            this.btnBatchPMOffset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBatchPMOffset.Location = new System.Drawing.Point(235, 25);
            this.btnBatchPMOffset.Name = "btnBatchPMOffset";
            this.btnBatchPMOffset.Size = new System.Drawing.Size(136, 37);
            this.btnBatchPMOffset.TabIndex = 2;
            this.btnBatchPMOffset.Text = "Batch PM Offset";
            this.btnBatchPMOffset.Click += new System.EventHandler(this.btnBatchPMOffset_Click);
            // 
            // btnBatchOVLMode
            // 
            this.btnBatchOVLMode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBatchOVLMode.Location = new System.Drawing.Point(69, 25);
            this.btnBatchOVLMode.Name = "btnBatchOVLMode";
            this.btnBatchOVLMode.Size = new System.Drawing.Size(136, 37);
            this.btnBatchOVLMode.TabIndex = 0;
            this.btnBatchOVLMode.Text = "Batch OVL Mode";
            this.btnBatchOVLMode.Click += new System.EventHandler(this.btnBatchOVLMode_Click);
            // 
            // panBatchOperation_1
            // 
            appearance13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panBatchOperation_1.Appearance = appearance13;
            // 
            // panBatchOperation_1.ClientArea
            // 
            this.panBatchOperation_1.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panBatchOperation_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panBatchOperation_1.Location = new System.Drawing.Point(0, 0);
            this.panBatchOperation_1.Name = "panBatchOperation_1";
            this.panBatchOperation_1.Size = new System.Drawing.Size(474, 42);
            this.panBatchOperation_1.TabIndex = 0;
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            appearance14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor1.Appearance = appearance14;
            this.ultraTextEditor1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ultraTextEditor1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.ultraTextEditor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor1.Location = new System.Drawing.Point(58, 12);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(339, 24);
            this.ultraTextEditor1.TabIndex = 0;
            this.ultraTextEditor1.Text = "This is part of UVL UI-Batch Operations";
            // 
            // ultraDataSource1
            // 
            this.ultraDataSource1.Band.Columns.AddRange(new object[] {
            ultraDataColumn3,
            ultraDataColumn4,
            ultraDataColumn5});
            // 
            // menuBatchOperation
            // 
            this.menuBatchOperation.DesignerFlags = 1;
            this.menuBatchOperation.DockWithinContainer = this;
            this.menuBatchOperation.DockWithinContainerBaseType = typeof(System.Windows.Forms.Form);
            this.menuBatchOperation.ShowFullMenusDelay = 500;
            popupMenuTool1.SharedPropsInternal.Caption = "Batch Mode";
            popupMenuTool1.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            buttonTool4,
            buttonTool5,
            buttonTool6});
            buttonTool1.SharedPropsInternal.Caption = "Batch OVL Mode";
            buttonTool2.SharedPropsInternal.Caption = "Batch R2R Mode";
            buttonTool3.SharedPropsInternal.Caption = "Batch PM Offset";
            this.menuBatchOperation.Tools.AddRange(new Infragistics.Win.UltraWinToolbars.ToolBase[] {
            popupMenuTool1,
            buttonTool1,
            buttonTool2,
            buttonTool3});
            this.menuBatchOperation.ToolClick += new Infragistics.Win.UltraWinToolbars.ToolClickEventHandler(this.menuBatchOperation_ToolClick);
            // 
            // _frmBatchOperation_Toolbars_Dock_Area_Left
            // 
            this._frmBatchOperation_Toolbars_Dock_Area_Left.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmBatchOperation_Toolbars_Dock_Area_Left.BackColor = System.Drawing.SystemColors.Control;
            this._frmBatchOperation_Toolbars_Dock_Area_Left.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Left;
            this._frmBatchOperation_Toolbars_Dock_Area_Left.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmBatchOperation_Toolbars_Dock_Area_Left.Location = new System.Drawing.Point(0, 0);
            this._frmBatchOperation_Toolbars_Dock_Area_Left.Name = "_frmBatchOperation_Toolbars_Dock_Area_Left";
            this._frmBatchOperation_Toolbars_Dock_Area_Left.Size = new System.Drawing.Size(0, 294);
            this._frmBatchOperation_Toolbars_Dock_Area_Left.ToolbarsManager = this.menuBatchOperation;
            // 
            // _frmBatchOperation_Toolbars_Dock_Area_Right
            // 
            this._frmBatchOperation_Toolbars_Dock_Area_Right.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmBatchOperation_Toolbars_Dock_Area_Right.BackColor = System.Drawing.SystemColors.Control;
            this._frmBatchOperation_Toolbars_Dock_Area_Right.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Right;
            this._frmBatchOperation_Toolbars_Dock_Area_Right.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmBatchOperation_Toolbars_Dock_Area_Right.Location = new System.Drawing.Point(474, 0);
            this._frmBatchOperation_Toolbars_Dock_Area_Right.Name = "_frmBatchOperation_Toolbars_Dock_Area_Right";
            this._frmBatchOperation_Toolbars_Dock_Area_Right.Size = new System.Drawing.Size(0, 294);
            this._frmBatchOperation_Toolbars_Dock_Area_Right.ToolbarsManager = this.menuBatchOperation;
            // 
            // _frmBatchOperation_Toolbars_Dock_Area_Top
            // 
            this._frmBatchOperation_Toolbars_Dock_Area_Top.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmBatchOperation_Toolbars_Dock_Area_Top.BackColor = System.Drawing.SystemColors.Control;
            this._frmBatchOperation_Toolbars_Dock_Area_Top.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Top;
            this._frmBatchOperation_Toolbars_Dock_Area_Top.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmBatchOperation_Toolbars_Dock_Area_Top.Location = new System.Drawing.Point(0, 0);
            this._frmBatchOperation_Toolbars_Dock_Area_Top.Name = "_frmBatchOperation_Toolbars_Dock_Area_Top";
            this._frmBatchOperation_Toolbars_Dock_Area_Top.Size = new System.Drawing.Size(474, 0);
            this._frmBatchOperation_Toolbars_Dock_Area_Top.ToolbarsManager = this.menuBatchOperation;
            // 
            // _frmBatchOperation_Toolbars_Dock_Area_Bottom
            // 
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.BackColor = System.Drawing.SystemColors.Control;
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Bottom;
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.ForeColor = System.Drawing.SystemColors.ControlText;
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.Location = new System.Drawing.Point(0, 294);
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.Name = "_frmBatchOperation_Toolbars_Dock_Area_Bottom";
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.Size = new System.Drawing.Size(474, 0);
            this._frmBatchOperation_Toolbars_Dock_Area_Bottom.ToolbarsManager = this.menuBatchOperation;
            // 
            // frmBatchOperation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 294);
            this.Controls.Add(this.panBatchOperation);
            this.Controls.Add(this._frmBatchOperation_Toolbars_Dock_Area_Left);
            this.Controls.Add(this._frmBatchOperation_Toolbars_Dock_Area_Right);
            this.Controls.Add(this._frmBatchOperation_Toolbars_Dock_Area_Bottom);
            this.Controls.Add(this._frmBatchOperation_Toolbars_Dock_Area_Top);
            this.Name = "frmBatchOperation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchOperation";
            this.Load += new System.EventHandler(this.frmBatchOperation_Load);
            this.panBatchOperation.ClientArea.ResumeLayout(false);
            this.panBatchOperation.ResumeLayout(false);
            this.panBatchOperation_2.ClientArea.ResumeLayout(false);
            this.panBatchOperation_2.ResumeLayout(false);
            this.panBatchOperationGrid.ClientArea.ResumeLayout(false);
            this.panBatchOperationGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchOperation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.batchOperationDataSource)).EndInit();
            this.panBatchOperationBtn.ClientArea.ResumeLayout(false);
            this.panBatchOperationBtn.ResumeLayout(false);
            this.panBatchOperation_1.ClientArea.ResumeLayout(false);
            this.panBatchOperation_1.ClientArea.PerformLayout();
            this.panBatchOperation_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDataSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBatchOperation)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panBatchOperation;
        private Infragistics.Win.Misc.UltraPanel panBatchOperation_1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.Misc.UltraPanel panBatchOperation_2;
        private Infragistics.Win.Misc.UltraPanel panBatchOperationBtn;
        private Infragistics.Win.Misc.UltraButton btnBatchPMOffset;
        private Infragistics.Win.Misc.UltraButton btnBatchOVLMode;
        private Infragistics.Win.Misc.UltraPanel panBatchOperationGrid;
        private Infragistics.Win.UltraWinDataSource.UltraDataSource ultraDataSource1;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdBatchOperation;
        private Infragistics.Win.UltraWinDataSource.UltraDataSource batchOperationDataSource;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsManager menuBatchOperation;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmBatchOperation_Toolbars_Dock_Area_Left;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmBatchOperation_Toolbars_Dock_Area_Right;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmBatchOperation_Toolbars_Dock_Area_Bottom;
        private Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea _frmBatchOperation_Toolbars_Dock_Area_Top;
    }
}