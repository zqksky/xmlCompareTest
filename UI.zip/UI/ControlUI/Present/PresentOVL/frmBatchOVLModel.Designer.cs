﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmBatchOVLModel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            this.panBatchMode = new Infragistics.Win.Misc.UltraPanel();
            this.panBatchModeGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdBatchOVLMode = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panBatchModeBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.ultraSplitter1 = new Infragistics.Win.Misc.UltraSplitter();
            this.panBatchModeTxt = new Infragistics.Win.Misc.UltraPanel();
            this.txtContextGroup = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor4 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtContext = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panBatchMode.ClientArea.SuspendLayout();
            this.panBatchMode.SuspendLayout();
            this.panBatchModeGrid.ClientArea.SuspendLayout();
            this.panBatchModeGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchOVLMode)).BeginInit();
            this.panBatchModeBtn.ClientArea.SuspendLayout();
            this.panBatchModeBtn.SuspendLayout();
            this.panBatchModeTxt.ClientArea.SuspendLayout();
            this.panBatchModeTxt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtContextGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            this.SuspendLayout();
            // 
            // panBatchMode
            // 
            // 
            // panBatchMode.ClientArea
            // 
            this.panBatchMode.ClientArea.Controls.Add(this.panBatchModeGrid);
            this.panBatchMode.ClientArea.Controls.Add(this.panBatchModeBtn);
            this.panBatchMode.ClientArea.Controls.Add(this.ultraSplitter1);
            this.panBatchMode.ClientArea.Controls.Add(this.panBatchModeTxt);
            this.panBatchMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchMode.Location = new System.Drawing.Point(0, 0);
            this.panBatchMode.Name = "panBatchMode";
            this.panBatchMode.Size = new System.Drawing.Size(683, 388);
            this.panBatchMode.TabIndex = 0;
            // 
            // panBatchModeGrid
            // 
            // 
            // panBatchModeGrid.ClientArea
            // 
            this.panBatchModeGrid.ClientArea.Controls.Add(this.grdBatchOVLMode);
            this.panBatchModeGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchModeGrid.Location = new System.Drawing.Point(0, 94);
            this.panBatchModeGrid.Name = "panBatchModeGrid";
            this.panBatchModeGrid.Size = new System.Drawing.Size(683, 252);
            this.panBatchModeGrid.TabIndex = 4;
            // 
            // grdBatchOVLMode
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdBatchOVLMode.DisplayLayout.Appearance = appearance1;
            this.grdBatchOVLMode.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchOVLMode.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchOVLMode.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchOVLMode.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdBatchOVLMode.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchOVLMode.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchOVLMode.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdBatchOVLMode.DisplayLayout.MaxColScrollRegions = 1;
            this.grdBatchOVLMode.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdBatchOVLMode.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdBatchOVLMode.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdBatchOVLMode.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdBatchOVLMode.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdBatchOVLMode.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdBatchOVLMode.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdBatchOVLMode.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdBatchOVLMode.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchOVLMode.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdBatchOVLMode.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdBatchOVLMode.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdBatchOVLMode.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdBatchOVLMode.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdBatchOVLMode.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdBatchOVLMode.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdBatchOVLMode.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdBatchOVLMode.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdBatchOVLMode.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdBatchOVLMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdBatchOVLMode.Location = new System.Drawing.Point(0, 0);
            this.grdBatchOVLMode.Name = "grdBatchOVLMode";
            this.grdBatchOVLMode.Size = new System.Drawing.Size(683, 252);
            this.grdBatchOVLMode.TabIndex = 0;
            this.grdBatchOVLMode.Text = "List of context group";
            this.grdBatchOVLMode.AfterCellUpdate += new Infragistics.Win.UltraWinGrid.CellEventHandler(this.grdBatchOVLMode_AfterCellUpdate);
            this.grdBatchOVLMode.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grdBatchOVLMode_InitializeLayout);
            // 
            // panBatchModeBtn
            // 
            // 
            // panBatchModeBtn.ClientArea
            // 
            this.panBatchModeBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panBatchModeBtn.ClientArea.Controls.Add(this.btnOk);
            this.panBatchModeBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBatchModeBtn.Location = new System.Drawing.Point(0, 346);
            this.panBatchModeBtn.Name = "panBatchModeBtn";
            this.panBatchModeBtn.Size = new System.Drawing.Size(683, 42);
            this.panBatchModeBtn.TabIndex = 3;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(573, 10);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 20);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(477, 10);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 20);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // ultraSplitter1
            // 
            this.ultraSplitter1.BackColor = System.Drawing.SystemColors.Control;
            this.ultraSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ultraSplitter1.Location = new System.Drawing.Point(0, 88);
            this.ultraSplitter1.Name = "ultraSplitter1";
            this.ultraSplitter1.RestoreExtent = 181;
            this.ultraSplitter1.Size = new System.Drawing.Size(683, 6);
            this.ultraSplitter1.TabIndex = 2;
            // 
            // panBatchModeTxt
            // 
            // 
            // panBatchModeTxt.ClientArea
            // 
            this.panBatchModeTxt.ClientArea.Controls.Add(this.txtContextGroup);
            this.panBatchModeTxt.ClientArea.Controls.Add(this.ultraTextEditor4);
            this.panBatchModeTxt.ClientArea.Controls.Add(this.txtContext);
            this.panBatchModeTxt.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panBatchModeTxt.Dock = System.Windows.Forms.DockStyle.Top;
            this.panBatchModeTxt.Location = new System.Drawing.Point(0, 0);
            this.panBatchModeTxt.Name = "panBatchModeTxt";
            this.panBatchModeTxt.Size = new System.Drawing.Size(683, 88);
            this.panBatchModeTxt.TabIndex = 0;
            // 
            // txtContextGroup
            // 
            this.txtContextGroup.Location = new System.Drawing.Point(296, 49);
            this.txtContextGroup.Name = "txtContextGroup";
            this.txtContextGroup.ReadOnly = true;
            this.txtContextGroup.Size = new System.Drawing.Size(154, 21);
            this.txtContextGroup.TabIndex = 3;
            // 
            // ultraTextEditor4
            // 
            this.ultraTextEditor4.Location = new System.Drawing.Point(116, 49);
            this.ultraTextEditor4.Name = "ultraTextEditor4";
            this.ultraTextEditor4.ReadOnly = true;
            this.ultraTextEditor4.Size = new System.Drawing.Size(159, 21);
            this.ultraTextEditor4.TabIndex = 2;
            this.ultraTextEditor4.Text = "Applying To Context Group:";
            // 
            // txtContext
            // 
            this.txtContext.Location = new System.Drawing.Point(296, 22);
            this.txtContext.Name = "txtContext";
            this.txtContext.ReadOnly = true;
            this.txtContext.Size = new System.Drawing.Size(154, 21);
            this.txtContext.TabIndex = 1;
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Location = new System.Drawing.Point(116, 22);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(159, 21);
            this.ultraTextEditor1.TabIndex = 0;
            this.ultraTextEditor1.Text = "Current Selected Contexts:";
            // 
            // frmBatchOVLModel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 388);
            this.Controls.Add(this.panBatchMode);
            this.Name = "frmBatchOVLModel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchOVLMode";
            this.Load += new System.EventHandler(this.frmBatchOVLMode_Load);
            this.panBatchMode.ClientArea.ResumeLayout(false);
            this.panBatchMode.ResumeLayout(false);
            this.panBatchModeGrid.ClientArea.ResumeLayout(false);
            this.panBatchModeGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchOVLMode)).EndInit();
            this.panBatchModeBtn.ClientArea.ResumeLayout(false);
            this.panBatchModeBtn.ResumeLayout(false);
            this.panBatchModeTxt.ClientArea.ResumeLayout(false);
            this.panBatchModeTxt.ClientArea.PerformLayout();
            this.panBatchModeTxt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtContextGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panBatchMode;
        private Infragistics.Win.Misc.UltraSplitter ultraSplitter1;
        private Infragistics.Win.Misc.UltraPanel panBatchModeTxt;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdBatchOVLMode;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtContextGroup;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor4;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtContext;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.Misc.UltraPanel panBatchModeGrid;
        private Infragistics.Win.Misc.UltraPanel panBatchModeBtn;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.Misc.UltraButton btnOk;
    }
}