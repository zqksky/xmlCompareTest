﻿namespace ControlUI.Present.PresentOVL
{
    partial class frmBatchR2RMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem5 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem6 = new Infragistics.Win.ValueListItem();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panReticle_1 = new Infragistics.Win.Misc.UltraPanel();
            this.updoneNew1 = new System.Windows.Forms.NumericUpDown();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.txtCurrent1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblTxt1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.panReticle_2 = new Infragistics.Win.Misc.UltraPanel();
            this.updoneNew1_2 = new System.Windows.Forms.NumericUpDown();
            this.lblCurrent = new Infragistics.Win.Misc.UltraLabel();
            this.lblNew = new Infragistics.Win.Misc.UltraLabel();
            this.txtCurrent1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.lblTxt1_2 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.panBatchR2RMode = new Infragistics.Win.Misc.UltraPanel();
            this.panBatchR2RModeTab = new Infragistics.Win.Misc.UltraPanel();
            this.tabReticle = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.panBatchR2RModeBtn = new Infragistics.Win.Misc.UltraPanel();
            this.btnOk = new Infragistics.Win.Misc.UltraButton();
            this.btnCancel = new Infragistics.Win.Misc.UltraButton();
            this.panBatchR2RModeGrid = new Infragistics.Win.Misc.UltraPanel();
            this.grdBatchR2RMode = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.panBatchR2RModeTxt = new Infragistics.Win.Misc.UltraPanel();
            this.rdoActive = new Infragistics.Win.UltraWinEditors.UltraOptionSet();
            this.cmbChuck = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.txtContextGroup = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor4 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.txtContext = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTabPageControl1.SuspendLayout();
            this.panReticle_1.ClientArea.SuspendLayout();
            this.panReticle_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).BeginInit();
            this.ultraTabPageControl2.SuspendLayout();
            this.panReticle_2.ClientArea.SuspendLayout();
            this.panReticle_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).BeginInit();
            this.panBatchR2RMode.ClientArea.SuspendLayout();
            this.panBatchR2RMode.SuspendLayout();
            this.panBatchR2RModeTab.ClientArea.SuspendLayout();
            this.panBatchR2RModeTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).BeginInit();
            this.tabReticle.SuspendLayout();
            this.panBatchR2RModeBtn.ClientArea.SuspendLayout();
            this.panBatchR2RModeBtn.SuspendLayout();
            this.panBatchR2RModeGrid.ClientArea.SuspendLayout();
            this.panBatchR2RModeGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchR2RMode)).BeginInit();
            this.panBatchR2RModeTxt.ClientArea.SuspendLayout();
            this.panBatchR2RModeTxt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoActive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbChuck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContextGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.panReticle_1);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(2, 24);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(630, 223);
            // 
            // panReticle_1
            // 
            // 
            // panReticle_1.ClientArea
            // 
            this.panReticle_1.ClientArea.Controls.Add(this.updoneNew1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel1);
            this.panReticle_1.ClientArea.Controls.Add(this.ultraLabel2);
            this.panReticle_1.ClientArea.Controls.Add(this.txtCurrent1);
            this.panReticle_1.ClientArea.Controls.Add(this.lblTxt1);
            this.panReticle_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_1.Location = new System.Drawing.Point(0, 0);
            this.panReticle_1.Name = "panReticle_1";
            this.panReticle_1.Size = new System.Drawing.Size(630, 223);
            this.panReticle_1.TabIndex = 0;
            // 
            // updoneNew1
            // 
            this.updoneNew1.Location = new System.Drawing.Point(118, 57);
            this.updoneNew1.Name = "updoneNew1";
            this.updoneNew1.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1.TabIndex = 20;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(286, 23);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(49, 17);
            this.ultraLabel1.TabIndex = 19;
            this.ultraLabel1.Text = "Current";
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel2.Location = new System.Drawing.Point(160, 23);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(32, 17);
            this.ultraLabel2.TabIndex = 18;
            this.ultraLabel2.Text = "New";
            // 
            // txtCurrent1
            // 
            this.txtCurrent1.Location = new System.Drawing.Point(255, 57);
            this.txtCurrent1.Name = "txtCurrent1";
            this.txtCurrent1.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1.TabIndex = 17;
            // 
            // lblTxt1
            // 
            this.lblTxt1.Location = new System.Drawing.Point(35, 57);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.ReadOnly = true;
            this.lblTxt1.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1.TabIndex = 16;
            this.lblTxt1.Text = "Input 1";
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.panReticle_2);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(630, 223);
            // 
            // panReticle_2
            // 
            // 
            // panReticle_2.ClientArea
            // 
            this.panReticle_2.ClientArea.Controls.Add(this.updoneNew1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblCurrent);
            this.panReticle_2.ClientArea.Controls.Add(this.lblNew);
            this.panReticle_2.ClientArea.Controls.Add(this.txtCurrent1_2);
            this.panReticle_2.ClientArea.Controls.Add(this.lblTxt1_2);
            this.panReticle_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panReticle_2.Location = new System.Drawing.Point(0, 0);
            this.panReticle_2.Name = "panReticle_2";
            this.panReticle_2.Size = new System.Drawing.Size(630, 223);
            this.panReticle_2.TabIndex = 0;
            // 
            // updoneNew1_2
            // 
            this.updoneNew1_2.Location = new System.Drawing.Point(118, 57);
            this.updoneNew1_2.Name = "updoneNew1_2";
            this.updoneNew1_2.Size = new System.Drawing.Size(100, 20);
            this.updoneNew1_2.TabIndex = 25;
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(286, 23);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(49, 17);
            this.lblCurrent.TabIndex = 24;
            this.lblCurrent.Text = "Current";
            // 
            // lblNew
            // 
            this.lblNew.AutoSize = true;
            this.lblNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNew.Location = new System.Drawing.Point(160, 23);
            this.lblNew.Name = "lblNew";
            this.lblNew.Size = new System.Drawing.Size(32, 17);
            this.lblNew.TabIndex = 23;
            this.lblNew.Text = "New";
            // 
            // txtCurrent1_2
            // 
            this.txtCurrent1_2.Location = new System.Drawing.Point(255, 57);
            this.txtCurrent1_2.Name = "txtCurrent1_2";
            this.txtCurrent1_2.Size = new System.Drawing.Size(100, 21);
            this.txtCurrent1_2.TabIndex = 22;
            // 
            // lblTxt1_2
            // 
            this.lblTxt1_2.Location = new System.Drawing.Point(35, 57);
            this.lblTxt1_2.Name = "lblTxt1_2";
            this.lblTxt1_2.ReadOnly = true;
            this.lblTxt1_2.Size = new System.Drawing.Size(58, 21);
            this.lblTxt1_2.TabIndex = 21;
            this.lblTxt1_2.Text = "Input 1";
            // 
            // panBatchR2RMode
            // 
            // 
            // panBatchR2RMode.ClientArea
            // 
            this.panBatchR2RMode.ClientArea.Controls.Add(this.panBatchR2RModeTab);
            this.panBatchR2RMode.ClientArea.Controls.Add(this.panBatchR2RModeBtn);
            this.panBatchR2RMode.ClientArea.Controls.Add(this.panBatchR2RModeGrid);
            this.panBatchR2RMode.ClientArea.Controls.Add(this.panBatchR2RModeTxt);
            this.panBatchR2RMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchR2RMode.Location = new System.Drawing.Point(0, 0);
            this.panBatchR2RMode.Name = "panBatchR2RMode";
            this.panBatchR2RMode.Size = new System.Drawing.Size(634, 571);
            this.panBatchR2RMode.TabIndex = 0;
            // 
            // panBatchR2RModeTab
            // 
            // 
            // panBatchR2RModeTab.ClientArea
            // 
            this.panBatchR2RModeTab.ClientArea.Controls.Add(this.tabReticle);
            this.panBatchR2RModeTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panBatchR2RModeTab.Location = new System.Drawing.Point(0, 268);
            this.panBatchR2RModeTab.Name = "panBatchR2RModeTab";
            this.panBatchR2RModeTab.Size = new System.Drawing.Size(634, 249);
            this.panBatchR2RModeTab.TabIndex = 3;
            // 
            // tabReticle
            // 
            this.tabReticle.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl1);
            this.tabReticle.Controls.Add(this.ultraTabPageControl2);
            this.tabReticle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabReticle.Location = new System.Drawing.Point(0, 0);
            this.tabReticle.Name = "tabReticle";
            this.tabReticle.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabReticle.Size = new System.Drawing.Size(634, 249);
            this.tabReticle.TabIndex = 0;
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "Reticle";
            ultraTab2.TabPage = this.ultraTabPageControl2;
            ultraTab2.Text = "Reticle2";
            this.tabReticle.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2});
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(630, 223);
            // 
            // panBatchR2RModeBtn
            // 
            // 
            // panBatchR2RModeBtn.ClientArea
            // 
            this.panBatchR2RModeBtn.ClientArea.Controls.Add(this.btnOk);
            this.panBatchR2RModeBtn.ClientArea.Controls.Add(this.btnCancel);
            this.panBatchR2RModeBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBatchR2RModeBtn.Location = new System.Drawing.Point(0, 517);
            this.panBatchR2RModeBtn.Name = "panBatchR2RModeBtn";
            this.panBatchR2RModeBtn.Size = new System.Drawing.Size(634, 54);
            this.panBatchR2RModeBtn.TabIndex = 2;
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(408, 19);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(510, 19);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panBatchR2RModeGrid
            // 
            // 
            // panBatchR2RModeGrid.ClientArea
            // 
            this.panBatchR2RModeGrid.ClientArea.Controls.Add(this.grdBatchR2RMode);
            this.panBatchR2RModeGrid.Dock = System.Windows.Forms.DockStyle.Top;
            this.panBatchR2RModeGrid.Location = new System.Drawing.Point(0, 100);
            this.panBatchR2RModeGrid.Name = "panBatchR2RModeGrid";
            this.panBatchR2RModeGrid.Size = new System.Drawing.Size(634, 168);
            this.panBatchR2RModeGrid.TabIndex = 1;
            // 
            // grdBatchR2RMode
            // 
            appearance1.BackColor = System.Drawing.SystemColors.Window;
            appearance1.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grdBatchR2RMode.DisplayLayout.Appearance = appearance1;
            this.grdBatchR2RMode.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchR2RMode.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.True;
            appearance2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance2.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance2.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchR2RMode.DisplayLayout.GroupByBox.Appearance = appearance2;
            appearance3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchR2RMode.DisplayLayout.GroupByBox.BandLabelAppearance = appearance3;
            this.grdBatchR2RMode.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grdBatchR2RMode.DisplayLayout.GroupByBox.Hidden = true;
            appearance4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance4.BackColor2 = System.Drawing.SystemColors.Control;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grdBatchR2RMode.DisplayLayout.GroupByBox.PromptAppearance = appearance4;
            this.grdBatchR2RMode.DisplayLayout.MaxColScrollRegions = 1;
            this.grdBatchR2RMode.DisplayLayout.MaxRowScrollRegions = 1;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grdBatchR2RMode.DisplayLayout.Override.ActiveCellAppearance = appearance5;
            appearance6.BackColor = System.Drawing.SystemColors.Highlight;
            appearance6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grdBatchR2RMode.DisplayLayout.Override.ActiveRowAppearance = appearance6;
            this.grdBatchR2RMode.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grdBatchR2RMode.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance7.BackColor = System.Drawing.SystemColors.Window;
            this.grdBatchR2RMode.DisplayLayout.Override.CardAreaAppearance = appearance7;
            appearance8.BorderColor = System.Drawing.Color.Silver;
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grdBatchR2RMode.DisplayLayout.Override.CellAppearance = appearance8;
            this.grdBatchR2RMode.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grdBatchR2RMode.DisplayLayout.Override.CellPadding = 0;
            appearance9.BackColor = System.Drawing.SystemColors.Control;
            appearance9.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance9.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance9.BorderColor = System.Drawing.SystemColors.Window;
            this.grdBatchR2RMode.DisplayLayout.Override.GroupByRowAppearance = appearance9;
            appearance10.TextHAlignAsString = "Left";
            this.grdBatchR2RMode.DisplayLayout.Override.HeaderAppearance = appearance10;
            this.grdBatchR2RMode.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grdBatchR2RMode.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            this.grdBatchR2RMode.DisplayLayout.Override.RowAppearance = appearance11;
            this.grdBatchR2RMode.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grdBatchR2RMode.DisplayLayout.Override.TemplateAddRowAppearance = appearance12;
            this.grdBatchR2RMode.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grdBatchR2RMode.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grdBatchR2RMode.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grdBatchR2RMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdBatchR2RMode.Location = new System.Drawing.Point(0, 0);
            this.grdBatchR2RMode.Name = "grdBatchR2RMode";
            this.grdBatchR2RMode.Size = new System.Drawing.Size(634, 168);
            this.grdBatchR2RMode.TabIndex = 0;
            this.grdBatchR2RMode.Text = "List Of Context Group";
            // 
            // panBatchR2RModeTxt
            // 
            // 
            // panBatchR2RModeTxt.ClientArea
            // 
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.rdoActive);
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.cmbChuck);
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.txtContextGroup);
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.ultraTextEditor4);
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.txtContext);
            this.panBatchR2RModeTxt.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.panBatchR2RModeTxt.Dock = System.Windows.Forms.DockStyle.Top;
            this.panBatchR2RModeTxt.Location = new System.Drawing.Point(0, 0);
            this.panBatchR2RModeTxt.Name = "panBatchR2RModeTxt";
            this.panBatchR2RModeTxt.Size = new System.Drawing.Size(634, 100);
            this.panBatchR2RModeTxt.TabIndex = 0;
            // 
            // rdoActive
            // 
            this.rdoActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            valueListItem5.CheckState = System.Windows.Forms.CheckState.Checked;
            valueListItem5.DataValue = "Default Item";
            valueListItem5.DisplayText = "Active";
            valueListItem6.DataValue = "ValueListItem1";
            valueListItem6.DisplayText = "Fixed";
            this.rdoActive.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem5,
            valueListItem6});
            this.rdoActive.ItemSpacingHorizontal = 15;
            this.rdoActive.Location = new System.Drawing.Point(392, 22);
            this.rdoActive.Name = "rdoActive";
            this.rdoActive.Size = new System.Drawing.Size(144, 23);
            this.rdoActive.TabIndex = 10;
            // 
            // cmbChuck
            // 
            this.cmbChuck.Location = new System.Drawing.Point(392, 60);
            this.cmbChuck.Name = "cmbChuck";
            this.cmbChuck.Size = new System.Drawing.Size(144, 21);
            this.cmbChuck.TabIndex = 9;
            // 
            // txtContextGroup
            // 
            this.txtContextGroup.Location = new System.Drawing.Point(193, 60);
            this.txtContextGroup.Name = "txtContextGroup";
            this.txtContextGroup.ReadOnly = true;
            this.txtContextGroup.Size = new System.Drawing.Size(178, 21);
            this.txtContextGroup.TabIndex = 8;
            // 
            // ultraTextEditor4
            // 
            this.ultraTextEditor4.Location = new System.Drawing.Point(36, 60);
            this.ultraTextEditor4.Name = "ultraTextEditor4";
            this.ultraTextEditor4.ReadOnly = true;
            this.ultraTextEditor4.Size = new System.Drawing.Size(151, 21);
            this.ultraTextEditor4.TabIndex = 7;
            this.ultraTextEditor4.Text = "Applying To Context Group:";
            // 
            // txtContext
            // 
            this.txtContext.Location = new System.Drawing.Point(193, 22);
            this.txtContext.Name = "txtContext";
            this.txtContext.ReadOnly = true;
            this.txtContext.Size = new System.Drawing.Size(178, 21);
            this.txtContext.TabIndex = 6;
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.Location = new System.Drawing.Point(36, 20);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.ReadOnly = true;
            this.ultraTextEditor1.Size = new System.Drawing.Size(151, 21);
            this.ultraTextEditor1.TabIndex = 5;
            this.ultraTextEditor1.Text = "Current Selected Contexts:";
            // 
            // frmBatchR2RMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 571);
            this.Controls.Add(this.panBatchR2RMode);
            this.Name = "frmBatchR2RMode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchR2RMode";
            this.Load += new System.EventHandler(this.frmBatchR2RMode_Load);
            this.ultraTabPageControl1.ResumeLayout(false);
            this.panReticle_1.ClientArea.ResumeLayout(false);
            this.panReticle_1.ClientArea.PerformLayout();
            this.panReticle_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1)).EndInit();
            this.ultraTabPageControl2.ResumeLayout(false);
            this.panReticle_2.ClientArea.ResumeLayout(false);
            this.panReticle_2.ClientArea.PerformLayout();
            this.panReticle_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.updoneNew1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTxt1_2)).EndInit();
            this.panBatchR2RMode.ClientArea.ResumeLayout(false);
            this.panBatchR2RMode.ResumeLayout(false);
            this.panBatchR2RModeTab.ClientArea.ResumeLayout(false);
            this.panBatchR2RModeTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabReticle)).EndInit();
            this.tabReticle.ResumeLayout(false);
            this.panBatchR2RModeBtn.ClientArea.ResumeLayout(false);
            this.panBatchR2RModeBtn.ResumeLayout(false);
            this.panBatchR2RModeGrid.ClientArea.ResumeLayout(false);
            this.panBatchR2RModeGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdBatchR2RMode)).EndInit();
            this.panBatchR2RModeTxt.ClientArea.ResumeLayout(false);
            this.panBatchR2RModeTxt.ClientArea.PerformLayout();
            this.panBatchR2RModeTxt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoActive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbChuck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContextGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel panBatchR2RMode;
        private Infragistics.Win.Misc.UltraPanel panBatchR2RModeGrid;
        private Infragistics.Win.Misc.UltraPanel panBatchR2RModeTxt;
        private Infragistics.Win.Misc.UltraPanel panBatchR2RModeTab;
        private Infragistics.Win.Misc.UltraPanel panBatchR2RModeBtn;
        private Infragistics.Win.UltraWinGrid.UltraGrid grdBatchR2RMode;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabReticle;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.Misc.UltraPanel panReticle_1;
        private Infragistics.Win.Misc.UltraPanel panReticle_2;
        private System.Windows.Forms.NumericUpDown updoneNew1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1;
        private System.Windows.Forms.NumericUpDown updoneNew1_2;
        private Infragistics.Win.Misc.UltraLabel lblCurrent;
        private Infragistics.Win.Misc.UltraLabel lblNew;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtCurrent1_2;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor lblTxt1_2;
        private Infragistics.Win.Misc.UltraButton btnOk;
        private Infragistics.Win.Misc.UltraButton btnCancel;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor cmbChuck;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtContextGroup;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor4;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtContext;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.UltraWinEditors.UltraOptionSet rdoActive;
    }
}