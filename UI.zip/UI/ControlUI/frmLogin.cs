﻿using ControlUI.Comman;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlUI
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        #region Parm Define
        private float frmLocationX;
        private float frmLocationY;

        public string strDomainName
        {
            set
            {
                txtDomainName.Text = value;
            }

            get
            {
                return txtDomainName.Text;
            }
        }

        public string strUserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string strPassword
        {
            set
            {
                txtPassword.Text = value;
            }

            get
            {
                return txtPassword.Text;
            }
        }

        public string strServerAddress
        {
            get
            {
                //return cmbServerAddress.Text;
                return cmbServerAddress.Value.ToString();
            }

            set
            {
                cmbServerAddress.Text = value;
            }
        }

        public bool bAutoLogin
        {
            get
            {
                return chkAutoLogin.Checked;
            }

            set
            {
                chkAutoLogin.Checked = value;
            }
        }
        #endregion

        private void frmLogin_Load(object sender, EventArgs e)
        {
            #region
            this.Resize += new EventHandler(frmLogin_Resize);
            frmLocationX = this.Width;
            frmLocationY = this.Height;
            FrmAutoSize.setTag(this);
            //Form1_Resize(new object(), new EventArgs());//x,y可在实例化时赋值,最后这句是新加的，在MDI时有用
            #endregion

            #region
            cmbServerAddress.SelectedIndex = 0;        //  设置为默认选中第一个
            string strDebugPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            strDebugPath = strDebugPath.Substring(0, strDebugPath.LastIndexOf('\\'));

            Hashtable ht = new Hashtable();
            ht = ReadServerConfig.GetXmlDataToHashtable(strDebugPath + "\\LogConfigFile.xml");
            bindCmbox(ht);
            #endregion
        }

        private void frmLogin_Resize(object sender, EventArgs e)
        {
            #region
            float newx = (this.Width) / frmLocationX;
            float newy = this.Height / frmLocationY;
            FrmAutoSize.setControls(newx, newy, this);
            //this.Text = this.Width.ToString() + " " + this.Height.ToString();
            #endregion
        }

        #region
        private void bindCmbox(Hashtable ht)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = ht;
            cmbServerAddress.DataSource = bs;
            cmbServerAddress.ValueMember = "Key";
            cmbServerAddress.DisplayMember = "Value";
        }
        #endregion

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDomainName.Text))
            {
                MessageBox.Show("Domain Name is mandatory");
            }

            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("User name is mandatory");
            }

            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Password is mandatory");
            }

            if (string.IsNullOrEmpty(cmbServerAddress.Text))
            {
                MessageBox.Show("E3 Server address is mandatory");
            }
            else
            {
                this.DialogResult = DialogResult.OK;
                //string strKey = this.cmbServerAddress.Value.ToString();
                //string strValue = this.cmbServerAddress.Text.ToString();
                this.Close();
            }
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                return;
            }

            if (string.IsNullOrEmpty(txtDomainName.Text))
            {
                MessageBox.Show("Domain Name is mandatory");
                e.Cancel = true;
                return;
            }

            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("User name is mandatory");
                e.Cancel = true;
                return;
            }

            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Password is mandatory");
                e.Cancel = true;
                return;
            }

            if (string.IsNullOrEmpty(cmbServerAddress.Text))
            {
                MessageBox.Show("E3 Server address is mandatory");
                e.Cancel = true;
                return;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
