﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TxtAndXmlCompare
{
    class FileHelper
    {
        #region 判断文件是否存在
        /// <summary>
        /// 判断指定类型的文件是否存在
        /// </summary>
        /// <param name="directory"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static bool FilesExist(DirectoryInfo directory, string pattern)
        {
            bool flag = false;
            if (directory.Exists || pattern.Trim() != string.Empty)
            {
                //判断其目录下是否存在pattern类型的文件
                if (directory.GetFiles(pattern).Count() > 0)
                {
                    flag = true;
                }
                else
                {
                    //遍历其子目录下是否存在pattern类型的文件
                    foreach (DirectoryInfo info in directory.GetDirectories())
                    {
                        if (FilesExist(info, pattern))
                        {
                            flag = true;
                            break;
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                }
            }
            return flag;
        }

        private static bool filesExist(string strPath, string strFileType)
        {
            if (!Directory.Exists(strPath))
            {
                return false;
            }
            else
            {
                //判断其目录下是否存在pattern类型的文件
                if (Directory.GetFiles(strPath, strFileType).Length > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        #endregion

        #region 清空文件夹内容
        /// <summary>
        /// 用来遍历删除目录下的文件以及该文件夹,只读文件夹删除需要先删除文件夹内的文件，然后在使用删除文件夹才能成功，否则将会报没有权限访问
        /// </summary>
        public void DeleteFileByDirectory(DirectoryInfo info)
        {
            foreach (DirectoryInfo newInfo in info.GetDirectories())
            {
                DeleteFileByDirectory(newInfo);
            }
            foreach (FileInfo newInfo in info.GetFiles())
            {
                newInfo.Attributes = newInfo.Attributes & ~(FileAttributes.Archive | FileAttributes.ReadOnly | FileAttributes.Hidden);
                newInfo.Delete();
            }
            info.Attributes = info.Attributes & ~(FileAttributes.Archive | FileAttributes.ReadOnly | FileAttributes.Hidden);
            info.Delete();
        }

        public static void CleanFolder(string strFolderPath)
        {
            if (Directory.Exists(strFolderPath))//如果存在就清空file文件夹
            {
                Directory.Delete(strFolderPath, true);//删除文件夹以及文件夹中的子目录，文件 
            }
            Directory.CreateDirectory(strFolderPath);
        }
        #endregion

        #region 获取指定类型的文件
        /// <summary>
        /// 获取单个指定目录下所有的指定类型的文件
        /// </summary>
        /// <param name="path">文件目录</param>
        /// <param name="strFileType">文件类型</param>
        /// <returns>获取的所有文件名</returns>
        public static List<string> GetFiles(string path, string strFileType)
        {
            List<string> strList = new List<string>();
            DirectoryInfo directory = new DirectoryInfo(path);

            FileInfo[] files = directory.GetFiles(strFileType);

            //MessageBox.Show(files.Length.ToString()); 
            foreach (FileInfo file in files)
            {
                strList.Add(file.Name);
                //MessageBox.Show(file.Name); 
                //MessageBox.Show(file.Directory.ToString()); 
            }
            return strList;
        }

        /// <summary>
        /// 获取指定目录及其子目录下所有的指定类型的文件
        /// </summary>
        /// <param name="directory">指定目录</param>
        /// <param name="pattern">文件类型（*.txt/*.xml等）</param>
        /// <param name="result">存放获取的所有文件</param>
        public static void GetFiles(DirectoryInfo directory, string pattern, ref List<string> result)
        {
            if (directory.Exists || pattern.Trim() != string.Empty)
            {
                try
                {
                    foreach (FileInfo info in directory.GetFiles(pattern))
                    {
                        result.Add(info.FullName.ToString());
                    }
                }
                catch
                {
                }
                foreach (DirectoryInfo info in directory.GetDirectories())
                {
                    GetFiles(info, pattern, ref result);
                }
            }
        }

        /// <summary>
        /// 获取目录及其子目录
        /// </summary>
        /// <param name="strPath"></param>
        /// <param name="lstDirect"></param>
        private static void GetDirectorys(string strPath, ref List<string> lstDirect)
        {
            DirectoryInfo diFliles = new DirectoryInfo(strPath);
            DirectoryInfo[] diArr = diFliles.GetDirectories();

            foreach (DirectoryInfo di in diArr)
            {
                try
                {
                    //directorySecurity = new DirectorySecurity(di.FullName, AccessControlSections.Access);
                    //if (!directorySecurity.AreAccessRulesProtected)
                    //{
                    lstDirect.Add(di.FullName);
                    GetDirectorys(di.FullName, ref lstDirect);
                    //}
                }
                catch
                {
                    continue;
                }
            }
        }
        /// <summary>
        /// 遍历当前目录及子目录
        /// </summary>
        /// <param name="strPath">文件路径</param>
        /// <returns>所有文件</returns>
        private static IList<FileInfo> GetFiles(string strPath)
        {
            List<FileInfo> lstFiles = new List<FileInfo>();
            List<string> lstDirect = new List<string>();
            lstDirect.Add(strPath);
            DirectoryInfo diFliles = null;
            GetDirectorys(strPath, ref lstDirect);
            foreach (string str in lstDirect)
            {
                try
                {
                    diFliles = new DirectoryInfo(str);
                    lstFiles.AddRange(diFliles.GetFiles());
                }
                catch
                {
                    continue;
                }
            }
            return lstFiles;
        }
        #endregion

        #region 文件另存
        /// <summary>
        /// 把List<string>列表下的文件另存到指定文件路径中
        /// </summary>
        /// <param name="strListSrcPath">存放文件列表</param>
        /// <param name="strDesPath">要另存的路径</param>
        public static void CopyFileToDir(List<string> strListSrcPath, string strDesPath)
        {
            try
            {
                // 检查目标目录是否以目录分割字符结束如果不是则添加
                if (strDesPath[strDesPath.Length - 1] != System.IO.Path.DirectorySeparatorChar)
                {
                    strDesPath += System.IO.Path.DirectorySeparatorChar;
                }

                CleanFolder(strDesPath);
                foreach (string file in strListSrcPath)
                {
                    System.IO.File.Copy(file, strDesPath + System.IO.Path.GetFileName(file), true);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 把指定目录及其子目录的所有文件另存到另一指定文件夹中
        /// </summary>
        /// <param name="srcPath"></param>
        /// <param name="aimPath"></param>
        private void CopyDir(string srcPath, string aimPath)
        {
            try
            {
                // 检查目标目录是否以目录分割字符结束如果不是则添加
                if (aimPath[aimPath.Length - 1] != System.IO.Path.DirectorySeparatorChar)
                {
                    aimPath += System.IO.Path.DirectorySeparatorChar;
                }
                // 判断目标目录是否存在如果不存在则新建
                if (!System.IO.Directory.Exists(aimPath))
                {
                    System.IO.Directory.CreateDirectory(aimPath);
                }
                // 得到源目录的文件列表，该里面是包含文件以及目录路径的一个数组
                // 如果你指向copy目标文件下面的文件而不包含目录请使用下面的方法
                // string[] fileList = Directory.GetFiles（srcPath）；
                string[] fileList = System.IO.Directory.GetFileSystemEntries(srcPath);
                // 遍历所有的文件和目录
                foreach (string file in fileList)
                {
                    // 先当作目录处理如果存在这个目录就递归Copy该目录下面的文件
                    if (System.IO.Directory.Exists(file))
                    {
                        CopyDir(file, aimPath + System.IO.Path.GetFileName(file));
                    }
                    // 否则直接Copy文件
                    else
                    {
                        System.IO.File.Copy(file, aimPath + System.IO.Path.GetFileName(file), true);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region 测试
        public static void testFileCopy()
        {
            string TXT_FILE = "*.txt";
            string XML_FILE = "*.xml";

            //bool flagTest = false;
            //flagTest = FilesExist(new DirectoryInfo(@"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96"), "*.txt");

            string strTxtPath = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPath = @"D:\TxtAndXmlTest\xmlFileCopy";

            List<string> strPathList1 = new List<string>();
            List<string> strPathList2 = new List<string>();

            GetFiles(new DirectoryInfo(@"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96"), TXT_FILE, ref strPathList1);
            GetFiles(new DirectoryInfo(@"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96"), XML_FILE, ref strPathList2);

            CopyFileToDir(strPathList1, strTxtPath);
            CopyFileToDir(strPathList2, strXmlPath);

            strPathList1 = GetFiles(strTxtPath, TXT_FILE);
            strPathList2 = GetFiles(strXmlPath, XML_FILE);
        }
        #endregion
    }
}
