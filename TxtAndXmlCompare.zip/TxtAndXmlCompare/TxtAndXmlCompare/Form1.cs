﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Globalization;

namespace TxtAndXmlCompare
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            //BaseFun.CleanFolder(@"D:\TxtAndXmlTest\csvFile");
            txtTxtPath.Text = @"D:\TxtAndXmlTest\txtFile";
            txtXmlPath.Text = @"D:\TxtAndXmlTest\xmlFile";
        }

        private void btnOpenPath1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtTxtPath.Text = dialog.SelectedPath;
            }
        }

        private void btnOpenPath2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtXmlPath.Text = dialog.SelectedPath;
            }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            //Hashtable txtHashtable = new Hashtable();
            //Hashtable xmlHashtable = new Hashtable();
            //txtHashtable = BaseFun.GetTxtDataToHashtable(@"D:\Qiankun Zheng\txtOutput\19XR-6061C67VFG52.txt");
            //xmlHashtable = BaseFun.GetXmlDataToHashtable(@"D:\Qiankun Zheng\txtOutput\19XR-6061C67VFG52_Chiller.XML");
            //BaseFun.compareHashtable(txtHashtable, xmlHashtable, @"D:\Qiankun Zheng\txtOutput\result.csv");

            string strTxtPath = txtTxtPath.Text;
            string strXmlPath = txtXmlPath.Text;
            List<string> strListCsvFileName = new List<string>();
            string strExcelPath = strTxtPath.Substring(0, strTxtPath.LastIndexOf('\\')+1).Trim();

            string strCsvPath = strExcelPath + "\\csvFile\\";
            strListCsvFileName = BaseFun.compareTxtAndXml(strTxtPath, strXmlPath, strCsvPath);
            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath + "result.xlsx");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
