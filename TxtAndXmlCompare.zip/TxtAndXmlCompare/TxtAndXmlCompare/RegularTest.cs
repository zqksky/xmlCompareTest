﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TxtAndXmlCompare
{
    class RegularTest
    {
        public static string testFun(string strInput, string pattern)
        {
            //string pattern = @"^(([A-Z]*|[a-z]*|\d*|[-_\~!@#\$%\^&\*\.\(\)\[\]\{\}<>\?\\\\']*)|.{0,5})$|\s";
            //Regex regex = new Regex(pattern);
            Match match = Regex.Match(strInput, pattern);
            return match.Value;
        }
        public static List<string> test(string strInput, string pattern)
        {
            List<string> strListOutput = new List<string>();

            pattern = @"gr[ae]y\s\S+?[\s\p{P}]";
            strInput = "The gray wolf jumped over the grey wall.";

            MatchCollection matches = Regex.Matches(strInput, pattern);
            foreach (Match match in matches)
            {
                strListOutput.Add(match.Value);
            }
            return strListOutput;
        }
    }
}
