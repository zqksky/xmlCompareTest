﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Linq;

namespace TxtAndXmlCompare
{
    class ReadXmlFun
    {
        #region 获取xml文件中的数据到Hashtable
        public static Hashtable GetXmlDataToHashtable(string xmlPath)
        {
            Hashtable ht = new Hashtable();

            XElement xe = XElement.Load(xmlPath);
            //IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
            //                                 select ele;

            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("Project").Elements("CSTIC")
                                             select ele;

            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("CHARC").Value;
                strValue = ele.Attribute("VALUE").Value;

                //if (ele.LastAttribute.Name == "VALUE_TXT")
                //{
                //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                //}
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

                ht.Add(strKey, strValue);
            }
            return ht;
        }
        #endregion
    }
}
