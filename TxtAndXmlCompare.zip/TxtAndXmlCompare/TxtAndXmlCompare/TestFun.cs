﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace TxtAndXmlCompare
{
    class TestFun
    {
        private const string TXT_FILE = "*.txt";
        private const string XML_FILE = "*.xml";

        public static void RemoveKey(ref string strTxt, string strKey)
        {
            //strTxt = strTxt.Substring(strTxt.IndexOf(strKey) + strKey.Length+2);
            if (strTxt.Contains(strKey))
            {
                strTxt = strTxt.Remove(strTxt.IndexOf(strKey), strKey.Length);
            }
            strTxt = FormatTxt(strTxt);
        }

        public static string GetSingLineValue(ref string strTxt, string strKey)
        {
            string strValue = "";
            string strTemp = "";
            if (strTxt.Contains(strKey))
            {
                strTemp = strTxt.Substring(strTxt.IndexOf(strKey));
                strTemp = strTemp.Substring(0, strTemp.IndexOf("\r\n"));
                strTxt = strTxt.Replace(strTemp+"\r\n", "");
                strValue = strTemp.Substring(strKey.Length);
            }

            return strValue.Trim();
        }

        public static string GetSingLineValue(ref string strTxt, string strKey,bool IsDelete)
        {
            string strValue = "";
            string strTemp = "";
            if (strTxt.Contains(strKey))
            {
                strTemp = strTxt.Substring(strTxt.IndexOf(strKey));
                strTemp = strTemp.Substring(0, strTemp.IndexOf("\r\n"));
                //strTxt = strTxt.Replace(strTemp + "\r\n", "");
                strValue = strTemp.Substring(strKey.Length);
                if (IsDelete)
                {
                    strTxt = strTxt.Substring(strTxt.IndexOf(strValue + "\r\n") + strValue.Length+2);
                }
            }

            return strValue.Trim();
        }

        public static string GetCombinSigleLineValue(ref string strTxt, string strKeyType, string strKey)
        {
            string strValue = "";
            string strTemp = "";
            if (strTxt.Contains(strKeyType+"\r\n"+strKey))
            {
                strTemp = strTxt.Substring(strTxt.IndexOf(strKey));
                strTemp = strTemp.Substring(0, strTemp.IndexOf("\r\n"));
                //strTxt = strTxt.Replace(strTemp + "\r\n", "");
                strTxt = strTxt.Remove(strTxt.IndexOf(strTemp + "\r\n"), strTemp.Length+2);
                strValue = strTemp.Substring(strKey.Length);
                strValue = strValue.Trim('\t');
            }
            strTxt = FormatTxt(strTxt);
            return strValue.Trim();
        }

        private static bool FirstIsNumber(string strValue)
        {
            Regex regChina = new Regex("^[^\x00-\xFF]");
            Regex regNum = new Regex("^[0-9-]");
            Regex regChar = new Regex("^[a-z]");
            Regex regDChar = new Regex("^[A-Z]");
            if (regNum.IsMatch(strValue))
            {
                //MessageBox.Show("是数字");
                return true;
            }
            else if (regChina.IsMatch(strValue))
            {
                //MessageBox.Show("是中文");
                return false;
            }
            else if (regChar.IsMatch(strValue))
            {
                //MessageBox.Show("小写");
                return false;
            }
            else if (regDChar.IsMatch(strValue))
            {
                //MessageBox.Show("大写");
                return false;
            }
            else
            {
                return false;
            }
        }
        public static void GetMultiLineValue(ref string strTxt, string strKeyType, ref List<string> strListValue)
        {
            string strValue = "";
            string strTemp = "";
            string strLineTemp="";

            strTemp = strKeyType + "\r\n";
            if (strTxt.Contains(strTemp))
            {
                strLineTemp = strTxt.Substring(strTxt.IndexOf(strTemp) + strTemp.Length);
                strLineTemp = strLineTemp.Substring(0, strLineTemp.IndexOf("\r\n"));
                if (FirstIsNumber(strLineTemp))
                {
                    strValue = Regex.Replace(strLineTemp, "[^\\d.%-]*", "", RegexOptions.IgnoreCase);
                    strValue = strValue.Trim();
                    strValue = strValue.TrimEnd('.');
                    strListValue.Add(strValue);
                    strTxt = strTxt.Remove(strTxt.IndexOf(strLineTemp + "\r\n"), strLineTemp.Length + 2);
                    strTxt = FormatTxt(strTxt);
                    GetMultiLineValue(ref strTxt, strKeyType, ref strListValue);
                }
                strTxt = strTxt.Replace(strKeyType + "\r\n", "");
                strTxt = FormatTxt(strTxt);
            }
        }
        public static void GetMultiLineValueNew(ref string strTxt, string strKeyType, ref List<string> strListValue)
        {
            string strValue = "";
            string strTemp = "";
            string strLineTemp = "";
            string strLineTempNext = "";

            strTemp = strKeyType + "\r\n";
            if (!strTxt.Contains(strTemp))
            {
                strLineTemp = strKeyType.Substring(0,strKeyType.LastIndexOf(" "));
                if (strTxt.Contains(strLineTemp))
                {
                    strLineTempNext = strTxt.Substring(strTxt.IndexOf(strLineTemp)+ strLineTemp.Length+3);
                    strLineTempNext = strLineTempNext.Substring(0, strLineTempNext.IndexOf("\r\n"));
                    if (strLineTemp + " " + strLineTempNext == strKeyType)
                    {
                        strTxt = strTxt.Replace(strLineTemp + " \r\n" + strLineTempNext, strKeyType);
                        strTxt = FormatTxt(strTxt);
                    }
                }
            }

            if (strTxt.Contains(strTemp))
            {
                strLineTemp = strTxt.Substring(strTxt.IndexOf(strTemp) + strTemp.Length);
                strLineTemp = strLineTemp.Substring(0, strLineTemp.IndexOf("\r\n"));
                if (FirstIsNumber(strLineTemp))
                {
                    strValue = Regex.Replace(strLineTemp, "[^\\d.%-]*", "", RegexOptions.IgnoreCase);
                    strValue = strValue.Trim();
                    strValue = strValue.TrimEnd('.');
                    strListValue.Add(strValue);
                    strTxt = strTxt.Remove(strTxt.IndexOf(strLineTemp + "\r\n"), strLineTemp.Length + 2);
                    strTxt = FormatTxt(strTxt);
                    GetMultiLineValueNew(ref strTxt, strKeyType, ref strListValue);
                }
                strTxt = strTxt.Replace(strKeyType + "\r\n", "");
                strTxt = FormatTxt(strTxt);
            }
        }
        public static void GetCombinMultiLineValueTemp(ref string strTxt, string strKeyType, string strKey, ref List<string> strListValue)
        {
            string strValue = "";
            string strTemp = "";
            string strLineTemp = "";
            string strLineTempNext = "";
            string strNextLineTemp = "";

            strTemp = strKeyType + "\r\n";
            if (strTxt.Contains(strTemp))
            {
                strLineTemp = strTxt.Substring(strTxt.IndexOf(strTemp) + strTemp.Length);
                strLineTemp = strLineTemp.Substring(0, strLineTemp.IndexOf("\r\n"));
                if (!strTxt.Contains(strKey))
                {
                    strLineTempNext = strTxt.Substring(strTxt.IndexOf(strLineTemp) + strLineTemp.Length + 2);
                    strLineTempNext = strLineTempNext.Substring(0, strLineTempNext.IndexOf("\r\n"));
                    //strLineTemp = strLineTemp + strLineTempNext;
                    if (strLineTemp + strLineTempNext == strKey)
                    {
                        strTxt = strTxt.Replace(strLineTemp + "\r\n" + strLineTempNext, strKey);
                        strLineTemp = strKey;
                    }
                }
                if (strLineTemp == strKey)
                {
                    strNextLineTemp = strTxt.Substring(strTxt.IndexOf(strLineTemp) + strLineTemp.Length + 2);
                    strNextLineTemp = strNextLineTemp.Substring(0, strNextLineTemp.IndexOf("\r\n"));
                    if (FirstIsNumber(strNextLineTemp))
                    {
                        strValue = Regex.Replace(strNextLineTemp, "[^\\d.%-]*", "", RegexOptions.IgnoreCase);
                        strValue = strValue.Trim();
                        strValue = strValue.TrimEnd('.');
                        strListValue.Add(strValue);
                        strTxt = strTxt.Remove(strTxt.IndexOf(strNextLineTemp + "\r\n"), strNextLineTemp.Length + 2);
                        strTxt = FormatTxt(strTxt);
                        GetCombinMultiLineValueTemp(ref strTxt, strKeyType, strKey, ref strListValue);
                    }
                }
                //strTxt = strTxt.Remove(strTxt.IndexOf(strKey), strKey.Length + 2);
                //strTxt = strTxt.Replace(strKeyType + "\r\n", "");
            }
        }

        public static void GetCombinMultiLineValue(ref string strTxt, string strKeyType, string strKey, ref List<string> strListValue)
        {
            GetCombinMultiLineValueTemp(ref strTxt, strKeyType, strKey, ref strListValue);
            if (strTxt.Contains(strKey))
            {
                strTxt = strTxt.Remove(strTxt.IndexOf(strKey + "\r\n"), strKey.Length + 2);
            }
            strTxt = FormatTxt(strTxt);
        }

        public static string FormatTxt(string strTxt)
        {
            strTxt = Regex.Replace(strTxt, @"[' ']+", " ", RegexOptions.IgnoreCase);
            strTxt = Regex.Replace(strTxt, @"\r\n ?", "\r\n");
            strTxt = Regex.Replace(strTxt, @"[\r\n]+", "\r\n", RegexOptions.IgnoreCase);
            strTxt = Regex.Replace(strTxt, @"[\t]+", "\t", RegexOptions.IgnoreCase);
            strTxt = Regex.Replace(strTxt, @"[^ A-Za-z0-9_\r\n\t()-/%*.' ':]", "", RegexOptions.IgnoreCase);
            return strTxt;
        }

        public static void WriteHashtableValue(List<string> strListValue, ref Hashtable ht, string strKey)
        {
            if (strListValue.Count > 0)
            {
                for (int i = 0; i < strListValue.Count; i++)
                {
                    if (i == 0)
                    {
                        ht.Add(strKey, strListValue[i]);
                    }
                    else
                    {
                        ht.Add(strKey + "_" + (i + 1), strListValue[i]);
                    }
                }
            }
        }

        public static string GetTheRangeString(ref string strTxt, string strStartKey,string strEndKey)
        {
            string strTemp = "";
            string strValue = "";
            string strTxtTemp = "";
            if (strTxt.Contains(strStartKey) && strTxt.Contains(strEndKey))
            {
                strTxtTemp = strTxt.Substring(strTxt.IndexOf(strStartKey));
                strTemp = strTxtTemp.Substring(0, strTxtTemp.IndexOf("\r\n"));
                strValue = strTxtTemp.Substring(strTxtTemp.IndexOf("\r\n") + 2);
                strValue = strValue.Substring(0, strValue.IndexOf(strEndKey));
                strTxt = strTxt.Remove(strTxt.IndexOf(strValue),strValue.Length);
                strTxt = strTxt.Remove(strTxt.IndexOf(strTemp + "\r\n"), strTemp.Length + 2);
                strTxt = FormatTxt(strTxt);
            }

            return strValue;
        }

        #region 读取txt文件
        public static void ReadTxt()
        {
            string strTemp;
            string strTxtValue = "";
            string strTxtValueTemp = "";
            string strTxtFilePath = @"D:\TxtAndXmlTest\PN4.txt";

            using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                strTxtValue = sr.ReadToEnd();
                strTxtValue = FormatTxt(strTxtValue);
                strTxtValueTemp = strTxtValue;

                strTemp = GetSingLineValue(ref strTxtValueTemp, "Project Name:",true);
                strTemp = strTemp.Substring(0, strTemp.IndexOf("\t"));

                strTemp = GetSingLineValue(ref strTxtValueTemp, "Tag Name:", true);

                strTemp = GetSingLineValue(ref strTxtValueTemp, "Chiller Model");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Starter / VFD");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Refrigerant Type");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Isolation Valve");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Automatic Hot Gas Bypass");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Operation Type");
                strTemp = GetSingLineValue(ref strTxtValueTemp, "Control Type");
                //RemoveKey(ref strTxtValueTemp, "Chiller\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Waterbox Type");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Passes");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Nozzle Arrangement");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Tubing");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Fluid Type");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Fouling Factor");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Tube Quantity");
                //RemoveKey(ref strTxtValueTemp, "Cooler\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Map ID");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Gear Size Code");
                //RemoveKey(ref strTxtValueTemp, "Compressor\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Total Rigging Weight");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Total Operating Weight");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Refrigerant Weight");
                //RemoveKey(ref strTxtValueTemp, "Weights\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Waterbox Type");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Passes");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Nozzle Arrangement");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Tubing");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Fluid Type");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Fouling Factor");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Tube Quantity");
                //RemoveKey(ref strTxtValueTemp, "Condenser\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Motor", "Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Motor", "Line Voltage/Hertz");
                //RemoveKey(ref strTxtValueTemp, "Motor\r\n");

                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "High Side Orifice Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Float Valve Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Economizer Float Valve Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Low Side Float Ball Valve Size");
                strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Flasc Orifice");
                //RemoveKey(ref strTxtValueTemp, "Flow Controls\r\n");

                List<string> strListValue = new List<string>();
                GetMultiLineValue(ref strTxtValueTemp, "Percent Load", ref strListValue);

                GetMultiLineValue(ref strTxtValueTemp, "Chiller Capacity", ref strListValue);

                GetMultiLineValue(ref strTxtValueTemp, "Chiller Input kW", ref strListValue);

                GetMultiLineValue(ref strTxtValueTemp, "Chiller Efficiency", ref strListValue);

                GetMultiLineValue(ref strTxtValueTemp, "Chiller COPR", ref strListValue);


                GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Entering Temp.", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Leaving Temp.", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Flow Rate", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Pressure Drop", ref strListValue);
                RemoveKey(ref strTxtValueTemp, "Cooler\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Heat Rejection", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Leaving Temp.", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Entering Temp.", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Flow Rate", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Pressure Drop", ref strListValue);
                RemoveKey(ref strTxtValueTemp, "Condenser\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor Rated Load Amps", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor OLTA", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor LRYA", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor LRDA", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Chiller Rated Line Amps", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Max Fuse/CB Amps", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Min Circuit Ampacity", ref strListValue);
                //RemoveKey(ref strTxtValueTemp, "Motor\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Flow Fraction", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Head Fraction", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Discharge Temp", ref strListValue);
                //RemoveKey(ref strTxtValueTemp, "Compressor\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP GVmin", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP Delta Tsmin", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge Line Shape Factor", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP GVmax", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP Delta Tsmax", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Cooler Min DP", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Condenser Min DP", ref strListValue);
                //RemoveKey(ref strTxtValueTemp, "Control Parameters\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Condensing Temp", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Wall Temp", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Suction Temp", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Freeze Temp", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Tube Vel", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Reynolds No", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cond Tube Vel", ref strListValue);
                //RemoveKey(ref strTxtValueTemp, "Heat Exchangers\r\n");

                GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Fouling Temp Adj", ref strListValue);
                GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Fouling Temp Adj", ref strListValue);

                sr.Close();
                fs.Close();
            }

            //strTxtValue = File.ReadAllText(strTxtFilePath, Encoding.UTF8);
            //StreamReader sr = new StreamReader(strTxtFilePath, Encoding.UTF8);
        }
        #endregion

        #region 获取txt文件中的数据到Hashtable
        public static Hashtable GetTxtDataToHashtable(string strTxtFilePath)
        {
            string strTemp;
            string strTemp2;
            string strTemp3;
            string strTemp4;
            string strTxtValue = "";
            string strTxtValueTemp = "";

            Hashtable ht = new Hashtable();
            List<string> strListValue = new List<string>();
            ht.Clear();

            using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                strTxtValue = sr.ReadToEnd();
                strTxtValue = FormatTxt(strTxtValue);
                if (!strTxtValue.Contains("Error:"))
                {
                    strTxtValueTemp = strTxtValue;
                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Chiller\r\nChiller Model", "Cooler\r\nSize");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Cooler\r\nSize", "Compressor\r\nSize");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Compressor\r\nSize", "Weights\r\n");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Weights\r\n", "Condenser\r\nSize");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Condenser\r\nSize", "Motor\r\nSize");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Motor\r\nSize", "Flow Controls\r\n");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Cooler\r\n", "Condenser\r\n");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Condenser\r\n", "Motor\r\n");

                    //strTemp = GetTheRangeString(ref strTxtValueTemp, "Cooler\r\n", "Condenser\r\n");

                    #region
                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Project Name:", true);
                    if (strTemp != "")
                    {
                        strTemp = strTemp.Substring(0, strTemp.IndexOf("\t"));
                        ht.Add("PROJECT_NAME", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "AquaEdge Chiller Builder", true);
                    if (strTemp != "")
                    {
                        strTemp = strTemp.Substring(0, strTemp.IndexOf("\t"));
                        strTemp = strTemp.Substring(1);
                        ht.Add("ECAT_VERSION", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Tag Name:", true);
                    if (strTemp != "")
                    {
                        ht.Add("TAG_NAME", strTemp);
                    }
                    #endregion

                    #region Chiller
                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Chiller Model");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp.TrimEnd('-');
                        strTemp3 = strTemp2.Substring(0, 5).TrimEnd('-');
                        if (strTemp3.IndexOf("19XRV") >= 0)
                        {
                            strTemp3 = "19XR";
                        }
                        strTemp2 = strTemp2.Substring(strTemp2.Length - 2, 2);
                        ht.Add("ITEM_PART_NUMBER", strTemp);
                        ht.Add("CHILLER_MODULE", strTemp3);
                        ht.Add("COMPR_MOTOR_VOLTAGE", strTemp2);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Starter / VFD");

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Refrigerant Type");
                    if (strTemp != "")
                    {
                        ht.Add("REFRIG_TYPE", "R134A");
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Isolation Valve");
                    if (strTemp != "")
                    {
                        if (strTemp == "Installed")
                        {
                            strTemp = "1";
                        }
                        else
                        {
                            strTemp = "0";
                        }
                        ht.Add("ISOLATION_VALVES", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Automatic Hot Gas Bypass");
                    if (strTemp != "")
                    {
                        ht.Add("ENVELOPE_STABILITY_CONTROL", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Envelope Stability Control");
                    if (strTemp != "")
                    {
                        ht.Add("ENVELOPE_STABILITY_CONTROL", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Operation Type");
                    if (strTemp != "")
                    {
                        ht.Add("OPERATION_TYPE", strTemp);
                    }

                    strTemp = GetSingLineValue(ref strTxtValueTemp, "Control Type");
                    if (strTemp != "")
                    {
                        ht.Add("CONTROL_TYPE", strTemp);
                    }

                    //RemoveKey(ref strTxtValueTemp, "Chiller\r\n");
                    #endregion

                    #region Cooler
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Size");
                    if (strTemp != "")
                    {
                        ht.Add("COOLER", strTemp);
                        ht.Add("COOL_FRAME", strTemp.Substring(0, 1));
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Waterbox Type");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp.Substring(0, strTemp.IndexOf(','));
                        if (strTemp2 == "Nozzle-in-Head")
                        {
                            strTemp2 = "A;Nozzle-in-Head";
                        }
                        else if (strTemp2 == "Marine Waterbox")
                        {
                            strTemp2 = "B;Marine Waterbox";
                        }
                        strTemp3 = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                        strTemp3 = Regex.Replace(strTemp3, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                        if (strTemp3.IndexOf("1034") >= 0)
                        {
                            strTemp3 = "150;Psi";
                        }
                        else if (strTemp3.IndexOf("1654") >= 0)
                        {
                            strTemp3 = "240;Psi";
                        }
                        else if (strTemp3.IndexOf("2068") >= 0)
                        {
                            strTemp3 = "300;Psi";
                        }
                        ht.Add("COOL_WB_TYPE", strTemp2);
                        ht.Add("COOL_WB_PRESS", strTemp3);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Passes");
                    if (strTemp != "")
                    {
                        ht.Add("COOL_PASS", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Nozzle Arrangement");
                    if (strTemp != "")
                    {
                        if (strTemp.IndexOf(')') >= 0)
                        {
                            strTemp = strTemp.Substring(0, 1);
                        }
                        else
                        {
                            if (strTemp.IndexOf("Will Advise") >= 0)
                            {
                                //批跑的xml文件会设置此项的值
                                //strTemp= "Nozzles on Drive End";
                            }
                        }
                        ht.Add("COOL_NOZZLE_CODE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Tubing");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp.Substring(0, strTemp.IndexOf(','));
                        strTemp2 = strTemp2.Trim();

                        strTemp4 = strTemp.Substring(strTemp.LastIndexOf(',') + 1).Trim();
                        strTemp3 = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                        strTemp3 = strTemp3.Substring(0, strTemp3.IndexOf(',')).Trim();
                        if (strTemp3.IndexOf(".635") >= 0)
                        {
                            strTemp3 = "A;0.025";
                        }
                        else if (strTemp3.IndexOf(".711") >= 0)
                        {
                            strTemp3 = "B;0.028";
                        }
                        else if (strTemp3.IndexOf(".889") >= 0)
                        {
                            strTemp3 = "C;0.035";
                        }
                        ht.Add("COOL_TUBE_DESCRP", strTemp2);
                        ht.Add("COOL_TUBE_MATL", strTemp4);
                        ht.Add("COOL_WALL_THICK", strTemp3);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Fluid Type");
                    if (strTemp != "")
                    {
                        if (strTemp.IndexOf(',') > 0)
                        {
                            strTemp = strTemp.Substring(0, strTemp.IndexOf(',')).Trim();
                        }
                        ht.Add("COOL_FLUID_TYPE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Fouling Factor");
                    if (strTemp != "")
                    {
                        strTemp = strTemp.Substring(strTemp.IndexOf("\t"));
                        //strTemp = strTemp.Substring(strTemp.IndexOf(")/") + 4);
                        strTemp = Regex.Replace(strTemp, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                        strTemp = strTemp.Trim();
                        ht.Add("COOLER_FOULING_FACTOR", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Cooler", "Tube Quantity");
                    if (strTemp != "")
                    {
                        //ht.Add("Tube Quantity", strTemp);
                    }

                    RemoveKey(ref strTxtValueTemp, "Cooler\r\n");
                    #endregion

                    #region Compressor
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Size");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp;
                        if (strTemp.IndexOf('(') > 0)
                        {
                            if (strTemp.IndexOf("R (FL Opt.)") >= 0)
                            {
                                strTemp = "R05";//R03、R05
                            }
                            else if (strTemp.IndexOf("R (PL Opt.)") >= 0)
                            {
                                strTemp = "R1";//R13、R15
                            }
                            else if (strTemp.IndexOf("Q (FL Opt.)") >= 0)
                            {
                                strTemp = "Q0";//Q03、Q05
                            }
                            else if (strTemp.IndexOf("Q (PL Opt.)") >= 0)
                            {
                                strTemp = "Q1";//Q13、Q15
                            }
                        }
                        strTemp2 = strTemp2.Substring(0, 1);
                        ht.Add("COMPRESSOR", strTemp);
                        ht.Add("COMPR_FRAME", strTemp2);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Map ID");
                    if (strTemp != "")
                    {
                        ht.Add("COMPRESSOR_MAP", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Compressor", "Gear Size Code");
                    if (strTemp != "")
                    {
                        ht.Add("GEAR_CODE", strTemp);
                    }

                    RemoveKey(ref strTxtValueTemp, "Compressor\r\n");
                    #endregion

                    #region Weights
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Total Rigging Weight");
                    if (strTemp != "")
                    {
                        strTemp = Regex.Replace(strTemp, "[a-z]", "", RegexOptions.IgnoreCase).Trim();
                        ht.Add("SHIPPING_WEIGHT", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Total Operating Weight");
                    if (strTemp != "")
                    {
                        strTemp = Regex.Replace(strTemp, "[a-z]", "", RegexOptions.IgnoreCase).Trim();
                        ht.Add("OPERATING_WEIGHT", strTemp);
                    }
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Weights", "Refrigerant Weight");
                    if (strTemp != "")
                    {
                        strTemp = Regex.Replace(strTemp, "[a-z]", "", RegexOptions.IgnoreCase).Trim();
                        ht.Add("REFRIG_WEIGHT", strTemp);
                    }
                    RemoveKey(ref strTxtValueTemp, "Weights\r\n");
                    #endregion

                    #region Condenser
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Size");
                    if (strTemp != "")
                    {
                        ht.Add("CONDENSER", strTemp);
                        ht.Add("COND_FRAME", strTemp.Substring(0, 1));
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Waterbox Type");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp.Substring(0, strTemp.IndexOf(','));
                        if (strTemp2 == "Nozzle-in-Head")
                        {
                            strTemp2 = "A;Nozzle-in-Head";
                        }
                        else if (strTemp2 == "Marine Waterbox")
                        {
                            strTemp2 = "B;Marine Waterbox";
                        }
                        strTemp3 = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                        strTemp3 = Regex.Replace(strTemp3, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                        if (strTemp3.IndexOf("1034") >= 0)
                        {
                            strTemp3 = "150;Psi";
                        }
                        else if (strTemp3.IndexOf("1654") >= 0)
                        {
                            strTemp3 = "240;Psi";
                        }
                        else if (strTemp3.IndexOf("2068") >= 0)
                        {
                            strTemp3 = "300;Psi";
                        }
                        ht.Add("COND_WB_TYPE", strTemp2);
                        ht.Add("COND_WB_PRESS", strTemp3);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Passes");
                    if (strTemp != "")
                    {
                        ht.Add("COND_PASS", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Nozzle Arrangement");
                    if (strTemp != "")
                    {
                        if (strTemp.IndexOf(')') >= 0)
                        {
                            strTemp = strTemp.Substring(0, 1);
                        }
                        else
                        {
                            if (strTemp.IndexOf("Will Advise") >= 0)
                            {
                                //批跑的xml文件会设置此项的值
                                strTemp = "Nozzles on Drive End";
                            }
                        }
                        ht.Add("COND_NOZZLE_CODE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Tubing");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp.Substring(0, strTemp.IndexOf(','));
                        strTemp2 = strTemp2.Trim();

                        strTemp4 = strTemp.Substring(strTemp.LastIndexOf(',') + 1).Trim();
                        strTemp3 = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                        strTemp3 = strTemp3.Substring(0, strTemp3.IndexOf(',')).Trim();
                        if (strTemp3.IndexOf(".635") >= 0)
                        {
                            strTemp3 = "A;0.025";
                        }
                        else if (strTemp3.IndexOf(".711") >= 0)
                        {
                            strTemp3 = "B;0.028";
                        }
                        else if (strTemp3.IndexOf(".889") >= 0)
                        {
                            strTemp3 = "C;0.035";
                        }
                        ht.Add("COND_TUBE_DESCRP", strTemp2);
                        ht.Add("COND_TUBE_MATL", strTemp4);
                        ht.Add("COND_WALL_THICK", strTemp3);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Fluid Type");
                    if (strTemp != "")
                    {
                        if (strTemp.IndexOf(',') > 0)
                        {
                            strTemp = strTemp.Substring(0, strTemp.IndexOf(',')).Trim();
                        }
                        ht.Add("COND_FLUID_TYPE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Fouling Factor");
                    if (strTemp != "")
                    {
                        strTemp = strTemp.Substring(strTemp.IndexOf("\t"));
                        //strTemp = strTemp.Substring(strTemp.IndexOf(")/") + 4);
                        strTemp = Regex.Replace(strTemp, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                        strTemp = strTemp.Trim();
                        ht.Add("CONDENSER_FOULING_FACTOR", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Condenser", "Tube Quantity");
                    if (strTemp != "")
                    {
                        //ht.Add("Tube Quantity", strTemp);
                    }
                    RemoveKey(ref strTxtValueTemp, "Condenser\r\n");
                    #endregion

                    #region Motor
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Motor", "Size");
                    if (strTemp != "")
                    {
                        if (strTemp.IndexOf(')') > 0)
                        {
                            strTemp2 = strTemp.Substring(0, strTemp.IndexOf('('));
                            strTemp2 = strTemp2.Trim();
                        }
                        else
                        {
                            strTemp2 = strTemp.Substring(0, 2);
                            strTemp = strTemp.Substring(strTemp.Length - 1, 1);
                        }
                        ht.Add("MOTOR_CODE", strTemp2);
                        ht.Add("MOTOR_EFFICIENCY", strTemp);
                    }
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Motor", "Line Voltage/Hertz");
                    if (strTemp != "")
                    {
                        strTemp2 = strTemp;
                        strTemp3 = strTemp2.Substring(strTemp2.IndexOf('-') + 1);
                        strTemp2 = System.Text.RegularExpressions.Regex.Replace(strTemp2.Substring(0, strTemp2.IndexOf('-')), @"[^0-9]+", "");
                        strTemp4 = strTemp3.Substring(0, strTemp3.IndexOf('-'));
                        strTemp3 = strTemp3.Substring(strTemp3.IndexOf('-') + 1);
                        ht.Add("COMPRESSOR_VOLTS", strTemp2);
                        ht.Add("COMPRESSOR_PHASE", strTemp4);
                        ht.Add("COMPRESSOR_HERTZ", strTemp3);
                    }
                    RemoveKey(ref strTxtValueTemp, "Motor\r\n");
                    #endregion

                    #region Flow Controls
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "High Side Orifice Size");
                    if (strTemp != "")
                    {
                    }
                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Float Valve Size");
                    if (strTemp != "")
                    {
                        ht.Add("FLOAT_VALVE_SIZE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Economizer Float Valve Size");
                    if (strTemp != "")
                    {
                        ht.Add("FLOAT_BALL_VALVE_SIZE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Low Side Float Ball Valve Size");
                    if (strTemp != "")
                    {
                        //ht.Add("FLOAT_BALL_VALVE_SIZE", strTemp);
                    }

                    strTemp = GetCombinSigleLineValue(ref strTxtValueTemp, "Flow Controls", "Flasc Orifice");
                    if (strTemp != "")
                    {
                        strTemp = System.Text.RegularExpressions.Regex.Replace(strTemp, @"[^0-9]+", "");
                        ht.Add("COND_FLASC_ORIFICE", strTemp);
                    }
                    RemoveKey(ref strTxtValueTemp, "Flow Controls\r\n");
                    #endregion

                    #region
                    strListValue.Clear();
                    GetMultiLineValue(ref strTxtValueTemp, "Percent Load", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PERCENT_LOAD");

                    strListValue.Clear();
                    GetMultiLineValueNew(ref strTxtValueTemp, "Chiller Heating Capacity", ref strListValue);
                    if (strListValue.Count > 0)
                    {
                        strTemp = strListValue[0];
                        if (!strTemp.Contains("."))
                        {
                            strTemp = strTemp.Insert(1, ",");
                        }
                        ht.Add("CHILLER_CAPACITY", strTemp);
                    }
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_CAPACITY");

                    strListValue.Clear();
                    GetMultiLineValue(ref strTxtValueTemp, "Chiller Capacity", ref strListValue);
                    if (strListValue.Count > 0)
                    {
                        strTemp = strListValue[0];
                        if (!strTemp.Contains("."))
                        {
                            strTemp = strTemp.Insert(1, ",");
                        }
                        ht.Add("CHILLER_CAPACITY", strTemp);
                    }
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_CAPACITY");

                    strListValue.Clear();
                    GetMultiLineValue(ref strTxtValueTemp, "Chiller Input kW", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "INPUT_KW");

                    strListValue.Clear();
                    GetMultiLineValueNew(ref strTxtValueTemp, "Chiller Heating Efficiency", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "INPUT_KW_PER_TON");

                    strListValue.Clear();
                    GetMultiLineValue(ref strTxtValueTemp, "Chiller Efficiency", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "INPUT_KW_PER_TON");

                    strListValue.Clear();
                    GetMultiLineValueNew(ref strTxtValueTemp, "Chiller Heating COP", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COP");

                    strListValue.Clear();
                    GetMultiLineValue(ref strTxtValueTemp, "Chiller COPR", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COP");
                    #endregion

                    #region Cooler
                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Entering Temp.", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_EWT");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Leaving Temp.", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_LWT");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Flow Rate", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_FLOW");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Pressure Drop", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_PRESSURE_DROP");

                    RemoveKey(ref strTxtValueTemp, "Cooler\r\n");
                    #endregion

                    #region Condenser
                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Heat Rejection", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "HEAT_REJECTION");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Leaving Temp.", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "CONDENSER_LWT");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Entering Temp.", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "CONDENSER_EWT");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Flow Rate", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "CONDENSER_FLOW");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Pressure Drop", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "CONDENSER_PRESSURE_DROP");

                    RemoveKey(ref strTxtValueTemp, "Condenser\r\n");
                    #endregion

                    #region Motor
                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor Rated Load Amps", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Motor Rated Load Amps", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MOTOR_RLA");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor OLTA", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Motor OLTA", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MOTOR_OLTA");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor LRYA", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Motor LRYA", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MOTOR_LRYA");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Motor LRDA", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Motor LRDA", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MOTOR_LRDA");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Chiller Rated Line Amps", ref strListValue);
                    GetMultiLineValueNew(ref strTxtValueTemp, "Chiller Rated Line Amps", ref strListValue);
                    //WriteHashtableValue(strListValue, ref  ht, "PERCENT_LOAD");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Max Fuse/CB Amps", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Max Fuse/CB Amps", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MAX_FUSE_CIRCUIT_BREAKER");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Motor", "Min Circuit Ampacity", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Min Circuit Ampacity", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "MIN_CIRCUIT_AMPACITY");

                    RemoveKey(ref strTxtValueTemp, "Motor\r\n");
                    #endregion

                    #region Compressor
                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Flow Fraction", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Flow Fraction", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COMPR_FLOW_FRACTION");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Head Fraction", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Head Fraction", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COMPR_HEAD_FRACTION");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Compressor", "Discharge Temp", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Discharge Temp", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COMP_DISCH_TEMP");

                    RemoveKey(ref strTxtValueTemp, "Compressor\r\n");
                    #endregion

                    #region Control Parameters
                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP GVmin", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Surge/HGBP GVmin", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_GV_MIN");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP Delta Tsmin", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Surge/HGBP Delta Tsmin", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_DTSMIN");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge Line Shape Factor", ref strListValue);
                    GetMultiLineValueNew(ref strTxtValueTemp, "Surge Line Shape Factor", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_SHAPEFAC");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP GVmax", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Surge/HGBP GVmax", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_GV_MAX");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Surge/HGBP Delta Tsmax", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Surge/HGBP Delta Tsmax", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_DTSMAX");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Cooler Min DP", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cooler Min DP", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_COOLER_MIN_DP");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Control Parameters", "Condenser Min DP", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Condenser Min DP", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "PARAM_CONDENSER_MIN_DP");

                    RemoveKey(ref strTxtValueTemp, "Control Parameters\r\n");
                    #endregion

                    #region Heat Exchangers
                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Condensing Temp", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Condensing Temp", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "CONDENSING_TEMP");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Wall Temp", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cooler Wall Temp", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_WALL_TEMP");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Suction Temp", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Suction Temp", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_REFRIGERANT_TEMP");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Freeze Temp", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cooler Freeze Temp", ref strListValue);
                    //WriteHashtableValue(strListValue, ref  ht, "PERCENT_LOAD");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Tube Vel", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cooler Tube Vel", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOL_TUBE_VELOCITY");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cooler Reynolds No", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cooler Reynolds No", ref strListValue);
                    //WriteHashtableValue(strListValue, ref  ht, "PERCENT_LOAD");

                    strListValue.Clear();
                    //GetCombinMultiLineValue(ref strTxtValueTemp, "Heat Exchangers", "Cond Tube Vel", ref strListValue);
                    GetMultiLineValue(ref strTxtValueTemp, "Cond Tube Vel", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COND_TUBE_VELOCITY");

                    RemoveKey(ref strTxtValueTemp, "Heat Exchangers\r\n");
                    #endregion

                    #region
                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Cooler", "Fouling Temp Adj", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COOLER_FOULING_ADJUSTMENT");

                    strListValue.Clear();
                    GetCombinMultiLineValue(ref strTxtValueTemp, "Condenser", "Fouling Temp Adj", ref strListValue);
                    WriteHashtableValue(strListValue, ref  ht, "COND_FOULING_ADJUSTMENT");

                    #endregion

                }
                sr.Close();
                fs.Close();
            }
            return ht;
            //strTxtValue = File.ReadAllText(strTxtFilePath, Encoding.UTF8);
            //StreamReader sr = new StreamReader(strTxtFilePath, Encoding.UTF8);
        }
        #endregion

        #region 测试 比较两个Hashtable中的数据
        public static bool compareHashtable(Hashtable txtHashtable, Hashtable xmlHashtable, string strCsvSaveFilePath)
        {
            string strTxtTemp;
            string strXmlTemp;
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in txtHashtable)
            {
                if (xmlHashtable.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == xmlHashtable[de.Key].ToString())
                    {
                        xmlHashtable.Remove(de.Key);
                    }
                    else
                    {
                        if (xmlHashtable[de.Key].ToString().Contains(";"))
                        {
                            if (de.Key.ToString() == "COND_TUBE_DESCRP" || de.Key.ToString() == "COOL_TUBE_DESCRP")
                            {
                                strXmlTemp = xmlHashtable[de.Key].ToString();
                                strXmlTemp = strXmlTemp.Substring(strXmlTemp.IndexOf(";") + 1);
                                if (de.Value.ToString().ToUpper().Contains(strXmlTemp.ToUpper()))
                                {
                                    xmlHashtable.Remove(de.Key);
                                }
                            }
                            else if (xmlHashtable[de.Key].ToString().ToUpper().Contains(de.Value.ToString().ToUpper()))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strList1.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                        else
                        {
                            strTxtTemp = de.Value.ToString();
                            if (strTxtTemp.Contains(".0"))
                            {
                                strTxtTemp = de.Value.ToString().TrimEnd('0');
                            }
                            if (xmlHashtable[de.Key].ToString().Contains(strTxtTemp))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strList1.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                    }
                }
                else
                {
                    strList2.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ""));
                }
            }
            foreach (DictionaryEntry de in xmlHashtable)
            {
                //strList3.Add(de.Key.ToString() + "," + de.Value.ToString());
                strList3.Add(de.Key.ToString() + "," + "," + de.Value.ToString().Replace(",", ""));
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);

                using (FileStream fs = new FileStream(strCsvSaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);

                    sw.WriteLine("Key,TxtValue,XmlValue");  //开始写入
                    if (strList1.Count > 0)
                    {
                        strList1.Sort();
                        //sw.WriteLine("");
                        sw.WriteLine("txt and xml not same");
                        //sw.WriteLine("两个xml文件中不相同的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        strList2.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in txt file");
                        //sw.WriteLine("xml文件1中有而2中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        strList3.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in xml file");
                        //sw.WriteLine("xml文件2中有而1中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }
        #endregion

        #region 测试 批量比较txt和xml
        public static List<string> compareTxtAndXml(string strTxtPath, string strXmlPath, string strCsvFilePath)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strTxtPath == "" || strXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strTxtPath), TXT_FILE))
            {
                MessageBox.Show("txt File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strXmlPath), XML_FILE))
            {
                MessageBox.Show("xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strTxtTemp;
                string strTxtTemp2;
                Hashtable htTxt = new Hashtable();
                Hashtable htXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strTxtPath, TXT_FILE);
                strPathList2 = FileHelper.GetFiles(strXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    if (str.IndexOf("(Inputs Only)") > 0)
                    {
                        strTxtTemp = str.Substring(0, str.LastIndexOf("(Inputs Only)")).Trim() + ".xml";
                        strTxtTemp2 = str.Substring(0, str.LastIndexOf("(Inputs Only)")).Trim() + "_Chiller.xml";
                    }
                    else
                    {
                        strTxtTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";
                        strTxtTemp2 = str.Substring(0, str.LastIndexOf('.')) + "_Chiller.xml";
                    }
                    if (strPathList2.Contains(strTxtTemp) || strPathList2.Contains(strTxtTemp2))
                    {
                        htTxt = BaseFun.GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        if (strPathList2.Contains(strTxtTemp))
                        {
                            htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp);
                        }
                        else if (strPathList2.Contains(strTxtTemp2))
                        {
                            htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp2);
                        }

                        flagSame = compareHashtable(htTxt, htXml, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }

        public static List<string> CompareTxtAndXmlTest(string strTxtPath, string strXmlPath, string strCsvFilePath)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strTxtPath == "" || strXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strTxtPath), TXT_FILE))
            {
                MessageBox.Show("txt File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strXmlPath), XML_FILE))
            {
                MessageBox.Show("xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strTxtTemp;
                Hashtable htTxt = new Hashtable();
                Hashtable htXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strTxtPath, TXT_FILE);
                strPathList2 = FileHelper.GetFiles(strXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    strTxtTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";

                    if (strPathList2.Contains(strTxtTemp))
                    {
                        htTxt = BaseFun.GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp);

                        flagSame = compareHashtable(htTxt, htXml, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }
        #endregion

        #region 测试 获取Hashtable中的数据到CSV文件中
        public static void HastableToCsv(Hashtable ht, string strCsvFileName)
        {
            List<string> strListCsvFileValue = new List<string>();

            if (ht.Count > 0)
            {
                foreach (DictionaryEntry de in ht)
                {
                    strListCsvFileValue.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ";"));
                }
                strListCsvFileValue.Sort();
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine("Key,Value");   //开始写入
                    foreach (var str in strListCsvFileValue)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
            }
        }
        #endregion

        #region 测试 根据集合中的路径生成相应的CSV文件
        public static void ListPathToCsv(List<string> strPathList, string strCsvPath, string strCopyPath)
        {
            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                    strFileName = strFileName.Substring(0, strFileName.LastIndexOf("."));
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                    }
                    else if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                    }
                    HastableToCsv(ht, strCsvPath + "\\" + strFileName + ".csv");
                    System.IO.File.Copy(str, strCopyPath + strFileName + strFileType, true);
                }
            }
        }

        public static void ListTxtPathToCsvNew(List<string> strPathList, string strCsvPath, string strTxtPath, ref Hashtable htTxtMap)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strTxtPath = FileHelper.PathComplement(strTxtPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (!htTxtMap.ContainsKey(strFileName))
                            {
                                pTagNum++;
                                strSaveName = "PN" + pTagNum;
                                htTxtMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                        }
                        else
                        {
                            pTagErrorNum++;
                            strSaveName = "Error-txt" + pTagErrorNum;
                            //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                            //strFileName = str.Substring(0, str.LastIndexOf("\\")) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                            //htTxtMap.Add(strFileName, strSaveName);
                        }
                        System.IO.File.Copy(str, strTxtPath + strSaveName + strFileType, true);
                    }
                }
            }
        }

        public static void ListXmlPathToCsvNew(List<string> strPathList, string strCsvPath, string strXmlPath, ref Hashtable htTxtOnlyMap, ref Hashtable htXmlOnlyMap)
        {
            int pTagNum = 0;
            string strSaveName = "PN";

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strXmlPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strXmlPath = FileHelper.PathComplement(strXmlPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (htTxtOnlyMap.ContainsKey(strFileName))
                            {
                                strSaveName = htTxtOnlyMap[strFileName].ToString();
                                htTxtOnlyMap.Remove(strFileName);
                            }
                            else
                            {
                                pTagNum++;
                                strSaveName = "Only-xml" + pTagNum;
                                htXmlOnlyMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                            System.IO.File.Copy(str, strXmlPath + strSaveName + strFileType, true);
                        }
                    }
                }
            }
        }

        public static Hashtable ListTxtPathToCsv(List<string> strPathList, string strCsvPath, string strTxtPath)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htTxtMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strTxtPath = FileHelper.PathComplement(strTxtPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (!htTxtMap.ContainsKey(strFileName))
                            {
                                pTagNum++;
                                strSaveName = "PN" + pTagNum;
                                htTxtMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                        }
                        else
                        {
                            pTagErrorNum++;
                            strSaveName = "Error-txt" + pTagErrorNum;
                            //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                            //strFileName = str.Substring(0, str.LastIndexOf("\\")) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                            //htTxtMap.Add(strFileName, strSaveName);
                        }
                        System.IO.File.Copy(str, strTxtPath + strSaveName + strFileType, true);
                    }
                }
            }
            return htTxtMap;
        }

        public static Hashtable ListXmlPathToCsv(List<string> strPathList, string strCsvPath, string strXmlPath, Hashtable htTxtMap)
        {
            int pTagNum = 0;
            string strSaveName = "PN";
            Hashtable htXmlMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strXmlPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strXmlPath = FileHelper.PathComplement(strXmlPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (htTxtMap.ContainsKey(strFileName))
                            {
                                strSaveName = htTxtMap[strFileName].ToString();
                                htTxtMap.Remove(strFileName);
                            }
                            else
                            {
                                pTagNum++;
                                strSaveName = "Only-xml" + pTagNum;
                                htXmlMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                            System.IO.File.Copy(str, strXmlPath + strSaveName + strFileType, true);
                        }
                    }
                }
            }
            return htXmlMap;
        }
        #endregion

        #region 测试方法
        public static void RunFun(string strTxtPath, string strXmlPath)
        {
            //strTxtPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";
            //strXmlPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";

            string TXT_FILE = "*.txt";
            string XML_FILE = "*.xml";

            string strCsvPath = @"D:\TxtAndXmlTest\ComPareCsvFile";
            string strExcelPath = @"D:\TxtAndXmlTest\result.xlsx";
            string strTxtSavePath = @"D:\TxtAndXmlTest\txtCsvFile";
            string strXmlSavePath = @"D:\TxtAndXmlTest\xmlCsvFile";
            string strTxtPathCopy = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPathCopy = @"D:\TxtAndXmlTest\xmlFileCopy";

            List<string> strListPathTxt = new List<string>();
            List<string> strListPathXml = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtSavePath);
            FileHelper.CleanFolder(strXmlSavePath);
            FileHelper.CleanFolder(strTxtPathCopy);
            FileHelper.CleanFolder(strXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strTxtPath), TXT_FILE, ref strListPathTxt);
            FileHelper.GetFiles(new DirectoryInfo(strXmlPath), XML_FILE, ref strListPathXml);

            ListPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy);
            ListPathToCsv(strListPathXml, strXmlSavePath, strXmlPathCopy);

            strListCsvFileName = compareTxtAndXml(strTxtPathCopy, strXmlPathCopy, strCsvPath);
            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);

            //List<string> strListTxtName = new List<string>();
            //List<string> strListXmlName = new List<string>();
            //strListTxtName = FileHelper.GetFiles(strTxtPathCopy, TXT_FILE);
            //strListXmlName = FileHelper.GetFiles(strXmlPathCopy, XML_FILE);

            //FileHelper.CopyFileToDir(strListPathTxt, strTxtPathCopy);
            //FileHelper.CopyFileToDir(strListPathXml, strXmlPathCopy);

            //bool flagTest = false;
            //flagTest = FilesExist(new DirectoryInfo(@"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96"), "*.txt");
        }

        public static void RunFunTest(string strTxtPath, string strXmlPath)
        {
            string TXT_FILE = "*.txt";
            string XML_FILE = "*.xml";

            string strCsvPath = @"D:\TxtAndXmlTest\ComPareCsvFile";
            string strExcelPath = @"D:\TxtAndXmlTest\result.xlsx";
            string strTxtSavePath = @"D:\TxtAndXmlTest\txtCsvFile";
            string strXmlSavePath = @"D:\TxtAndXmlTest\xmlCsvFile";
            string strTxtPathCopy = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPathCopy = @"D:\TxtAndXmlTest\xmlFileCopy";

            Hashtable htTxtMap = new Hashtable();
            Hashtable htXmlOnlyMap = new Hashtable();
            Hashtable htTxtOnlyMap = new Hashtable();

            List<string> strListPathTxt = new List<string>();
            List<string> strListPathXml = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtSavePath);
            FileHelper.CleanFolder(strXmlSavePath);
            FileHelper.CleanFolder(strTxtPathCopy);
            FileHelper.CleanFolder(strXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strTxtPath), TXT_FILE, ref strListPathTxt);
            FileHelper.GetFiles(new DirectoryInfo(strXmlPath), XML_FILE, ref strListPathXml);

            //ListTxtPathToCsvNew(strListPathTxt, strTxtSavePath, strTxtPathCopy, ref htTxtMap);
            //htTxtOnlyMap = (Hashtable)htTxtMap.Clone();
            //ListXmlPathToCsvNew(strListPathXml, strXmlSavePath, strXmlPathCopy, ref htTxtOnlyMap, ref htXmlOnlyMap);

            htTxtMap = ListTxtPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy);
            htXmlOnlyMap = ListXmlPathToCsv(strListPathXml, strXmlSavePath, strXmlPathCopy, htTxtMap);

            strListCsvFileName = CompareTxtAndXmlTest(strTxtPathCopy, strXmlPathCopy, strCsvPath);
            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);
        }
        #endregion
    }
}
