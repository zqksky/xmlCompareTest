﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace TxtAndXmlCompare
{
    class TestFun
    {
        private const string TXT_FILE = "*.txt";
        private const string XML_FILE = "*.xml";

        #region 测试 比较两个Hashtable中的数据
        public static bool compareHashtable(Hashtable txtHashtable, Hashtable xmlHashtable, string strCsvSaveFilePath)
        {
            string strTxtTemp;
            string strXmlTemp;
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in txtHashtable)
            {
                if (xmlHashtable.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == xmlHashtable[de.Key].ToString())
                    {
                        xmlHashtable.Remove(de.Key);
                    }
                    else
                    {
                        if (xmlHashtable[de.Key].ToString().Contains(";"))
                        {
                            if (de.Key.ToString() == "COND_TUBE_DESCRP" || de.Key.ToString() == "COOL_TUBE_DESCRP")
                            {
                                strXmlTemp = xmlHashtable[de.Key].ToString();
                                strXmlTemp = strXmlTemp.Substring(strXmlTemp.IndexOf(";") + 1);
                                if (de.Value.ToString().ToUpper().Contains(strXmlTemp.ToUpper()))
                                {
                                    xmlHashtable.Remove(de.Key);
                                }
                            }
                            else if (xmlHashtable[de.Key].ToString().ToUpper().Contains(de.Value.ToString().ToUpper()))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strList1.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                        else
                        {
                            strTxtTemp = de.Value.ToString();
                            if (strTxtTemp.Contains(".0"))
                            {
                                strTxtTemp = de.Value.ToString().TrimEnd('0');
                            }
                            if (xmlHashtable[de.Key].ToString().Contains(strTxtTemp))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strList1.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                    }
                }
                else
                {
                    strList2.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ""));
                }
            }
            foreach (DictionaryEntry de in xmlHashtable)
            {
                //strList3.Add(de.Key.ToString() + "," + de.Value.ToString());
                strList3.Add(de.Key.ToString() + "," + "," + de.Value.ToString().Replace(",", ""));
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);

                using (FileStream fs = new FileStream(strCsvSaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);

                    sw.WriteLine("Key,TxtValue,XmlValue");  //开始写入
                    if (strList1.Count > 0)
                    {
                        strList1.Sort();
                        //sw.WriteLine("");
                        sw.WriteLine("txt and xml not same");
                        //sw.WriteLine("两个xml文件中不相同的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        strList2.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in txt file");
                        //sw.WriteLine("xml文件1中有而2中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        strList3.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in xml file");
                        //sw.WriteLine("xml文件2中有而1中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }
        #endregion

        #region 测试 批量比较txt和xml
        public static List<string> compareTxtAndXml(string strTxtPath, string strXmlPath, string strCsvFilePath)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strTxtPath == "" || strXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strTxtPath), TXT_FILE))
            {
                MessageBox.Show("txt File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strXmlPath), XML_FILE))
            {
                MessageBox.Show("xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strTxtTemp;
                string strTxtTemp2;
                Hashtable htTxt = new Hashtable();
                Hashtable htXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strTxtPath, TXT_FILE);
                strPathList2 = FileHelper.GetFiles(strXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    if (str.IndexOf("(Inputs Only)") > 0)
                    {
                        strTxtTemp = str.Substring(0, str.LastIndexOf("(Inputs Only)")).Trim() + ".xml";
                        strTxtTemp2 = str.Substring(0, str.LastIndexOf("(Inputs Only)")).Trim() + "_Chiller.xml";
                    }
                    else
                    {
                        strTxtTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";
                        strTxtTemp2 = str.Substring(0, str.LastIndexOf('.')) + "_Chiller.xml";
                    }
                    if (strPathList2.Contains(strTxtTemp) || strPathList2.Contains(strTxtTemp2))
                    {
                        htTxt = BaseFun.GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        if (strPathList2.Contains(strTxtTemp))
                        {
                            htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp);
                        }
                        else if (strPathList2.Contains(strTxtTemp2))
                        {
                            htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp2);
                        }

                        flagSame = compareHashtable(htTxt, htXml, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }

        public static List<string> CompareTxtAndXmlTest(string strTxtPath, string strXmlPath, string strCsvFilePath)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strTxtPath == "" || strXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strTxtPath), TXT_FILE))
            {
                MessageBox.Show("txt File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strXmlPath), XML_FILE))
            {
                MessageBox.Show("xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strTxtTemp;
                Hashtable htTxt = new Hashtable();
                Hashtable htXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strTxtPath, TXT_FILE);
                strPathList2 = FileHelper.GetFiles(strXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    strTxtTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";

                    if (strPathList2.Contains(strTxtTemp))
                    {
                        htTxt = BaseFun.GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        htXml = BaseFun.GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp);

                        flagSame = compareHashtable(htTxt, htXml, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }
        #endregion

        #region 测试 获取Hashtable中的数据到CSV文件中
        public static void HastableToCsv(Hashtable ht, string strCsvFileName)
        {
            List<string> strListCsvFileValue = new List<string>();

            if (ht.Count > 0)
            {
                foreach (DictionaryEntry de in ht)
                {
                    strListCsvFileValue.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ";"));
                }
                strListCsvFileValue.Sort();
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine("Key,Value");   //开始写入
                    foreach (var str in strListCsvFileValue)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
            }
        }
        #endregion

        #region 测试 根据集合中的路径生成相应的CSV文件
        public static void ListPathToCsv(List<string> strPathList, string strCsvPath, string strCopyPath)
        {
            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                    strFileName = strFileName.Substring(0, strFileName.LastIndexOf("."));
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                    }
                    else if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                    }
                    HastableToCsv(ht, strCsvPath + "\\" + strFileName + ".csv");
                    System.IO.File.Copy(str, strCopyPath + strFileName + strFileType, true);
                }
            }
        }

        public static void ListTxtPathToCsvNew(List<string> strPathList, string strCsvPath, string strTxtPath, ref Hashtable htTxtMap)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strTxtPath = FileHelper.PathComplement(strTxtPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (!htTxtMap.ContainsKey(strFileName))
                            {
                                pTagNum++;
                                strSaveName = "PN" + pTagNum;
                                htTxtMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                        }
                        else
                        {
                            pTagErrorNum++;
                            strSaveName = "Error-txt" + pTagErrorNum;
                            //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                            //strFileName = str.Substring(0, str.LastIndexOf("\\")) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                            //htTxtMap.Add(strFileName, strSaveName);
                        }
                        System.IO.File.Copy(str, strTxtPath + strSaveName + strFileType, true);
                    }
                }
            }
        }

        public static void ListXmlPathToCsvNew(List<string> strPathList, string strCsvPath, string strXmlPath, ref Hashtable htTxtOnlyMap, ref Hashtable htXmlOnlyMap)
        {
            int pTagNum = 0;
            string strSaveName = "PN";

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strXmlPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strXmlPath = FileHelper.PathComplement(strXmlPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (htTxtOnlyMap.ContainsKey(strFileName))
                            {
                                strSaveName = htTxtOnlyMap[strFileName].ToString();
                                htTxtOnlyMap.Remove(strFileName);
                            }
                            else
                            {
                                pTagNum++;
                                strSaveName = "Only-xml" + pTagNum;
                                htXmlOnlyMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                            System.IO.File.Copy(str, strXmlPath + strSaveName + strFileType, true);
                        }
                    }
                }
            }
        }

        public static Hashtable ListTxtPathToCsv(List<string> strPathList, string strCsvPath, string strTxtPath)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htTxtMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strTxtPath = FileHelper.PathComplement(strTxtPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".txt")
                    {
                        ht = BaseFun.GetTxtDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (!htTxtMap.ContainsKey(strFileName))
                            {
                                pTagNum++;
                                strSaveName = "PN" + pTagNum;
                                htTxtMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                        }
                        else
                        {
                            pTagErrorNum++;
                            strSaveName = "Error-txt" + pTagErrorNum;
                            //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                            //strFileName = str.Substring(0, str.LastIndexOf("\\")) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                            //htTxtMap.Add(strFileName, strSaveName);
                        }
                        System.IO.File.Copy(str, strTxtPath + strSaveName + strFileType, true);
                    }
                }
            }
            return htTxtMap;
        }

        public static Hashtable ListXmlPathToCsv(List<string> strPathList, string strCsvPath, string strXmlPath, Hashtable htTxtMap)
        {
            int pTagNum = 0;
            string strSaveName = "PN";
            Hashtable htXmlMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strXmlPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strXmlPath = FileHelper.PathComplement(strXmlPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = BaseFun.GetXmlDataToHashtable(str);
                        if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                        {
                            strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                            if (htTxtMap.ContainsKey(strFileName))
                            {
                                strSaveName = htTxtMap[strFileName].ToString();
                                htTxtMap.Remove(strFileName);
                            }
                            else
                            {
                                pTagNum++;
                                strSaveName = "Only-xml" + pTagNum;
                                htXmlMap.Add(strFileName, strSaveName);
                            }
                            HastableToCsv(ht, strCsvPath + strSaveName + ".csv");
                            System.IO.File.Copy(str, strXmlPath + strSaveName + strFileType, true);
                        }
                    }
                }
            }
            return htXmlMap;
        }
        #endregion

        #region 测试方法
        public static void RunFun(string strTxtPath, string strXmlPath)
        {
            //strTxtPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";
            //strXmlPath = @"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96";

            string TXT_FILE = "*.txt";
            string XML_FILE = "*.xml";

            string strCsvPath = @"D:\TxtAndXmlTest\ComPareCsvFile";
            string strExcelPath = @"D:\TxtAndXmlTest\result.xlsx";
            string strTxtSavePath = @"D:\TxtAndXmlTest\txtCsvFile";
            string strXmlSavePath = @"D:\TxtAndXmlTest\xmlCsvFile";
            string strTxtPathCopy = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPathCopy = @"D:\TxtAndXmlTest\xmlFileCopy";

            List<string> strListPathTxt = new List<string>();
            List<string> strListPathXml = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtSavePath);
            FileHelper.CleanFolder(strXmlSavePath);
            FileHelper.CleanFolder(strTxtPathCopy);
            FileHelper.CleanFolder(strXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strTxtPath), TXT_FILE, ref strListPathTxt);
            FileHelper.GetFiles(new DirectoryInfo(strXmlPath), XML_FILE, ref strListPathXml);

            ListPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy);
            ListPathToCsv(strListPathXml, strXmlSavePath, strXmlPathCopy);

            strListCsvFileName = compareTxtAndXml(strTxtPathCopy, strXmlPathCopy, strCsvPath);
            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);

            //List<string> strListTxtName = new List<string>();
            //List<string> strListXmlName = new List<string>();
            //strListTxtName = FileHelper.GetFiles(strTxtPathCopy, TXT_FILE);
            //strListXmlName = FileHelper.GetFiles(strXmlPathCopy, XML_FILE);

            //FileHelper.CopyFileToDir(strListPathTxt, strTxtPathCopy);
            //FileHelper.CopyFileToDir(strListPathXml, strXmlPathCopy);

            //bool flagTest = false;
            //flagTest = FilesExist(new DirectoryInfo(@"D:\Qiankun Zheng\txtOutput\testXml_Version 4.96"), "*.txt");
        }

        public static void RunFunTest(string strTxtPath, string strXmlPath)
        {
            string TXT_FILE = "*.txt";
            string XML_FILE = "*.xml";

            string strCsvPath = @"D:\TxtAndXmlTest\ComPareCsvFile";
            string strExcelPath = @"D:\TxtAndXmlTest\result.xlsx";
            string strTxtSavePath = @"D:\TxtAndXmlTest\txtCsvFile";
            string strXmlSavePath = @"D:\TxtAndXmlTest\xmlCsvFile";
            string strTxtPathCopy = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPathCopy = @"D:\TxtAndXmlTest\xmlFileCopy";

            Hashtable htTxtMap = new Hashtable();
            Hashtable htXmlOnlyMap = new Hashtable();
            Hashtable htTxtOnlyMap = new Hashtable();

            List<string> strListPathTxt = new List<string>();
            List<string> strListPathXml = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtSavePath);
            FileHelper.CleanFolder(strXmlSavePath);
            FileHelper.CleanFolder(strTxtPathCopy);
            FileHelper.CleanFolder(strXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strTxtPath), TXT_FILE, ref strListPathTxt);
            FileHelper.GetFiles(new DirectoryInfo(strXmlPath), XML_FILE, ref strListPathXml);

            //ListTxtPathToCsvNew(strListPathTxt, strTxtSavePath, strTxtPathCopy, ref htTxtMap);
            //htTxtOnlyMap = (Hashtable)htTxtMap.Clone();
            //ListXmlPathToCsvNew(strListPathXml, strXmlSavePath, strXmlPathCopy, ref htTxtOnlyMap, ref htXmlOnlyMap);

            htTxtMap = ListTxtPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy);
            htXmlOnlyMap = ListXmlPathToCsv(strListPathXml, strXmlSavePath, strXmlPathCopy, htTxtMap);

            strListCsvFileName = CompareTxtAndXmlTest(strTxtPathCopy, strXmlPathCopy, strCsvPath);
            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);
        }
        #endregion
    }
}
