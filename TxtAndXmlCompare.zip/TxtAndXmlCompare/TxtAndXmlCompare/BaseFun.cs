﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace TxtAndXmlCompare
{
    class BaseFun
    {
        private const string TXT_FILE = "*.txt";
        private const string XML_FILE = "*.xml";
        public static List<string> strListSummary = new List<string>();

        #region 定义txt文件的数据结构
        public struct ChillerDataStruct
        {
            //public string strChillerModel;                //   19XR-7172C87VHJ52	ITEM_PART_NUMBER、CHILLER_MODULE、COMPR_MOTOR_VOLTAGE
            public string strITEM_PART_NUMBER;
            public string strCHILLER_MODULE;
            public string strCOMPR_MOTOR_VOLTAGE;
            public string strREFRIG_TYPE;                 // 	 R-134a				REFRIG_TYPE
            public string strISOLATION_VALVES;            // 	 Installed			ISOLATION_VALVES
            public string strENVELOPE_STABILITY_CONTROL;  // 	 Not Installed		ENVELOPE_STABILITY_CONTROL
            public string strOPERATION_TYPE;              // 	 Cooling			OPERATION_TYPE
            public string strCONTROL_TYPE;                 // 	 PIC 5	CONTROL_TYPE

            public override string ToString()
            {
                return "ITEM_PART_NUMBER: " + strITEM_PART_NUMBER + "\r\n" +
                       "CHILLER_MODULE: " + strCHILLER_MODULE + "\r\n" +
                       "COMPR_MOTOR_VOLTAGE: " + strCOMPR_MOTOR_VOLTAGE + "\r\n" +
                       "REFRIG_TYPE: " + strREFRIG_TYPE + "\r\n" +
                       "ISOLATION_VALVES: " + strISOLATION_VALVES + "\r\n" +
                       "ENVELOPE_STABILITY_CONTROL: " + strENVELOPE_STABILITY_CONTROL + "\r\n" +
                       "OPERATION_TYPE: " + strOPERATION_TYPE + "\r\n" +
                       "CONTROL_TYPE: " + strCONTROL_TYPE + "\r\n";
            }
        }
        public struct CoolerDataStruct
        {
            public string strCOOLER;                      // 	 71					                COOLER
            public string strCOOL_FRAME;                  // 	 7					                COOL_FRAME
            public string strCOOL_WB_TYPE;                //   Nozzle-in-Head, 1034 kPa	        COOL_WB_TYPE
            public string strCOOL_WB_PRESS;               //    1034 kPa	        COOL_WB_PRESS
            public string strCOOL_PASS;                   // 	 2					                COOL_PASS
            public string strCOOL_NOZZLE_CODE;            // 	 C (Nozzles on Drive End)	        COOL_NOZZLE_CODE
            //public string strTubing;                    //   Super B5 (SUPB5), .635 mm, Copper	COOL_TUBE_DESCRP、COOL_TUBE_MATL、COOL_WALL_THICK
            public string strCOOL_TUBE_DESCRP;
            public string strCOOL_TUBE_MATL;
            public string strCOOL_WALL_THICK;
            public string strCOOL_FLUID_TYPE;             //   Fresh Water				        COOL_FLUID_TYPE
            public string strCOOLER_FOULING_FACTOR;       //                                    COOLER_FOULING_FACTOR

            public override string ToString()
            {
                return "COOLER: " + strCOOLER + "\r\n" +
                       "COOL_FRAME: " + strCOOL_FRAME + "\r\n" +
                       "COOL_WB_TYPE: " + strCOOL_WB_TYPE + "\r\n" +
                       "COOL_WB_PRESS: " + strCOOL_WB_PRESS + "\r\n" +
                       "COOL_PASS: " + strCOOL_PASS + "\r\n" +
                       "COOL_NOZZLE_CODE: " + strCOOL_NOZZLE_CODE + "\r\n" +
                       "COOL_TUBE_DESCRP: " + strCOOL_TUBE_DESCRP + "\r\n" +
                       "COOL_TUBE_MATL: " + strCOOL_TUBE_MATL + "\r\n" +
                       "COOL_WALL_THICK: " + strCOOL_WALL_THICK + "\r\n" +
                       "COOL_FLUID_TYPE: " + strCOOL_FLUID_TYPE + "\r\n" +
                       "COOLER_FOULING_FACTOR: " + strCOOLER_FOULING_FACTOR + "\r\n";
            }
        }

        public struct CondenserDataStruct
        {
            public string strCONDENSER;                   // 	 71					                CONDENSER
            public string strCOND_FRAME;                  // 	 7					                COND_FRAME
            public string strCOND_WB_TYPE;                //   Nozzle-in-Head, 1034 kPa	        COND_WB_TYPE
            public string strCOND_WB_PRESS;               //   1034 kPa	        COND_WB_PRESS
            public string strCOND_PASS;                   // 	 2					                COND_PASS
            public string strCOND_NOZZLE_CODE;            // 	 C (Nozzles on Drive End)	        COND_NOZZLE_CODE
            //public string strTubing;                    //   Super B5 (SUPB5), .635 mm, Copper	COND_TUBE_DESCRP、COND_TUBE_MATL、COND_WALL_THICK
            public string strCOND_TUBE_DESCRP;
            public string strCOND_TUBE_MATL;
            public string strCOND_WALL_THICK;
            public string strCOND_FLUID_TYPE;             //   Fresh Water				        COND_FLUID_TYPE
            public string strCONDENSER_FOULING_FACTOR;       //                                      CONDENSER_FOULING_FACTOR

            public override string ToString()
            {
                return "CONDENSER: " + strCONDENSER + "\r\n" +
                       "COND_FRAME: " + strCOND_FRAME + "\r\n" +
                       "COND_WB_TYPE: " + strCOND_WB_TYPE + "\r\n" +
                       "COND_WB_PRESS: " + strCOND_WB_PRESS + "\r\n" +
                       "COND_PASS: " + strCOND_PASS + "\r\n" +
                       "COND_NOZZLE_CODE: " + strCOND_NOZZLE_CODE + "\r\n" +
                       "COND_TUBE_DESCRP: " + strCOND_TUBE_DESCRP + "\r\n" +
                       "COND_TUBE_MATL: " + strCOND_TUBE_MATL + "\r\n" +
                       "COND_WALL_THICK: " + strCOND_WALL_THICK + "\r\n" +
                       "COND_FLUID_TYPE: " + strCOND_FLUID_TYPE + "\r\n" +
                       "CONDENSER_FOULING_FACTOR: " + strCONDENSER_FOULING_FACTOR + "\r\n";
            }
        }

        public struct CompressorDataStruct
        {
            public string strCOMPRESSOR;                  //   C87			COMPRESSOR
            public string strCOMPR_FRAME;                 //   C			COMPR_FRAME
            public string strCOMPRESSOR_MAP;              //   145			COMPRESSOR_MAP
            public string strGEAR_CODE;               //   j	            GEAR_CODE

            public override string ToString()
            {
                return "COMPRESSOR: " + strCOMPRESSOR + "\r\n" +
                       "COMPR_FRAME: " + strCOMPR_FRAME + "\r\n" +
                       "COMPRESSOR_MAP: " + strCOMPRESSOR_MAP + "\r\n";
            }
        }

        public struct WeightsDataStruct
        {
            public string strSHIPPING_WEIGHT;        //     15745	kg  SHIPPING_WEIGHT
            public string strOPERATING_WEIGHT;       //     17880	kg  OPERATING_WEIGHT
            public string strREFRIG_WEIGHT;          // 	1192	kg	REFRIG_WEIGHT			   
        }

        public struct MotorDataStruct
        {
            public string strMOTOR_CODE;                // 	 VHH				MOTOR_CODE
            public string strMOTOR_EFFICIENCY;          // 	 VHH				MOTOR_EFFICIENCY
            //public string strLineVoltage_Hertz;       //   400-3-50			COMPRESSOR_VOLTS、COMPRESSOR_PHASE、COMPRESSOR_HERTZ
            public string strCOMPRESSOR_VOLTS;          //   400-3-50			COMPRESSOR_VOLTS、COMPRESSOR_PHASE、COMPRESSOR_HERTZ  
            public string strCOMPRESSOR_PHASE;          //   400-3-50			COMPRESSOR_VOLTS、COMPRESSOR_PHASE、COMPRESSOR_HERTZ 
            public string strCOMPRESSOR_HERTZ;          //   400-3-50			COMPRESSOR_VOLTS、COMPRESSOR_PHASE、COMPRESSOR_HERTZ  

            public override string ToString()
            {
                return "MOTOR_CODE: " + strMOTOR_CODE + "\r\n" +
                       "MOTOR_EFFICIENCY: " + strMOTOR_EFFICIENCY + "\r\n" +
                       "COMPRESSOR_VOLTS: " + strCOMPRESSOR_VOLTS + "\r\n" +
                       "COMPRESSOR_PHASE: " + strCOMPRESSOR_PHASE + "\r\n" +
                       "COMPRESSOR_HERTZ: " + strCOMPRESSOR_HERTZ + "\r\n";
            }
        }

        public struct FlowControlsDataStruct
        {
            public string strHighSideOrificeSize;       // 	 C33
            public string strFLOAT_VALVE_SIZE;          //   5			FLOAT_VALVE_SIZE	
            public string strFLOAT_BALL_VALVE_SIZE;     //   B			FLOAT_BALL_VALVE_SIZE	
            public string strCOND_FLASC_ORIFICE;        //   70			COND_FLASC_ORIFICE	

            public override string ToString()
            {
                return "FLOAT_BALL_VALVE_SIZE: " + strFLOAT_BALL_VALVE_SIZE + "\r\n" +
                       "FLOAT_VALVE_SIZE: " + strFLOAT_VALVE_SIZE + "\r\n" +
                       "COND_FLASC_ORIFICE: " + strCOND_FLASC_ORIFICE + "\r\n";
            }
        }

        public struct txtDataStruct
        {
            public string strTagName;
            public string strProjectName;
            public string strECAT_VERSION;                      //  ECAT_VERSION
            public List<string> strListPERCENT_LOAD;            //  PERCENT_LOAD
            public List<string> strListCHILLER_CAPACITY;        //  CHILLER_CAPACITY
            public List<string> strLisCOOLER_CAPACITY;          //  COOLER_CAPACITY
            public List<string> strListINPUT_KW;                //  INPUT_KW
            public List<string> strListINPUT_KW_PER_TON;        //  INPUT_KW_PER_TON
            public List<string> strListCOP;                     //  COP

            public List<string> strListCOOLER_EWT;              //	COOLER_EWT
            public List<string> strListCOOLER_LWT;              //	COOLER_LWT
            public List<string> strListCOOLER_FLOW;             //	COOLER_FLOW
            public List<string> strListCOOLER_PRESSURE_DROP;    //	COOLER_PRESSURE_DROP

            public List<string> strListHEAT_REJECTION;          //	HEAT_REJECTION
            public List<string> strListCONDENSER_LWT;           //  CONDENSER_LWT
            public List<string> strListCONDENSER_EWT;           //	CONDENSER_EWT
            public List<string> strListCONDENSER_FLOW;          //	CONDENSER_FLOW
            public List<string> strListCONDENSER_PRESSURE_DROP; //	CONDENSER_PRESSURE_DROP

            public List<string> strListMOTOR_RLA;               //	MOTOR_RLA
            public List<string> strListMOTOR_OLTA;              //	MOTOR_OLTA
            public List<string> strListMOTOR_LRYA;              //	MOTOR_LRYA
            public List<string> strListMOTOR_LRDA;              //	MOTOR_LRDA
            public List<string> strListMAX_FUSE_CIRCUIT_BREAKER;//	MAX_FUSE_CIRCUIT_BREAKER
            public List<string> strListMIN_CIRCUIT_AMPACITY;    //	MIN_CIRCUIT_AMPACITY

            public List<string> strListCOMPR_FLOW_FRACTION;     //	COMPR_FLOW_FRACTION
            public List<string> strListCOMPR_HEAD_FRACTION;     //	COMPR_HEAD_FRACTION
            public List<string> strListCOMP_DISCH_TEMP;         //	COMP_DISCH_TEMP

            public List<string> strListPARAM_GV_MIN;
            public List<string> strListPARAM_GV_MAX;
            public List<string> strListPARAM_DTSMIN;
            public List<string> strListPARAM_DTSMAX;
            public List<string> strListPARAM_SHAPEFAC;
            public List<string> strListPARAM_COOLER_MIN_DP;
            public List<string> strListPARAM_CONDENSER_MIN_DP;

            public List<string> strListCONDENSING_TEMP;
            public List<string> strListCOOLER_WALL_TEMP;
            public List<string> strListCOOLER_REFRIGERANT_TEMP;
            public List<string> strListCOOL_TUBE_VELOCITY;
            public List<string> strListCOND_TUBE_VELOCITY;

            public List<string> strListCOOLER_FOULING_ADJUSTMENT;
            public List<string> strListCOND_FOULING_ADJUSTMENT;


            public override string ToString()
            {
                string strDataTest = "";
                foreach (var str in strListHEAT_REJECTION)
                {
                    strDataTest += str + ";";
                }
                return "DataOut: " + strDataTest;
            }

            #region
            //public override string ToString()
            //{
            //    string strListPercentLoadTemp = "";
            //    string strListChillerCapacityTemp = "";
            //    string strListChillerInputkWTemp = "";
            //    string strListChillerEfficiencyTemp = "";
            //    string strListChillerCOPRTemp = "";

            //    string strListCoolerEnteringTemp = "";
            //    string strCoolerLeavingTemp = "";
            //    string strCoolerFlowRate = "";
            //    string strCoolerPressureDrop = "";

            //    string strCondenserHeatRejection = "";
            //    string strCondenserLeavingTemp = "";
            //    string strCondenserEnteringTemp = "";
            //    string strCondenserFlowRate = "";
            //    string strCondenserPressureDrop = "";

            //    string strMotorRatedLoadAmps = "";
            //    string strMotorOLTA = "";
            //    string strMotorLRYA = "";
            //    string strMotorLRDA = "";

            //    string strMaxFuseCBAmps = "";
            //    string strMinCircuitAmpacity = "";

            //    string strCompressorFlowFraction = "";
            //    string strCompressorHeadFraction = "";
            //    string strCompressorDischargeTemp = "";

            //    string strParamGVMin = "";
            //    string strParamGVMax = "";
            //    string strParamShapefac = "";

            //    string strCoolerMinDP = "";
            //    string strCondenserMinDP = "";

            //    string strCondensingTemp = "";
            //    string strCoolerWallTemp = "";
            //    string strSuctionTemp = "";
            //    string strCoolerFreezeTemp = "";

            //    string strCoolerTubeVel = "";
            //    string strCondTubeVel = "";

            //    string strCoolerFoulingTempAdj = "";
            //    string strCondenserFoulingTempAdj = "";

            //    foreach (var str in strListPERCENT_LOAD)
            //    {
            //        strListPercentLoadTemp += str + ";";
            //    }
            //    foreach (var str in strListCHILLER_CAPACITY)
            //    {
            //        strListChillerCapacityTemp += str + ";";
            //    }
            //    foreach (var str in strListINPUT_KW)
            //    {
            //        strListChillerInputkWTemp += str + ";";
            //    }
            //    foreach (var str in strListINPUT_KW_PER_TON)
            //    {
            //        strListChillerEfficiencyTemp += str + ";";
            //    }
            //    foreach (var str in strListCOP)
            //    {
            //        strListChillerCOPRTemp += str + ";";
            //    }
            //    foreach (var str in strListCOOLER_EWT)
            //    {
            //        strListCoolerEnteringTemp += str + ";";
            //    }

            //    return "TagName: " + strTagName + "\r\n" +
            //            "PercentLoad: " + strListPercentLoadTemp + "\r\n" +
            //            "ChillerCapacity: " + strListChillerCapacityTemp + "\r\n" +
            //            "ChillerInputkW: " + strListChillerInputkWTemp + "\r\n" +
            //            "ChillerEfficiency: " + strListChillerEfficiencyTemp + "\r\n" +
            //            "ChillerCOPR: " + strListChillerCOPRTemp + "\r\n" +
            //            "EnteringTemp: " + strListCoolerEnteringTemp + "\r\n" +

            //            "CoolerLeavingTemp: " + strCoolerLeavingTemp + "\r\n" +
            //            "CoolerFlowRate: " + strCoolerFlowRate + "\r\n" +
            //            "CoolerPressureDrop: " + strCoolerPressureDrop + "\r\n" +

            //            "CondenserHeatRejection: " + strCondenserHeatRejection + "\r\n" +
            //            "CondenserLeavingTemp: " + strCondenserLeavingTemp + "\r\n" +
            //            "CondenserEnteringTemp: " + strCondenserEnteringTemp + "\r\n" +
            //            "CondenserFlowRate: " + strCondenserFlowRate + "\r\n" +
            //            "CondenserPressureDrop: " + strCondenserPressureDrop + "\r\n" +

            //            "MotorRatedLoadAmps: " + strMotorRatedLoadAmps + "\r\n" +
            //            "MotorOLTA: " + strMotorOLTA + "\r\n" +
            //            "MotorLRYA : " + strMotorLRYA + "\r\n" +
            //            "MotorLRDA: " + strMotorLRDA + "\r\n" +

            //            "MaxFuseCBAmps: " + strMaxFuseCBAmps + "\r\n" +
            //            "MinCircuitAmpacity: " + strMinCircuitAmpacity + "\r\n" +

            //            "CompressorFlowFraction: " + strCompressorFlowFraction + "\r\n" +
            //            "CompressorHeadFraction: " + strCompressorHeadFraction + "\r\n" +
            //            "CompressorDischargeTemp: " + strCompressorDischargeTemp + "\r\n" +

            //            "ParamGVMin: " + strParamGVMin + "\r\n" +
            //            "ParamGVMax: " + strParamGVMax + "\r\n" +
            //            "ParamShapefac: " + strParamShapefac + "\r\n" +

            //            "CoolerMinDP: " + strCoolerMinDP + "\r\n" +
            //            "CondenserMinDP: " + strCondenserMinDP + "\r\n" +

            //            "CondensingTemp: " + strCondensingTemp + "\r\n" +
            //            "CoolerWallTemp: " + strCoolerWallTemp + "\r\n" +
            //            "SuctionTemp: " + strSuctionTemp + "\r\n" +
            //            "CoolerFreezeTemp: " + strCoolerFreezeTemp + "\r\n" +

            //            "CoolerTubeVel: " + strCoolerTubeVel + "\r\n" +
            //            "CondTubeVel: " + strCondTubeVel + "\r\n" +

            //            "CoolerFoulingTempAdj: " + strCoolerFoulingTempAdj + "\r\n" +
            //            "CondenserFoulingTempAdj: " + strCondenserFoulingTempAdj + "\r\n";
            //}
            #endregion
        }
        #endregion

        #region 获取txt文件中的数据到Hashtable
        public static Hashtable GetTxtDataToHashtable(string strTxtFilePath)
        {
            string strTemp;
            string strLineData;
            string strMotorTemp;
            string strChillerModelTemp;
            string strCoolerTubingTemp;
            string strCondenserTubingTemp;

            ChillerDataStruct txtChillerData = new ChillerDataStruct();
            CoolerDataStruct txtCoolerData = new CoolerDataStruct();
            CondenserDataStruct txtCondenserData = new CondenserDataStruct();
            CompressorDataStruct txtCompressorData = new CompressorDataStruct();
            WeightsDataStruct txtWeightsData = new WeightsDataStruct();
            MotorDataStruct txtMotorData = new MotorDataStruct();
            FlowControlsDataStruct txtFlowControlsData = new FlowControlsDataStruct();
            txtDataStruct txtData = new txtDataStruct();
            Hashtable ht = new Hashtable();
            ht.Clear();

            // 判断文件是否存在，不存在则创建，否则读取值显示到窗体
            if (!File.Exists(strTxtFilePath))
            {
                MessageBox.Show("文件不存在");
            }
            else
            {
                using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
                {
                    StreamReader sr = new StreamReader(fs);
                    string readLine;
                    while ((readLine = sr.ReadLine()) != null)
                    {
                        if (readLine.IndexOf("Error:") >= 0)
                        {
                            break;
                        }

                        if (readLine.IndexOf("Project Name:") >= 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf(':') + 1);
                            strLineData = strLineData.Trim();
                            strLineData=Regex.Replace(strLineData, "\t", ";", RegexOptions.IgnoreCase);
                            //MessageBox.Show(strLineData);
                            txtData.strProjectName = strLineData.Substring(0,strLineData.IndexOf(";"));
                            ht.Add("PROJECT_NAME", txtData.strProjectName);
                            continue;
                        }
                        if (readLine.IndexOf("AquaEdge Chiller Builder") >= 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf("Builder") + 7);
                            strTemp = strLineData.Substring(0, strLineData.IndexOf("Page"));
                            strTemp = strTemp.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strECAT_VERSION = strTemp.Substring(1);
                            ht.Add("ECAT_VERSION", txtData.strECAT_VERSION);
                            continue;
                        }
                        if (readLine.IndexOf("Tag Name:") >= 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf(':') + 1);
                            strLineData = strLineData.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strTagName = strLineData;
                            ht.Add("TAG_NAME", txtData.strTagName);
                            continue;
                        }
                        #region txtChillerData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Chiller") > 0 && strTemp == "Chiller")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Cooler")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Chiller Model") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Model") + 5);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        strChillerModelTemp = strLineData.TrimEnd('-');
                                        txtChillerData.strITEM_PART_NUMBER = strLineData;
                                        strTemp = strChillerModelTemp.Substring(0, 5).TrimEnd('-');
                                        if(strTemp.IndexOf("19XRV")>=0)
                                        {
                                            strTemp="19XR";
                                        }
                                        txtChillerData.strCHILLER_MODULE = strTemp;
                                        txtChillerData.strCOMPR_MOTOR_VOLTAGE = strChillerModelTemp.Substring(strChillerModelTemp.Length - 2, 2);
                                        ht.Add("ITEM_PART_NUMBER", txtChillerData.strITEM_PART_NUMBER);
                                        ht.Add("CHILLER_MODULE", txtChillerData.strCHILLER_MODULE);
                                        ht.Add("COMPR_MOTOR_VOLTAGE", txtChillerData.strCOMPR_MOTOR_VOLTAGE);
                                    }
                                    if (readLine.IndexOf("Refrigerant Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        //txtChillerData.strREFRIG_TYPE = strLineData;
                                        txtChillerData.strREFRIG_TYPE = "R134A";
                                        ht.Add("REFRIG_TYPE", txtChillerData.strREFRIG_TYPE);
                                    }
                                    if (readLine.IndexOf("Isolation Valve") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Valve") + 5);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        if (strLineData == "Installed")
                                        {
                                            txtChillerData.strISOLATION_VALVES = "1";
                                        }
                                        else
                                        {
                                            txtChillerData.strISOLATION_VALVES = "0";
                                        }
                                        ht.Add("ISOLATION_VALVES", txtChillerData.strISOLATION_VALVES);
                                    }
                                    if (readLine.IndexOf("Envelope Stability Control") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Control") + 7);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtChillerData.strENVELOPE_STABILITY_CONTROL = strLineData;
                                        ht.Add("ENVELOPE_STABILITY_CONTROL", txtChillerData.strENVELOPE_STABILITY_CONTROL);
                                    }
                                    else if (readLine.IndexOf("Automatic Hot Gas Bypass") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Bypass") + 6);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtChillerData.strENVELOPE_STABILITY_CONTROL = strLineData;
                                        ht.Add("ENVELOPE_STABILITY_CONTROL", txtChillerData.strENVELOPE_STABILITY_CONTROL);
                                    }
                                    if (readLine.IndexOf("Operation Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtChillerData.strOPERATION_TYPE = strLineData;
                                        ht.Add("OPERATION_TYPE", txtChillerData.strOPERATION_TYPE);
                                    }
                                    if (readLine.IndexOf("Control Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtChillerData.strCONTROL_TYPE = strLineData;
                                        ht.Add("CONTROL_TYPE", txtChillerData.strCONTROL_TYPE);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtCoolerData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Cooler") > 0 && strTemp == "Cooler")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Compressor")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Size") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCoolerData.strCOOLER = strLineData;
                                        txtCoolerData.strCOOL_FRAME = strLineData.Substring(0, 1);
                                        ht.Add("COOLER", txtCoolerData.strCOOLER);
                                        ht.Add("COOL_FRAME", txtCoolerData.strCOOL_FRAME);
                                    }
                                    if (readLine.IndexOf("Waterbox Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        strTemp = strLineData;
                                        //MessageBox.Show(strLineData);
                                        txtCoolerData.strCOOL_WB_TYPE = strTemp.Substring(0, strTemp.IndexOf(','));
                                        if (txtCoolerData.strCOOL_WB_TYPE == "Nozzle-in-Head")
                                        {
                                            txtCoolerData.strCOOL_WB_TYPE = "A;Nozzle-in-Head";
                                        }
                                        else if (txtCoolerData.strCOOL_WB_TYPE == "Marine Waterbox")
                                        {
                                            txtCoolerData.strCOOL_WB_TYPE = "B;Marine Waterbox";
                                        }
                                        strTemp = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                                        txtCoolerData.strCOOL_WB_PRESS = Regex.Replace(strTemp, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                        if (txtCoolerData.strCOOL_WB_PRESS.IndexOf("1034") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WB_PRESS = "150;Psi";
                                        }
                                        else if (txtCoolerData.strCOOL_WB_PRESS.IndexOf("1654") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WB_PRESS = "240;Psi";
                                        }
                                        else if (txtCoolerData.strCOOL_WB_PRESS.IndexOf("2068") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WB_PRESS = "300;Psi";
                                        }
                                        ht.Add("COOL_WB_TYPE", txtCoolerData.strCOOL_WB_TYPE);
                                        ht.Add("COOL_WB_PRESS", txtCoolerData.strCOOL_WB_PRESS);
                                    }
                                    if (readLine.IndexOf("Passes") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Passes") + 6);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCoolerData.strCOOL_PASS = strLineData;
                                        ht.Add("COOL_PASS", txtCoolerData.strCOOL_PASS);
                                    }
                                    if (readLine.IndexOf("Nozzle Arrangement") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Arrangement") + 11);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        if (strLineData.IndexOf(')') >= 0)
                                        {
                                            strTemp = strLineData.Substring(0, 1);
                                            txtCoolerData.strCOOL_NOZZLE_CODE = strTemp;

                                            //strTemp = strLineData.Substring(0, 1) + ";";
                                            //strLineData = strLineData.Substring(strLineData.IndexOf('(') + 1);
                                            //txtCoolerData.strCOOL_NOZZLE_CODE = strTemp + strLineData.Substring(0, strLineData.IndexOf(')'));
                                        }
                                        else
                                        {
                                            if (strLineData.IndexOf("Will Advise") >= 0)
                                            {
                                                //批跑的xml文件会设置此项的值
                                                //txtCoolerData.strCOOL_NOZZLE_CODE = "Nozzles on Drive End";
                                            }
                                            else
                                            {
                                                txtCoolerData.strCOOL_NOZZLE_CODE = strLineData;
                                            }
                                        }
                                        ht.Add("COOL_NOZZLE_CODE", txtCoolerData.strCOOL_NOZZLE_CODE);
                                    }
                                    if (readLine.IndexOf("Tubing") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Tubing") + 6);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);

                                        strCoolerTubingTemp = strLineData;
                                        //strTemp = strCoolerTubingTemp.Substring(strCoolerTubingTemp.IndexOf('(') + 1);
                                        //strTemp = strTemp.Substring(0,strTemp.IndexOf(')'));

                                        //strTemp = strCoolerTubingTemp.Substring(0, strCoolerTubingTemp.IndexOf('(')).Trim();

                                        strTemp = strCoolerTubingTemp.Substring(0,strCoolerTubingTemp.IndexOf(','));
                                        txtCoolerData.strCOOL_TUBE_DESCRP = strTemp.Trim();

                                        txtCoolerData.strCOOL_TUBE_MATL = strCoolerTubingTemp.Substring(strCoolerTubingTemp.LastIndexOf(',') + 1).Trim();
                                        strTemp = strCoolerTubingTemp.Substring(strCoolerTubingTemp.IndexOf(',') + 1).Trim();
                                        txtCoolerData.strCOOL_WALL_THICK = strTemp.Substring(0, strTemp.IndexOf(',')).Trim();
                                        if (txtCoolerData.strCOOL_WALL_THICK.IndexOf(".635") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WALL_THICK = "A;0.025";
                                        }
                                        else if (txtCoolerData.strCOOL_WALL_THICK.IndexOf(".711") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WALL_THICK = "B;0.028";
                                        }
                                        else if (txtCoolerData.strCOOL_WALL_THICK.IndexOf(".889") >= 0)
                                        {
                                            txtCoolerData.strCOOL_WALL_THICK = "C;0.035";
                                        }
                                        ht.Add("COOL_TUBE_DESCRP", txtCoolerData.strCOOL_TUBE_DESCRP);
                                        ht.Add("COOL_TUBE_MATL", txtCoolerData.strCOOL_TUBE_MATL);
                                        ht.Add("COOL_WALL_THICK", txtCoolerData.strCOOL_WALL_THICK);
                                    }
                                    if (readLine.IndexOf("Fluid Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        if (strLineData.IndexOf(',')>0)
                                        {
                                            strLineData = strLineData.Substring(0, strLineData.IndexOf(',')).Trim();
                                        }
                                        //MessageBox.Show(strLineData);
                                        txtCoolerData.strCOOL_FLUID_TYPE = strLineData;
                                        ht.Add("COOL_FLUID_TYPE", txtCoolerData.strCOOL_FLUID_TYPE);
                                    }
                                    if (readLine.IndexOf("Fouling Factor") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf(")/") + 4);
                                        strLineData = Regex.Replace(strLineData, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCoolerData.strCOOLER_FOULING_FACTOR = strLineData;
                                        ht.Add("COOLER_FOULING_FACTOR", txtCoolerData.strCOOLER_FOULING_FACTOR);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtCompressorData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Compressor") > 0 && strTemp == "Compressor")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Weights")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Size") >= 0 && readLine.IndexOf("Gear Size Code") < 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        strTemp = strLineData;
                                        if (strTemp.IndexOf('(') > 0)
                                        {
                                            if (strTemp.IndexOf("R (FL Opt.)") >= 0)
                                            {
                                                strTemp = "R05";//R03、R05
                                            }
                                            else if (strTemp.IndexOf("R (PL Opt.)") >= 0)
                                            {
                                                strTemp = "R1";//R13、R15
                                            }
                                            else if (strTemp.IndexOf("Q (FL Opt.)") >= 0)
                                            {
                                                strTemp = "Q0";//Q03、Q05
                                            }
                                            else if (strTemp.IndexOf("Q (PL Opt.)") >= 0)
                                            {
                                                strTemp = "Q1";//Q13、Q15
                                            }
                                            txtCompressorData.strCOMPRESSOR = strTemp;
                                        }
                                        else
                                        {
                                            txtCompressorData.strCOMPRESSOR = strLineData;
                                        }
                                        txtCompressorData.strCOMPR_FRAME = strLineData.Substring(0, 1);
                                        ht.Add("COMPRESSOR", txtCompressorData.strCOMPRESSOR);
                                        ht.Add("COMPR_FRAME", txtCompressorData.strCOMPR_FRAME);
                                    }
                                    if (readLine.IndexOf("Map ID") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("ID") + 2);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCompressorData.strCOMPRESSOR_MAP = strLineData;
                                        ht.Add("COMPRESSOR_MAP", txtCompressorData.strCOMPRESSOR_MAP);
                                    }
                                    if (readLine.IndexOf("Gear Size Code") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Code") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCompressorData.strGEAR_CODE = strLineData;
                                        ht.Add("GEAR_CODE", txtCompressorData.strGEAR_CODE);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtWeightsData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Weights") > 0 && strTemp == "Weights")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Condenser")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Total Rigging Weight") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Weight") + 6);
                                        strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtWeightsData.strSHIPPING_WEIGHT = strLineData;
                                        ht.Add("SHIPPING_WEIGHT", txtWeightsData.strSHIPPING_WEIGHT);
                                    }
                                    if (readLine.IndexOf("Total Operating Weight") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Weight") + 6);
                                        strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtWeightsData.strOPERATING_WEIGHT = strLineData;
                                        ht.Add("OPERATING_WEIGHT", txtWeightsData.strOPERATING_WEIGHT);
                                    }
                                    if (readLine.IndexOf("Refrigerant Weight") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Weight") + 6);
                                        strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtWeightsData.strREFRIG_WEIGHT = strLineData;
                                        ht.Add("REFRIG_WEIGHT", txtWeightsData.strREFRIG_WEIGHT);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtCondenserData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Condenser") > 0 && strTemp == "Condenser")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Motor")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Size") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCondenserData.strCONDENSER = strLineData;
                                        txtCondenserData.strCOND_FRAME = strLineData.Substring(0, 1);
                                        ht.Add("CONDENSER", txtCondenserData.strCONDENSER);
                                        ht.Add("COND_FRAME", txtCondenserData.strCOND_FRAME);
                                    }
                                    if (readLine.IndexOf("Waterbox Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        strTemp = strLineData;
                                        //MessageBox.Show(strLineData);
                                        txtCondenserData.strCOND_WB_TYPE = strTemp.Substring(0, strTemp.IndexOf(','));
                                        if (txtCondenserData.strCOND_WB_TYPE == "Nozzle-in-Head")
                                        {
                                            txtCondenserData.strCOND_WB_TYPE = "A;Nozzle-in-Head";
                                        }
                                        else if (txtCondenserData.strCOND_WB_TYPE == "Marine Waterbox")
                                        {
                                            txtCondenserData.strCOND_WB_TYPE = "B;Marine Waterbox";
                                        }
                                        strTemp = strTemp.Substring(strTemp.IndexOf(',') + 1).Trim();
                                        txtCondenserData.strCOND_WB_PRESS = Regex.Replace(strTemp, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                        if (txtCondenserData.strCOND_WB_PRESS.IndexOf("1034") >= 0)
                                        {
                                            txtCondenserData.strCOND_WB_PRESS = "150;Psi";
                                        }
                                        else if (txtCondenserData.strCOND_WB_PRESS.IndexOf("1654") >= 0)
                                        {
                                            txtCondenserData.strCOND_WB_PRESS = "240;Psi";
                                        }
                                        else if (txtCondenserData.strCOND_WB_PRESS.IndexOf("2068") >= 0)
                                        {
                                            txtCondenserData.strCOND_WB_PRESS = "300;Psi";
                                        }
                                        ht.Add("COND_WB_TYPE", txtCondenserData.strCOND_WB_TYPE);
                                        ht.Add("COND_WB_PRESS", txtCondenserData.strCOND_WB_PRESS);
                                    }
                                    if (readLine.IndexOf("Passes") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Passes") + 6);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCondenserData.strCOND_PASS = strLineData;
                                        ht.Add("COND_PASS", txtCondenserData.strCOND_PASS);
                                    }
                                    if (readLine.IndexOf("Nozzle Arrangement") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Arrangement") + 11);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        if (strLineData.IndexOf(')') >= 0)
                                        {
                                            strTemp = strLineData.Substring(0, 1);
                                            txtCondenserData.strCOND_NOZZLE_CODE = strTemp;

                                            //strTemp = strLineData.Substring(0, 1) + ";";
                                            //strLineData = strLineData.Substring(strLineData.IndexOf('(') + 1);
                                            //txtCondenserData.strCOND_NOZZLE_CODE = strTemp + strLineData.Substring(0, strLineData.IndexOf(')'));
                                        }
                                        else
                                        {
                                            if (strLineData.IndexOf("Will Advise") >= 0)
                                            {
                                                //批跑的xml文件会设置此项的值
                                                txtCondenserData.strCOND_NOZZLE_CODE = "Nozzles on Drive End";
                                            }
                                            else
                                            {
                                                txtCondenserData.strCOND_NOZZLE_CODE = strLineData;
                                            }
                                        }
                                        ht.Add("COND_NOZZLE_CODE", txtCondenserData.strCOND_NOZZLE_CODE);
                                    }
                                    if (readLine.IndexOf("Tubing") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Tubing") + 6);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);

                                        strCondenserTubingTemp = strLineData;
                                        //strTemp = strCondenserTubingTemp.Substring(strCondenserTubingTemp.IndexOf('(') + 1);
                                        //strTemp = strCondenserTubingTemp.Substring(0, strCondenserTubingTemp.IndexOf('(')).Trim();

                                        strTemp = strCondenserTubingTemp.Substring(0, strCondenserTubingTemp.IndexOf(','));
                                        txtCondenserData.strCOND_TUBE_DESCRP = strTemp.Trim();

                                        txtCondenserData.strCOND_TUBE_MATL = strCondenserTubingTemp.Substring(strCondenserTubingTemp.LastIndexOf(',') + 1).Trim();
                                        strTemp = strCondenserTubingTemp.Substring(strCondenserTubingTemp.IndexOf(',') + 1).Trim();
                                        txtCondenserData.strCOND_WALL_THICK = strTemp.Substring(0, strTemp.IndexOf(',')).Trim();
                                        if (txtCondenserData.strCOND_WALL_THICK.IndexOf(".635") >= 0)
                                        {
                                            txtCondenserData.strCOND_WALL_THICK = "A;0.025";
                                        }
                                        else if (txtCondenserData.strCOND_WALL_THICK.IndexOf(".711") >= 0)
                                        {
                                            txtCondenserData.strCOND_WALL_THICK = "B;0.028";
                                        }
                                        else if (txtCondenserData.strCOND_WALL_THICK.IndexOf(".889") >= 0)
                                        {
                                            txtCondenserData.strCOND_WALL_THICK = "C;0.035";
                                        }
                                        ht.Add("COND_TUBE_DESCRP", txtCondenserData.strCOND_TUBE_DESCRP);
                                        ht.Add("COND_TUBE_MATL", txtCondenserData.strCOND_TUBE_MATL);
                                        ht.Add("COND_WALL_THICK", txtCondenserData.strCOND_WALL_THICK);
                                    }
                                    if (readLine.IndexOf("Fluid Type") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Type") + 4);
                                        strLineData = strLineData.Trim();
                                        if (strLineData.IndexOf(',') > 0)
                                        {
                                            strLineData = strLineData.Substring(0, strLineData.IndexOf(',')).Trim();
                                        }
                                        txtCondenserData.strCOND_FLUID_TYPE = strLineData;
                                        ht.Add("COND_FLUID_TYPE", txtCondenserData.strCOND_FLUID_TYPE);
                                    }
                                    if (readLine.IndexOf("Fouling Factor") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf(")/") + 4);
                                        strLineData = Regex.Replace(strLineData, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtCondenserData.strCONDENSER_FOULING_FACTOR = strLineData;
                                        ht.Add("CONDENSER_FOULING_FACTOR", txtCondenserData.strCONDENSER_FOULING_FACTOR);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtMotorData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Motor") > 0 && strTemp == "Motor")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Flow Controls")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Size") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        if (strLineData.IndexOf(')') > 0)
                                        {
                                            strMotorTemp = strLineData.Substring(0, strLineData.IndexOf('('));
                                            txtMotorData.strMOTOR_CODE = strMotorTemp.Trim();
                                            txtMotorData.strMOTOR_EFFICIENCY = strLineData;
                                            ht.Add("MOTOR_CODE", txtMotorData.strMOTOR_CODE);
                                            ht.Add("MOTOR_EFFICIENCY", txtMotorData.strMOTOR_EFFICIENCY);
                                        }
                                        else
                                        {
                                            txtMotorData.strMOTOR_CODE = strLineData.Substring(0, 2);
                                            txtMotorData.strMOTOR_EFFICIENCY = strLineData.Substring(strLineData.Length - 1, 1);
                                            ht.Add("MOTOR_CODE", txtMotorData.strMOTOR_CODE);
                                            ht.Add("MOTOR_EFFICIENCY", txtMotorData.strMOTOR_EFFICIENCY);
                                        }
                                    }
                                    if (readLine.IndexOf("Line Voltage/Hertz") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Hertz") + 5);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        strMotorTemp = strLineData;
                                        strTemp = strMotorTemp.Substring(strMotorTemp.IndexOf('-') + 1);
                                        txtMotorData.strCOMPRESSOR_VOLTS = System.Text.RegularExpressions.Regex.Replace(strMotorTemp.Substring(0, strMotorTemp.IndexOf('-')), @"[^0-9]+", "");
                                        txtMotorData.strCOMPRESSOR_PHASE = strTemp.Substring(0, strTemp.IndexOf('-'));
                                        txtMotorData.strCOMPRESSOR_HERTZ = strTemp.Substring(strTemp.IndexOf('-') + 1);
                                        ht.Add("COMPRESSOR_VOLTS", txtMotorData.strCOMPRESSOR_VOLTS);
                                        ht.Add("COMPRESSOR_PHASE", txtMotorData.strCOMPRESSOR_PHASE);
                                        ht.Add("COMPRESSOR_HERTZ", txtMotorData.strCOMPRESSOR_HERTZ);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region txtFlowControlsData
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Flow Controls") > 0 && strTemp == "Flow Controls")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Output Type")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Float Valve Size") >= 0 && readLine.IndexOf("Economizer") < 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtFlowControlsData.strFLOAT_VALVE_SIZE = strLineData;
                                        ht.Add("FLOAT_VALVE_SIZE", txtFlowControlsData.strFLOAT_VALVE_SIZE);
                                    }
                                    if (readLine.IndexOf("Economizer Float Valve Size") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Size") + 4);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        txtFlowControlsData.strFLOAT_BALL_VALVE_SIZE = strLineData;
                                        ht.Add("FLOAT_BALL_VALVE_SIZE", txtFlowControlsData.strFLOAT_BALL_VALVE_SIZE);
                                    }
                                    if (readLine.IndexOf("Flasc Orifice") >= 0)
                                    {
                                        strLineData = readLine.Substring(readLine.IndexOf("Orifice") + 7);
                                        strLineData = strLineData.Trim();
                                        //MessageBox.Show(strLineData);
                                        strTemp = strLineData;
                                        txtFlowControlsData.strCOND_FLASC_ORIFICE = System.Text.RegularExpressions.Regex.Replace(strTemp, @"[^0-9]+", "");
                                        ht.Add("COND_FLASC_ORIFICE", txtFlowControlsData.strCOND_FLASC_ORIFICE);
                                    }
                                }
                            }
                        }
                        #endregion

                        if (readLine.IndexOf("Percent Load") == 0)
                        {
                            txtData.strListPERCENT_LOAD = new List<string>();
                            while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                            {
                                strLineData = readLine.Trim();
                                //MessageBox.Show(strLineData);
                                txtData.strListPERCENT_LOAD.Add(strLineData);

                            }
                            for (int i = 0; i < txtData.strListPERCENT_LOAD.Count; i++)
                            {
                                if (i == 0)
                                {
                                    ht.Add("PERCENT_LOAD", txtData.strListPERCENT_LOAD[i]);
                                }
                                else
                                {
                                    ht.Add("PERCENT_LOAD" + "_" + (i + 1), txtData.strListPERCENT_LOAD[i]);
                                }
                            }
                        }
                        if (readLine.IndexOf("Chiller Capacity") == 0)
                        {
                            txtData.strLisCOOLER_CAPACITY = new List<string>();
                            txtData.strListCHILLER_CAPACITY = new List<string>();
                            while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                if (txtData.strLisCOOLER_CAPACITY.Count < 1)
                                {
                                    strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                    strLineData = strLineData.Trim();
                                    strLineData = strLineData.Replace("*", "");
                                    strLineData = strLineData.TrimEnd('.');
                                    txtData.strListCHILLER_CAPACITY.Add(strLineData.Trim());
                                    ht.Add("CHILLER_CAPACITY", txtData.strListCHILLER_CAPACITY[0]);
                                }
                                strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Replace("*", "");
                                strLineData = strLineData.Trim();
                                txtData.strLisCOOLER_CAPACITY.Add(strLineData.TrimEnd('.'));
                                //MessageBox.Show(strLineData);
                            }
                            for (int i = 0; i < txtData.strLisCOOLER_CAPACITY.Count; i++)
                            {
                                if (i == 0)
                                {
                                    ht.Add("COOLER_CAPACITY", txtData.strLisCOOLER_CAPACITY[i]);
                                }
                                else
                                {
                                    ht.Add("COOLER_CAPACITY" + "_" + (i + 1), txtData.strLisCOOLER_CAPACITY[i]);
                                }
                            }
                        }
                        if (readLine.IndexOf("Chiller Heating") == 0)
                        {
                            txtData.strLisCOOLER_CAPACITY = new List<string>();
                            txtData.strListCHILLER_CAPACITY = new List<string>();
                            readLine = sr.ReadLine();
                            if (readLine.Trim() == "Capacity")
                            {
                                while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                {
                                    //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                    if (txtData.strLisCOOLER_CAPACITY.Count < 1)
                                    {
                                        strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                        strLineData = strLineData.Trim();
                                        strLineData = strLineData.Replace("*", "");
                                        strLineData = strLineData.TrimEnd('.');
                                        txtData.strListCHILLER_CAPACITY.Add(strLineData.Trim());
                                        ht.Add("CHILLER_CAPACITY", txtData.strListCHILLER_CAPACITY[0]);
                                    }
                                    strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                    strLineData = strLineData.Replace("*", "");
                                    strLineData = strLineData.Trim();
                                    txtData.strLisCOOLER_CAPACITY.Add(strLineData.TrimEnd('.'));
                                    //MessageBox.Show(strLineData);
                                }
                                for (int i = 0; i < txtData.strLisCOOLER_CAPACITY.Count; i++)
                                {
                                    if (i == 0)
                                    {
                                        ht.Add("COOLER_CAPACITY", txtData.strLisCOOLER_CAPACITY[i]);
                                    }
                                    else
                                    {
                                        ht.Add("COOLER_CAPACITY" + "_" + (i + 1), txtData.strLisCOOLER_CAPACITY[i]);
                                    }
                                }
                            }
                        }

                        if (readLine.IndexOf("Chiller Input kW") == 0)
                        {
                            txtData.strListINPUT_KW = new List<string>();
                            while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);

                                //strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                //strLineData = strLineData.Replace("*", "");

                                strLineData = strLineData.Trim();
                                txtData.strListINPUT_KW.Add(strLineData.TrimEnd('.'));
                                //MessageBox.Show(strLineData);
                            }
                            for (int i = 0; i < txtData.strListINPUT_KW.Count; i++)
                            {
                                if (i == 0)
                                {
                                    ht.Add("INPUT_KW", txtData.strListINPUT_KW[i]);
                                }
                                else
                                {
                                    ht.Add("INPUT_KW" + "_" + (i + 1), txtData.strListINPUT_KW[i]);
                                }
                            }
                        }
                        if (readLine.IndexOf("Chiller Efficiency") == 0)
                        {
                            txtData.strListINPUT_KW_PER_TON = new List<string>();
                            while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);

                                //strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                //strLineData = strLineData.Replace("/", "");
                                //strLineData = strLineData.Replace("*", "");

                                strLineData = strLineData.Trim();
                                txtData.strListINPUT_KW_PER_TON.Add(strLineData.TrimEnd('.'));
                                //MessageBox.Show(strLineData);
                            }
                            for (int i = 0; i < txtData.strListINPUT_KW_PER_TON.Count; i++)
                            {
                                if (i == 0)
                                {
                                    ht.Add("INPUT_KW_PER_TON", txtData.strListINPUT_KW_PER_TON[i]);
                                }
                                else
                                {
                                    ht.Add("INPUT_KW_PER_TON" + "_" + (i + 1), txtData.strListINPUT_KW_PER_TON[i]);
                                }
                            }
                        }

                        if (readLine.IndexOf("Chiller Heating") == 0)
                        {
                            txtData.strListINPUT_KW_PER_TON = new List<string>();
                            readLine = sr.ReadLine();
                            if (readLine.Trim() == "Efficiency")
                            {
                                while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                {
                                    //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                    strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);

                                    //strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                    //strLineData = strLineData.Replace("/", "");
                                    //strLineData = strLineData.Replace("*", "");

                                    strLineData = strLineData.Trim();
                                    txtData.strListINPUT_KW_PER_TON.Add(strLineData.TrimEnd('.'));
                                    //MessageBox.Show(strLineData);
                                }
                                for (int i = 0; i < txtData.strListINPUT_KW_PER_TON.Count; i++)
                                {
                                    if (i == 0)
                                    {
                                        ht.Add("INPUT_KW_PER_TON", txtData.strListINPUT_KW_PER_TON[i]);
                                    }
                                    else
                                    {
                                        ht.Add("INPUT_KW_PER_TON" + "_" + (i + 1), txtData.strListINPUT_KW_PER_TON[i]);
                                    }
                                }
                            }
                        }

                        if (readLine.IndexOf("Chiller COPR") == 0 || readLine.IndexOf("Chiller Heating COP") == 0)
                        {
                            txtData.strListCOP = new List<string>();
                            while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);

                                //strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                //strLineData = strLineData.Replace("/", "");
                                //strLineData = strLineData.Replace("*", "");

                                strLineData = strLineData.Trim();
                                txtData.strListCOP.Add(strLineData.TrimEnd('.'));
                                //MessageBox.Show(strLineData);
                            }
                            for (int i = 0; i < txtData.strListCOP.Count; i++)
                            {
                                if (i == 0)
                                {
                                    ht.Add("COP", txtData.strListCOP[i]);
                                }
                                else
                                {
                                    ht.Add("COP" + "_" + (i + 1), txtData.strListCOP[i]);
                                }
                            }
                        }
                        #region Cooler
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Cooler") == 0 && strTemp == "Cooler")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Condenser")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Entering Temp") == 0)
                                    {
                                        txtData.strListCOOLER_EWT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_EWT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_EWT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_EWT", txtData.strListCOOLER_EWT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_EWT" + "_" + (i + 1), txtData.strListCOOLER_EWT[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Leaving Temp") == 0)
                                    {
                                        txtData.strListCOOLER_LWT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_LWT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_LWT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_LWT", txtData.strListCOOLER_LWT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_LWT" + "_" + (i + 1), txtData.strListCOOLER_LWT[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Flow Rate") == 0)
                                    {
                                        txtData.strListCOOLER_FLOW = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_FLOW.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_FLOW.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_FLOW", txtData.strListCOOLER_FLOW[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_FLOW" + "_" + (i + 1), txtData.strListCOOLER_FLOW[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Pressure Drop") == 0)
                                    {
                                        txtData.strListCOOLER_PRESSURE_DROP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_PRESSURE_DROP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_PRESSURE_DROP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_PRESSURE_DROP", txtData.strListCOOLER_PRESSURE_DROP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_PRESSURE_DROP" + "_" + (i + 1), txtData.strListCOOLER_PRESSURE_DROP[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Condenser
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Condenser") == 0 && strTemp == "Condenser")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Motor")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Heat Rejection") == 0)
                                    {
                                        txtData.strListHEAT_REJECTION = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            //strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                            //strLineData = strLineData.Replace("*", "");
                                            strLineData = strLineData.Trim();
                                            txtData.strListHEAT_REJECTION.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListHEAT_REJECTION.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("HEAT_REJECTION", txtData.strListHEAT_REJECTION[i]);
                                            }
                                            else
                                            {
                                                ht.Add("HEAT_REJECTION" + "_" + (i + 1), txtData.strListHEAT_REJECTION[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Entering Temp") == 0)
                                    {
                                        txtData.strListCONDENSER_EWT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCONDENSER_EWT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCONDENSER_EWT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("CONDENSER_EWT", txtData.strListCONDENSER_EWT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("CONDENSER_EWT" + "_" + (i + 1), txtData.strListCONDENSER_EWT[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Leaving Temp") == 0)
                                    {
                                        txtData.strListCONDENSER_LWT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCONDENSER_LWT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCONDENSER_LWT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("CONDENSER_LWT", txtData.strListCONDENSER_LWT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("CONDENSER_LWT" + "_" + (i + 1), txtData.strListCONDENSER_LWT[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Flow Rate") == 0)
                                    {
                                        txtData.strListCONDENSER_FLOW = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCONDENSER_FLOW.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCONDENSER_FLOW.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("CONDENSER_FLOW", txtData.strListCONDENSER_FLOW[i]);
                                            }
                                            else
                                            {
                                                ht.Add("CONDENSER_FLOW" + "_" + (i + 1), txtData.strListCONDENSER_FLOW[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Pressure Drop") == 0)
                                    {
                                        txtData.strListCONDENSER_PRESSURE_DROP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCONDENSER_PRESSURE_DROP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCONDENSER_PRESSURE_DROP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("CONDENSER_PRESSURE_DROP", txtData.strListCONDENSER_PRESSURE_DROP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("CONDENSER_PRESSURE_DROP" + "_" + (i + 1), txtData.strListCONDENSER_PRESSURE_DROP[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Motor
                        strTemp = readLine.Trim();
                        if (readLine.IndexOf("Motor") == 0 && strTemp == "Motor")
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Compressor" || strTemp == "Control Parameters" || strTemp == "Heat Exchangers" || strTemp == "Cooler" || strTemp == "Condenser" || strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Motor Rated Load Amps") == 0)
                                    {
                                        txtData.strListMOTOR_RLA = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMOTOR_RLA.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMOTOR_RLA.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MOTOR_RLA", txtData.strListMOTOR_RLA[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MOTOR_RLA" + "_" + (i + 1), txtData.strListMOTOR_RLA[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Motor OLTA") == 0)
                                    {
                                        txtData.strListMOTOR_OLTA = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMOTOR_OLTA.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMOTOR_OLTA.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MOTOR_OLTA", txtData.strListMOTOR_OLTA[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MOTOR_OLTA" + "_" + (i + 1), txtData.strListMOTOR_OLTA[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Motor LRYA") == 0)
                                    {
                                        txtData.strListMOTOR_LRYA = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMOTOR_LRYA.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMOTOR_LRYA.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MOTOR_LRYA", txtData.strListMOTOR_LRYA[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MOTOR_LRYA" + "_" + (i + 1), txtData.strListMOTOR_LRYA[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Motor LRDA") == 0)
                                    {
                                        txtData.strListMOTOR_LRDA = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMOTOR_LRDA.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMOTOR_LRDA.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MOTOR_LRDA", txtData.strListMOTOR_LRDA[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MOTOR_LRDA" + "_" + (i + 1), txtData.strListMOTOR_LRDA[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Max Fuse/CB Amps") == 0)
                                    {
                                        txtData.strListMAX_FUSE_CIRCUIT_BREAKER = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMAX_FUSE_CIRCUIT_BREAKER.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMAX_FUSE_CIRCUIT_BREAKER.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MAX_FUSE_CIRCUIT_BREAKER", txtData.strListMAX_FUSE_CIRCUIT_BREAKER[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MAX_FUSE_CIRCUIT_BREAKER" + "_" + (i + 1), txtData.strListMAX_FUSE_CIRCUIT_BREAKER[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Min Circuit Ampacity") == 0)
                                    {
                                        txtData.strListMIN_CIRCUIT_AMPACITY = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListMIN_CIRCUIT_AMPACITY.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListMIN_CIRCUIT_AMPACITY.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("MIN_CIRCUIT_AMPACITY", txtData.strListMIN_CIRCUIT_AMPACITY[i]);
                                            }
                                            else
                                            {
                                                ht.Add("MIN_CIRCUIT_AMPACITY" + "_" + (i + 1), txtData.strListMIN_CIRCUIT_AMPACITY[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Compressor
                        strTemp = strTemp.Trim();
                        if (strTemp == "Compressor" && readLine.IndexOf("Compressor") == 0)
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Control Parameters" || strTemp == "Heat Exchangers" || strTemp == "Cooler" || strTemp == "Condenser" || strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Flow Fraction") == 0)
                                    {
                                        txtData.strListCOMPR_FLOW_FRACTION = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOMPR_FLOW_FRACTION.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOMPR_FLOW_FRACTION.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COMPR_FLOW_FRACTION", txtData.strListCOMPR_FLOW_FRACTION[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COMPR_FLOW_FRACTION" + "_" + (i + 1), txtData.strListCOMPR_FLOW_FRACTION[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Head Fraction") == 0)
                                    {
                                        txtData.strListCOMPR_HEAD_FRACTION = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOMPR_HEAD_FRACTION.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOMPR_HEAD_FRACTION.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COMPR_HEAD_FRACTION", txtData.strListCOMPR_HEAD_FRACTION[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COMPR_HEAD_FRACTION" + "_" + (i + 1), txtData.strListCOMPR_HEAD_FRACTION[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Discharge Temp") == 0)
                                    {
                                        txtData.strListCOMP_DISCH_TEMP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOMP_DISCH_TEMP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOMP_DISCH_TEMP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COMP_DISCH_TEMP", txtData.strListCOMP_DISCH_TEMP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COMP_DISCH_TEMP" + "_" + (i + 1), txtData.strListCOMP_DISCH_TEMP[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Control Parameters
                        strTemp = strTemp.Trim();
                        if (strTemp == "Control Parameters" && readLine.IndexOf("Control Parameters") == 0)
                        {
                            //ht.Add("PARAM_GV_MIN", "5%");
                            //ht.Add("PARAM_GV_MAX", "100%");
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Heat Exchangers" || strTemp == "Cooler" || strTemp == "Condenser" || strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Surge/HGBP GVmin") == 0)
                                    {
                                        txtData.strListPARAM_GV_MIN = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.%]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_GV_MIN.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_GV_MIN.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_GV_MIN", txtData.strListPARAM_GV_MIN[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_GV_MIN" + "_" + (i + 1), txtData.strListPARAM_GV_MIN[i]);
                                            }
                                        }
                                        //ht.Add("PARAM_GV_MIN", "5%");
                                    }
                                    if (readLine.IndexOf("Surge/HGBP GVmax") == 0)
                                    {
                                        txtData.strListPARAM_GV_MAX = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.%]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_GV_MAX.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_GV_MAX.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_GV_MAX", txtData.strListPARAM_GV_MAX[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_GV_MAX" + "_" + (i + 1), txtData.strListPARAM_GV_MAX[i]);
                                            }
                                        }
                                        //ht.Add("PARAM_GV_MAX", "100%");
                                    }
                                    if (readLine.IndexOf("Surge/HGBP Delta Tsmin") == 0)
                                    {
                                        txtData.strListPARAM_DTSMIN = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_DTSMIN.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_DTSMIN.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_DTSMIN", txtData.strListPARAM_DTSMIN[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_DTSMIN" + "_" + (i + 1), txtData.strListPARAM_DTSMIN[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Surge/HGBP Delta Tsmax") == 0)
                                    {
                                        txtData.strListPARAM_DTSMAX = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_DTSMAX.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_DTSMAX.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_DTSMAX", txtData.strListPARAM_DTSMAX[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_DTSMAX" + "_" + (i + 1), txtData.strListPARAM_DTSMAX[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Surge Line Shape") == 0 || readLine.IndexOf("Surge Line Shape Factor") == 0)
                                    {
                                        txtData.strListPARAM_SHAPEFAC = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            if (readLine.IndexOf("Factor") == 0)
                                            {
                                                readLine = sr.ReadLine();
                                            }
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            //strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = readLine;
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_SHAPEFAC.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_SHAPEFAC.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_SHAPEFAC", txtData.strListPARAM_SHAPEFAC[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_SHAPEFAC" + "_" + (i + 1), txtData.strListPARAM_SHAPEFAC[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Cooler Min DP") == 0)
                                    {
                                        txtData.strListPARAM_COOLER_MIN_DP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_COOLER_MIN_DP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_COOLER_MIN_DP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_COOLER_MIN_DP", txtData.strListPARAM_COOLER_MIN_DP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_COOLER_MIN_DP" + "_" + (i + 1), txtData.strListPARAM_COOLER_MIN_DP[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Condenser Min DP") == 0)
                                    {
                                        txtData.strListPARAM_CONDENSER_MIN_DP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListPARAM_CONDENSER_MIN_DP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListPARAM_CONDENSER_MIN_DP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("PARAM_CONDENSER_MIN_DP", txtData.strListPARAM_CONDENSER_MIN_DP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("PARAM_CONDENSER_MIN_DP" + "_" + (i + 1), txtData.strListPARAM_CONDENSER_MIN_DP[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Heat Exchangers
                        strTemp = strTemp.Trim();
                        if (strTemp == "Heat Exchangers" && readLine.IndexOf("Heat Exchangers") == 0)
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Cooler"|| strTemp == "Condenser" || strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Condensing Temp") == 0)
                                    {
                                        txtData.strListCONDENSING_TEMP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCONDENSING_TEMP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCONDENSING_TEMP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("CONDENSING_TEMP", txtData.strListCONDENSING_TEMP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("CONDENSING_TEMP" + "_" + (i + 1), txtData.strListCONDENSING_TEMP[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Cooler Wall Temp") == 0)
                                    {
                                        txtData.strListCOOLER_WALL_TEMP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_WALL_TEMP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_WALL_TEMP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_WALL_TEMP", txtData.strListCOOLER_WALL_TEMP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_WALL_TEMP" + "_" + (i + 1), txtData.strListCOOLER_WALL_TEMP[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Suction Temp") == 0)
                                    {
                                        txtData.strListCOOLER_REFRIGERANT_TEMP = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_REFRIGERANT_TEMP.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_REFRIGERANT_TEMP.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_REFRIGERANT_TEMP", txtData.strListCOOLER_REFRIGERANT_TEMP[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_REFRIGERANT_TEMP" + "_" + (i + 1), txtData.strListCOOLER_REFRIGERANT_TEMP[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Cooler Tube Vel") == 0)
                                    {
                                        txtData.strListCOOL_TUBE_VELOCITY = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOL_TUBE_VELOCITY.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOL_TUBE_VELOCITY.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOL_TUBE_VELOCITY", txtData.strListCOOL_TUBE_VELOCITY[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOL_TUBE_VELOCITY" + "_" + (i + 1), txtData.strListCOOL_TUBE_VELOCITY[i]);
                                            }
                                        }
                                    }
                                    if (readLine.IndexOf("Cond Tube Vel") == 0)
                                    {
                                        txtData.strListCOND_TUBE_VELOCITY = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOND_TUBE_VELOCITY.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOND_TUBE_VELOCITY.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COND_TUBE_VELOCITY", txtData.strListCOND_TUBE_VELOCITY[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COND_TUBE_VELOCITY" + "_" + (i + 1), txtData.strListCOND_TUBE_VELOCITY[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Cooler
                        strTemp = strTemp.Trim();
                        if (strTemp == "Cooler" && readLine.IndexOf("Cooler") == 0 )
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Condenser" || strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Fouling Temp Adj") == 0)
                                    {
                                        txtData.strListCOOLER_FOULING_ADJUSTMENT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOOLER_FOULING_ADJUSTMENT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOOLER_FOULING_ADJUSTMENT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COOLER_FOULING_ADJUSTMENT", txtData.strListCOOLER_FOULING_ADJUSTMENT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COOLER_FOULING_ADJUSTMENT" + "_" + (i + 1), txtData.strListCOOLER_FOULING_ADJUSTMENT[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Condenser
                        strTemp = strTemp.Trim();
                        if (strTemp == "Condenser" && readLine.IndexOf("Condenser") == 0)
                        {
                            while ((readLine = sr.ReadLine()) != null)
                            {
                                strTemp = readLine.Trim();
                                if (strTemp == "Messages")
                                {
                                    break;
                                }
                                else
                                {
                                    if (readLine.IndexOf("Fouling Temp Adj") == 0)
                                    {
                                        txtData.strListCOND_FOULING_ADJUSTMENT = new List<string>();
                                        while ((readLine = sr.ReadLine()) != "" && readLine != " ")
                                        {
                                            //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                            strLineData = Regex.Replace(readLine, "[^\\d.]*", "", RegexOptions.IgnoreCase);
                                            strLineData = strLineData.Trim();
                                            txtData.strListCOND_FOULING_ADJUSTMENT.Add(strLineData.TrimEnd('.'));
                                            //MessageBox.Show(strLineData);
                                        }
                                        for (int i = 0; i < txtData.strListCOND_FOULING_ADJUSTMENT.Count; i++)
                                        {
                                            if (i == 0)
                                            {
                                                ht.Add("COND_FOULING_ADJUSTMENT", txtData.strListCOND_FOULING_ADJUSTMENT[i]);
                                            }
                                            else
                                            {
                                                ht.Add("COND_FOULING_ADJUSTMENT" + "_" + (i + 1), txtData.strListCOND_FOULING_ADJUSTMENT[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                    sr.Close();
                    fs.Close();
                }
            }
            //MessageBox.Show(txtChillerData.ToString());
            //MessageBox.Show(txtCoolerData.ToString());
            //MessageBox.Show(txtCondenserData.ToString());
            //MessageBox.Show(txtCompressorData.ToString());
            //MessageBox.Show(txtMotorData.ToString());
            //MessageBox.Show(txtFlowControlsData.ToString());
            //MessageBox.Show(txtData.ToString());
            return ht;
        }
        #endregion

        #region 获取xml文件中的数据到Hashtable
        public static Hashtable GetXmlDataToHashtable(string xmlPath)
        {
            Hashtable ht = new Hashtable();

            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
                                             select ele;
            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("CHARC").Value;
                strValue = ele.Attribute("VALUE").Value;
                if (ele.LastAttribute.Name == "VALUE_TXT")
                {
                    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                }
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);
                ht.Add(strKey, strValue);
            }
            return ht;
        }
        #endregion

        #region 根据hashtable中的值获取键值
        public static string GetHashtableKey(Hashtable txtMapHashtable,string strValue)
        {
            string strKey = "";
            foreach (DictionaryEntry de in txtMapHashtable)
            {
                if (de.Value.ToString() == strValue)
                {
                    strKey = de.Key.ToString();
                }
            }
            return strKey;
        }
        #endregion

        #region 比较两个Hashtable中的数据
        public static bool CompareHashtable(Hashtable txtHashtable, Hashtable xmlHashtable, Hashtable txtMapHashtable, string strCsvSaveFilePath)
        {
            string strTxtTemp;
            string strXmlTemp;
            bool flagSame = false;

            List<string> strListPublic = new List<string>();
            List<string> strListOnlyTxt = new List<string>();
            List<string> strListOnlyXml = new List<string>();

            foreach (DictionaryEntry de in txtHashtable)
            {
                if (xmlHashtable.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == xmlHashtable[de.Key].ToString())
                    {
                        xmlHashtable.Remove(de.Key);
                    }
                    else
                    {
                        if (xmlHashtable[de.Key].ToString().Contains(";"))
                        {
                            if (de.Key.ToString() == "COND_TUBE_DESCRP" || de.Key.ToString() == "COOL_TUBE_DESCRP")
                            {
                                strXmlTemp = xmlHashtable[de.Key].ToString();
                                strXmlTemp = strXmlTemp.Substring(strXmlTemp.IndexOf(";") + 1);
                                if (de.Value.ToString().ToUpper().Contains(strXmlTemp.ToUpper()))
                                {
                                    xmlHashtable.Remove(de.Key);
                                }
                            }
                            else if (xmlHashtable[de.Key].ToString().ToUpper().Contains(de.Value.ToString().ToUpper()))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strListPublic.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                        else
                        {
                            strTxtTemp = de.Value.ToString();
                            if (strTxtTemp.Contains(".0"))
                            {
                                strTxtTemp = de.Value.ToString().TrimEnd('0');
                            }
                            if (xmlHashtable[de.Key].ToString().Contains(strTxtTemp))
                            {
                                xmlHashtable.Remove(de.Key);
                            }
                            else
                            {
                                strListPublic.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", "") + "," + xmlHashtable[de.Key].ToString().Replace(",", ""));
                                xmlHashtable.Remove(de.Key);
                            }
                        }
                    }
                }
                else
                {
                    strListOnlyTxt.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ""));
                }
            }
            foreach (DictionaryEntry de in xmlHashtable)
            {
                //strList3.Add(de.Key.ToString() + "," + de.Value.ToString());
                strListOnlyXml.Add(de.Key.ToString() + "," + "," + de.Value.ToString().Replace(",", ""));
            }
            if ((strListPublic.Count + strListOnlyTxt.Count + strListOnlyXml.Count) > 0)
            {
                string strName;
                string strProjectTagName;

                strName = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                strName =strName.Substring(0, strName.IndexOf(".csv"));
                strProjectTagName = GetHashtableKey(txtMapHashtable, strName);

                using (FileStream fs = new FileStream(strCsvSaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    sw.WriteLine(strProjectTagName + "," + strName);
                    sw.WriteLine("");

                    sw.WriteLine("Key,TxtValue,XmlValue");
                    if (strListPublic.Count > 0)
                    {
                        strListSummary.Add(strProjectTagName);
                        strListPublic.Sort();
                        //sw.WriteLine("");
                        sw.WriteLine("txt and xml not same");
                        //sw.WriteLine("两个xml文件中不相同的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListPublic)
                        {
                            sw.WriteLine(s);
                            strListSummary.Add(s);
                        }
                        strListSummary.Add(" ");
                    }
                    if (strListOnlyTxt.Count > 0)
                    {
                        strListOnlyTxt.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in txt file");
                        //sw.WriteLine("xml文件1中有而2中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListOnlyTxt)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strListOnlyXml.Count > 0)
                    {
                        strListOnlyXml.Sort();
                        sw.WriteLine("");
                        sw.WriteLine("Only in xml file");
                        //sw.WriteLine("xml文件2中有而1中没有的值如下：");
                        //sw.WriteLine("");
                        foreach (var s in strListOnlyXml)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = strCsvSaveFilePath.Substring(strCsvSaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }
        #endregion

        #region 获取Hashtable中的数据到CSV文件中
        public static void HastableToCsv(Hashtable ht, string strCsvFileName, string strFirstLine)
        {
            List<string> strListCsvFileValue = new List<string>();

            if (ht.Count > 0)
            {
                foreach (DictionaryEntry de in ht)
                {
                    strListCsvFileValue.Add(de.Key.ToString() + "," + de.Value.ToString().Replace(",", ";"));
                }
                strListCsvFileValue.Sort();
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine(strFirstLine);   //开始写入
                    foreach (var str in strListCsvFileValue)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
            }
        }
        #endregion

        #region 获取List<string>中的数据到CSV文件中
        public static void ListToCsv(List<string> strList, string strCsvFileName)
        {
            if (strList.Count > 0)
            {
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    foreach (var str in strList)
                    {
                        sw.WriteLine(str);
                    }

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
            else
            {
                using (FileStream fs = new FileStream(strCsvFileName, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    sw.WriteLine("The result all same!");   //开始写入

                    sw.Flush(); //清空缓冲区
                    sw.Close(); //关闭流
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
            }
        }
        #endregion

        #region 根据集合中的路径生成相应的CSV文件,并把路劲下的txt或xml文件复制到指定路径
        public static Hashtable ListPathToCsv(List<string> strPathList, string strCsvPath, string strCopyPath,int pathLength)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                    //strFileName = strFileName.Substring(0, strFileName.LastIndexOf(".")) + ".csv";
                    if (strFileType == ".txt")
                    {
                        ht = GetTxtDataToHashtable(str);
                        //ht = ReadTxtFun.GetTxtDataToHashtable(str);
                    }
                    else if (strFileType == ".xml")
                    {
                        ht = GetXmlDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (!htNameMap.ContainsKey(strFileName))
                        {
                            pTagNum++;
                            strSaveName = "PN" + pTagNum;
                            htNameMap.Add(strFileName, strSaveName);
                        }
                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv","Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htNameMap;
        }

        public static Hashtable ListTxtPathToCsv(List<string> strPathList, string strCsvPath, string strCopyPath, int pathLength)
        {
            int pTagNum = 0;
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htTxtNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    //strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                    //strFileName = strFileName.Substring(0, strFileName.LastIndexOf(".")) + ".csv";
                    if (strFileType == ".txt")
                    {
                        ht = GetTxtDataToHashtable(str);
                        //ht = ReadTxtFun.GetTxtDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (!htTxtNameMap.ContainsKey(strFileName))
                        {
                            pTagNum++;
                            strSaveName = "PN" + pTagNum;
                            htTxtNameMap.Add(strFileName, strSaveName);
                        }
                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv", "Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htTxtNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htTxtNameMap;
        }

        public static Hashtable ListXmlPathToCsv(List<string> strPathList, Hashtable htNameMap, string strCsvPath, string strCopyPath, int pathLength)
        {
            int pTagErrorNum = 0;
            string strSaveName = "PN";
            Hashtable htXmlNameMap = new Hashtable();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strCopyPath);

            strCsvPath = FileHelper.PathComplement(strCsvPath);
            strCopyPath = FileHelper.PathComplement(strCopyPath);

            if (strPathList.Count > 0)
            {
                foreach (var str in strPathList)
                {
                    string strFileName;
                    string strFileType;
                    Hashtable ht = new Hashtable();
                    strFileType = str.Substring(str.LastIndexOf(".")).ToLower();
                    if (strFileType == ".xml")
                    {
                        ht = GetXmlDataToHashtable(str);
                    }
                    if (ht.Count > 0 && ht.ContainsKey("PROJECT_NAME") && ht.ContainsKey("TAG_NAME"))
                    {
                        strFileName = ht["PROJECT_NAME"].ToString() + "," + ht["TAG_NAME"].ToString();
                        if (htNameMap.ContainsKey(strFileName))
                        {
                            strSaveName = htNameMap[strFileName].ToString();
                            htXmlNameMap.Add(strFileName, strSaveName);
                        }
                        HastableToCsv(ht, strCsvPath + strSaveName + ".csv", "Key,Value");
                    }
                    else
                    {
                        pTagErrorNum++;
                        strSaveName = "Error-" + strFileType.TrimStart('.') + pTagErrorNum;
                        strFileName = str.Substring(str.LastIndexOf("\\") + 1);
                        strFileName = str.Substring(pathLength, str.LastIndexOf("\\") - pathLength) + "," + strFileName.Substring(0, strFileName.LastIndexOf("."));
                        htNameMap.Add(strFileName, strSaveName);
                    }
                    System.IO.File.Copy(str, strCopyPath + strSaveName + strFileType, true);
                }
            }
            return htXmlNameMap;
        }
        #endregion

        #region 批量比较txt和xml
        public static List<string> CompareTxtAndXml(string strTxtPath, string strXmlPath, string strCsvFilePath, Hashtable htTxtMap)
        {
            List<string> strListCsvFileName = new List<string>();
            if (strTxtPath == "" || strXmlPath == "")
            {
                MessageBox.Show("File Path is null！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strTxtPath), TXT_FILE))
            {
                MessageBox.Show("txt File not exist！");
            }
            if (!FileHelper.FilesExist(new DirectoryInfo(strXmlPath), XML_FILE))
            {
                MessageBox.Show("xml File not exist！");
            }
            else
            {
                bool flagSame = false;
                string strTxtTemp;
                Hashtable htTxt = new Hashtable();
                Hashtable htXml = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                FileHelper.CleanFolder(strCsvFilePath);
                strCsvFilePath = FileHelper.PathComplement(strCsvFilePath);

                strPathList1 = FileHelper.GetFiles(strTxtPath, TXT_FILE);
                strPathList2 = FileHelper.GetFiles(strXmlPath, XML_FILE);

                foreach (var str in strPathList1)
                {
                    strTxtTemp = str.Substring(0, str.LastIndexOf('.')) + ".xml";

                    if (strPathList2.Contains(strTxtTemp))
                    {
                        //htTxt = ReadTxtFun.GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        htTxt = GetTxtDataToHashtable(strTxtPath + "\\" + str);
                        htXml = GetXmlDataToHashtable(strXmlPath + "\\" + strTxtTemp);

                        flagSame = CompareHashtable(htTxt, htXml, htTxtMap, strCsvFilePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListCsvFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
            }
            return strListCsvFileName;
        }
        #endregion

        #region 主方法
        public static void RunFun(string strTxtPath, string strXmlPath)
        {
            Hashtable htTxtMap = new Hashtable();
            Hashtable htXmlMap = new Hashtable();

            string strExcelPath = @"D:\TxtAndXmlTest\result.xlsx";
            string strCsvPath = @"D:\TxtAndXmlTest\ComPareCsvFile";
            string strTxtSavePath = @"D:\TxtAndXmlTest\txtCsvFile";
            string strXmlSavePath = @"D:\TxtAndXmlTest\xmlCsvFile";
            string strTxtPathCopy = @"D:\TxtAndXmlTest\txtFileCopy";
            string strXmlPathCopy = @"D:\TxtAndXmlTest\xmlFileCopy";

            List<string> strListPathTxt = new List<string>();
            List<string> strListPathXml = new List<string>();
            List<string> strListCsvFileName = new List<string>();

            FileHelper.CleanFolder(strCsvPath);
            FileHelper.CleanFolder(strTxtSavePath);
            FileHelper.CleanFolder(strXmlSavePath);
            FileHelper.CleanFolder(strTxtPathCopy);
            FileHelper.CleanFolder(strXmlPathCopy);

            FileHelper.GetFiles(new DirectoryInfo(strTxtPath), TXT_FILE, ref strListPathTxt);
            FileHelper.GetFiles(new DirectoryInfo(strXmlPath), XML_FILE, ref strListPathXml);

            //htTxtMap = ListPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy, strTxtPath.Length);
            //htXmlMap = ListPathToCsv(strListPathXml, strXmlSavePath, strXmlPathCopy, strXmlPath.Length);

            htTxtMap = ListTxtPathToCsv(strListPathTxt, strTxtSavePath, strTxtPathCopy, strTxtPath.Length);
            htXmlMap = ListXmlPathToCsv(strListPathXml, htTxtMap, strXmlSavePath, strXmlPathCopy, strXmlPath.Length);

            strListSummary.Clear();
            strListCsvFileName = CompareTxtAndXml(strTxtPathCopy, strXmlPathCopy, strCsvPath, htTxtMap);

            HastableToCsv(htTxtMap, strCsvPath + "\\txtMap.csv", "ProjectName,TagName,Value");
            HastableToCsv(htXmlMap, strCsvPath + "\\xmlMap.csv", "ProjectName,TagName,Value");
            ListToCsv(strListSummary, strCsvPath + "\\Sumary.csv");
            strListCsvFileName.Add("txtMap.csv");
            strListCsvFileName.Add("xmlMap.csv");
            strListCsvFileName.Add("Sumary.csv");

            ExcelHelper.SaveCsvToExcel(strListCsvFileName, strCsvPath, strExcelPath);
        }
        #endregion
    }
}
