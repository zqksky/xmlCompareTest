﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Globalization;
using System.Windows.Forms;

namespace TxtAndXmlCompare
{
    class ExcelHelper
    {
        #region 保存到Excel
        private void SaveCsvToExcel(string strCsvFilePath, string strExcelFilePath)
        {
            FileInfo newFile = new FileInfo(strExcelFilePath);
            if (newFile.Exists)
            {
                newFile.Delete();
                newFile = new FileInfo(strExcelFilePath);
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("test");
                worksheet.Cells["A1"].LoadFromText(new FileInfo(strCsvFilePath));
                worksheet.Row(1).CustomHeight = true;//自动调整行高
                worksheet.Column(1).AutoFit();//自动调整列宽
                worksheet.Column(2).AutoFit();//自动调整列宽
                worksheet.Column(3).AutoFit();//自动调整列宽
                worksheet.Cells.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;//水平居中
                worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小
                package.Save();
            }
        }
        public static void SaveCsvToExcel(List<string> strListCsvFileName, string strCsvFilePath, string strExcelFilePath)
        {
            if (strCsvFilePath[strCsvFilePath.Length - 1] != System.IO.Path.DirectorySeparatorChar)
            {
                strCsvFilePath += System.IO.Path.DirectorySeparatorChar;
            }
            FileInfo newFile = new FileInfo(strExcelFilePath);
            if (newFile.Exists)
            {
                newFile.Delete();
                newFile = new FileInfo(strExcelFilePath);
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                if (strListCsvFileName.Count > 0)
                {
                    foreach (var str in strListCsvFileName)
                    {
                        string strTemp = str.Substring(0, str.IndexOf('.'));

                        //sheet表名不能超过31个字符
                        if (strTemp.Length > 31)
                        {
                            strTemp = strTemp.Substring(0, 30);
                        }
                        var format = new ExcelTextFormat();
                        //format.Encoding = new UTF8Encoding;
                        format.Culture = new CultureInfo(System.Threading.Thread.CurrentThread.CurrentCulture.ToString());
                        format.Culture.DateTimeFormat.ShortDatePattern = "dd.mm.yyyy";

                        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(strTemp);
                        worksheet.Cells["A1"].LoadFromText(new FileInfo(strCsvFilePath + str));
                        worksheet.Row(1).CustomHeight = true;//自动调整行高
                        worksheet.Column(1).AutoFit();//自动调整列宽
                        worksheet.Column(2).AutoFit();//自动调整列宽
                        worksheet.Column(3).AutoFit();//自动调整列宽
                        worksheet.Cells.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;//水平居中
                        worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小
                    }
                    package.Save();
                }
                else
                {
                    MessageBox.Show("Not Csv file！");
                }
            }
        }
        #endregion
    }
}
