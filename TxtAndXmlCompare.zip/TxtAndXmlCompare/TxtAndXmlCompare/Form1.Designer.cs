﻿namespace TxtAndXmlCompare
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnOpenPath2 = new System.Windows.Forms.Button();
            this.txtXmlPath = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOpenPath1 = new System.Windows.Forms.Button();
            this.txtTxtPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(286, 109);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 32;
            this.btnExit.Text = "退出";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnOpenPath2
            // 
            this.btnOpenPath2.Location = new System.Drawing.Point(396, 59);
            this.btnOpenPath2.Name = "btnOpenPath2";
            this.btnOpenPath2.Size = new System.Drawing.Size(75, 23);
            this.btnOpenPath2.TabIndex = 31;
            this.btnOpenPath2.Text = "打开";
            this.btnOpenPath2.UseVisualStyleBackColor = true;
            this.btnOpenPath2.Click += new System.EventHandler(this.btnOpenPath2_Click);
            // 
            // txtXmlPath
            // 
            this.txtXmlPath.Location = new System.Drawing.Point(125, 61);
            this.txtXmlPath.Name = "txtXmlPath";
            this.txtXmlPath.Size = new System.Drawing.Size(256, 20);
            this.txtXmlPath.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "XML文件路径：";
            // 
            // btnOpenPath1
            // 
            this.btnOpenPath1.Location = new System.Drawing.Point(396, 23);
            this.btnOpenPath1.Name = "btnOpenPath1";
            this.btnOpenPath1.Size = new System.Drawing.Size(75, 23);
            this.btnOpenPath1.TabIndex = 28;
            this.btnOpenPath1.Text = "打开";
            this.btnOpenPath1.UseVisualStyleBackColor = true;
            this.btnOpenPath1.Click += new System.EventHandler(this.btnOpenPath1_Click);
            // 
            // txtTxtPath
            // 
            this.txtTxtPath.Location = new System.Drawing.Point(125, 25);
            this.txtTxtPath.Name = "txtTxtPath";
            this.txtTxtPath.Size = new System.Drawing.Size(256, 20);
            this.txtTxtPath.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "TXT文件路径：";
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(167, 109);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 25;
            this.btnRun.Text = "运行";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 169);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnOpenPath2);
            this.Controls.Add(this.txtXmlPath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnOpenPath1);
            this.Controls.Add(this.txtTxtPath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRun);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnOpenPath2;
        private System.Windows.Forms.TextBox txtXmlPath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOpenPath1;
        private System.Windows.Forms.TextBox txtTxtPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRun;
    }
}

