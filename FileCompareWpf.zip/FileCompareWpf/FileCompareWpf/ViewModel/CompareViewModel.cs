﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileCompareWpf.Command;
using FileCompareWpf.Model;
using System.IO;
using System.Windows.Forms;
using System.Collections;

namespace FileCompareWpf.ViewModel
{
    class CompareViewModel
    {
        public CompareModel myCompare { get; set; }
        public DelegateCommand OpenFolderCommand1 { get; set; }
        public DelegateCommand OpenFolderCommand2 { get; set; }
        public DelegateCommand CompareFolderCommand { get; set; }
        public DelegateCommand ExitCommand { get; set; }

        public CompareViewModel()
        {
            myCompare = new CompareModel();

            OpenFolderCommand1=new DelegateCommand();
            OpenFolderCommand1.ExecuteCommand = new Action<object>(SetFolderPath1);

            OpenFolderCommand2 = new DelegateCommand();
            OpenFolderCommand2.ExecuteCommand = new Action<object>(SetFolderPath2);

            CompareFolderCommand = new DelegateCommand();
            CompareFolderCommand.ExecuteCommand = new Action<object>(CompareFolder);

            ExitCommand = new DelegateCommand();
            ExitCommand.ExecuteCommand = new Action<object>(ExitSystem);
        }
        private void SetFolderPath1(object obj)
        {
            System.Windows.Forms.FolderBrowserDialog folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                myCompare.StrFolderPath_1 = folderBrowserDialog.SelectedPath;
            }
        }

        private void SetFolderPath2(object obj)
        {
            System.Windows.Forms.FolderBrowserDialog folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                myCompare.StrFolderPath_2 = folderBrowserDialog.SelectedPath;
            }
        }

        private void ExitSystem(object obj)
        {
            Environment.Exit(0);
        }

        private void CompareFolder(object obj)
        {
            string strDirectoryPath1 = myCompare.StrFolderPath_1;
            string strDirectoryPath2 = myCompare.StrFolderPath_2;
            string strSavePath = strDirectoryPath1.TrimEnd('\\');
            strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);

            //getAllFiles(@"D:\xmlTest");

            if (myCompare.StrFolderPath_1 == "" || myCompare.StrFolderPath_2 == "")
            {
                MessageBox.Show("文件路径不能为空！");
            }
            //判断文件路径是否存在，不存在则创建文件夹 
            else if (!Directory.Exists(myCompare.StrFolderPath_1))
            {
                MessageBox.Show("文件路径1不存在！");
            }
            else if (!Directory.Exists(myCompare.StrFolderPath_2))
            {
                MessageBox.Show("文件路径2不存在！");
            }
            else
            {
                #region hashtable实现
                Hashtable ht1 = new Hashtable();
                Hashtable ht2 = new Hashtable();

                ht1 = getDirectoryAllFiles(strDirectoryPath1, ht1);
                ht2 = getDirectoryAllFiles(strDirectoryPath2, ht2);
                //ht1 = getDirectoryAllFiles(strDirectoryPath1,0, ht1);
                //ht2 = getDirectoryAllFiles(strDirectoryPath2,0, ht2);
                fileCompare(ht1, ht2, strSavePath + "result.txt");
                #endregion
            }
        }

        #region 方法

        private bool CompareFile(string filePath1, string filePath2)
        {
            //使用System.security.Cryptography.HashAlgorithm类为每个文件生成一个哈希码，然后比较两个哈希码是否一致
            var hash = System.Security.Cryptography.HashAlgorithm.Create();

            //计算第一个文件的哈希值
            var stream_1 = new System.IO.FileStream(filePath1, System.IO.FileMode.Open);
            byte[] hashByte_1 = hash.ComputeHash(stream_1);
            stream_1.Close();

            //计算第二个文件的哈希值
            var stream_2 = new System.IO.FileStream(filePath2, System.IO.FileMode.Open);
            byte[] hashByte_2 = hash.ComputeHash(stream_2);
            stream_2.Close();

            //比较两个哈希值
            if (BitConverter.ToString(hashByte_1) == BitConverter.ToString(hashByte_2))
            {
                //MessageBox.Show("两个文件相等");
                return true;
            }
            else
            {
                //MessageBox.Show("两个文件不等");
                return false;
            }
        }

        private bool fileCompare(Hashtable ht1, Hashtable ht2, string SaveFilePath)
        {
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in ht1)
            {
                if (ht2.ContainsKey(de.Key))
                {
                    if (CompareFile(de.Value.ToString(), ht2[de.Key].ToString()))
                    {
                        ht2.Remove(de.Key);
                    }
                    else
                    {
                        strList1.Add(de.Value.ToString() + "; " + ht2[de.Key].ToString());
                        ht2.Remove(de.Key);
                    }
                }
                else
                {
                    strList2.Add(de.Value.ToString());
                }
            }
            foreach (DictionaryEntry de in ht2)
            {
                strList3.Add(de.Value.ToString());
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);

                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    //sw.WriteLine("****************比较结果如下**********************");
                    if (strList1.Count > 0)
                    {
                        //sw.WriteLine("");
                        //sw.WriteLine("The data in A and B is not the same");
                        sw.WriteLine("************两个文件中不相同的文件如下*********");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file1 in file2");
                        sw.WriteLine("************路径1中有而2中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file2 in file1");
                        sw.WriteLine("************路径2中有而1中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }

        private Hashtable getDirectoryAllFiles(string path, Hashtable ht)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string strKey;
                strKey = NextFile.FullName;
                //str = str.Substring(0, str.LastIndexOf('\\') + 1);
                strKey = strKey.Substring(strKey.IndexOf('\\') + 1);
                strKey = strKey.Substring(strKey.IndexOf('\\') + 1);
                strKey = strKey.Substring(strKey.IndexOf('\\'));
                ht.Add(strKey, NextFile.FullName);
                //ht.Add(str + NextFile.Name, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, ht);
            }
            return ht;
        }

        private Hashtable getDirectoryAllFiles(string path, int leval, Hashtable ht)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            leval++;

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string str;
                str = NextFile.FullName;
                //str = str.Substring(0,str.LastIndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\') + 1);
                str = str.Substring(str.IndexOf('\\') + 1);
                str = str.Substring(str.IndexOf('\\'));
                ht.Add(leval + str, NextFile.FullName);
                //ht.Add(leval + str + NextFile.Name, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, leval, ht);
            }
            return ht;
        }
        #endregion
    }
}
