﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;
using System.ComponentModel;

namespace fileCompare
{
    class NpoiHelper
    {
        private static bool ConvertWithNPOI(string excelFileName, string worksheetName, IEnumerable<string[]> csvLines)
        {
            if (csvLines == null || csvLines.Count() == 0)
            {
                return (false);
            }

            int rowCount = 0;
            int colCount = 0;

            IWorkbook workbook = new XSSFWorkbook();
            ISheet worksheet = workbook.CreateSheet(worksheetName);

            foreach (var line in csvLines)
            {
                IRow row = worksheet.CreateRow(rowCount);

                colCount = 0;
                foreach (var col in line)
                {
                    //row.CreateCell(colCount).SetCellValue(TypeConverter.TryConvert(col));
                    colCount++;
                }
                rowCount++;
            }

            using (FileStream fileWriter = File.Create(excelFileName))
            {
                workbook.Write(fileWriter);
                fileWriter.Close();
            }

            worksheet = null;
            workbook = null;

            return (true);
        }

        public static DataTable ExcelToTable(string fileName)
        {
            DataTable dt = new DataTable();

            //将文件转换成stream
            using (FileStream fileStream = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                //根据不同版本创建不同的workbook
                IWorkbook workbook;
                if (fileName.Contains(".xlsx"))
                {
                    //针对07及以上（.xlsx文件）
                    workbook = new XSSFWorkbook(fileStream);
                }
                else
                {
                    //针对03（.xls文件）
                    workbook = new HSSFWorkbook(fileStream);
                }

                //获取第一个sheet
                ISheet sheet = workbook.GetSheetAt(0);
                //获取sheet的第一行
                IRow firstRow = sheet.GetRow(0);
                //获取sheet的列数
                int cellCount = firstRow.LastCellNum;
                //第一行作为标题加到datatable中
                for (int i = firstRow.FirstCellNum; i < cellCount; i++)
                {
                    DataColumn column = new DataColumn(firstRow.GetCell(i).StringCellValue);
                    dt.Columns.Add(column);
                }

                //sheet的行数（这里获取的行数是去除首行的行数）
                int rowCount = sheet.LastRowNum;
                for (int i = (sheet.FirstRowNum + 1); i <= rowCount; i++)
                {
                    //获取sheet的行数据
                    IRow row = sheet.GetRow(i);
                    //因为没有数据的行默认是null,去除空数据
                    if (row == null)
                    {
                        continue;
                    }

                    DataRow dataRow = dt.NewRow();
                    for (int j = row.FirstCellNum; j < cellCount; j++)
                    {
                        //没有数据的单元格默认是null,去除
                        if (row.GetCell(j) != null)
                        {
                            dataRow[j] = row.GetCell(j).ToString();
                        }
                    }
                    dt.Rows.Add(dataRow);
                }
            }
            return dt;
        }
    }
}
