﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using OfficeOpenXml.Drawing.Chart;
using OfficeOpenXml.Drawing;

namespace fileCompare
{
    #region EPPlus核心类介绍
    //2.1  ExcelPackage类

    //ExcelPackage是EPPlus的入口类，解析一个Excel文件，生成ExcelWorkbook对象来表示一个Excel。该类实现了IDisposable接口，也就是说可以使用using进行对象释放。

    //10个构造函数，下面是常用的3个：
    //public ExcelPackage();

    //public ExcelPackage(FileInfo newFile);

    //public ExcelPackage(Stream newStream);

    //不管构造函数中传入的参数是否有效，该类的Workbook属性都会自动创建，无须担心空指针问题。

    //2.2 ExcelWorkbook类

    //ExcelWorkbook类表示了一个Excel文件，其Worksheets属性对应着Excel的各个Sheet。Worksheets属性会自动创建，不用担心空指针异常，但是其Count可能为0。

    //ExcelWorkbook的Properties属性可以对Office的一些属性进行设置，例如：
    //public string Author { get; set; }
    //public string Title { get; set; }
    //public string Comments { get; set; }

    //注意：在获取具体的Sheet时，索引号从1开始，例如：
    //ExcelWorksheet sheet = package.Workbook.Worksheets[1];

    //2.3 ExcelWorksheet类

    //一些常用属性：
    //sheet.DefaultColWidth = 10; //默认列宽
    //sheet.DefaultRowHeight = 30; //默认行高
    //sheet.TabColor = Color.Blue; //Sheet Tab的颜色
    //sheet.Cells.Style.WrapText = true; //单元格文字自动换行

    //对行列的增删操作：
    //public void InsertRow(int rowFrom, int rows);

    //public void InsertColumn(int columnFrom, int columns);

    //public void DeleteRow(int rowFrom, int rows);

    //public void DeleteColumn(int columnFrom, int columns);

    //设置指定行或列的样式(宽、高、隐藏、自动换行、数字格式、锁定等)：
    //sheet.Column(1).Width = 10;
    //sheet.Row(1).Height = 30;

    //sheet.Column(1).Hidden = true;
    //sheet.Row(1).Hidden = true;

    //sheet.Column(1).Style.WrapText = true;

    //sheet.Column(1).Style.Numberformat.Format = "$#,###.00";

    //sheet.Row(1).Style.Locked = true;

    //自适应宽度设置：
    //public void AutoFit();
    //public void AutoFit(double MinimumWidth);
    //public void AutoFit(double MinimumWidth, double MaximumWidth);
    ////未传入MinimumWidth时，使用Sheet的DefaultColWidth作为最小值，此时若没有提前对DefaultColWidth进行设置就会报错
    ////此方法时对自动换行和合并的单元格无效

    //2.4 ExcelRange类

    //3个获取单元格范围的方法：
    //public ExcelRange this[string Address] { get; }
    ////Address是指"A1:C5"这种格式

    //public ExcelRange this[int Row, int Col] { get; }

    //public ExcelRange this[int FromRow, int FromCol, int ToRow, int ToCol] { get; }

    //重要属性：
    //public object Value { get; set; }
    ////获取或设置单元格的值

    //复制单元格：
    //public void Copy(ExcelRangeBase Destination);

    //从二维数据集合中装载数据：
    //public ExcelRangeBase LoadFromCollection<T>(IEnumerable<T> Collection);

    //public ExcelRangeBase LoadFromDataReader(IDataReader Reader, bool PrintHeaders);

    //public ExcelRangeBase LoadFromText(FileInfo TextFile);
    ////这里的文件是指CSV文件

    ////数据装载时，会与ExcelRange的行列进行对应，将值设置到其中，这些单元格没有样式和数字格式

    //2.5 样式

    //样式包括字体、颜色、对齐、边框等。
    //range.Style.Fill.PatternType = ExcelFillStyle.Solid;
    //range.Style.Fill.BackgroundColor.SetColor(Color.Gray);
    ////在设置Style.Fill的其他属性之前，必须设置PatternType 
    ////设置了Style.Fill.PatternType之后，必须设置Style.Fill.BackgroundColor，否则单元格背景为黑色
    ////注意Style.Fill.BackgroundColor是个只读属性，需要通过SetColor()方法设置颜色
    //range.Font.Color.SetColor(Color.Red);
    //range.HorizontalAlignment = ExcelHorizontalAlignment.CenterContinuous;

    //2.6  数字格式
    //range.Style.Numberformat.Format = "$#,###.00";

    //使用数字格式时，一定要自行检查格式的正确性，因为产生的过程中EPPlus不会检查其正确性，如果格式有错，在打开产生的Excel文件时会提示文件格式不正确。

    //2.7 公式
    //sheet.Cells[1, 3].range.Formula = "AVERAGE(A1, B1)";
    //sheet.Cells[1, 3].FormulaR1C1 = "AVERAGE(RC[-2], RC[-1])";
    ////以上两个公式表达意思相同——对于第一行，C列的值等于A列和B列的平均值
    #endregion

    #region EPPlus的使用
    //1> 添加dll文件至工程bin文件中

    //2>在程式中添加引用

    //using OfficeOpenXml;        
    //using OfficeOpenXml.Drawing;        
    //using OfficeOpenXml.Drawing.Chart;        
    //using OfficeOpenXml.Style;

    //3>所有的操作语句需要放置在下面的using中

    //using (ExcelPackage package = new ExcelPackage()) 
    // { 
    // }

    //4.添加新的sheet

    // var worksheet = package.Workbook.Worksheets.Add(“sheet1"); 

    //5.单元格赋值,这里多说一句,NPOI必须先创建单元格,然后再给单元格赋值,而Epplus不需要,直接找到单元格进行赋值就可以了.

    //worksheet.Cells[int row, int col].Value = “”;
    //或者
    //worksheet.Cells["A1"].Value = “”;

    //6.合并单元格

    //worksheet.Cells[int fromRow, fromCol, int toRow,int toCol].Merge = true; 

    //7.获取某一个区域

    //var rangeData= worksheet.Cells[fromRow, fromCol, toRow, toCol];

    //8.设置字体

    //worksheet.Cells.Style.Font.Name= “正楷”;
    //worksheet.Cells.Style.Font.Color    
    //worksheet.Cells.Style.Font.Size 

    //9.设置边框的属性

    //worksheet.Cells.Style.Border.Left.Style= ExcelBorderStyle.Thin ； 
    //worksheet.Cells.Style.Border.Right.Style= ExcelBorderStyle.Thin;
    //worksheet.Cells.Style.Border.Top.Style= ExcelBorderStyle.Thin;
    //worksheet.Cells.Style.Border.Bottom.Style= ExcelBorderStyle.Thin; 

    //10.对齐方式

    //worksheet.Cells.Style.HorizontalAlignment=ExcelHorizontalAlignment.Center;
    //worksheet.Cells.Style.VerticalAlignment =  ExcelVerticalAlignment.Bottom;   

    //11. 设置整个sheet的背景色

    //worksheet.Cells.Style.Fill.PatternType= ExcelFillStyle.Solid; 
    //worksheet.Cells.Style.Fill.BackgroundColor.SetColor(Color.LightBlue);

    //12.折行显示

    //worksheet.Cells.Style.WrapText= true;

    //13.单元格自动适应大小

    //worksheet.Cells.Style.ShrinkToFit= true;

    //14.格式化单元格value值

    //worksheet.Cells.Style.Numberformat.Format= "0.00";

    //15.锁定

    //worksheet.Cells["A1"].Style.Locked= true;

    #endregion

    #region 样式设置
    //1、公式计算

    //excel中离不开各种各样的公式计算，在Epplus中运用公式有两种方式，你都可以尝试一下：

    //worksheet.Cells["D2:D5"].Formula = "B2*C2";//这是乘法的公式，意思是第二列乘以第三列的值赋值给第四列，这种方法比较简单明了

    //worksheet.Cells[6, 2, 6, 4].Formula = string.Format("SUBTOTAL(9,{0})", new ExcelAddress(2, 2, 5, 2).Address);//这是自动求和的方法，至于subtotal的用法你需要自己去了解了 

    //2、设置单元格格式

    //worksheet.Cells[5, 3].Style.Numberformat.Format = "#,##0.00";//这是保留两位小数 


    //单元格的格式设置还有很多，我就不一一列出来了，基本上excel上能实现的Epplus都能实现，大家可以去Epplus的源码上看。

    //3、设置字体和单元格样式

    //设置单元格对齐方式   

    //worksheet.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;//水平居中

    //worksheet.Cells[1, 1].Style.VerticalAlignment = ExcelVerticalAlignment.Center;//垂直居中

    //worksheet.Cells[1, 4, 1, 5].Merge = true;//合并单元格

    //worksheet.Cells.Style.WrapText = true;//自动换行 


    //设置单元格字体样式

    //worksheet.Cells[1, 1].Style.Font.Bold = true;//字体为粗体

    //worksheet.Cells[1, 1].Style.Font.Color.SetColor(Color.White);//字体颜色

    //worksheet.Cells[1, 1].Style.Font.Name = "微软雅黑";//字体

    //worksheet.Cells[1, 1].Style.Font.Size = 12;//字体大小 


    //设置单元格背景样式

    //worksheet.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;

    //worksheet.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(128, 128, 128));//设置单元格背景色 


    //设置单元格边框，两种方法

    //worksheet.Cells[1, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));//设置单元格所有边框

    //worksheet.Cells[1, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;//单独设置单元格底部边框样式和颜色（上下左右均可分开设置）

    //worksheet.Cells[1, 1].Style.Border.Bottom.Color.SetColor(Color.FromArgb(191, 191, 191));　 

    //设置单元格的行高和列宽

    //worksheet.Cells.Style.ShrinkToFit = true;//单元格自动适应大小

    //worksheet.Row(1).Height = 15;//设置行高

    //worksheet.Row(1).CustomHeight = true;//自动调整行高

    //worksheet.Column(1).Width = 15;//设置列宽 


    //4、设置sheet背景

    //worksheet.View.ShowGridLines = false;//去掉sheet的网格线

    //worksheet.Cells.Style.Fill.PatternType = ExcelFillStyle.Solid;

    //worksheet.Cells.Style.Fill.BackgroundColor.SetColor(Color.LightGray);//设置背景色

    //worksheet.BackgroundImage.Image = Image.FromFile(@"firstbg.jpg");//设置背景图片 


    //5、插入图片和形状

    //插入图片

    //ExcelPicture picture = worksheet.Drawings.AddPicture("logo", Image.FromFile(@"firstbg.jpg"));//插入图片

    //picture.SetPosition(100, 100);//设置图片的位置

    //picture.SetSize(100, 100);//设置图片的大小 

    //插入形状

    //ExcelShape shape = worksheet.Drawings.AddShape("shape", eShapeStyle.Rect);//插入形状

    //shape.Font.Color = Color.Red;//设置形状的字体颜色

    //shape.Font.Size = 15;//字体大小

    //shape.Font.Bold = true;//字体粗细

    //shape.Fill.Style = eFillStyle.NoFill;//设置形状的填充样式

    //shape.Border.Fill.Style = eFillStyle.NoFill;//边框样式

    //shape.SetPosition(200, 300);//形状的位置

    //shape.SetSize(80, 30);//形状的大小

    //shape.Text = "test";//形状的内容 


    //6、超链接

    //给图片加超链接

    //ExcelPicture picture = worksheet.Drawings.AddPicture("logo", Image.FromFile(@"firstbg.jpg"), new ExcelHyperLink("http:\\www.baidu.com", UriKind.Relative)); 


    //给单元格加超链接

    //worksheet.Cells[1, 1].Hyperlink = new ExcelHyperLink("http:\\www.baidu.com", UriKind.Relative); 


    //7、隐藏sheet

    //worksheet.Hidden = eWorkSheetHidden.Hidden;//隐藏sheet

    //worksheet.Column(1).Hidden = true;//隐藏某一列

    //worksheet.Row(1).Hidden = true;//隐藏某一行 

    #endregion

    #region 创建图表
    //1、创建图表

    //ExcelChart chart = worksheet.Drawings.AddChart("chart", eChartType.ColumnClustered);//eChartType中可以选择图表类型 

    //2、选择数据

    //这一步是很关键的一步，chart.Series.Add()方法所需参数为：chart.Series.Add(Y轴数据区,X轴数据区) 

    //ExcelChartSerie serie = chart.Series.Add(worksheet.Cells[2, 3, 5, 3], worksheet.Cells[2, 1, 5, 1]);//设置图表的x轴和y轴

    //serie.HeaderAddress = worksheet.Cells[1, 3];//设置图表的图例 


    //3、设置图表样式   

    //chart.SetPosition(150, 10);//设置位置

    //chart.SetSize(500, 300);//设置大小

    //chart.Title.Text = "销量走势";//设置图表的标题

    //chart.Title.Font.Color = Color.FromArgb(89, 89, 89);//设置标题的颜色

    //chart.Title.Font.Size = 15;//标题的大小

    //chart.Title.Font.Bold = true;//标题的粗体

    //chart.Style = eChartStyle.Style15;//设置图表的样式

    //chart.Legend.Border.LineStyle = eLineStyle.Solid;

    //chart.Legend.Border.Fill.Color = Color.FromArgb(217, 217, 217);//设置图例的样式 

    #endregion

    #region 嵌入VBA代码、Excel加密锁定、属性设置、下拉框
    //1、嵌入VBA代码

    //首先将vba代码保存成txt文本格式，然后用epplus去调用这个txt文本文件即可，非常简单，当然要想vba调用成功，前提是你的vba代码是没问题的喽！

    //worksheet.CodeModule.Name = "sheet" ;
    //worksheet.CodeModule.Code = File.ReadAllText(@"VBA-Code\vba.txt"), Encoding.Default); 

    //2、Excel加密和锁定

    //对于一些不希望别人随便改的excel可以对其进行锁定和加密，这样别人只能看不能改了，除非有密码。

    //worksheet.Protection.IsProtected = true;//设置是否进行锁定

    //worksheet.Protection.SetPassword("yk");//设置密码

    //worksheet.Protection.AllowAutoFilter = false;//下面是一些锁定时权限的设置

    //worksheet.Protection.AllowDeleteColumns = false;

    //worksheet.Protection.AllowDeleteRows = false;

    //worksheet.Protection.AllowEditScenarios = false;

    //worksheet.Protection.AllowEditObject = false;

    //worksheet.Protection.AllowFormatCells = false;

    //worksheet.Protection.AllowFormatColumns = false;

    //worksheet.Protection.AllowFormatRows = false;

    //worksheet.Protection.AllowInsertColumns = false;

    //worksheet.Protection.AllowInsertHyperlinks = false;

    //worksheet.Protection.AllowInsertRows = false;

    //worksheet.Protection.AllowPivotTables = false;

    //worksheet.Protection.AllowSelectLockedCells = false;

    //worksheet.Protection.AllowSelectUnlockedCells = false;

    //worksheet.Protection.AllowSort = false; 


    //3、属性设置

    //针对整个Excel本身的一些其他设置

    //epk.Workbook.Properties.Title = "inventory";//设置excel的标题

    //epk.Workbook.Properties.Author = "mei";//作者

    //epk.Workbook.Properties.Comments = "this is a test";//备注

    //epk.Workbook.Properties.Company = "ABC";//公司 


    //4、下拉框

    //设置下拉框时首先需要设置下拉框显示的数据区域块并将其命名

    //var val = worksheet.DataValidations.AddListValidation(worksheet.Cells[7, 8].Address);//设置下拉框显示的数据区域

    //val.Formula.ExcelFormula = "=parameter";//数据区域的名称

    //val.Prompt = "下拉选择参数";//下拉提示

    //val.ShowInputMessage = true;//显示提示内容 

    #endregion

    class EPPlusHelper
    {
        private ExcelPackage excelPackage = null;
        private ExcelWorkbook workbook = null;
        private ExcelWorksheet worksheet = null;

        public override void CloseExcel()
        {
            excelPackage.Dispose();
            worksheet = null;
            workbook = null;
            excelPackage = null;
            GC.Collect();
        }

        public override void CreatExcel()
        {
            excelPackage = new ExcelPackage();
            workbook = excelPackage.Workbook;
        }

        public override void CreatSheet(string sheetName)
        {
            workbook.Worksheets.Add(sheetName);
        }

        public override int MergerCells(int firstRow, int firstCol, int lastRow, int lastCol)
        {
            worksheet.Cells[firstRow, firstCol, lastRow, lastCol].Merge = true;
            return (lastCol - firstCol) * (lastRow - firstRow);
        }

        public override string SaveAs(string fileName)
        {
            if (excelPackage == null)
            {
                throw new Exception("请先创建excel实例");
            }
            string filePath = string.Empty;
            filePath = System.Environment.CurrentDirectory;
            string datastr = DateTime.Now.ToString();
            datastr = datastr.Replace(" ", "");
            datastr = datastr.Replace("/", "");
            datastr = datastr.Replace(":", "");
            fileName = fileName + datastr + ".xlsx";
            filePath = filePath + fileName;
            using (FileStream file = new FileStream(filePath, FileMode.Create))
            {
                excelPackage.SaveAs(file);
            }
            return filePath;
        }

        public override void SetCellsStyle(int firstRow, int firstCol, int lastRow, int lastCol, bool isBold, int size)
        {
            using (var range = worksheet.Cells[firstRow, firstCol, lastRow, lastCol])
            {
                range.Style.Font.Bold = isBold;
                range.Style.Font.Size = size;
            }
        }

        public override void SetCellValue(int row, int col, string value)
        {
            if (workbook == null)
            {
                throw new Exception("请先创建excel实例");
            }
            if (worksheet == null)
            {
                throw new Exception("请先设置当前使用工作簿");
            }
            worksheet.Cells[row, col].Value = value;
        }

        private IEnumerable<string[]> ReadCsv(string fileName, char delimiter = ';')
        {
            var lines = System.IO.File.ReadAllLines(fileName, Encoding.UTF8).Select(a => a.Split(delimiter));
            return (lines);
        }

        public override void SetCurrentSheet(int sheetIndex)
        {
            if (workbook.Worksheets.Count < sheetIndex)
            {
                throw new Exception("没有这么多工作簿");
            }
            worksheet = workbook.Worksheets[sheetIndex];
        }

        private void csvToExcel(string csvFileName, string excelFileName)
        {
            string worksheetsName = "TEST";
            bool firstRowIsHeader = false;

            var format = new ExcelTextFormat();
            format.Delimiter = ',';
            format.EOL = "\r";              // DEFAULT IS "\r\n";

            using (ExcelPackage package = new ExcelPackage(new FileInfo(excelFileName)))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(worksheetsName);
                worksheet.Cells["A1"].LoadFromText(new FileInfo(csvFileName), format, OfficeOpenXml.Table.TableStyles.Medium27, firstRowIsHeader);
                package.Save();
            }
        }

        public static void Test2()
        {
            FileInfo newFile = new FileInfo(@"D:\testEPPlus.xlsx");
            if (newFile.Exists)
            {
                newFile.Delete();
                newFile = new FileInfo(@"D:\testEPPlus.xlsx");
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("test");

                worksheet.Cells.Style.WrapText = true;
                worksheet.View.ShowGridLines = false;//去掉sheet的网格线

                worksheet.Cells[1, 1].Value = "名称";
                worksheet.Cells[1, 2].Value = "价格";
                worksheet.Cells[1, 3].Value = "销量";

                worksheet.Cells[2, 1].Value = "大米";
                worksheet.Cells[2, 2].Value = 56;
                worksheet.Cells[2, 3].Value = 100;

                worksheet.Cells[3, 1].Value = "玉米";
                worksheet.Cells[3, 2].Value = 45;
                worksheet.Cells[3, 3].Value = 150;

                worksheet.Cells[4, 1].Value = "小米";
                worksheet.Cells[4, 2].Value = 38;
                worksheet.Cells[4, 3].Value = 130;

                worksheet.Cells[5, 1].Value = "糯米";
                worksheet.Cells[5, 2].Value = 22;
                worksheet.Cells[5, 3].Value = 200;

                using (ExcelRange range = worksheet.Cells[1, 1, 5, 3])
                {
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                }

                using (ExcelRange range = worksheet.Cells[1, 1, 1, 3])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Font.Color.SetColor(Color.White);
                    range.Style.Font.Name = "微软雅黑";
                    range.Style.Font.Size = 12;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(128, 128, 128));
                }

                worksheet.Cells[1, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[1, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[1, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));

                worksheet.Cells[2, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[2, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[2, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));

                worksheet.Cells[3, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[3, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[3, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));

                worksheet.Cells[4, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[4, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[4, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));

                worksheet.Cells[5, 1].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[5, 2].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));
                worksheet.Cells[5, 3].Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.FromArgb(191, 191, 191));

                ExcelChart chart = worksheet.Drawings.AddChart("chart", eChartType.ColumnClustered);

                ExcelChartSerie serie = chart.Series.Add(worksheet.Cells[2, 3, 5, 3], worksheet.Cells[2, 1, 5, 1]);
                serie.HeaderAddress = worksheet.Cells[1, 3];

                chart.SetPosition(150, 10);
                chart.SetSize(500, 300);
                chart.Title.Text = "销量走势";
                chart.Title.Font.Color = Color.FromArgb(89, 89, 89);
                chart.Title.Font.Size = 15;
                chart.Title.Font.Bold = true;
                chart.Style = eChartStyle.Style15;
                chart.Legend.Border.LineStyle = eLineStyle.Solid;
                chart.Legend.Border.Fill.Color = Color.FromArgb(217, 217, 217);

                package.Save();
            }
        }
        public static void Test()
        {
            //获取excel文件
            var file = new FileInfo(@"D:\testEPPlus.xlsx");
            DataTable dt = null;
            using (var package = new ExcelPackage(file))
            {
                //获取workbook
                ExcelWorkbook workbook = package.Workbook;
                if (workbook != null)
                {
                    if (workbook.Worksheets.Count > 0)
                    {
                        //获取workbook的第一个worksheet
                        ExcelWorksheet worksheet = workbook.Worksheets.First();
                        //将worksheet转成datatable
                        dt = WorksheetToTable(worksheet);
                    }
                }
            }

            if (dt != null)
            {
                Console.WriteLine(dt.Rows.Count);
                Console.WriteLine(dt.Columns.Count);
            }
            Console.ReadLine();
        }

        /// <summary>
        /// 将worksheet转成datatable
        /// </summary>
        /// <param name="worksheet">待处理的worksheet</param>
        /// <returns>返回处理后的datatable</returns>
        private static DataTable WorksheetToTable(ExcelWorksheet worksheet)
        {
            //获取worksheet的行数
            int rows = worksheet.Dimension.End.Row;
            //获取worksheet的列数
            int cols = worksheet.Dimension.End.Column;

            DataTable dt = new DataTable(worksheet.Name);
            DataRow dr = null;
            for (int i = 1; i <= rows; i++)
            {
                if (i > 1)
                {
                    dr = dt.Rows.Add();
                }

                for (int j = 1; j <= cols; j++)
                {
                    //默认将第一行设置为datatable的标题
                    if (i == 1)
                    {
                        dt.Columns.Add(worksheet.Cells[i, j].Value.ToString());
                    }
                    //剩下的写入datatable
                    else
                    {
                        dr[j - 1] = worksheet.Cells[i, j].Value.ToString();
                    }
                }
            }
            return dt;
        }
    }
}
